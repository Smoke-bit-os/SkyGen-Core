## Horse Deathnerite
execute as @e[type=horse] at @s if entity @s[hasitem={item=true_dn:deathnerite_horse_armor,location=slot.armor}] run tag @s add "true_armor|true_dn:deathnerite_horse_armor"
execute as @e[type=horse] at @s unless entity @s[hasitem=[{item=true_dn:deathnerite_horse_armor,location=slot.armor}]] run tag @s remove "true_armor|true_dn:deathnerite_horse_armor"

execute as @e[type=horse,tag="true_armor|true_dn:deathnerite_horse_armor"] at @s run replaceitem entity @s slot.weapon.offhand 0 true_dn:deathnerite_horse_armor
# execute as @e[type=horse,tag=true_armor|true_dn:deathnerite_horse_armor] at @s run effect @s resistance 1 3 true

## Horse Parcanite
execute as @e[type=horse] at @s if entity @s[hasitem={location=slot.armor, item=true_dn:parcanite_horse_armor}] run tag @s add "true_armor|true_dn:parcanite_horse_armor"
execute as @e[type=horse] at @s unless entity @s[hasitem=[{location=slot.armor, item=true_dn:parcanite_horse_armor}]] run tag @s remove "true_armor|true_dn:parcanite_horse_armor"

execute as @e[type=horse,tag="true_armor|true_dn:parcanite_horse_armor"] at @s run replaceitem entity @s slot.weapon.offhand 0 true_dn:parcanite_horse_armor
# execute as @e[type=horse,tag=true_armor|true_dn:parcanite_armor] at @s run effect @s resistance 1 3 true

execute as @e[type=horse] at @s unless entity @s[tag="true_armor|true_dn:deathnerite_horse_armor"] unless entity @s[tag="true_armor|true_dn:parcanite_horse_armor"] run replaceitem entity @s slot.weapon.offhand 0 air

## Nautilus Deathnerite
execute as @e[type=nautilus] at @s if entity @s[hasitem={item=true_dn:deathnerite_nautilus_armor,location=slot.armor.body}] run tag @s add "true_armor|true_dn:deathnerite_nautilus_armor"
execute as @e[type=nautilus] at @s unless entity @s[hasitem={item=true_dn:deathnerite_nautilus_armor,location=slot.armor.body}] run tag @s remove "true_armor|true_dn:deathnerite_nautilus_armor"

## Nautilus Parcanite
execute as @e[type=nautilus] at @s if entity @s[hasitem={item=true_dn:parcanite_nautilus_armor,location=slot.armor.body}] run tag @s add "true_armor|true_dn:parcanite_nautilus_armor"
execute as @e[type=nautilus] at @s unless entity @s[hasitem={item=true_dn:parcanite_nautilus_armor,location=slot.armor.body}] run tag @s remove "true_armor|true_dn:parcanite_nautilus_armor"