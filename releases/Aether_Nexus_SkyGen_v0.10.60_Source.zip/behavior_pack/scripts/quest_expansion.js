// v0.10.52 Quest Codex. The 500 new contracts are assigned through the
// dedicated Ascended/Weekly claim paths, not the original legacy Daily board.
// Owner-approved monetary payouts use a separate, journaled claim handler. Stable IDs 500-999 must never be reordered.
// Every contract combines two independently verified actions. No quest differs
// from another only by ID, quantity, XP, or rank.
const PRIMARY = [
  {key:'blocks',label:'Mine blocks on your plot or at the mine',need:16},
  {key:'harvests',label:'Harvest output from your private generators',need:6},
  {key:'crops',label:'Harvest mature crops on your plot',need:8},
  {key:'kills',label:'Defeat hostile mobs',need:5},
  {key:'build',label:'Place building blocks on your plot',need:12},
  {key:'visits',label:'Visit different Aether Nexus districts',need:2},
  {key:'sold',label:'Sell ordinary items through the shops',need:24},
  {key:'public',label:'Mine resources at the community mine',need:14},
  {key:'placements',label:'Install a private generator core on your plot',need:1},
  {key:'build',subject:'minecraft:cobblestone',label:'Build with cobblestone on your plot',need:6}
];
const ZONES = [
  ['Northwest District','-1,-1'],['Northern District','0,-1'],['Northeast District','1,-1'],
  ['Western District','-1,0'],['Central Citadel','0,0'],['Eastern District','1,0'],
  ['Southwest District','-1,1'],['Southern District','0,1'],['Southeast District','1,1']
];
const PUBLIC = [
  ['Oak Logs','minecraft:oak_log'],['Coal Ore','minecraft:coal_ore'],
  ['Cobblestone','minecraft:cobblestone'],['Dirt','minecraft:dirt']
];
const CROPS = [
  ['Wheat','minecraft:wheat'],['Carrots','minecraft:carrots'],
  ['Potatoes','minecraft:potatoes'],['Beetroot','minecraft:beetroot']
];
// All 33 entries are items sellable through the current Server/Food shops.
const SALE_IDS = [
  'minecraft:cobblestone','minecraft:oak_log','minecraft:iron_ingot','minecraft:diamond',
  'minecraft:stone','minecraft:dirt','minecraft:gravel','minecraft:sand','minecraft:clay_ball',
  'minecraft:spruce_log','minecraft:birch_log','minecraft:cherry_log','minecraft:copper_ingot',
  'minecraft:coal','minecraft:gold_ingot','minecraft:redstone','minecraft:lapis_lazuli',
  'minecraft:emerald','minecraft:quartz','minecraft:netherrack','minecraft:soul_sand',
  'minecraft:blackstone','minecraft:glowstone_dust','minecraft:magma_cream','minecraft:obsidian',
  'minecraft:prismarine','minecraft:end_stone','minecraft:sculk','minecraft:apple',
  'minecraft:bread','minecraft:baked_potato','minecraft:carrot','minecraft:potato'
];
const SECONDARY = [
  ...ZONES.map(([label,subject])=>({key:'visits',subject,label:'Visit '+label,need:1})),
  ...PUBLIC.map(([label,subject])=>({key:'public',subject,label:'Mine '+label+' at the public mine',need:6})),
  ...CROPS.map(([label,subject])=>({key:'crops',subject,label:'Harvest mature '+label,need:4})),
  ...SALE_IDS.map(subject=>({key:'sold',subject,label:'Sell '+subject.slice(10).replaceAll('_',' '),need:8}))
];
if(SECONDARY.length!==50 || PRIMARY.length!==10)throw Error('Quest catalog shape requires review');
// The 50 formerly duplicated Farming slots become 50 genuinely different
// two-part, early-rank expeditions. Every target is available in the existing
// public mine, nine city districts, or ordinary crop farms.
export const LEGACY_EXPEDITIONS = Array.from({length:50},(_,i)=>{
  const publicSource=PUBLIC[i<36?Math.floor(i/9):Math.floor((i-36)/4)];
  const secondary=i<36
    ? {key:'visits',subject:ZONES[i%9][1],label:'Visit '+ZONES[i%9][0],need:1}
    : {key:'crops',subject:CROPS[(i-36)%4][1],label:'Harvest mature '+CROPS[(i-36)%4][0],need:2};
  return Object.freeze({group:'Sky Realm Expeditions',key:'public',
    primarySubject:publicSource[1],need:6,
    label:'Mine '+publicSource[0]+' at the public mine AND '+secondary.label,
    secondary:Object.freeze(secondary)});
});
const DIFFICULTY = ['easy','normal','hard','elite'];
export const NEW_QUESTS = Array.from({length:500},(_,i)=>{
  const primary=PRIMARY[Math.floor(i/50)],secondary=SECONDARY[i%50];
  const rank=51+Math.floor(i*949/499); // exactly first unlock 51, last unlock 1000
  return Object.freeze({
    id:500+i,rank,group:'Ascended Contracts',key:primary.key,
    primarySubject:primary.subject,
    label:primary.label+' AND '+secondary.label,
    need:primary.need,secondary:Object.freeze({...secondary}),
    difficulty:DIFFICULTY[i%4],credits:null,xp:null,
    pendingEconomy:true // legacy Daily-board fail-closed guard; independent contract path pays
  });
});
const RATES = {easy:5n,normal:10n,hard:15n,elite:25n};
export function percentageQuestXP(nextRankCost,difficulty){
  if(typeof nextRankCost!=='bigint'||nextRankCost<0n)throw Error('XP cost must be a nonnegative BigInt');
  const percent=RATES[difficulty];if(percent===undefined)throw Error('Unknown quest difficulty');
  return ((nextRankCost*percent+99n)/100n).toString(); // round UP; exact arithmetic
}
export const QUEST_OBJECTIVE_KEYS=Object.freeze(NEW_QUESTS.map(q=>
  [q.key,q.primarySubject??'*',q.secondary.key,q.secondary.subject].join('|')));
