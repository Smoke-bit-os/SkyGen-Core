import {NEW_QUESTS,LEGACY_EXPEDITIONS} from './quest_expansion.js';
const farming = ['Farming', 'crops', 'Harvest mature wheat, carrots, potatoes or beetroot on your plot', 8, 4];
const expeditionSlot = ['Sky Realm Expeditions', 'public', 'Complete a public-mine and district/crop expedition', 6, 0];
const FORMER_ENCHANTING_SLOT = 8;
const QUEST_BOARD_RULES = 42;
// New contracts are catalog-only until their approved Credit/Orbit payouts
// and exactly-once settlement integration are implemented.
export const ASCENDED_CONTRACTS_ENABLED = false;

// Stable IDs double as the persisted catalog keys. Keep these rows in order.
const templates = [
    ['Mining', 'blocks', 'Mine blocks in a SkyGen mine or on your plot', 20, 5],
    ['Generators', 'harvests', 'Harvest regenerated blocks from your generators', 5, 2],
    farming,
    ['Combat', 'kills', 'Defeat hostile mobs', 4, 2],
    ['Building', 'build', 'Place blocks on your own plot', 10, 5],
    ['Exploration', 'visits', 'Travel between Aether Nexus districts', 1, 1],
    ['Trading', 'sold', 'Sell items through the Server Shop', 16, 4],
    ['Fishing', 'fish', 'Turn in raw cod, salmon, tropical fish or pufferfish', 4, 2],
    expeditionSlot,
    ['Resource Collection', 'public', 'Collect resources by mining at the community mine', 12, 4]
];
const rewards = [
    [1000, 3000, 50, 150],
    [3000, 8000, 150, 300],
    [8000, 20000, 300, 600],
    [20000, 50000, 600, 1000],
    [50000, 125000, 1000, 1800],
    [125000, 300000, 1800, 3000],
    [300000, 650000, 3000, 5000],
    [650000, 1250000, 5000, 8000],
    [1250000, 2500000, 8000, 12000],
    [2500000, 5000000, 12000, 20000]
];

const EXISTING_QUESTS = Array.from({length: 500}, (_, index) => {
    const rank = Math.floor(index / templates.length) + 1;
    const [group, key, label, base, step] = templates[index % templates.length];
    const [lowCredits, highCredits, lowXp, highXp] = rewards[Math.floor((rank - 1) / 5)];
    const position = ((rank - 1) % 5) / 4;
    const definition={
        id: index, rank, group, key, label, need: base + (rank - 1) * step,
        credits: Math.round(lowCredits + (highCredits - lowCredits) * position),
        xp: Math.round(lowXp + (highXp - lowXp) * position)
    };
    if(index%templates.length===FORMER_ENCHANTING_SLOT){
        Object.assign(definition,LEGACY_EXPEDITIONS[rank-1]);
    }
    return definition;
});

export const QUESTS = Object.freeze([...EXISTING_QUESTS,...NEW_QUESTS]);

const legacy = [
    {id: -1, group: 'Legacy Mining', key: 'blocks', label: 'Mine plot or community mine blocks', need: 50, credits: 1500, xp: 100},
    {id: -2, group: 'Legacy Generators', key: 'harvests', label: 'Harvest generator blocks', need: 10, credits: 3500, xp: 250},
    {id: -3, group: 'Legacy Generators', key: 'placements', label: 'Place a generator core', need: 1, credits: 2000, xp: 250}
];
export function questDefinition(id) {
    return id < 0 ? legacy[-id - 1] : QUESTS[id];
}
function eligibleCount(rank) {
    // Explicit release gate: the new 500 definitions are not activated before
    // monetary payout rules and exactly-once claim transactions are approved.
    return Math.max(1, Math.min(50, rank)) * templates.length;
}
function mineRequired(quest) {
    return quest.key === 'visits' || quest.key === 'public';
}

function assign(state, rank, mineReady) {
    if (mineReady) {
        while (state.parked.length && state.active.length < 3) state.active.push(state.parked.shift());
    }
    const eligible = eligibleCount(rank);
    const seen = new Set(state.seen);
    // 503 is prime and coprime to every unlocked catalog size (10 to 500).
    for (let offset = 0; state.active.length < 3 && offset < eligible; offset++) {
        const id = (state.start + offset * 503) % eligible;
        if (seen.has(id) || (!mineReady && mineRequired(QUESTS[id]))) continue;
        state.active.push({id, progress: 0, assigned: state.day});
        state.seen.push(id);
        seen.add(id);
    }
}

export function questState(profile, playerId, day, mineReady = true) {
    let state = profile.questBoard;
    if (state && (state.rules ?? 0) < QUEST_BOARD_RULES) {
        const oldRules=state.rules ?? 0;
        for (const entry of [...(state.active??[]),...(state.parked??[])]) {
            if(!Number.isSafeInteger(entry.id))throw Error('Malformed quest ID requires operator review');
            const isReplaced=entry.id>=0&&entry.id<500&&entry.id%templates.length===FORMER_ENCHANTING_SLOT;
            const hadFishSnapshot=oldRules<40&&questDefinition(entry.id).key==='fish';
            if(hadFishSnapshot)entry.progress=0;
            if(isReplaced){
                // Pre-v41 entries were Enchanting rather than Farming; never
                // convert that older unrelated progress into a free reward.
                const previous=oldRules<41?0:Math.max(0,Number(entry.progress)||0);
                const oldNeed=8+Math.floor(entry.id/templates.length)*4;
                const newNeed=questDefinition(entry.id).need;
                entry.progress=Math.min(newNeed,Math.ceil(Math.min(previous,oldNeed)*newNeed/oldNeed));
                // An already completed Farming assignment must stay claimable
                // despite gaining a second expedition condition. Incomplete
                // progress is credited toward the primary objective only.
                entry.secondaryProgress=previous>=oldNeed?questDefinition(entry.id).secondary.need:0;
                // IDs, 'seen', assignment date, and claim journal are unchanged.
            }
        }
        state.rules=QUEST_BOARD_RULES; // makes migration idempotent
    }
    if (!state || state.day !== day) {
        let seed = 0;
        for (const char of playerId + day) seed = (Math.imul(seed, 31) + char.charCodeAt(0)) >>> 0;
        const active = (state?.active ?? []).filter(entry => entry.progress >= questDefinition(entry.id).need);
        const seen = active.map(entry => entry.id);
        state = {day, start: seed, active, seen, parked: [], rules: QUEST_BOARD_RULES};
        // Preserve the previous daily board for players already mid-rotation.
        if (profile.daily?.day === day && !profile.questBoard) {
            for (const quest of legacy) {
                if (!profile.daily.claimed?.includes(quest.key)) {
                    state.active.push({id: quest.id, assigned: day, progress: Math.min(quest.need, profile.daily[quest.key] || 0)});
                }
            }
        }
        profile.questBoard = state;
    }
    state.parked ??= [];
    if (!mineReady) {
        state.active = state.active.filter(entry => {
            const quest = questDefinition(entry.id);
            if (!mineRequired(quest) || entry.progress >= quest.need) return true;
            state.parked.push(entry);
            return false;
        });
    }
    if (state.active.length < 3) assign(state, profile.rank, mineReady);
    return state;
}

export function recordQuestProgress(state, keys, amount = 1, snapshot = false, subject = undefined) {
    let changed = false;
    for (const entry of state.active) {
        const quest = questDefinition(entry.id);
        if(keys.includes(quest.key)&&(!quest.primarySubject||quest.primarySubject===subject)){
            const progress=Math.min(quest.need,snapshot?Math.max(entry.progress,amount):entry.progress+amount);
            if(progress!==entry.progress){entry.progress=progress;changed=true;}
        }
        // Two-part contracts count the second qualifying action separately;
        // an unrelated item/zone must never advance a targeted objective.
        if(quest.secondary&&keys.includes(quest.secondary.key)&&quest.secondary.subject===subject&&!snapshot){
            const next=Math.min(quest.secondary.need,(entry.secondaryProgress??0)+amount);
            if(next!==entry.secondaryProgress){entry.secondaryProgress=next;changed=true;}
        }
    }
    return changed;
}

export function completeQuest(state, selected, rank, mineReady = true) {
    const index = state.active.findIndex(entry => {
        if(entry.id!==selected.id||entry.assigned!==selected.assigned)return false;
        const quest=questDefinition(entry.id);
        if(quest.pendingEconomy)return false; // never pay unapproved contracts
        return entry.progress>=quest.need&&(!quest.secondary||(entry.secondaryProgress??0)>=quest.secondary.need);
    });
    if (index < 0) return false;
    state.active.splice(index, 1);
    assign(state, rank, mineReady);
    return true;
}
