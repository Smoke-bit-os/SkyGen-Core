import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { system, world } from '@minecraft/server';
import { SIDEBAR_PANEL, SIDEBAR_OBJECTIVES, ensureSidebarObjectives } from '../../numeric_scores.js';

// 2.0.0 form controls require options objects, not the legacy positional values.
// All form callbacks re-check operator privileges before mutating public holograms.
const colorNames = ['§4Dark Red§r','§mMahogany§r','§cRed§r','§6Gold§r','§pDandelion§r','§gHoney§r','§eYellow§r','§2Dark Green§r','§qForest Green§r','§aLime§r','§bAqua§r','§3Dark Aqua§r','§sCadet Blue§r','§tTeal§r','§1Dark Blue§r','§9Grape§r','§dLight Purple§r','§uLavender§r','§5Dark Purple§r','§nBrown§r','§fWhite§r','§hOff White§r','§7Gray§r','§8Dark Gray§r','§jCharcoal§r','§0Black§r'];
const colorCodes = ['§4','§m','§c','§6','§p','§g','§e','§2','§q','§a','§b','§3','§s','§t','§1','§9','§d','§u','§5','§n','§f','§h','§7','§8','§j','§0'];
const OFFSET=0.58;
const HOLOGRAMS_PER_PAGE=12;

function isOperator(p){
 try { if (p?.typeId!=='minecraft:player') return false; if (typeof p.isOp==='function' && p.isOp()===true) return true; } catch {}
 try { return p?.playerPermissionLevel===2; } catch { return false; }
}
function allowed(p){
 if (isOperator(p)) return true;
 try { p.sendMessage('§cRealm operator permission is required to edit floating text.'); } catch {}
 return false;
}
function tell(p,message){try{p.sendMessage(message);}catch{}}
function problem(p,reason){
 console.warn('[MonkeyChan] '+String(reason));
 tell(p,'§cFloating text: '+String(reason).slice(0,170));
}
function show(p,form,done,attempt=0){
 system.runTimeout(()=>{
  if(p.isValid===false||!allowed(p))return;
  try{form.show(p).then(response=>{
   if(response.canceled){
    if(attempt<4&&String(response.cancelationReason||'').includes('UserBusy'))show(p,form,done,attempt+1);
    return;
   }
   if(allowed(p))done(response);
  }).catch(e=>problem(p,e));}catch(e){problem(p,e);}
 },attempt?20:8);
}
function position(value,p){
 const parts=String(value??'').trim().split(/\s+/).map(Number);
 if (parts.length!==3 || !parts.every(Number.isFinite)) throw Error('Enter three numeric coordinates: X Y Z.');
 const [x,y,z]=parts;
 if (Math.max(Math.abs(x),Math.abs(z))>29999984 || y < -64 || y > 320) throw Error('Coordinates are outside the valid world range.');
 return {x,y:y-OFFSET,z};
}
function defaultPosition(point){return [point.x.toFixed(2),point.y.toFixed(2),point.z.toFixed(2)].join(' ');}
function displayText(value){return (String(value??'').trim()||'Floating Text').replace(/\\n/g,'\n').slice(0,4096);}
function ensureEntity(entity){if (!entity?.isValid) throw Error('That floating text is no longer loaded. Reopen the list.');}
function dimensions(){return [world.getDimension('overworld'),world.getDimension('nether'),world.getDimension('the_end')];}
function getInfo(entity){
 try {const value=JSON.parse(entity.getDynamicProperty('scoreboardinfo')||'null');
  if (Array.isArray(value) && (value.length>=7&&value.length<=9) && typeof value[0]==='string')return value;
 } catch{}
 return null;
}
function validIndex(i,max,backup=0){return Number.isInteger(i)&&i>=0&&i<max?i:backup;}
function validColors(info,offset,backup){return validIndex(colorCodes.indexOf(info?.[offset]),colorCodes.length,backup);}
export function showMenu(viewer){
 if(!allowed(viewer))return;
 const form=new ActionFormData().title('Floating Text & Scoreboards')
  .body('Create text, link an existing scoreboard, or show a player’s Personal Sidebar stats.')
  .button('Create Floating Text','textures/ui/book_addtextpage_default')
  .button('Edit Loaded Texts','textures/ui/icon_book_writable')
  .button('Create Floating Scoreboard','textures/ui/book_addpicture_default')
  .button('Edit or Delete Loaded Scoreboard')
  .button('Exit');
 show(viewer,form,({selection})=>{
  const back=()=>showMenu(viewer);
  if(selection===0)newText(viewer);
  if(selection===1)showTexts(viewer,false,back);
  if(selection===2)createScoreboardForm(viewer,back);
  if(selection===3)showTexts(viewer,true,back);
 });
}
function newText(viewer){
 const form=new ModalFormData().title('New Floating Text')
  .textField('Text to Display (\\n for a new line)','Text',{defaultValue:'Floating Text'})
  .textField('Text Position','X Y Z',{defaultValue:defaultPosition(viewer.location)});
 show(viewer,form,({formValues:v})=>{
  const spot=position(v[1],viewer);
  // Explicit spawnEvent avoids relying on legacy event notation inside the type ID.
  const entity=viewer.dimension.spawnEntity('monkey:floatingtext',spot,{spawnEvent:'text',initialPersistence:true});
  entity.nameTag=displayText(v[0]);
  tell(viewer,'§aFloating text created.');
 });
}
function createScoreboardForm(viewer,back,existing=null){
 ensureSidebarObjectives();
 const objectives=world.scoreboard.getObjectives();
 const sidebarIds=new Set(SIDEBAR_OBJECTIVES.map(([,id])=>id));
 objectives.sort((a,b)=>Number(sidebarIds.has(b.id))-Number(sidebarIds.has(a.id)));
 const ids=[SIDEBAR_PANEL,...objectives.map(x=>x.id)];
 const labels=['Personal Sidebar — all stats',...objectives.map(x=>x.displayName+' ['+x.id+']')];
 const info=existing?getInfo(existing):null;

 const pos=existing?existing.location:viewer.location;
 const inputPos=existing?{x:pos.x,y:pos.y+OFFSET,z:pos.z}:pos;
 const form=new ModalFormData().title(existing?'Edit Floating Scoreboard':'New Floating Scoreboard')
  .dropdown('Score source',labels,{defaultValueIndex:validIndex(ids.indexOf(info?.[0]),ids.length)})
  .textField('Scoreboard Position','X Y Z',{defaultValue:defaultPosition(inputPos)})
  .dropdown('Score Order',['ascending','descending'],{defaultValueIndex:validIndex(info?.[1],2,1)})
  .toggle('Number the Players',{defaultValue:info?!!info[2]:true})
  .dropdown('Number Color',colorNames,{defaultValueIndex:validColors(info,3,3)})
  .dropdown('Player Color',colorNames,{defaultValueIndex:validColors(info,4,20)})
  .dropdown('Score Color',colorNames,{defaultValueIndex:validColors(info,5,2)})
  .slider('Number of Players (1–15)',1,15,{valueStep:1,defaultValue:Math.min(15,Math.max(1,Number(info?.[6])||8))})
  .textField('Gamertag (blank: yourself for all stats, leaderboard for one stat)','Exact gamertag',{defaultValue:info?.[7]??''});
 if(existing)form.toggle('§cDelete this scoreboard?§r',{defaultValue:false});
 show(viewer,form,({formValues:v})=>{
  if(existing&&v[9])return confirmDelete(viewer,existing,back);
  const spot=position(v[1],viewer);
  const objectiveId=ids[v[0]];
  if(objectiveId!==SIDEBAR_PANEL&&(!objectiveId||!world.scoreboard.getObjective(objectiveId)))
   throw Error('Scoreboard objective no longer available.');
  const entered=String(v[8]??'').trim();
  const participant=objectiveId===SIDEBAR_PANEL&&!entered?viewer.name:entered;
  if(participant.length>64||/[§\x00-\x1f]/.test(participant))throw Error('Invalid player gamertag.');
  const latest=existing?getInfo(existing):null;
  const sameTarget=participant&&participant.toLowerCase()===String(info?.[7]??'').toLowerCase();
  const priorLink=sameTarget?latest?.[8]:undefined;
  const online=participant&&!priorLink?world.getAllPlayers().find(player=>player.name.toLowerCase()===participant.toLowerCase()):undefined;
  const link=priorLink??(online?{playerId:online.id}:undefined);
  const settings=JSON.stringify([objectiveId,v[2],v[3],colorCodes[v[4]],colorCodes[v[5]],colorCodes[v[6]],v[7],
   priorLink?latest[7]:online?.name??participant,link]);
  if(existing){
   ensureEntity(existing);
   const prior=existing.getDynamicProperty('scoreboardinfo');
   try{
    existing.setDynamicProperty('scoreboardinfo',settings);
    existing.teleport(spot);
   }catch(err){existing.setDynamicProperty('scoreboardinfo',prior);throw err}
   tell(viewer,'§aFloating scoreboard updated.');
   return back();
  }
  let entity;
  try{
   entity=viewer.dimension.spawnEntity('monkey:floatingtext',spot,{spawnEvent:'scoreboard',initialPersistence:true});
   entity.setDynamicProperty('scoreboardinfo',settings);
   entity.nameTag='Loading scoreboard...';
  }catch(err){
   try{entity?.remove();}catch{}
   throw err;
  }
  tell(viewer,'§aFloating scoreboard created.');
  back();
 });
}
function showTexts(viewer,scoreboards,back){
 const found=[];
 for(const dimension of dimensions()){
  try{for(const entity of dimension.getEntities({type:'monkey:floatingtext',families:['inanimate']})){
   if(entity.matches({families:['scoreboard']})===scoreboards)found.push(entity);
  }}catch(err){console.warn('[MonkeyChan] Loaded text scan: '+err);}
 }
 if(!found.length){tell(viewer,'§eNo matching holograms are loaded. Visit their chunk first.');return back();}
 function page(index){
  const start=index*HOLOGRAMS_PER_PAGE;
  const last=Math.ceil(found.length/HOLOGRAMS_PER_PAGE)-1;
  const form=new ActionFormData().title(scoreboards?'Edit Loaded Scoreboards':'Edit Loaded Texts')
   .body('§7Loaded chunks only. Page '+(index+1)+' of '+(last+1)+'.');
  const actions=[];
  for(const entity of found.slice(start,start+HOLOGRAMS_PER_PAGE)){
   const title=entity.isValid?String(entity.nameTag||'Unnamed').split('\n')[0].slice(0,55):'Unloaded hologram';
   const at=entity.isValid?'\n§7'+entity.dimension.id.replace('minecraft:','')+' '+defaultPosition(entity.location):'';
   form.button(title+at);
   actions.push(()=>{
    ensureEntity(entity);
    if(scoreboards)createScoreboardForm(viewer,back,entity);
    else editText(viewer,entity);
   });
  }
  if(index>0){form.button('Previous Page');actions.push(()=>page(index-1));}
  if(index<last){form.button('Next Page');actions.push(()=>page(index+1));}
  form.button('Back').button('Exit');
  actions.push(back);
  show(viewer,form,({selection})=>actions[selection]?.());
 }
 page(0);
}
function editText(viewer,entity){
 ensureEntity(entity);
 const p=entity.location;
 const form=new ModalFormData().title('Edit Floating Text')
  .textField('Text to Display (\\n for a new line)','Text',{defaultValue:String(entity.nameTag||'').replace(/\n/g,'\\n')})
  .textField('Text Position','X Y Z',{defaultValue:defaultPosition({x:p.x,y:p.y+OFFSET,z:p.z})})
  .toggle('§cDelete this text?§r',{defaultValue:false});
 show(viewer,form,({formValues:v})=>{
  ensureEntity(entity);
  if(v[2]){confirmDelete(viewer,entity);return;}
  const spot=position(v[1],viewer);
  entity.nameTag=displayText(v[0]);
  entity.teleport(spot);
  tell(viewer,'§aFloating text updated.');
 });
}
function confirmDelete(viewer,entity,back){
 const form=new MessageFormData().title('Delete Floating Text?')
  .body('§cThis permanently deletes this hologram. Your other holograms and scoreboard objectives are not affected.')
  .button1('Cancel').button2('Delete');
 show(viewer,form,({selection})=>{
  if(selection!==1)return;
  ensureEntity(entity);entity.remove();tell(viewer,'§eHologram deleted.');back?.();
 });
}
