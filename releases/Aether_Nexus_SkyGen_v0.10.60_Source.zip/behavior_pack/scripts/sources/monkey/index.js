import { ScoreboardIdentityType, system, world } from '@minecraft/server';
import { showMenu } from './ui.js';
import { readSidebarStats } from '../../main.js';
import { SIDEBAR_OBJECTIVES, SIDEBAR_PANEL, sidebarStats, sidebarLines } from '../../numeric_scores.js';


// Resolve dimensions only when an operator opens the menu or a world-loaded tick runs.
// @minecraft/server 2.x prohibits this world access during early module execution.
export function getDimensions() {
    return [world.getDimension('overworld'), world.getDimension('nether'), world.getDimension('the_end')];
}


// Use a custom item component so the menu activates reliably on current Bedrock.
// Keep the vanilla itemUse listener as a fallback for existing menu items.
// Some engines trigger both; deduplicate openings to avoid a "UI already open" error.
const lastMenuOpen = new Map();
function openFloatingMenu(source) {
    if (!source || source.typeId !== 'minecraft:player') return;
    const isOperator = (() => {
        try { if (typeof source.isOp === 'function' && source.isOp()) return true; } catch {}
        try { return source.playerPermissionLevel === 2; } catch { return false; }
    })();
    if (!isOperator) {
        source.sendMessage('§cOnly Realm operators can use Floating Text & Leaderboards.');
        return;
    }
    const tick = system.currentTick;
    const previous = lastMenuOpen.get(source.id);
    if (previous !== undefined && tick - previous < 10) return;
    lastMenuOpen.set(source.id, tick);
    system.run(() => showMenu(source));
}
system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
    itemComponentRegistry.registerCustomComponent('monkey:open_menu', {
        onUse({ source }) { openFloatingMenu(source); }
    });
});
world.afterEvents.itemUse.subscribe(({ itemStack, source }) => {
    if (itemStack?.typeId === 'monkey:textmenu') openFloatingMenu(source);
});


const f = { 'commands.scoreboard.players.offlinePlayerName': 'Offline Player' };
const rankId = SIDEBAR_OBJECTIVES.find(([key]) => key === 'rank')[1];
const sidebarIds = new Set(SIDEBAR_OBJECTIVES.map(([, id]) => id));
const isPlayerScore = ({ participant }) => participant.type === ScoreboardIdentityType.Player;

function playerScoreboardId(player) {
    try { return player.scoreboardIdentity?.id; } catch { return undefined; }
}

function resolvePlayer(entity, info, getRows, online) {
    const name = info[7];
    const saved = info[8];
    const target = name.toLowerCase();
    const player = saved?.playerId !== undefined ? online.byId.get(saved.playerId)
        : saved?.scoreboardId !== undefined ? online.byScoreboardId.get(saved.scoreboardId)
        : online.byName.get(target);
    const scoreboardId = (player && playerScoreboardId(player)) ?? saved?.scoreboardId;
    let row;
    if (!player && scoreboardId !== undefined && !online.byScoreboardId.has(scoreboardId)) {
        row = getRows().find(entry => isPlayerScore(entry) && entry.participant.id === scoreboardId);
    } else if (!player && !saved) {
        row = getRows().find(entry => isPlayerScore(entry) && entry.participant.displayName.toLowerCase() === target);
    }
    const link = {
        playerId: player?.id ?? saved?.playerId,
        scoreboardId: scoreboardId ?? row?.participant.id
    };
    const displayName = player?.name ?? (saved?.playerId === undefined ? row?.participant.displayName : undefined) ?? name;
    if ((player || row) && (link.playerId !== saved?.playerId || link.scoreboardId !== saved?.scoreboardId || displayName !== name)) {
        info[7] = displayName;
        info[8] = link;
        entity.setDynamicProperty('scoreboardinfo', JSON.stringify(info));
    }
    return { player, row, displayName, linked: Boolean(saved || player || row) };
}

function sidebarLabel(target, scoresFor, sidebarFor) {
    const header = '§b§lPERSONAL SIDEBAR§r\n§f' + target.displayName;
    if (target.player) return header + '\n' + sidebarLines(sidebarFor(target.player)).join('\n');
    if (!target.row) return header + '\n§7Player stats unavailable';
    const values = {};
    for (const [key, id] of SIDEBAR_OBJECTIVES) {
        const value = scoresFor(id)?.objective.getScore(target.row.participant);
        if (value !== undefined) values[key] = value;
    }
    if (['credits', 'orbits', 'xp', 'rank', 'plot'].some(key => values[key] === undefined)) {
        return header + '\n§7Waiting for sidebar stats';
    }
    // Historic players may have the original five objectives only.
    const stats = sidebarStats({...values, plot: values.plot - 1});
    return header + '\n' + sidebarLines({...stats, ...values}).join('\n');
}

// Reuse one scoreboard snapshot per objective across all loaded holograms.
// Skip player/profile/scoreboard work entirely when no scoreboard hologram is
// loaded in any dimension. Keep the same 20-tick refresh for active holograms.
function refreshFloatingScoreboards() {
    let dimensions;
    try { dimensions = getDimensions(); }
    catch (err) { console.warn('[MonkeyChan] scoreboard initialization: ' + err); return; }
    const activeDisplays = [];
    for (const dimension of dimensions) {
        try {
            const entities = dimension.getEntities({ type: 'monkey:floatingtext', families: ['scoreboard'] });
            if (entities.length) activeDisplays.push(entities);
        } catch (err) { console.warn('[MonkeyChan] floating-text query: ' + err); }
    }
    if (!activeDisplays.length) return;
    let scoreboard, players;
    try { scoreboard = world.scoreboard; players = world.getAllPlayers(); }
    catch (err) { console.warn('[MonkeyChan] scoreboard initialization: ' + err); return; }
    const online = {byId: new Map(), byName: new Map(), byScoreboardId: new Map()};
    for (const player of players) {
        online.byId.set(player.id, player);
        online.byName.set(player.name.toLowerCase(), player);
        const id = playerScoreboardId(player);
        if (id !== undefined) online.byScoreboardId.set(id, player);
    }
    const cache = new Map();
    // A player can be referenced by several loaded Personal Sidebar holograms.
    // Keep one per-player snapshot for this refresh only; no persistent stale cache.
    const sidebarCache = new Map();
    function sidebarFor(player) {
        if (!sidebarCache.has(player.id)) sidebarCache.set(player.id, readSidebarStats(player));
        return sidebarCache.get(player.id);
    }
    function scoresFor(id) {
        if (!cache.has(id)) {
            const objective = scoreboard.getObjective(id);
            let entries;
            const rows = () => entries ??= objective.getScores()
                .filter(({ participant }) => !participant.displayName.startsWith('#'));
            cache.set(id, objective ? {objective, rows} : null);
        }
        return cache.get(id);
    }
    for (const entities of activeDisplays) {
        for (const entity of entities) {
            try {
                let info;
                try { info = JSON.parse(entity.getDynamicProperty('scoreboardinfo') ?? 'null'); }
                catch { continue; }
                if (!Array.isArray(info) || typeof info[0] !== 'string') continue;
                if (info[0] === SIDEBAR_PANEL) {
                    if (typeof info[7] !== 'string' || !info[7]) continue;
                    const target = resolvePlayer(entity, info, () => scoresFor(rankId)?.rows() ?? [], online);
                    const label = sidebarLabel(target, scoresFor, sidebarFor);
                    if (entity.nameTag !== label) entity.nameTag = label;
                    continue;
                }
                const data = scoresFor(info[0]);
                if (!data) continue; // An objective may be restored later.
                const name = typeof info[7] === 'string' ? info[7] : '';
                let selected;
                let unavailableName = name;
                if (name) {
                    const target = resolvePlayer(entity, info, data.rows, online);
                    unavailableName = target.displayName;
                    if (target.player) {
                        const score = data.objective.getScore(target.player);
                        selected = score === undefined ? [] : [{participant: {displayName: target.displayName}, score}];
                    } else if (target.linked) {
                        selected = target.row ? [{participant: {displayName: target.displayName}, score: target.row.score}] : [];
                    } else {
                        const matches = data.rows().filter(({participant}) =>
                            participant.displayName.toLowerCase() === name.toLowerCase());
                        selected = matches.sort((a, b) => info[1] ? b.score - a.score : a.score - b.score);
                    }
                } else if (sidebarIds.has(info[0])) {
                    selected = data.skygenLeaderboard ??= data.rows().filter(isPlayerScore).sort((a, b) => b.score - a.score);
                } else {
                    const order = info[1] ? 'descending' : 'ascending';
                    selected = data[order] ??= [...data.rows()].sort((a, b) => info[1] ? b.score - a.score : a.score - b.score);
                }
                const rows = selected.slice(0, name ? 1 : info[6])
                    .map(({ participant: { displayName }, score }, i) => `${!name && info[2] ? `${info[3] + (i + 1)}. ` : ''}${info[4] + (f[displayName] ?? displayName)}§r ${info[5] + score}§r`);
                if (!rows.length && name) rows.push(unavailableName + ' §7— No score yet');
                const label = data.objective.displayName + '§r\n' + rows.join('\n');
                if (entity.nameTag !== label) entity.nameTag = label;
            } catch (err) { console.warn('[MonkeyChan] floating-scoreboard refresh: ' + err); }
        }
    }
}
world.afterEvents.worldLoad.subscribe(() => {
    console.warn('[MonkeyChan] Floating Text & Scoreboards module initialized.');
    system.runInterval(refreshFloatingScoreboards, 20);
});