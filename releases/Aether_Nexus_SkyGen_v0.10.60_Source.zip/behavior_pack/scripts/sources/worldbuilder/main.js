import { world, system, ItemStack } from '@minecraft/server';
import { ZONES } from './blueprints.js';

// Sky Realm Aether Nexus: auto-build ONLY on a genuinely fresh verified void world.
// A saved/completed build never restarts automatically, and non-void terrain is rejected.
// Operators still control pause/resume/status manually.
// All construction data is static and checked during packaging.
const STATE_KEY = 'sg_skyrealm_builder_v8_state';
const LOCK_KEY = 'sg_skyrealm_builder_v8_running';
const DONE_KEY = 'sg_skyrealm_builder_v8_complete';
const AREA_NAME = 'sg_aether_v8_tmp';
const PER_TICK_COMMAND_LIMIT = 9;
const PER_TICK_BLOCK_BUDGET = 650;
const MAX_COMMAND_FAILURES = 5;
const MAX_VERIFY_REPLAYS = 3;
const MAX_LOAD_TICKS = 1800;
const RELEASE = '8.0.5';
const PUBLIC_MINE_SCOREBOARD='sg_public_mine',CITY_BUILD_SCOREBOARD='sg_city_build';
function getFlag(obj,who){try{return world.scoreboard.getObjective(obj)?.getScore(who)===1}catch{return false}}
function setFlag(obj,who,value){
 let objective=world.scoreboard.getObjective(obj);
 if(!objective)objective=world.scoreboard.addObjective(obj,obj);
 objective.setScore(who,value?1:0);
 if(objective.getScore(who)!==(value?1:0))throw new Error('Failed to verify shared scoreboard '+obj+'/'+who);
}
function publicStarterEnabled(){return getFlag(PUBLIC_MINE_SCOREBOARD,'ready')}
function setPublicStarterEnabled(value){setFlag(PUBLIC_MINE_SCOREBOARD,'ready',value)}
let active = null;
let startupDone = false;

function message(text) { try { world.sendMessage('§b[Sky Realm] §r' + text); } catch (err) { console.warn('[Sky Realm] ' + text + ': ' + err); } }
function op(player) {
  if (!player || player.typeId !== 'minecraft:player') return false;
  try { if (typeof player.isOp === 'function' && player.isOp() === true) return true; } catch {}
  try { return player.playerPermissionLevel === 2; } catch { return false; }
}
function dimension() { return world.getDimension('overworld'); }
function readState() {
  try { const val = world.getDynamicProperty(STATE_KEY); return typeof val === 'string' ? JSON.parse(val) : null; }
  catch (err) { console.warn('[Sky Realm] state read failure: ' + err); return null; }
}
function writeState(state) {
  const encoded = JSON.stringify(state);
  world.setDynamicProperty(STATE_KEY, encoded);
  if (world.getDynamicProperty(STATE_KEY) !== encoded) throw new Error('Construction checkpoint write not verified');
}
function setLock(value) {
  world.setDynamicProperty(LOCK_KEY, !!value);
  if (world.getDynamicProperty(LOCK_KEY) !== !!value) throw new Error('Construction lock write not verified');
  // Mirror lock to a scoreboard so Core can enforce it from its different pack UUID.
  setFlag(CITY_BUILD_SCOREBOARD,'active',!!value);
}
function releaseArea() {
  try { dimension().runCommand('tickingarea remove ' + AREA_NAME); } catch { /* no area allocated */ }
}
function pause(reason) {
  if (!active) return;
  const state = active;
  state.status = 'paused'; state.lastError = String(reason).slice(0, 300);
  try { writeState(state); } catch (err) { console.error('[Sky Realm] CRITICAL: could not write paused state: ' + err); }
  active = null;
  try { setLock(false); } catch (err) { console.warn('[Sky Realm] lock release failed: ' + err); }
  releaseArea();
  message('§cPAUSED safely: ' + reason + '. Use /scriptevent skyrealm:build status, then resume.');
}
function completed() {
  if (!active) return;
  const state = active;
  try {
    state.status = 'completed'; state.stage = 'completed'; state.zone = ZONES.length; state.command = 0;
    writeState(state);
    world.setDynamicProperty(DONE_KEY, true);
    if (world.getDynamicProperty(DONE_KEY) !== true) throw new Error('Completion flag was not saved');
    // Core will only allow mining/regeneration after the new public grid is verified.
    setPublicStarterEnabled(true);
    setLock(false);
    active = null;
    releaseArea();
    message(state.mode==='mine-update'?
      '§aPUBLIC STARTER MINE UPDATED: 50 output blocks verified; mining and regeneration enabled.':
      '§aCOMPLETE: Aether Nexus: nine custom-decorated districts, 8 direct spokes, 8 grid-aligned ring links, and 50 starter generators verified. Test in-game before publishing.');
  } catch (err) { pause('Could not finalize build: ' + err); }
}
function normalizedBounds(command) {
  const p = command.split(' ');
  if (p[0] !== 'fill' && p[0] !== 'setblock') throw new Error('Non-construction command blocked');
  const expected = p[0] === 'fill' ? 8 : 5;
  if (p.length !== expected || !/^minecraft:[a-z0-9_]+$/.test(p[expected - 1])) throw new Error('Invalid construction blueprint');
  const n = p.slice(1, expected - 1).map(Number);
  if (!n.every(Number.isSafeInteger)) throw new Error('Invalid coordinates');
  const lo = n.slice(0, 3), hi = p[0] === 'fill' ? n.slice(3, 6) : lo;
  const a = [0, 1, 2].map(i => Math.min(lo[i], hi[i]));
  const b = [0, 1, 2].map(i => Math.max(lo[i], hi[i]));
  return { a, b, type: p[expected - 1],
    volume: (b[0] - a[0] + 1) * (b[1] - a[1] + 1) * (b[2] - a[2] + 1) };
}
function loaded(x, y, z) {
  try { return !!dimension().getBlock({ x, y, z }); } catch { return false; }
}
function rectangleLoaded(a, b) {
  // Probe EVERY chunk intersecting a footprint, not just the zone center.
  const lowX = Math.floor(a[0] / 16), highX = Math.floor(b[0] / 16);
  const lowZ = Math.floor(a[2] / 16), highZ = Math.floor(b[2] / 16);
  for (let cx = lowX; cx <= highX; cx++) {
    for (let cz = lowZ; cz <= highZ; cz++) {
      if (!loaded(cx * 16, 0, cz * 16)) return false;
    }
  }
  return true;
}
function zoneLoaded(zone) { return rectangleLoaded(zone.bounds[0], zone.bounds[1]); }
function matchesCommand(spec) {
  const dim = dimension();
  for (let x = spec.a[0]; x <= spec.b[0]; x++) {
    for (let z = spec.a[2]; z <= spec.b[2]; z++) {
      for (let y = spec.a[1]; y <= spec.b[1]; y++) {
        const block = dim.getBlock({ x, y, z });
        if (!block || block.typeId !== spec.type) return false;
      }
    }
  }
  return true;
}
function describeFirstMismatch(spec) {
  try {
    const dim = dimension();
    for (let x = spec.a[0]; x <= spec.b[0]; x++) {
      for (let z = spec.a[2]; z <= spec.b[2]; z++) {
        for (let y = spec.a[1]; y <= spec.b[1]; y++) {
          const b = dim.getBlock({ x, y, z });
          if (!b || b.typeId !== spec.type) {
            return ' at ' + x + ',' + y + ',' + z +
              ', expected ' + spec.type + ', found ' + (b?.typeId || 'unloaded');
          }
        }
      }
    }
    return ' (no mismatch found on a second read)';
  } catch (error) { return ' (could not inspect mismatch: ' + String(error) + ')'; }
}
// Scan all 26 zone footprints BEFORE executing any construction command.
// Each zone gets its OWN temporary loaded area. The old preflight attempted
// to inspect distant zones while only the 49-chunk Citadel was loaded, making
// a fresh void world pause falsely at (88,0,-86).
function preflightZone(zone, includeSpawnSamples) {
  const [a,b]=zone.bounds;
  const x0=a[0],x1=b[0],z0=a[2],z1=b[2],xm=Math.floor((x0+x1)/2),zm=Math.floor((z0+z1)/2);
  const samples=[[x0,z0],[x1,z1],[x0,z1],[x1,z0],[xm,zm]];
  if(includeSpawnSamples) samples.push(
    [30,30],[-30,30],[30,-30],[-30,-30],
    [38,0],[-38,0],[0,38],[0,-38],[45,25],[-45,-25]);
  const dim=dimension();
  for(const [x,z] of samples){
    // Keep the original 25x25 starter-floor exemption.
    if(Math.abs(x)<=12&&Math.abs(z)<=12)continue;
    for(const y of [0,1,2,8]){
      const block=dim.getBlock({x,y,z});
      if(!block)return 'Preflight unloaded at '+x+','+y+','+z;
      if(block.typeId!=='minecraft:air')return 'World not virgin: '+x+','+y+','+z+' = '+block.typeId;
    }
  }
  return null;
}
function preflightIndex(state){
  return Number.isSafeInteger(state.preflightIndex) && state.preflightIndex >= 0 && state.preflightIndex <= ZONES.length
    ? state.preflightIndex : 0; // Backward compatible with paused v0.10.50 states.
}
function prepareZone(state, preflight=false) {
  const zone = ZONES[preflight ? preflightIndex(state) : state.zone];
  releaseArea();
  const a = zone.bounds[0], b = zone.bounds[1];
  const chunkCount = (Math.floor(b[0] / 16) - Math.floor(a[0] / 16) + 1) * (Math.floor(b[2] / 16) - Math.floor(a[2] / 16) + 1);
  if (chunkCount > 100) throw new Error('Footprint exceeds maximum 100 ticking-area chunks: ' + zone.id);
  const result = dimension().runCommand('tickingarea add ' + a[0] + ' 0 ' + a[2] + ' ' + b[0] + ' 0 ' + b[2] + ' ' + AREA_NAME + ' true');
  if (!result || result.successCount <= 0) throw new Error('Could not allocate rectangular ticking area; check 10-area limit');
  state.stage = preflight ? 'preflight_loading' : 'loading'; state.loadTicks = 0; state.delay = 25;
  writeState(state);
  message(preflight
    ? '§ePreflight ' + (preflightIndex(state) + 1) + '/' + ZONES.length + ': loading ' + zone.id + ' (' + chunkCount + ' chunks).'
    : '§eLoading ' + zone.id + ' (' + (state.zone + 1) + '/' + ZONES.length + ', ' + chunkCount + ' chunks).');
}
function executeNext(state, zone) {
  const command = zone.cmds[state.command];
  const spec = normalizedBounds(command);
  if (!rectangleLoaded(spec.a, spec.b)) {
    state.stage = 'loading'; state.delay = 20; writeState(state); return false;
  }
  let error = null;
  try {
    const result = dimension().runCommand(command);
    if (result?.successCount <= 0 && !matchesCommand(spec)) error = new Error('Command returned zero; placement absent' + describeFirstMismatch(spec));
    else if (!matchesCommand(spec)) error = new Error('Post-placement block verification failed' + describeFirstMismatch(spec));
  } catch (err) {
    // Idempotent replay: Minecraft may report an error if blocks were already identical.
    try { if (!matchesCommand(spec)) error = new Error(String(err) + describeFirstMismatch(spec)); } catch { error = err; }
  }
  if (error !== null) {
    state.failures += 1;
    state.lastError = zone.id + ' command ' + (state.command + 1) + '/' + zone.cmds.length + ': ' + String(error);
    writeState(state);
    console.warn('[Sky Realm] ' + state.lastError);
    if (state.failures >= MAX_COMMAND_FAILURES) {
      pause(state.lastError + ' (max retries reached; no command skipped)'); return false;
    }
    state.delay = 10 * state.failures;
    return false;
  }
  // Save AFTER each verified command. If storage fails, do not advance in memory.
  state.command++;
  state.failures = 0;
  state.lastError = '';
  writeState(state);
  return true;
}
function stockZone(zone) {
  if (!zone.stock || zone.stock.length === 0) return;
  const dim = dimension();
  for (const data of zone.stock) {
    const [x, y, z, contents] = data;
    const block = dim.getBlock({ x, y, z });
    if (!block || block.typeId !== 'minecraft:barrel') throw new Error('Supply crate not placed at ' + x + ',' + y + ',' + z);
    const inv = block.getComponent('minecraft:inventory')?.container;
    if (!inv) throw new Error('Supply inventory unavailable at ' + x + ',' + y + ',' + z);
    for (let slot = 0; slot < contents.length; slot++) {
      const [itemId, count] = contents[slot];
      // Replaying after a crash never duplicates supplied resources.
      if (inv.getItem(slot)) continue;
      inv.setItem(slot, new ItemStack(itemId, count));
      if (inv.getItem(slot)?.typeId !== itemId) throw new Error('Could not verify supplies ' + itemId + ' in ' + zone.id);
    }
  }
}
function verifyZone(state, zone) {
  const budget = 100;
  let checked = 0;
  while (state.verifyAt < zone.probes.length && checked++ < budget) {
    const sample = zone.probes[state.verifyAt];
    const [x,y,z,type,writer] = sample;
    if (!loaded(x,y,z)) return pause('Verification chunk unloaded in ' + zone.id + ' at ' + x + ',' + y + ',' + z);
    const actual = dimension().getBlock({ x,y,z });
    if (!actual || actual.typeId !== type) {
      if (state.verifyRetries >= MAX_VERIFY_REPLAYS) return pause('Verification failed ' + zone.id + ' at ' + x + ',' + y + ',' + z + ': expected ' + type + ' got ' + (actual?.typeId || 'unloaded'));
      state.verifyRetries++;
      state.command = writer; // Only replay from last writer forward; never skip missing blocks.
      state.stage = 'building'; state.verifyAt = 0;
      writeState(state);
      message('§eVerification retry ' + state.verifyRetries + '/' + MAX_VERIFY_REPLAYS + ' in ' + zone.id + ' from command ' + (writer+1));
      return;
    }
    state.verifyAt++;
  }
  writeState(state);
  if (state.verifyAt >= zone.probes.length) {
    try { stockZone(zone); } catch(err) { return pause('Supply verification: ' + err); }
    message('§aVerified ' + zone.id + ': ' + zone.cmds.length + ' commands, ' + zone.probes.length + ' sample blocks.');
    releaseArea();
    state.zone++; state.command = 0; state.stage = 'prepare'; state.verifyAt = 0; state.verifyRetries = 0;
    writeState(state);
    if (state.zone >= ZONES.length) completed();
  }
}
function workTick() {
  if (!startupDone || !active) return;
  const state = active;
  try {
    if (state.status !== 'running') return;
    if (state.zone >= ZONES.length) return completed();
    const zone = ZONES[state.zone];
    if (state.delay > 0) { state.delay--; return; }
    if (state.stage === 'prepare') {
      // Never place even one city block until ALL 26 void preflights finish.
      if (!state.preflightPassed) {
        if (preflightIndex(state) >= ZONES.length) {
          state.preflightPassed=true; writeState(state); return;
        }
        return prepareZone(state, true);
      }
      return prepareZone(state);
    }
    if (state.stage === 'preflight_loading') {
      const i=preflightIndex(state), checkZone=ZONES[i];
      if (!checkZone) return pause('Invalid saved preflight zone '+i);
      if (!zoneLoaded(checkZone)) {
        state.loadTicks += 10; state.delay = 10;
        if (state.loadTicks > MAX_LOAD_TICKS) return pause('Preflight chunks for '+checkZone.id+' did not load. Check ticking-area limit and world performance.');
        return;
      }
      const issue=preflightZone(checkZone,i===0);
      if (issue) return pause(issue);
      state.preflightIndex=i+1;
      state.preflightPassed=state.preflightIndex>=ZONES.length;
      state.stage='prepare';state.delay=0;state.loadTicks=0;
      writeState(state);
      releaseArea();
      if(state.preflightPassed) message('§aAll '+ZONES.length+' zone preflights passed. Starting city construction.');
      return;
    }
    if (state.stage === 'loading') {
      if (!zoneLoaded(zone)) {
        state.loadTicks += 10; state.delay = 10;
        if (state.loadTicks > MAX_LOAD_TICKS) return pause('Chunks for ' + zone.id + ' did not load. Check ticking-area limit and world performance.');
        return;
      }
      state.stage = 'building'; state.loadTicks = 0; writeState(state);
      return;
    }
    if (state.stage === 'building') {
      let count = 0, volume = 0;
      while (count < PER_TICK_COMMAND_LIMIT && state.command < zone.cmds.length && volume < PER_TICK_BLOCK_BUDGET) {
        const cost = normalizedBounds(zone.cmds[state.command]).volume;
        if (!executeNext(state, zone)) break;
        count++; volume += cost;
      }
      if (active === state && state.command >= zone.cmds.length) {
        state.stage = 'verifying'; state.verifyAt = 0; writeState(state);
      }
      return;
    }
    if (state.stage === 'verifying') return verifyZone(state, zone);
    return pause('Unknown saved construction stage ' + state.stage);
  } catch (err) {
    console.error('[Sky Realm] work tick exception: ' + err);
    pause('Unexpected construction error: ' + String(err));
  }
}
// Never start building in an existing world on import; fresh void + no saved state required.
// Sample only nearby loaded void blocks before staging construction chunks.
// The complete 26-zone preflight now streams one loaded zone at a time.
function autoBuildFreshVoid(){
  if(!startupDone||active||world.getDynamicProperty(DONE_KEY)===true||readState()||publicStarterEnabled())return;
  if(world.getAllPlayers().length===0)return;
  const dim=dimension();
  for(const [x,z] of [[16,16],[-16,16],[16,-16],[-16,-16],[20,0],[-20,0],[0,20],[0,-20]]){
    const sample=dim.getBlock({x,y:0,z});
    if(!sample||sample.typeId!=='minecraft:air')return;
  }
  const state={version:8,status:'running',stage:'prepare',zone:0,command:0,failures:0,
    verifyAt:0,verifyRetries:0,delay:0,loadTicks:0,preflightPassed:false,preflightIndex:0,lastError:''};
  try{
    setPublicStarterEnabled(false);
    writeState(state);
    setLock(true);
    active=state;
    message('§aFresh verified VOID world detected. Starting Aether Nexus construction automatically. Use /scriptevent skyrealm:build status.');
  }catch(err){
    console.error('[Sky Realm] Auto-start failed safely: '+err);
    try{
      const saved=readState();
      if(saved?.status==='running'){
        saved.status='paused';saved.lastError='Auto-start interrupted: '+String(err);
        writeState(saved);
      }
    }catch(recoveryErr){console.error('[Sky Realm] Checkpoint recovery failed: '+recoveryErr)}
    try{setLock(false)}catch{}
    active=null;
  }
}
function start(player) {
  if (world.getDynamicProperty(DONE_KEY) === true) return player.sendMessage('§aAether Nexus already completed. This release builds fresh worlds only.');
  if (active) return player.sendMessage('§eAlready constructing. Use /scriptevent skyrealm:build status.');
  const prior = readState();
  if (prior) return player.sendMessage('§eExisting build state: ' + prior.status + '. Use status / resume; this builder will not overwrite existing progress.');
  if (player.dimension?.id !== 'minecraft:overworld') return player.sendMessage('§cRun from the Overworld.');
  const state = { version: 8, status:'running', stage:'prepare',zone:0,command:0,failures:0,
    verifyAt:0,verifyRetries:0,delay:0,loadTicks:0,preflightPassed:false,preflightIndex:0,lastError:'' };
  try {
    setPublicStarterEnabled(false);
    writeState(state);setLock(true);active=state;
    player.sendMessage('§aSTART ACCEPTED: Builder v'+RELEASE+', stage 1/'+ZONES.length+'.');
    message('§aFresh Aether Nexus build authorized: '+ZONES.length+' stages including the 50-block public starter mine.');
  }
  catch (err) { player.sendMessage('§cBuild not started: ' + err); }
}
function resume(player) {
  if (active) return player.sendMessage('§eAlready running.');
  const state = readState();
  if (!state || state.version !== 8 || state.status !== 'paused') return player.sendMessage('§cNo paused v8 build to resume.');
  if (player.dimension?.id !== 'minecraft:overworld') return player.sendMessage('§cRun from Overworld.');
  try {
    state.status='running';state.stage='prepare';state.delay=0;state.failures=0;state.verifyAt=0;state.loadTicks=0;
    writeState(state);setLock(true);active=state;
    message('§aResumed ' + ZONES[state.zone]?.id + ' at stored command ' + (state.command+1) + '.');
  } catch(err) { player.sendMessage('§cCannot resume: ' + err); }
}
function status(player) {
  const state = active || readState();
  if (!state) return player.sendMessage('§eBuilder v' + RELEASE + ' READY, no saved build. Run /scriptevent skyrealm:build start. A true void world is required.');
  if (state.status === 'completed') return player.sendMessage(publicStarterEnabled() ? '§aCOMPLETED: Aether Nexus and 50 starter generators ready.' : '§eCity marked complete but Core mine flag missing; do not overwrite this world.');
  const zone = ZONES[state.zone];
  player.sendMessage('§eBuilder v' + RELEASE + ': Sky Realm ' + state.status.toUpperCase() + ' • ' + (zone?.id || 'finalizing') + ' • ' + (state.zone+1) + '/' + ZONES.length + ' • ' + (state.command || 0) + '/' + (zone?.cmds.length || 0) + ' commands • stage ' + state.stage);
  if(!state.preflightPassed) player.sendMessage('§eVoid preflight: '+preflightIndex(state)+'/'+ZONES.length+' zones checked (no construction commands executed yet).');
  if(state.lastError) player.sendMessage('§cLast error: ' + state.lastError);
}
function bootstrap() {
  startupDone = true;
  message('§aAether Nexus Builder v' + RELEASE + ' script initialized. Operator commands: /scriptevent skyrealm:build help');
  const saved = readState();
  if (saved?.status === 'running') {
    saved.status='paused'; saved.stage='prepare'; saved.lastError='Game/script restarted before completion. Operator resume required.';
    try { writeState(saved); } catch (err) { console.error('[Sky Realm] FATAL state restoration: ' + err); }
    message('§eFound an interrupted city build. Progress preserved; operator must use resume.');
  }
  try { setLock(false); } catch (err) { console.warn('[Sky Realm] startup lock cleanup: ' + err); }
  releaseArea();
}
try {
  system.afterEvents.scriptEventReceive.subscribe(ev => {
    if (ev.id !== 'skyrealm:build') return;
    const player = ev.sourceEntity;
    if (!player || player.typeId !== 'minecraft:player') return;
    if (!op(player)) return player.sendMessage('§cOnly a Minecraft Realm operator can control the city builder.');
    const arg = String(ev.message || '').trim().toLowerCase();
    try {
      if (arg === 'ping') return player.sendMessage('§aAether Nexus Builder v' + RELEASE + ' ACTIVE; operator authorized.');
      if (arg === 'help') return player.sendMessage('§eCommands: ping, preview, start, status, pause, resume. Use /scriptevent skyrealm:build <action>.');
      if (arg === 'status') return status(player);
      if (arg === 'preview') {
        player.sendMessage('§6FRESH CITY: 9 newly redesigned districts, 16 aligned links, decorated 50-slot starter mine; fresh void world only.');
        player.sendMessage('§cVOID WORLD ONLY. Changes terrain; no existing city/plots should be inside the footprint. /scriptevent skyrealm:build start');
        return;
      }
      if (arg === 'start') return start(player);
      if (arg === 'mine update') return player.sendMessage('§cFresh-world release: old-world mine updates disabled.');
      if (arg === 'resume') return resume(player);
      if (arg === 'abort' || arg === 'pause') {
        if (!active) return player.sendMessage('§eNo active job.');
        return pause('Paused by operator ' + player.name);
      }
      player.sendMessage('§eCommands: ping / preview / start / status / pause / resume');
    } catch (err) { player.sendMessage('§cBuilder command failed: ' + err); console.warn('[Sky Realm] event handler: ' + err); }
  });
} catch (err) { console.error('[Sky Realm] scriptEventReceive registration failed: ' + err); }
system.runTimeout(bootstrap, 20);
system.runInterval(autoBuildFreshVoid, 100);
system.runInterval(workTick, 1);
