import mine_block from "./OnMineBlock.js";
export default [mine_block];
