import { EquipmentSlot, GameMode, system } from "@minecraft/server";
import { Component } from "../../libraries/Component.js";
import { beforeEvents } from "../../libraries/utils.js";
// SkyGen integration: a custom tool can change blocks one tick AFTER the usual
// interaction guard, so we validate permissions at the point of mutation too.
function skygenMayTransform(player, block){
 if(player.dimension?.id!=='minecraft:overworld')return true;
 try{if(typeof player.isOp==='function'&&player.isOp())return true}catch{}
 const {x,z}=block.location;
 // Public islands + bridges + starter mine are always protected from custom transforms.
 if(Math.abs(x)<=116&&Math.abs(z)<=116)return false;
 // Private plots are centered at (512+128*column, 512+128*row).
 const col=Math.round((x-512)/128),row=Math.round((z-512)/128);
 if(col>=0&&col<8&&row>=0){
  const dx=Math.abs(x-(512+col*128)),dz=Math.abs(z-(512+row*128));
  if(dx<=56&&dz<=56){
   const id=row*8+col;
   return player.getTags().some(tag=>{
    const m=/^sg_owner_(\d+)_(24|40|56)$/.exec(tag);
    return m&&Number(m[1])===id&&dx<=Number(m[2])&&dz<=Number(m[2]);
   });
  }
 }
 return true;
}
const component = new Component('true_dn:transform_block', 'onUseOn', { affect_ids: [], affect_tags: [], damage: 1 });
beforeEvents.playerInteractWithBlock.subscribe(async (data) => {
    const { block, player, itemStack: item } = data;
    if(data.cancel || !skygenMayTransform(player, block)) return;
    if (!item)
        return;
    const params = component.getParamsFrom(item);
    if (params === null)
        return;
    if (!params.transform_to && !params.specific_transformations)
        throw new Error(`"${item?.typeId}" did not specify "transform_to" or "specific_transformations" at "${component.id}"`);
    if (!item)
        return;
    const specific = params.specific_transformations?.[block.typeId];
    if (specific === null)
        return;
    const affect_ids = [params.affect_ids].flat();
    const affect_tags = [params.affect_tags].flat();
    if (!specific &&
        affect_ids.length && !affect_ids.includes(block.typeId) &&
        affect_tags.length && !affect_tags.some(t => t && block.permutation.hasTag(t)))
        return;
    // Cancel vanilla interaction once, then re-check the block and player permissions
    // after the deferred tick. Checking data.cancel here would always abort our own transform.
    const originalBlockType = block.typeId;
    data.cancel = true;
    await system.waitTicks(1);
    if (!block.isValid || block.typeId !== originalBlockType || !skygenMayTransform(player, block)) return;
    const next = specific ?? params.transform_to;
    block.setType(next);
    if (player.isPlayer() && player.getGameMode() !== GameMode.Creative) {
        const result = item.damage(params.damage);
        if (!result)
            player.dimension.playSound('random.break', player.location);
        player.equippable?.setEquipment(EquipmentSlot.Mainhand, result);
    }
    if (!params.sfx)
        return;
    const { sound, volume, pitch } = params.sfx;
    if (!sound)
        throw new Error(`"${item.typeId}" did not specify "sound" at "${component.id}/sfx"`);
    const v = Array.isArray(volume) ? volume[Math.floor(Math.random() * volume.length)] : volume;
    const p = Array.isArray(pitch) ? pitch[Math.floor(Math.random() * pitch.length)] : pitch;
    for (const id of [sound].flat()) {
        player.dimension.playSound(id, block.center(), { volume: v, pitch: p });
    }
});
export default component;
