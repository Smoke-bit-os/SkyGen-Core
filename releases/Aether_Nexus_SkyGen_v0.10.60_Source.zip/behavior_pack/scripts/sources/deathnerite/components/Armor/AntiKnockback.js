import { afterEvents, getArmorAttributes, Vector } from "../../libraries/utils.js";
import { EquipmentSlot } from "@minecraft/server";
import { Component } from "../../libraries/Component.js";
const component = new Component('true_dn:anti_knockback', '', { resistance: 1 });
afterEvents.entityHurt.subscribe(({ hurtEntity: entity, damageSource: { damagingEntity: other } }) => {
    const attributes = getArmorAttributes(entity);
    const anti = attributes[component.id];
    if (!anti)
        return;
    const { x, z } = other?.isValid ? Vector.subtract(entity.location, other.location).normalize() : Vector.down;
    const hand = other?.equippable?.getEquipment(EquipmentSlot.Mainhand);
    const ench = hand?.enchantable;
    const extra = ench?.getEnchantment(hand.typeId.includes('bow') ? 'punch' : 'knockback')?.level ?? 0;
    entity.applyKnockback(new Vector(x, 0, z).multiply(0.5 - anti + (extra / 10)), 0.25 - (anti / 5));
});
export default component;
