import { Component } from "../../libraries/Component.js";
const component = new Component('true_dn:armor_points', '', {});
export default component;
