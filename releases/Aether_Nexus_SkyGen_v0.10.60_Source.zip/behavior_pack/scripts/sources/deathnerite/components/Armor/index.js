import AntiKnockback from "./AntiKnockback.js";
import RemoveEffects from "./RemoveEffects.js";
import ArmorPoints from "./ArmorPoints.js";
import Toughness from "./Toughness.js";
export default [AntiKnockback, RemoveEffects, ArmorPoints, Toughness];
