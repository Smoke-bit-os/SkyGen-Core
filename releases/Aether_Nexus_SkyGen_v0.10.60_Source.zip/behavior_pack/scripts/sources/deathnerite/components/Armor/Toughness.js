import { getArmorAttributes } from "../../libraries/utils.js";
import { Component } from "../../libraries/Component.js";
import { world } from "@minecraft/server";
const component = new Component('true_dn:armor_toughness', '', { value: 1 });
world.beforeEvents.entityHurt.subscribe((data) => {
    const { hurtEntity: entity, damage } = data;
    const attributes = getArmorAttributes(entity);
    const toughness = attributes[component.id];
    if (!toughness)
        return;
    const { totalArmor, totalToughness } = entity.equippable ?? { totalArmor: 0, totalToughness: 0 };
    const raw = getRawDamageFromArmorReduced(damage, totalArmor, totalToughness);
    data.damage = applyArmorToughness(raw, totalArmor + (attributes['true_dn:armor_points'] ?? 0), totalToughness, toughness);
});
export function getRawDamageFromArmorReduced(reducedDamage, armor, toughness) {
    if (reducedDamage <= 0)
        return 0;
    const minArmor = armor / 5;
    const c = 4 / (toughness + 8);
    if (armor > 20) {
        const rawAt20Cap = (armor - 20) / c;
        const reducedAt20Cap = rawAt20Cap * 0.2;
        if (reducedDamage <= reducedAt20Cap) {
            return reducedDamage / 0.2;
        }
    }
    const rawAtMinArmor = (armor - minArmor) / c;
    const reducedAtMinArmor = rawAtMinArmor * (1 - minArmor / 25);
    if (reducedDamage < reducedAtMinArmor) {
        const A = c / 25;
        const B = 1 - armor / 25;
        return (-B + Math.sqrt(B * B + 4 * A * reducedDamage)) / (2 * A);
    }
    return reducedDamage / (1 - minArmor / 25);
}
export function applyArmorToughness(rawDamage, armorPoints, vanillaToughness, customToughness) {
    const toughness = vanillaToughness + customToughness;
    const effectiveArmor = Math.min(20, Math.max(armorPoints / 5, armorPoints - (4 * rawDamage) / (toughness + 8)));
    return rawDamage * (1 - effectiveArmor / 25);
}
export default component;
