import { EquipmentSlot, system, world } from "@minecraft/server";
import { Component } from "../../libraries/Component.js";
const component = new Component('true_dn:remove_effects', '', { cooldown: -1, effect_ids: [] });
// const Slots = Object.values(EquipmentSlot);
// beforeEvents.effectAdd.subscribe((data) => {
//     const { entity: player, effectType } = data;
//     console.warn(effectType);
//     if (!player.isPlayer()) return;
//     const { equippable } = player;
//     for (const slot of Slots) {
//         if (['Mainhand', 'Offhand'].includes(slot)) return;
//         const item = equippable.getEquipment(slot);
//         if (!item) return;
//         const params = component.getParamsFrom(item);
//         if (!params?.effect_ids.includes(effectType)) continue;
//         data.cancel = true;
//         break;
//     }
// });
// The original handler remains every tick: no delay to armor effect removal.
// Avoid calling getEffects() on players who have no effect-removal gear.
// Keep the same EquipmentSlot coverage as the original implementation.
const ARMOR_SLOTS = Object.values(EquipmentSlot).filter(s => s !== 'Mainhand' && s !== 'Offhand');
system.runInterval(() => {
    for (const player of world.getPlayers()) {
        try {
            const { equippable } = player;
            if (!equippable) continue;
            const blocked = new Set();
            for (const slot of ARMOR_SLOTS) {
                const item = equippable.getEquipment(slot);
                if (!item) continue;
                const params = component.getParamsFrom(item);
                if (!Array.isArray(params?.effect_ids)) continue;
                for (const id of params.effect_ids) blocked.add(id);
            }
            if (!blocked.size) continue; // Most players have no effect-removal gear.
            for (const effect of player.getEffects()) {
                if (blocked.has(effect.typeId.split(':')[1])) player.removeEffect(effect.typeId);
            }
        } catch (e) {
            console.warn('[Deathnerite] effect removal check failed: ' + e);
        }
    }
});
export default component;
