import lore from "./Lore.js";
export default [lore];
