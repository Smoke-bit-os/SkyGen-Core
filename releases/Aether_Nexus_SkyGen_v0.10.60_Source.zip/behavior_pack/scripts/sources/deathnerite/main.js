import { afterEvents, cloneItemStackInfo, Vector } from "./libraries/utils.js";
import { ItemStack, system } from "@minecraft/server";
import SmithingRecipes from "./SmithingRecipes.js";
import "./components/main.js";
const ItemTemplates = new Map();
afterEvents.worldLoad.subscribe(() => {
    ItemTemplates.set('next', new ItemStack('true:next'));
    ItemTemplates.set('empty', new ItemStack('true:empty'));
    ItemTemplates.set('invalid', new ItemStack('true:invalid'));
});
system.afterEvents.scriptEventReceive.subscribe(({ id, sourceEntity: table }) => {
    if (id.split(':')[1] !== 'special_smithing_table' || !table?.isValid)
        return;
    const { container: inv } = table.inventory;
    const block = table.dimension.getBlock(table.location);
    if (!block?.isValid)
        return;
    if (block?.typeId !== table.typeId) {
        const templates = [...ItemTemplates.values()].map(i => i.typeId);
        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);
            if (!item || templates.includes(item.typeId))
                continue;
            try {
                table.dimension.spawnItem(item, Vector.center(table.location).add({ y: 0.5 }));
            }
            catch { }
        }
        return table.remove();
    }
    const slots = Array.from({ length: 5 }, (_, i) => inv.getItem(i));
    const [template, base, addition, _, result] = slots;
    const recipe = SmithingRecipes.find(r => r.template === template?.typeId && r.base === base?.typeId && r.addition === addition?.typeId);
    inv.setItem(3, ItemTemplates.get(!template || !base || !addition || recipe ? 'next' : 'invalid'));
    if (!recipe) {
        if (!result || result.typeId === 'true:empty')
            inv.setItem(4, ItemTemplates.get('empty'));
        return;
    }
    if (result && result.typeId !== 'true:empty')
        return;
    template.amount > 1 ? inv.getSlot(0).amount-- : inv.setItem(0);
    base.amount > 1 ? inv.getSlot(1).amount-- : inv.setItem(1);
    addition.amount > 1 ? inv.getSlot(2).amount-- : inv.setItem(2);
    table.dimension.playSound('smithing_table.use', Vector.center(table.location));
    const next = cloneItemStackInfo(base, new ItemStack(recipe.result));
    next.amount = 1;
    inv.setItem(4, next);
}, { namespaces: ['true'] });
afterEvents.playerPlaceBlock.subscribe(({ block, dimension }) => {
    if (block.typeId !== 'true:special_smithing_table' || dimension.getEntitiesAtBlockLocation(block.location).some(e => e.typeId === block.typeId))
        return;
    const permutation = block.permutation;
    const direction = permutation.getState('minecraft:cardinal_direction');
    const table = dimension.spawnEntity(block.typeId, Vector.add(block.center(), { y: 0.1 }));
    table.setRotation({ y: direction === 'north' ? 90 : direction === 'south' ? -90 : direction === 'east' ? 180 : 0, x: 0 });
    table.nameTag = 'Special Smithing Table';
});
// afterEvents.playerSwingStart.subscribe(({ heldItemStack: item, player }) => {
//     if (!item?.typeId.match(/true_dn:parcanite/)) return;
//     player.playAnimation('animation.true_dn.first_person.attack_animation_arm', {
//         stopExpression: '!variable.attack_time',
//         controller: 'parcanite_attack',
//     });
// });
