/** HUD-only badge presentation. Does not grant, purchase, or unlock cosmetics.
 * Gameplay unlocks must write cosmetics.owned before the player may equip. */
export const HUD_BADGES = Object.freeze({
  sky_guardian_crest: '[SGBG]',
  merchant_insignia: '[SGBM]',
  sky_feast_crest: '[SGBF]'
});

export function equippedBadgeMarkers(profile) {
  const cosmetics = profile?.cosmetics;
  if (!cosmetics || typeof cosmetics !== 'object' || Array.isArray(cosmetics)) return '';
  if (!Array.isArray(cosmetics.owned) || !Array.isArray(cosmetics.equipped)) return '';
  const owned = new Set(cosmetics.owned.filter(s => typeof s === 'string'));
  const equipped = new Set(cosmetics.equipped.filter(s => typeof s === 'string'));
  return Object.entries(HUD_BADGES)
    .filter(([id]) => owned.has(id) && equipped.has(id))
    .map(([, marker]) => marker).join('');
}
