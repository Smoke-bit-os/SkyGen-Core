import { EnchantmentTypes } from '@minecraft/server';

const durability = [['unbreaking', 3], ['mending', 1]];
const armorBase = [['protection', 4], ...durability, ['thorns', 3]];
const pieces = [
    ['helmet', [['respiration', 3], ['aqua_affinity', 1]]],
    ['chestplate', []],
    ['leggings', [['swift_sneak', 3]]],
    ['boots', [['feather_falling', 4], ['depth_strider', 3], ['soul_speed', 3]]]
];

function armorSet(tier, price, orbitPrice) {
    return {
        name: 'Elite ' + tier + ' Armor (4 pieces)',
        price, orbitPrice,
        lines: pieces.map(([slot, extras]) => ({
            id: 'true_dn:' + tier.toLowerCase() + '_' + slot,
            count: 1,
            enchantments: [...armorBase, ...extras]
        }))
    };
}

export const PRO_SHOP = [
    {
        name: 'Enchanted Elytra',
        price: 60000000, orbitPrice:3,
        lines: [{ id: 'minecraft:elytra', count: 1, enchantments: durability }]
    },
    { name:'Totem of Undying',price:25000,lines:[{id:'minecraft:totem_of_undying',count:1}] },
    { name:'Enchanted Golden Apple',price:10000,lines:[{id:'minecraft:enchanted_golden_apple',count:1}] },
    { name:'Regular Elytra',price:40000000,orbitPrice:2,lines:[{id:'minecraft:elytra',count:1}] },
    armorSet('Deathnerite', 220000000, 11),
    armorSet('Parcanite', 420000000, 21)
];

export function hasProEnchantments(item, expected) {
    const applied = item.getComponent('minecraft:enchantable')?.getEnchantments() ?? [];
    return applied.length === expected.length && expected.every(([id, level]) =>
        applied.some(e => e.type.id.replace(/^minecraft:/, '') === id && e.level === level));
}

export function enchantProItem(item, enchantments) {
    const component = item.getComponent('minecraft:enchantable');
    if (!component) throw Error(item.typeId + ' is not enchantable.');
    for (const [id, level] of enchantments) {
        const type = EnchantmentTypes.get('minecraft:' + id);
        if (!type || !component.canAddEnchantment({ type, level })) {
            throw Error(item.typeId + ' cannot accept ' + id + ' ' + level + '.');
        }
        component.addEnchantment({ type, level });
    }
    if (!hasProEnchantments(item, enchantments)) throw Error('Could not verify enchantments on ' + item.typeId + '.');
}
