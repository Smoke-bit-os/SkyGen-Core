// SkyGen v0.10.29: unified module bootloader. Original modules preserved.
import './main.js'; // SkyGen Core
import './sources/deathnerite/main.js'; // Deathnerite Plus
import './sources/monkey/index.js'; // MonkeyChan Floating Text
import './sources/worldbuilder/main.js'; // Sky Realm World Builder
