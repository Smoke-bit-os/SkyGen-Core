// v0.10.52 Checkpoint 4 — pure weekly CONTRACT STATE ENGINE (NOT LIVE).
// No monetary amounts, script events, profile writes, or reward claims are enabled.
// This module prepares frozen assignments and tests safe state transitions before
// a future transactional settlement is approved and integrated into main.js.
import { NEW_QUESTS } from './quest_expansion.js';
import { selectWeeklyElite, utcWeekStart, WEEKLY_ELITE_LIMIT, WEEKLY_UNLOCK_RANK } from './weekly_contracts.js';
const BY_ID=new Map(NEW_QUESTS.map(q=>[q.id,q]));
export const WEEKLY_STATE_SCHEMA=1;
const BAD_KEYS=['credits','orbits','xp','paid','reward','claimed','transactionId','payout'];
// The quest catalog and selector are immutable for this script runtime. Cache
// expected IDs by player, locked rank, and UTC Monday so repeated verified
// actions do not re-hash and sort the eligible Elite catalog every time.
// Only derived IDs are cached, never mutable player progress or currency.
// A bounded cache avoids increasing memory use indefinitely as players join.
const EXPECTED_SELECTION_CACHE=new Map(),EXPECTED_SELECTION_CACHE_LIMIT=128;
function expectedWeeklyIds(playerId,lockedRank,week){
 const key=JSON.stringify([playerId,lockedRank,week]);
 if(EXPECTED_SELECTION_CACHE.has(key))return EXPECTED_SELECTION_CACHE.get(key);
 const ids=Object.freeze(selectWeeklyElite(playerId,lockedRank,week).map(e=>e.questId));
 if(EXPECTED_SELECTION_CACHE.size>=EXPECTED_SELECTION_CACHE_LIMIT)
  EXPECTED_SELECTION_CACHE.delete(EXPECTED_SELECTION_CACHE.keys().next().value);
 EXPECTED_SELECTION_CACHE.set(key,ids);
 return ids;
}
function isCount(value,maximum){return Number.isSafeInteger(value)&&value>=0&&value<=maximum;}
function validateEntry(raw,week,lockedRank){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Bad weekly quest entry');
 if(BAD_KEYS.some(key=>Object.hasOwn(raw,key)))throw Error('Unexpected monetary/claim data; operator review');
 const q=BY_ID.get(raw.questId);
 if(!q||q.difficulty!=='elite'||q.rank>lockedRank)throw Error('Untrusted weekly quest ID');
 if(raw.assignedWeek!==week||raw.lockedRank!==lockedRank||raw.pendingEconomy!==true)throw Error('Weekly assignment was modified');
 if(raw.primaryKey!==q.key||raw.primarySubject!==(q.primarySubject??null)||raw.secondaryKey!==q.secondary.key||raw.secondarySubject!==q.secondary.subject||raw.target!==q.need||raw.secondaryTarget!==q.secondary.need)throw Error('Frozen weekly objectives changed');
 if(!isCount(raw.progress,q.need)||!isCount(raw.secondaryProgress,q.secondary.need))throw Error('Invalid weekly progress');
 return {...raw};
}
function validateExisting(existing,playerId){
 if(!existing||typeof existing!=='object'||Array.isArray(existing)||existing.schema!==WEEKLY_STATE_SCHEMA||existing.playerId!==playerId)throw Error('Weekly state owner/schema mismatch');
 if(BAD_KEYS.some(key=>Object.hasOwn(existing,key)))throw Error('Unexpected weekly settlement state; operator review');
 if(existing.week!==utcWeekStart(existing.week+'T00:00:00Z'))throw Error('Invalid weekly period');
 if(!Number.isSafeInteger(existing.lockedRank)||existing.lockedRank<WEEKLY_UNLOCK_RANK||existing.lockedRank>1000)throw Error('Invalid locked rank');
 if(!Array.isArray(existing.entries)||existing.entries.length!==WEEKLY_ELITE_LIMIT)throw Error('Invalid weekly entry count');
 const entries=existing.entries.map(e=>validateEntry(e,existing.week,existing.lockedRank));
 if(new Set(entries.map(e=>e.questId)).size!==WEEKLY_ELITE_LIMIT)throw Error('Duplicate weekly contracts');
 const expected=expectedWeeklyIds(playerId,existing.lockedRank,existing.week);
 if(entries.some((e,i)=>e.questId!==expected[i]))throw Error('Weekly assignment ID or order changed');
 return {...existing,entries};
}
export function weeklyAssignmentPreview(existing,playerId,rank,date){
 if(typeof playerId!=='string'||!playerId.trim())throw Error('Missing immutable player ID');
 if(!Number.isInteger(rank)||rank<1||rank>1000)throw Error('Invalid player rank');
 const week=utcWeekStart(date);
 if(existing){
  const prior=validateExisting(existing,playerId);
  if(prior.week===week)return prior; // no reroll, preserve progress and LOCKED rank
  if(prior.week>week)throw Error('Clock rolled backward; preserve assignment for operator review');
  // Unpaid draft progress is historical only. This module cannot pay or claim it.
 }
 if(rank<WEEKLY_UNLOCK_RANK)return null;
 const entries=selectWeeklyElite(playerId,rank,week).map(({questId})=>{
  const q=BY_ID.get(questId);
  return {questId,assignedWeek:week,lockedRank:rank,pendingEconomy:true,
   primaryKey:q.key,primarySubject:q.primarySubject??null,target:q.need,progress:0,
   secondaryKey:q.secondary.key,secondarySubject:q.secondary.subject,
   secondaryTarget:q.secondary.need,secondaryProgress:0};
 });
 return {schema:WEEKLY_STATE_SCHEMA,playerId,week,lockedRank:rank,entries};
}
// A verified shop sale can contain thousands of items. Calling the old
// 64-item helper once per chunk revalidated and reselected ALL three weekly
// assignments up to 64 times in one event. A single bounded progress update
// has the exact same saturated counter result, while validating once.
// No monetary amounts or reward/claim capabilities exist in this module.
function progressOnce(state,keys,subject,amount,maxAmount){
 if(!Array.isArray(keys)||!keys.every(k=>typeof k==='string')||!Number.isSafeInteger(amount)||amount<1||amount>maxAmount)
  throw Error('Invalid activity');
 const checked=validateExisting(state,state?.playerId);
 for(const entry of checked.entries){
  if(keys.includes(entry.primaryKey)&&(entry.primarySubject===null||entry.primarySubject===subject))
   entry.progress=Math.min(entry.target,entry.progress+amount);
  if(keys.includes(entry.secondaryKey)&&entry.secondarySubject===subject)
   entry.secondaryProgress=Math.min(entry.secondaryTarget,entry.secondaryProgress+amount);
 }
 return checked;
}
export function weeklyProgressPreview(state,keys,subject,amount=1){
 return progressOnce(state,keys,subject,amount,64);
}
export function weeklyProgressPreviewBatch(state,keys,subject,amount){
 return progressOnce(state,keys,subject,amount,4096);
}
export function weeklyReadyPreview(state){
 const checked=validateExisting(state,state?.playerId);
 return checked.entries.filter(e=>e.progress===e.target&&e.secondaryProgress===e.secondaryTarget).map(e=>e.questId);
}
export function claimWeeklyElite(){throw Error('Weekly claims are LOCKED until exact Credits/Orbits and durable settlement are approved.');}
