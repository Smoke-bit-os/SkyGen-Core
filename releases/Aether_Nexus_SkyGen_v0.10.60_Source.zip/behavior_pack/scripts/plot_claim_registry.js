// Phase 1: interrupt-safe, recoverable plot reservations. Keep persisted legacy keys.
// This module has no Minecraft API imports so storage failure boundaries can be unit-tested.
const INTENT = 'sg_claim_allocating_v1048';
const INDEX = 'sg_next_plot';
const LIMIT = 64000;
const reservationKey = owner => 'sg_claim_reserve_' + owner;
function validId(id) { return Number.isSafeInteger(id) && id >= 0 && id <= LIMIT; }

export function allocateOrRecoverPlot(registry, playerId) {
 if(typeof playerId !== 'string' || !playerId) throw Error('Invalid plot owner');
 const get = key => registry.get(key);
 const checkedSet = (key, value) => {
  registry.set(key,value);
  if (get(key) !== value) throw Error('Plot registry write failed: ' + key);
 };
 const pointer = () => {
  const value = Number(get(INDEX) ?? 0);
  if(!validId(value)) throw Error('Plot index invalid or limit reached');
  return value;
 };
 // Complete any interrupted global reservation before considering a new owner.
 function reconcileIntent() {
  const raw=get(INTENT);
  if(raw===null || raw===undefined) return;
  if(typeof raw!=='string') throw Error('Plot allocation intent damaged');
  let intent;
  try { intent=JSON.parse(raw); } catch { throw Error('Plot allocation intent corrupt'); }
  if(intent?.v!==1 || !validId(intent.id) || typeof intent.owner!=='string' || !intent.owner)
   throw Error('Invalid plot allocation intent; operator review');
  const next=pointer(),id=intent.id;
  if(next!==id && next!==id+1) throw Error('Plot allocation intent/index conflict; operator review');
  const owner=registry.owner(id);
  if(owner && owner!==intent.owner) throw Error('Plot allocation owner mismatch; operator review');
  const reserve=reservationKey(intent.owner),r=get(reserve);
  if(r!==undefined && r!==null && r!==id) throw Error('Plot reservation collision; operator review');
  if(r!==id) checkedSet(reserve,id);
  if(!registry.owner(id)) checkedSet(registry.ownerKey(id),intent.owner);
  if(registry.owner(id)!==intent.owner) throw Error('Plot owner not verified');
  if(next===id) checkedSet(INDEX,id+1);
  // Clearing the intent is safe only after reservation, owner, and index verify.
  registry.set(INTENT,undefined);
  if(get(INTENT)!==undefined && get(INTENT)!==null) throw Error('Plot intent cleanup incomplete');
 }
 reconcileIntent();
 // On v0.10.47 a failed reservation write could leave an owner at the cursor.
 // Preserve that owner and reconstruct their recoverable reservation; never reassign.
 for(let safety=0;safety<=LIMIT;safety++) {
  const next=pointer(),orphanOwner=registry.owner(next);
  if(!orphanOwner)break;
  if(typeof orphanOwner!=='string') throw Error('Legacy plot owner record invalid');
  const key=reservationKey(orphanOwner),r=get(key);
  if(r!==undefined && r!==null && r!==next) throw Error('Legacy plot owner has conflicting reservation');
  if(r!==next) checkedSet(key,next);
  checkedSet(INDEX,next+1);
 }
 const reservation=get(reservationKey(playerId));
 if(reservation!==undefined && reservation!==null){
  if(!validId(reservation)||reservation>=pointer())throw Error('Existing plot reservation invalid');
  if(registry.owner(reservation)!==playerId)throw Error('Existing plot ownership conflict; operator review');
  return reservation;
 }
 const id=pointer();
 if(registry.overlaps(id))throw Error('New plot overlaps spawn protection; relocate lobby safely');
 if(registry.owner(id))throw Error('Plot registry occupied; operator review');
 checkedSet(INTENT,JSON.stringify({v:1,id,owner:playerId}));
 reconcileIntent();
 if(registry.owner(id)!==playerId||get(reservationKey(playerId))!==id||pointer()!==id+1)
  throw Error('Plot allocation incomplete; operator review');
 return id;
}
