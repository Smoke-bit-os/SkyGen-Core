const page = (id, title, lines, shortcut, branch) => ({ id, title, lines, shortcut, branch });

export const RULEBOOK_TOPIC = {
    title: 'Rulebook',
    intro: 'SkyGen Player Rulebook. Choose a page to read the Realm rules.',
    pages: [
        page('rules-respect', 'Respect Other Players', [
            'Keep chat respectful.',
            'Harassment, threats, impersonating staff, and spam are prohibited.'
        ]),
        page('rules-fair-play', 'Play Fair', [
            'Cheats, duplication, and exploits are prohibited.',
            'If a bug gives extra items or Credits or bypasses protection, stop using it and report it to staff.'
        ]),
        page('rules-plots', 'Respect Plots and Spawn', [
            'Build on another player’s plot only with permission.',
            'Respect other players’ builds, containers, and generators.',
            'Take only what you need from the shared starter-kit boxes.'
        ]),
        page('rules-pvp', 'Raid Night and PvP', [
            'PvP is allowed outside the central sanctuary during Raid Night.',
            'During Daytime Safe, PvP is off.',
            'Bypassing sanctuary protection is prohibited.'
        ]),
        page('rules-trade', 'Trade Honestly', [
            'Honor the terms you confirm.',
            'Scams, misleading offers, and abusing Marketplace or Bank transfers are prohibited.',
            'Check the recipient, amount, and item details before confirming.',
            'The Sell-All Chest is owner-only. Never use hoppers, pistons, or other mechanics to bypass plot protection.'
        ]),
        page('rules-report', 'Report a Problem', [
            'Tell a Realm operator what happened, who was involved, and roughly when and where it occurred.',
            'Include a screenshot or clip if you have one.'
        ])
    ]
};

export const HELP_TOPICS = [
    RULEBOOK_TOPIC,
    { title: 'Start Here', pages: [
        page('start', 'Your First Few Minutes', [
            '1. Your personal plot is assigned when you join.',
            '2. Use the Plot Horn to reach it. Stand still during the countdown.',
            '3. Use the Compass to open shops, quests, the Bank, and your plot settings.',
            '4. Back at spawn, try the Community Mine for starter resources once it is ready.'
        ], 'plot'),
        page('hotbar', 'Your SkyGen Hotbar', [
            'Slot 7 · Compass: open SkyGen.',
            'Slot 8 · Spawn Horn: travel to the lobby.',
            'Slot 9 · Plot Horn: travel to your own plot.',
            'If a tool is missing, give SkyGen a moment to restore it. If your plot still has no assignment, rejoin and try the Plot Horn.'
        ], 'teleport'),
        page('kits', 'Starter Kits at Spawn', [
            'Use an empty hand to open a starter-kit shulker.',
            'Overworld coordinates: 3 1 8, -3 1 8, -3 1 -8, and 3 1 -8.',
            'The boxes use shared inventory, so available stock depends on what other players have taken or added.',
            'Spawn protection still blocks breaking and placing blocks around the kits.'
        ])
    ] },
    { title: 'Plots, Travel & Raid Night', pages: [
        page('plots', 'Manage and Expand Your Plot', [
            'Compass → Plots & Travel → My Plot.',
            'Each player gets one permanent plot. Show Boundaries in Chat gives its exact limits.',
            'Starter: 49×49. Expanded: 81×81 for 250,000 Credits. Estate: 113×113 for another 1,000,000 Credits.',
            'Choose Buy Plot Expansion to review the new boundary and price.'
        ], 'plot'),
        page('visits', 'Visitors and Trusted Builders', [
            'In My Plot, use Manage Visitors for visit access and Manage Trusted Players for building access.',
            'Visitors can use authorized plot travel. Trusted builders can also place and break eligible blocks.',
            'To visit someone, use Compass → Plots & Travel → Visit Other Plots. Request access if needed and wait for the owner to accept.',
            'Use the visit menu to cross the plot forcefield.'
        ], 'visit'),
        page('teleports', 'Teleport Safely', [
            'Use a horn or Compass → Plots & Travel → Teleport.',
            'Stand still for the 5-second countdown. Moving cancels the request.',
            'A successful teleport starts a 5-second base cooldown. Mobility skills can shorten it to 4 or 3 seconds.',
            'If the destination is blocked or still loading, wait and try again. Clear the landing area on your plot if needed.'
        ], 'teleport'),
        page('raid', 'Raid Night and the Safe Zone', [
            'Watch for the RAID NIGHT and DAYTIME SAFE announcements.',
            'During Raid Night, PvP is enabled outside the central island sanctuary. The central island remains protected.',
            'During Daytime Safe, SkyGen disables PvP across the Realm.',
            'The Overworld Raid Night window is tick 13,000 up to tick 23,000. The announcement reflects whether Raid Night is active.'
        ])
    ] },
    { title: 'Generators & Farming', pages: [
        page('generators', 'Buy, Place, and Harvest Generators', [
            '1. Open Compass → Generators → Buy Generator.',
            '2. Pick Starter, Mining, Nature, or Endgame. Check the required rank and Credit price.',
            '3. Select the purchased token and use it on an open floor block on your own Overworld plot. Leave space above.',
            '4. Mine the resource above the core. It regenerates automatically.',
            'If a paid token is held for review, do not purchase again. Ask an operator to inspect the token ID and generator registry.'
        ], 'generators'),
        page('generator-management', 'Upgrades and the Community Mine', [
            'My Generators / Upgrade shows your generator level, coordinates, and next upgrade price. Level 10 has instant regeneration.',
            'You start with 20 generator slots. Engineering can add 5 or 10 slots.',
            'If output stalls, check the space above the core and use Diagnose Generator before deleting anything. Deleting gives no refund.',
            'The public Community Mine is shared and becomes usable when its construction finishes.'
        ], 'generators'),
        page('farming', 'Farm Supplies and Harvest Sales', [
            'Compass → Shops & Economy → Farming Shop.',
            'Buy Supplies has seeds, crops, tools, growing supplies, livestock and bee supplies, spawn eggs, and automation parts.',
            'Sell Harvest offers a custom amount or Sell All. Check the eligible quantity and Credit payout before confirming.',
            'For Farming quests, harvest mature wheat, carrots, potatoes, or beetroot on your own plot.'
        ], 'farming')
    ] },
    { title: 'Shops, Wallet & Bank', pages: [
        page('shops', 'Server Shop Purchases and Sales', [
            'Compass → Shops & Economy → Server Shop.',
            'Choose Buy or Sell From Inventory, then a category and an item. Enter the quantity and check the final Credit total.',
            'Sell All counts eligible stacks across your inventory. Named, locked, and protected items stay with you.',
            'Purchases use wallet Credits. Make room for the delivery before confirming.'
        ], 'shops'),
        page('food', 'Buy Food and Sell Produce', [
            'Compass → Shops & Economy → Food Shop is for buying food.',
            'Pick Basics, Cooked Meats, Seafood, Snacks, or Premium, then enter a quantity and confirm.',
            'Use Server Shop → Sell From Inventory for eligible food, or Farming Shop → Sell Harvest for crops and farm products.'
        ], 'food'),
        page('pro', 'Deathnerite and Pro Gear', [
            'Compass → Shops & Economy → Deathnerite Shop sells materials, tools, and armor.',
            'Pro Shop offers Enchanted Elytra for 60 million Credits or 3 Orbits, and four-piece Elite Deathnerite and Parcanite sets at their existing Credit prices.',
            'Also offers Totem of Undying (25,000 Credits), Enchanted Golden Apple (10,000 Credits), and regular Elytra (40 million Credits or 2 Orbits).',
            'Sell-All Chest costs 55,000 Credits: place a single chest on your plot, look at it, and bind via Pro Shop → Manage Sell-All Chest.',
            'Only you may open the bound chest. On closing, eligible items sell using current ordinary shop prices; unsupported items remain. Empty it and unbind before moving.',
            'Nearby hoppers, hopper minecarts, pistons, and double chests can block automatic sales for safety. Remove them before closing.',
            'Read the confirmation for the exact enchantments and price. Leave enough inventory space for every piece.',
            'Both shops use their listed prices. Standard buy discounts apply to Server, Food, and Farming shops.'
        ], 'pro'),
        page('wallet', 'Credits, Orbits, and Exchange', [
            'Wallet Credits pay for purchases and upgrades. Withdraw banked Credits before spending them.',
            'Compass → Shops & Economy → Wallet / Exchange. Enter how many Orbits to buy and confirm the quoted total.',
            '18,000,000 Credits buys 1 Orbit. The wallet limits are 2 billion Credits and 2 billion Orbits.',
            'Your Credits leaderboard score reflects wallet Credits. The Bank displays your combined bank balance separately.'
        ], 'wallet'),
        page('bank', 'Open and Manage Bank Accounts', [
            'Compass → Bank → Open Account. You can keep up to 20 named accounts, each holding up to 2 billion Credits.',
            'Select an account to deposit, withdraw, rename, set it as default, or close it once empty.',
            'Bank accounts hold Credits. Withdrawals must fit in your wallet.',
            'The Bank shows your exact wallet and account balances, even when your combined savings exceed 2 billion.',
            'After a restart, historical bank transfers may initialize in batches. Retry the Bank if it reports indexing.'
        ], 'bank'),
        page('payouts', 'Where Your Payout Goes', [
            'Eligible earned Credits go to the wallet if the full payout fits, then to your default bank account if it has room.',
            'If neither fits, shop sales leave your items with you and Daily Quests stay claimable.',
            'After making room, use Compass → Bank → Collect Pending Payouts for Marketplace proceeds and pending rank rewards.',
            'Blocked milestone Orbits stay pending until there is room in the Orbit wallet.'
        ], 'bank'),
        page('transfers', 'Send and Receive Credits', [
            'Bank → Send Credits. Choose an online player, choose your source, enter the amount, and confirm.',
            'The recipient opens Incoming Transfers, accepts, and chooses a wallet or account with enough room.',
            'Sent Transfers & Refunds shows the status. A declined, canceled, or seven-day-expired transfer can be refunded.',
            'If the original source is full, collect the refund into an eligible balance from that menu.'
        ], 'bank')
    ] },
    { title: 'Ranks, Skills & Quests', pages: [
        page('ranks', 'Ranks, XP, and Skill Points', [
            'Compass → Ranks & Progression → Ranks. Use 10 group buttons, each containing 100 scrollable selectable rank entries. Original Ranks 1–50 still need 1,000 XP each.',
            'Rank 50→51 needs 1,100 XP; each later rank needs 10% more, rounded up. Large XP is stored exactly as a string.',
            'Mine on your own plot or in the Community Mine, harvest generator output, and claim quests to earn XP.',
            'Ranks 1–50 keep original Skill Point rewards. Ranks 51–81 grant one point each, reaching 90 total to finish the existing tree; later ranks grant no extra points.',
            'Rank-based Credit rewards and one Orbit each tenth rank continue; payouts respect wallet and bank limits.'
        ], 'ranks'),
        page('skills', 'How to Learn and Use Skills', [
            'Compass → Ranks & Progression → Skill Tree.',
            'Each node shows its rank and Skill Point cost. Learn its prerequisite before buying it.',
            'Use Active Abilities / Toggles for supported skills. Plot-only passives stay on your plot; toggled skills and activated abilities also work within nine districts.',
            'Reset Skills refunds spent Skill Points for a Credit fee. Check the quote before confirming.'
        ], 'skills'),
        page('mining-skills', 'Mining Skills', [
            'Build toward faster mining, more generator XP, and a chance at bonus material.'
        ], 'skills', 'Mining'),
        page('mobility-skills', 'Mobility Skills', [
            'Run and jump faster on your plot. Use the toggles for Jump Boost and Slow Falling.'
        ], 'skills', 'Mobility'),
        page('survival-skills', 'Survival Skills', [
            'Get on-plot defenses and recovery. Activate Second Wind and Survival Feast from Active Abilities / Toggles.'
        ], 'skills', 'Survival'),
        page('exploration-skills', 'Exploration Skills', [
            'Work toward water and vision perks on your own plot. Expedition Rewards increases Daily Quest Credits.'
        ], 'skills', 'Exploration'),
        page('economy', 'Economy Skills', [
            'Only the highest buy or sell tier applies. Buy discounts cover Server, Food, and Farming shops. Pro and Deathnerite gear use listed prices.',
            'Rank Rewards boosts future rank-up Credits.'
        ], 'skills', 'Economy'),
        page('engineering-skills', 'Engineering Skills', [
            'Speed up private generator output, expand your generator limit, and reduce generator purchase and upgrade costs.'
        ], 'skills', 'Engineering'),
        page('quests', 'Daily Quest Rotation and Claims', [
            'Compass → Quests opens Daily Quests directly; Ranks & Progression → Daily Quests still works. Select a finished quest marked CLAIM.',
            'The rotation changes at 00:00 UTC. Completed quests remain until claimed.',
            'Fishing claims consume the listed fish after confirmation. Farming counts mature crops harvested on your own plot.',
            'Mine-dependent tasks wait for the Community Mine. If the full payout cannot fit, the quest remains claimable.',
            'Ranks 51+ receive up to three distinct Ascended daily contracts, with XP and bounded Credit payouts after both objectives are completed.',
            'Weekly Elite contracts unlock at Rank 101, with three per UTC week paying rank-based XP, Credits and Orbits. Rewards can each be claimed once, with saved progress and transaction review protection.'
        ], 'quests')
    ] },
    { title: 'Trading & Marketplace', pages: [
        page('market', 'List and Buy Marketplace Items', [
            'Compass → Shops & Economy → Player Marketplace.',
            'Use List an Item for supported plain commodities. Pick a stack and enter the total asking price in Credits.',
            'Use Browse Listings to check the seller, stack size, and price before buying.',
            'My Listings / Cancel returns the stock from a canceled listing when your inventory has room.'
        ], 'market'),
        page('market-payments', 'Collect Sale Credits', [
            'Sale Credits are routed to the wallet first, then the default bank account if the full amount fits.',
            'If proceeds are pending, make room and select Bank → Collect Pending Payouts.',
            'If a listing says it needs operator review, give the operator its listing ID and follow the review message.'
        ], 'bank'),
        page('trade', 'Trade Gear or Items with a Player', [
            'Compass → Shops & Economy → Player Trading. Pick an online player and choose an item stack.',
            'The recipient selects their offer. Both players review the item, quantity, and any gear enchantments and durability.',
            'Items with opaque custom dynamic properties cannot be traded or sold as ordinary commodities.',
            'Both must accept. Closing a trade screen, disconnecting, or changing an offer can cancel the trade.',
            'Use Compass → Bank → Send Credits for Credit transfers.'
        ], 'trade')
    ] },
    { title: 'HUD, Leaderboards & Troubleshooting', pages: [
        page('hud', 'Show Your Personal Sidebar', [
            'Compass → Display & Leaderboards → Personal Sidebar.',
            'Enable it to see wallet Credits, Orbits, rank, XP progress, and plot number on your screen.',
            'Bank totals are shown separately in the Bank. Floating displays can show a player profile or rank players by a selected scoreboard.'
        ], 'sidebar'),
        page('leaderboards', 'Read a Floating Leaderboard', [
            'SkyGen Credits ranks players by spendable wallet Credits. XP and other boards rank by their selected stats.',
            'A leaderboard can show up to 15 entries. A Personal Sidebar hologram shows the selected player’s stats.',
            'If a board shows only its title, verify that both packs are active, have the affected player join, and allow a moment for scores to sync.',
            'If the rows are still missing, tell an operator which board and player are affected.'
        ], 'sidebar'),
        page('troubleshoot', 'Fix Common Player Problems', [
            'Teleport canceled: stand still during the countdown and wait for cooldown or chunk loading.',
            'Shop sale blocked: check your eligible items and available wallet or default bank space.',
            'Quest claim blocked: read the payout message and make enough room before retrying.',
            'Transfer pending: check Incoming Transfers or Sent Transfers & Refunds in the Bank.'
        ])
    ] },
    { title: 'Commands', pages: [
        page('player', 'SkyGen Chat Help', [
            'Regular players can reach Help using the Compass. Bedrock requires command permission and cheats for /scriptevent.',
            '/scriptevent skygen:help player — show chat help.',
            '/scriptevent skygen:menu open — open the Compass menu.',
            '/scriptevent skygen:rankchat status — check overhead rank and chat prefix support.'
        ]),
        page('topics', 'Chat Help Topics', [
            '/scriptevent skygen:help generators',
            '/scriptevent skygen:help food',
            '/scriptevent skygen:help farming',
            '/scriptevent skygen:help pro',
            '/scriptevent skygen:help bank',
            '/scriptevent skygen:help economy',
            '/scriptevent skygen:help leaderboards'
        ])
    ] },
    { title: 'Operator Guide', operator: true, pages: [
        page('admin-access', 'Admin Axe and Player Management', [
            '/scriptevent skygen:adminaxe give — get the Admin Axe. Free a slot in hotbar slots 1–6 if needed.',
            '/scriptevent skygen:admin grant PlayerName — grant SkyGen Admin access to an online player.',
            '/scriptevent skygen:admin revoke PlayerName — remove SkyGen Admin access.',
            'Use the Admin Axe for wallet adjustments, item grants, and access. Wallet and item changes require Realm operator permission.'
        ]),
        page('admin-spawn', 'Spawn, Forcefields, and Raid Night', [
            '/scriptevent skygen:spawn status — check the 233×233 spawn zone, loaded chunks, and safe landing.',
            '/scriptevent skygen:spawn set — review and confirm the location where you stand.',
            'Use Admin Axe → Boundary Controls for spawn build mode and operator walk bypass.',
            '/scriptevent skygen:raidstatus status — check the clock, Raid Night window, PvP rule, and sanctuary guard.'
        ]),
        page('admin-world', 'Public Mine and Floating Displays', [
            'Admin Axe → Public Mine Levels sets shared generator levels by resource.',
            'Get the Floating Text Menu from Creative → Equipment or Compass → Display & Leaderboards → Floating Text (Operator).',
            'Create Floating Scoreboard: choose a SkyGen stat, leave Gamertag blank for a leaderboard, and choose the number of rows.',
            'For one player, enter their gamertag. Use Personal Sidebar — all stats to show their full profile.'
        ]),
        page('admin-review', 'Review Transactions and Tokens', [
            '/scriptevent skygen:security status — check flagged generator tokens and direct trades.',
            '/scriptevent skygen:marketreview status — check flagged Marketplace listings.',
            '/scriptevent skygen:txnreview PlayerName — inspect a player’s transaction lock.',
            'Check the transaction ID, wallet, and inventory before clearing or replacing anything.'
        ]),
        page('admin-repair', 'Recovery Commands', [
            '/scriptevent skygen:txnclear PlayerName | TxID — clear a reviewed transaction only after manual reconciliation.',
            '/scriptevent skygen:tokenrestore PlayerName | Cobblestone — restore a supported token after verifying the original purchase. The target must be online.',
            '/scriptevent skygen:debug status — check command registration and permission status.'
        ])
    ] }
];
