// v0.10.52 Checkpoint 6: rank-aware Ascended daily PREVIEW ONLY.
// No monetary payouts, inventory debits, XP grants, or claim callbacks.
// Canonical IDs 500-999 are stable. Reserve Elite contracts for the distinct
// weekly board, avoiding a duplicate daily/weekly contract ID on a given day.
import {NEW_QUESTS,percentageQuestXP} from './quest_expansion.js';
import {transitionCost,MAX_RANK} from './rank_progression.js';
const BY_ID=new Map(NEW_QUESTS.map(q=>[q.id,q]));
const DAILY=NEW_QUESTS.filter(q=>q.difficulty!=='elite');
export const ASCENDED_DAILY_UNLOCK_RANK=51;
export const ASCENDED_DAILY_MAX=3;
export const ASCENDED_DAILY_SCHEMA=1;
const FORBIDDEN=['credits','orbits','paid','claimed','reward','transactionId','payout','bank'];
function utcDay(value){
 const d=value instanceof Date?new Date(value.getTime()):new Date(value);
 if(!Number.isFinite(d.getTime()))throw Error('Invalid UTC date');
 return d.toISOString().slice(0,10);
}
function hash32(s){
 let h=2166136261;
 for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
 return h>>>0;
}
function gcd(a,b){while(b){const r=a%b;a=b;b=r}return a}
function eligibleCount(rank){
 let lo=0,hi=DAILY.length;
 while(lo<hi){const m=(lo+hi)>>1;if(DAILY[m].rank<=rank)lo=m+1;else hi=m}
 return lo;
}
// O(log 500) eligibility check, at most 3 choices. No per-action sorting.
export function chooseAscendedDaily(playerId,rank,day){
 if(typeof playerId!=='string'||!playerId.trim())throw Error('Invalid player ID');
 if(!Number.isSafeInteger(rank)||rank<1||rank>MAX_RANK)throw Error('Invalid rank');
 if(typeof day!=='string'||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(day)||utcDay(day+'T00:00:00Z')!==day)throw Error('Invalid UTC day');
 if(rank<ASCENDED_DAILY_UNLOCK_RANK)return [];
 const n=eligibleCount(rank),limit=Math.min(ASCENDED_DAILY_MAX,n);
 if(!n)return [];
 const start=hash32(playerId+'|'+day+'|ascended')%n;
 let step=Math.max(1,Math.floor(n/3)+1);
 while(gcd(step,n)!==1)step++;
 return Array.from({length:limit},(_,i)=>DAILY[(start+i*step)%n]);
}
function xpAt(rank,difficulty){return rank===MAX_RANK?'0':percentageQuestXP(transitionCost(rank),difficulty)}
function makeEntry(q,rank,day){
 return {questId:q.id,day,lockedRank:rank,pendingEconomy:true,
  primaryKey:q.key,primarySubject:q.primarySubject??null,target:q.need,progress:0,
  secondaryKey:q.secondary.key,secondarySubject:q.secondary.subject,
  secondaryTarget:q.secondary.need,secondaryProgress:0,previewXP:xpAt(rank,q.difficulty)};
}
function isCount(x,max){return Number.isSafeInteger(x)&&x>=0&&x<=max}
function validateState(state,id){
 if(!state||typeof state!=='object'||Array.isArray(state)||state.schema!==ASCENDED_DAILY_SCHEMA||state.playerId!==id)throw Error('Ascended preview owner/schema mismatch');
 if(FORBIDDEN.some(k=>Object.hasOwn(state,k)))throw Error('Unexpected settlement data; operator review');
 if(typeof state.day!=='string'||utcDay(state.day+'T00:00:00Z')!==state.day)throw Error('Invalid assigned day');
 if(!Number.isSafeInteger(state.lockedRank)||state.lockedRank<ASCENDED_DAILY_UNLOCK_RANK||state.lockedRank>MAX_RANK)throw Error('Invalid locked rank');
 const expected=chooseAscendedDaily(id,state.lockedRank,state.day);
 if(!Array.isArray(state.entries)||state.entries.length!==expected.length)throw Error('Ascended preview assignment count changed');
 const entries=state.entries.map((entry,i)=>{
  const q=expected[i];
  if(!entry||typeof entry!=='object'||Array.isArray(entry)||FORBIDDEN.some(k=>Object.hasOwn(entry,k)))throw Error('Unexpected contract state');
  if(entry.questId!==q.id||entry.day!==state.day||entry.lockedRank!==state.lockedRank||entry.pendingEconomy!==true||
     entry.primaryKey!==q.key||entry.primarySubject!==(q.primarySubject??null)||entry.target!==q.need||
     entry.secondaryKey!==q.secondary.key||entry.secondarySubject!==q.secondary.subject||entry.secondaryTarget!==q.secondary.need||
     entry.previewXP!==xpAt(state.lockedRank,q.difficulty))throw Error('Ascended preview was modified');
  if(!isCount(entry.progress,q.need)||!isCount(entry.secondaryProgress,q.secondary.need))throw Error('Invalid Ascended progress');
  return {...entry};
 });
 return {...state,entries};
}
export function openAscendedDailyPreview(profile,playerId,date){
 if(!profile||typeof profile!=='object'||Array.isArray(profile)||!Number.isSafeInteger(profile.rank)||profile.rank<1||profile.rank>MAX_RANK)throw Error('Invalid player profile rank');
 if(typeof playerId!=='string'||!playerId.trim())throw Error('Invalid player ID');
 const today=utcDay(date);
 const existing=profile.ascendedDailyPreview??null;
 if(existing){
  const old=validateState(existing,playerId);
  if(old.day>today)throw Error('UTC clock moved backwards; operator review');
  if(old.day===today)return {state:old,changed:false,locked:false}; // frozen rank after level-up
 }
 if(profile.rank<ASCENDED_DAILY_UNLOCK_RANK)return {state:null,changed:false,locked:true};
 const state={schema:ASCENDED_DAILY_SCHEMA,playerId,day:today,lockedRank:profile.rank,
  entries:chooseAscendedDaily(playerId,profile.rank,today).map(q=>makeEntry(q,profile.rank,today))};
 profile.ascendedDailyPreview=state;
 return {state,changed:true,locked:false};
}
export function recordAscendedDailyPreviewActivity(profile,playerId,keys,subject,amount,date){
 if(!Array.isArray(keys)||!keys.every(k=>typeof k==='string')||!Number.isSafeInteger(amount)||amount<1||amount>4096)throw Error('Invalid Ascended activity');
 const opened=openAscendedDailyPreview(profile,playerId,date);
 if(!opened.state)return false;
 const next=opened.state;
 let changed=false;
 for(const e of next.entries){
  if(keys.includes(e.primaryKey)&&(e.primarySubject===null||e.primarySubject===subject)){
   const progress=Math.min(e.target,e.progress+amount);
   if(progress!==e.progress){e.progress=progress;changed=true}
  }
  if(keys.includes(e.secondaryKey)&&e.secondarySubject===subject){
   const progress=Math.min(e.secondaryTarget,e.secondaryProgress+amount);
   if(progress!==e.secondaryProgress){e.secondaryProgress=progress;changed=true}
  }
 }
 if(changed)profile.ascendedDailyPreview=next;
 return changed||opened.changed;
}
export function ascendedDailyStatus(profile,playerId,date){
 const {state,changed,locked}=openAscendedDailyPreview(profile,playerId,date);
 if(!state)return {locked:true,changed,entries:[],previewOnly:true};
 return {locked:false,changed,day:state.day,lockedRank:state.lockedRank,previewOnly:true,
  entries:state.entries.map(e=>({questId:e.questId,primary:e.progress,target:e.target,
   secondary:e.secondaryProgress,secondaryTarget:e.secondaryTarget,
   previewXP:e.previewXP,ready:e.progress===e.target&&e.secondaryProgress===e.secondaryTarget}))};
}
export function claimAscendedDailyPreview(){throw Error('Ascended contract claims disabled pending owner-approved monetary terms and transaction journaling');}
