const item = (name, id, buy, sell = 0) => ({ name, id: 'minecraft:' + id, count: 1, buy, sell });

export function createFarmingCatalog(existingItems) {
    const shared = new Map(existingItems.map(entry => [entry.id, entry]));
    const existing = id => {
        const entry = shared.get('minecraft:' + id);
        if (!entry) throw Error('Missing shared Farming Shop item: ' + id);
        return entry;
    };

    const supply = id => ({ ...existing(id), sell: 0 });

    return {
        'Seeds & Crops': [
            item('Wheat Seeds', 'wheat_seeds', 5),
            item('Beetroot Seeds', 'beetroot_seeds', 6),
            item('Pumpkin Seeds', 'pumpkin_seeds', 8),
            item('Melon Seeds', 'melon_seeds', 8),
            item('Wheat', 'wheat', 16, 4),
            existing('carrot'),
            existing('potato'),
            existing('beetroot'),
            item('Pumpkin', 'pumpkin', 48, 10),
            existing('melon_slice'),
            item('Sugar Cane', 'sugar_cane', 14, 3),
            item('Bamboo', 'bamboo', 12, 2),
            item('Cactus', 'cactus', 18, 4),
            item('Cocoa Beans', 'cocoa_beans', 20, 5),
            existing('sweet_berries'),
            existing('glow_berries'),
            item('Red Mushroom', 'red_mushroom', 18, 4),
            item('Brown Mushroom', 'brown_mushroom', 18, 4),
            item('Nether Wart', 'nether_wart', 24, 6),
            item('Kelp', 'kelp', 12, 2)
        ],
        'Tools & Growing Supplies': [
            item('Wooden Hoe', 'wooden_hoe', 30),
            item('Stone Hoe', 'stone_hoe', 55),
            item('Iron Hoe', 'iron_hoe', 160),
            item('Diamond Hoe', 'diamond_hoe', 1150),
            item('Shears', 'shears', 135),
            item('Water Bucket', 'water_bucket', 200),
            item('Bone Meal', 'bone_meal', 12),
            item('Composter', 'composter', 80),
            supply('dirt'),
            supply('sand'),
            supply('soul_sand')
        ],
        'Livestock & Bees': [
            item('Lead', 'lead', 90),
            item('Oak Fence', 'oak_fence', 12),
            item('Oak Fence Gate', 'fence_gate', 24),
            item('Beehive', 'beehive', 280),
            item('Glass Bottle', 'glass_bottle', 15),
            item('Campfire', 'campfire', 95),
            item('Dandelion', 'dandelion', 10),
            item('Poppy', 'poppy', 10),
            item('Hay Bale', 'hay_block', 145, 30),
            item('Egg', 'egg', 14, 3),
            item('White Wool', 'white_wool', 24, 5),
            item('Leather', 'leather', 40, 9),
            item('Feather', 'feather', 20, 4),
            item('Raw Beef', 'beef', 45, 8),
            item('Raw Porkchop', 'porkchop', 40, 8),
            item('Raw Chicken', 'chicken', 35, 7),
            item('Raw Mutton', 'mutton', 35, 7),
            item('Raw Rabbit', 'rabbit', 45, 8),
            item('Honeycomb', 'honeycomb', 32, 7),
            existing('honey_bottle')
        ],
        'Farm Animal Spawn Eggs': [
            item('Chicken Spawn Egg', 'chicken_spawn_egg', 500),
            item('Cow Spawn Egg', 'cow_spawn_egg', 800),
            item('Sheep Spawn Egg', 'sheep_spawn_egg', 750),
            item('Pig Spawn Egg', 'pig_spawn_egg', 700),
            item('Rabbit Spawn Egg', 'rabbit_spawn_egg', 600),
            item('Goat Spawn Egg', 'goat_spawn_egg', 850),
            item('Bee Spawn Egg', 'bee_spawn_egg', 750)
        ],
        'Automation & Storage': [
            item('Hopper', 'hopper', 360),
            item('Hopper Minecart', 'hopper_minecart', 660),
            item('Piston', 'piston', 150),
            item('Sticky Piston', 'sticky_piston', 220),
            item('Observer', 'observer', 180),
            item('Dispenser', 'dispenser', 160),
            item('Dropper', 'dropper', 95),
            item('Repeater', 'repeater', 125),
            item('Comparator', 'comparator', 180),
            item('Redstone Torch', 'redstone_torch', 30),
            supply('redstone'),
            item('Rail', 'rail', 18),
            item('Powered Rail', 'golden_rail', 115),
            item('Chest', 'chest', 85),
            item('Barrel', 'barrel', 80)
        ]
    };
}
