// Visual-only HUD indicator. Never alters rank, XP, economy, or player saves.
// Exact BigInt division avoids overflow at high ranks (up to Rank 1,000).
import {MAX_RANK,transitionCost,parseProgress} from './rank_progression.js';
export const HUD_XP_SEGMENTS=10;
export function hudFilledSegments(rank,xpProgress){
  if(!Number.isSafeInteger(rank)||rank<1||rank>MAX_RANK)throw Error('Invalid HUD rank');
  if(rank===MAX_RANK)return HUD_XP_SEGMENTS;
  const cost=transitionCost(rank);
  const progress=parseProgress(xpProgress??'0');
  const count=(progress*BigInt(HUD_XP_SEGMENTS))/cost;
  return Number(count<0n?0n:count>10n?10n:count);
}
export function hudProgressMarkers(rank,xpProgress){
  const filled=hudFilledSegments(rank,xpProgress);
  let text='';
  for(let i=1;i<=filled;i++)text+='[SGXP'+i+']';
  return text;
}
