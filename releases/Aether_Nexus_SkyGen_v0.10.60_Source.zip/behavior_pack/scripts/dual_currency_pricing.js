// v0.10.52 — pure whole-Orbit pricing validation, used by approved Elytra checkout.
// Other Pro Shop SKU/bundle prices remain unapproved and are not enabled.
// These pure functions never debit balances or deliver items themselves.
export const CREDIT_PER_ORBIT=18000000n;
export const ORBIT_DISCOUNT_PERCENT=10n;
export const MAX_CREDIT_PRICE=2000000000n;
const normalize=(v,label)=>{
 if(typeof v==='number'&&(!Number.isSafeInteger(v)||v<0))throw Error(label+' must be a nonnegative safe integer');
 const s=String(v);
 if(!/^(0|[1-9][0-9]*)$/.test(s))throw Error(label+' must be a nonnegative integer');
 return BigInt(s);
};
export function exactOrbitQuote(creditListPrice,orbitAmount){
 const credits=normalize(creditListPrice,'Credit list price'),orbits=normalize(orbitAmount,'Orbit amount');
 if(!credits||!orbits||credits>MAX_CREDIT_PRICE||orbits>111n)throw Error('Invalid quote limits');
 const orbitCreditValue=orbits*CREDIT_PER_ORBIT;
 const correct=orbitCreditValue*100n===credits*(100n-ORBIT_DISCOUNT_PERCENT);
 if(!correct)throw Error('Whole-Orbit quote cannot be represented as an exact 10% discount; propose another bundle or price');
 return Object.freeze({creditListPrice:credits.toString(),orbitPrice:orbits.toString(),creditEquivalent:orbitCreditValue.toString(),savings: (credits-orbitCreditValue).toString(),discountPercent:10,previewOnly:true});
}
export function orbitBundlePreview(lines,orbits){
 if(!Array.isArray(lines)||!lines.length||lines.length>32)throw Error('Invalid bundle lines');
 let sum=0n;
 const items=[];
 for(const x of lines){
  if(!x||typeof x.id!=='string'||!/^([a-z0-9_.-]+):([a-z0-9_.-]+)$/.test(x.id))throw Error('Invalid bundle item identifier');
  const count=normalize(x.count,'Quantity'),unit=normalize(x.unitCredits,'Unit price');
  if(!count||count>1728n||!unit||unit>MAX_CREDIT_PRICE)throw Error('Invalid bundle line');
  sum+=count*unit;
  if(sum>MAX_CREDIT_PRICE)throw Error('Bundle exceeds credit price ceiling');
  items.push(Object.freeze({id:x.id,count:count.toString(),unitCredits:unit.toString()}));
 }
 const quote=exactOrbitQuote(sum,orbits);
 return Object.freeze({...quote,items:Object.freeze(items)});
}
