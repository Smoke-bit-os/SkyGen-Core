export const CREDIT_CAP = 2000000000;
const ACCOUNT_LIMIT = 20;
const TRANSFER_PREFIX = 'sg_bank_transfer_';
const SEQUENCE_KEY = 'sg_bank_sequence';
const EXPIRY_MS = 7 * 24 * 60 * 60 * 1000;
const money = value => value.toLocaleString('en-US');

function bankData(profile) {
    const data = profile.bank ?? { nextId: 1, defaultId: null, accounts: [] };
    if (!Number.isSafeInteger(data.nextId) || data.nextId < 1 ||
        !Array.isArray(data.accounts) || data.accounts.length > ACCOUNT_LIMIT ||
        data.accounts.some(a => !a || !Number.isSafeInteger(a.id) || a.id < 1 || a.id >= data.nextId ||
            typeof a.name !== 'string' || !Number.isSafeInteger(a.credits) || a.credits < 0 || a.credits > CREDIT_CAP) ||
        new Set(data.accounts.map(a => a.id)).size !== data.accounts.length ||
        (data.defaultId !== null && !data.accounts.some(a => a.id === data.defaultId))) {
        throw Error('Bank account data requires operator review.');
    }
    return data;
}
function account(profile, id) {
    return bankData(profile).accounts.find(a => a.id === id);
}
function balance(profile, id) {
    return id === 'wallet' ? profile.credits : account(profile, id)?.credits;
}
export function destinationName(profile, id) {
    return id === 'wallet' ? 'Wallet' : account(profile, id)?.name ?? 'Bank account';
}
function canReceive(profile, id, amount) {
    const current = balance(profile, id);
    return Number.isSafeInteger(amount) && amount > 0 && Number.isSafeInteger(current) &&
        amount <= CREDIT_CAP - current;
}
function changeBalance(profile, id, delta) {
    if (id === 'wallet') profile.credits += delta;
    else account(profile, id).credits += delta;
}
export function payoutDestination(profile, amount) {
    if (canReceive(profile, 'wallet', amount)) return 'wallet';
    const id = bankData(profile).defaultId;
    return canReceive(profile, id, amount) ? id : undefined;
}
export function creditPayout(profile, id, amount) {
    if (!canReceive(profile, id, amount)) throw Error('The destination has insufficient space for this payout.');
    changeBalance(profile, id, amount);
}

export function createBank({ world, system, profile, save, assertUnlocked, collectPayouts, form, showUI, skyModal, skyMessage, back }) {
    const online = id => world.getAllPlayers().find(p => p.id === id);
    const writeProperty = (key, value) => {
        world.setDynamicProperty(key, value);
        if (world.getDynamicProperty(key) !== value) throw Error('Bank record could not be verified.');
    };
    const transferKey = id => TRANSFER_PREFIX + id;
    const transfer = id => {
        const raw = world.getDynamicProperty(transferKey(id));
        if (raw === undefined) return undefined;
        const record = JSON.parse(raw);
        if (record?.id !== id || !Number.isSafeInteger(record.amount) || record.amount < 1 || record.amount > CREDIT_CAP ||
            typeof record.from !== 'string' || typeof record.to !== 'string' || record.from === record.to ||
            !Number.isSafeInteger(record.expires) ||
            !['debit','pending','accept','refundable','refund','accepted','refunded'].includes(record.state)) {
            throw Error('Bank transfer record requires operator review.');
        }
        return record;
    };
    const write = (record, state, reason = record.reason) =>
        writeProperty(transferKey(record.id), JSON.stringify({ ...record, state, reason }));
    const actor = record => record.state === 'accept' ? record.to :
        ['debit','refund'].includes(record.state) ? record.from : undefined;

    // Intent is saved first. A balance and its receipt are saved in one player
    // profile write. Recovery uses the receipt to finish or undo only the intent.
    function recoverIntent(p, record) {
        if (!record || actor(record) !== p.id) return;
        const receipt = profile(p).bankTransferReceipt;
        const applied = receipt?.id === record.id && receipt.phase === record.state;
        if (record.state === 'debit' && !applied) writeProperty(transferKey(record.id), undefined);
        else if (record.state === 'debit') write(record, 'pending');
        else if (record.state === 'accept') write(record, applied ? 'accepted' : 'pending');
        else write(record, applied ? 'refunded' : 'refundable');
    }
    function fresh(p) {
        assertUnlocked(p);
        const receipt = profile(p).bankTransferReceipt;
        if (receipt) recoverIntent(p, transfer(receipt.id));
        return profile(p);
    }
    function commit(p, data, record, phase, done) {
        write(record, phase);
        data.bankTransferReceipt = { id: record.id, phase };
        save(p, data);
        write(record, done);
    }
    function send(p, recipient, source, amount) {
        const data = fresh(p);
        const target = online(recipient.id);
        if (!target || target.id === p.id) throw Error('Select another player who is online.');
        const available = balance(data, source);
        if (!Number.isSafeInteger(available) || available < amount) throw Error('The source has insufficient Credits.');
        const previous = world.getDynamicProperty(SEQUENCE_KEY) ?? 0;
        if (!Number.isSafeInteger(previous) || previous < 0 || previous === Number.MAX_SAFE_INTEGER) {
            throw Error('Bank transfer sequence requires operator review.');
        }
        const id = previous + 1;
        if (transfer(id)) throw Error('Bank transfer sequence conflicts with an existing record.');
        ensureIndex();
        writeProperty(SEQUENCE_KEY, id);
        changeBalance(data, source, -amount);
        try {
            indexRecord({id,from:p.id,to:target.id});
            commit(p, data, {
                id, from: p.id, fromName: p.name, to: target.id, toName: target.name,
                source, amount, expires: Date.now() + EXPIRY_MS
            }, 'debit', 'pending');
        } catch (err) {
            console.warn('[SkyGen BANK] Send #'+id+': '+err);
            throw Error('Check Sent Transfers for #'+id+' before sending again.');
        }
        p.sendMessage('§aTransfer #'+id+' is awaiting acceptance.');
        try { target.sendMessage('§e'+p.name+' sent '+money(amount)+' Credits. Open Compass → Bank → Incoming Transfers.'); } catch {}
    }
    function refund(p, id, destination) {
        const data = fresh(p);
        const record = transfer(id);
        if (record?.from !== p.id || record.state !== 'refundable') throw Error('Refund is no longer available.');
        creditPayout(data, destination, record.amount);
        commit(p, data, record, 'refund', 'refunded');
        p.sendMessage('§aRefunded '+money(record.amount)+' Credits to '+destinationName(data,destination)+'.');
    }
    function autoRefund(record) {
        const sender = online(record.from);
        if (!sender) return;
        try {
            if (canReceive(profile(sender), record.source, record.amount)) refund(sender, record.id, record.source);
        } catch (err) { console.warn('[SkyGen BANK] Refund #'+record.id+': '+err); }
    }
    function returnTransfer(record, reason) {
        write(record, 'refundable', reason);
        autoRefund(record);
    }
    function pendingTransfer(p, id, role) {
        fresh(p);
        let record = transfer(id);
        if (record && actor(record) === p.id) {
            recoverIntent(p,record);
            record = transfer(id);
        }
        if (record?.[role] !== p.id || record.state !== 'pending') throw Error('Transfer is no longer pending.');
        if (Date.now() >= record.expires) {
            returnTransfer(record, 'Expired');
            throw Error('Transfer expired. The sender can recover the Credits.');
        }
        return record;
    }
    function accept(p, id, destination) {
        const record = pendingTransfer(p,id,'to');
        const data = profile(p);
        creditPayout(data,destination,record.amount);
        commit(p,data,record,'accept','accepted');
        p.sendMessage('§aReceived '+money(record.amount)+' Credits in '+destinationName(data,destination)+'.');
    }
    // Bounded rebuild: do not parse thousands of unrelated terminal records
    // in a single tick on first join/Bank open. All records remain intact.
    // Pending, refundable and ambiguous transfers are NEVER pruned.
    const participantIds=new Map();let indexBuilt=false,indexRebuilding=false;
    let indexCursor=0,indexKeys=[],indexStage=null;
    const BANK_INDEX_BATCH=64;
    function indexRecord(record){
        if(!record)return;
        for(const id of [record.from,record.to]){
            if(!participantIds.has(id))participantIds.set(id,new Set());
            participantIds.get(id).add(record.id);
        }
    }
    function scanBankBatch(){
        if(!indexRebuilding)return;
        try{
            let handled=0;
            while(indexCursor<indexKeys.length&&handled<BANK_INDEX_BATCH){
                const key=indexKeys[indexCursor++];handled++;
                if(!key.startsWith(TRANSFER_PREFIX))continue;
                const id=Number(key.slice(TRANSFER_PREFIX.length));
                if(!Number.isSafeInteger(id)||id<1)continue;
                let record;
                try{record=transfer(id)}catch(err){console.warn('[SkyGen BANK] history #'+id+' requires operator review: '+err);continue}
                if(!record)continue;
                for(const pid of [record.from,record.to]){
                    if(!indexStage.has(pid))indexStage.set(pid,new Set());
                    indexStage.get(pid).add(record.id);
                }
            }
            if(indexCursor>=indexKeys.length){
                participantIds.clear();for(const [pid,ids] of indexStage)participantIds.set(pid,ids);
                indexStage=null;indexKeys=[];indexBuilt=true;indexRebuilding=false;
                console.warn('[SkyGen BANK] transfer index ready; deferred history scan complete');
            }else system.runTimeout(scanBankBatch,1);
        }catch(err){
            console.warn('[SkyGen BANK] history indexing stopped for operator review: '+err);
            // Restart from scratch next attempt; never falsely report a partial index as complete.
            indexRebuilding=false;indexBuilt=false;indexKeys=[];indexStage=null;
        }
    }
    function ensureIndex(){
        if(indexBuilt)return;
        if(!system?.runTimeout){
            // Test harness / older runtimes without scheduler: preserve existing
            // immediate behavior; main production integration always supplies system.
            const staged=new Map();
            for(const key of world.getDynamicPropertyIds()){
                if(!key.startsWith(TRANSFER_PREFIX))continue;
                const id=Number(key.slice(TRANSFER_PREFIX.length));
                let record;try{record=transfer(id)}catch{continue}
                if(!record)continue;
                for(const pid of [record.from,record.to]){
                    if(!staged.has(pid))staged.set(pid,new Set());staged.get(pid).add(id);
                }
            }
            participantIds.clear();for(const [pid,ids] of staged)participantIds.set(pid,ids);
            indexBuilt=true;return;
        }
        if(!indexRebuilding){
            indexKeys=world.getDynamicPropertyIds().filter(key=>key.startsWith(TRANSFER_PREFIX));
            indexCursor=0;indexStage=new Map();indexRebuilding=true;
            system.runTimeout(scanBankBatch,1);
        }
        throw Error('Bank history is initializing safely. Please retry in a moment.');
    }
    function list(p) {
        ensureIndex();
        const entries = [];
        for (const id of (participantIds.get(p.id)??[])) {
            try {
                let record = transfer(id);
                if (!record || (record.from !== p.id && record.to !== p.id)) continue;
                const participant = online(actor(record));
                if (participant) recoverIntent(participant,record);
                record = transfer(id);
                if (!record) continue;
                if (record.state === 'pending' && Date.now() >= record.expires) {
                    returnTransfer(record,'Expired');
                    record = transfer(id);
                } else if (record.state === 'refundable' && record.from === p.id) {
                    autoRefund(record);
                    record = transfer(id);
                }
                entries.push(record);
            } catch (err) { console.warn('[SkyGen BANK] Transfer #'+id+': '+err); }
        }
        return entries.sort((a,b) => b.id-a.id);
    }

    function run(p, action) {
        try { action(); } catch (err) { p.sendMessage('§cBank: '+err.message); }
    }
    function choices(p, title, body, options) {
        form(p,title,body,options.map(([label])=>label),i=>run(p,()=>options[i]?.[1]()));
    }
    function input(p,title,label,initial,done) {
        showUI(p,skyModal().title(title).textField(label,'',{defaultValue:initial})).then(r=>{
            if (!r.canceled) run(p,()=>done(String(r.formValues?.[0]??'').trim()));
        }).catch(err=>p.sendMessage('§cBank: '+err.message));
    }
    function enterAmount(p,title,done) {
        input(p,title,'Whole Credits','',value=>{
            const amount = /^\d+$/.test(value) ? Number(value) : 0;
            if (!Number.isSafeInteger(amount) || amount < 1 || amount > CREDIT_CAP) throw Error('Enter 1 to 2,000,000,000 Credits.');
            done(amount);
        });
    }
    function confirm(p,title,body,done) {
        showUI(p,skyMessage().title(title).body(body).button1('Cancel').button2('Confirm')).then(r=>{
            if (!r.canceled && r.selection === 1) run(p,done);
        }).catch(err=>p.sendMessage('§cBank: '+err.message));
    }
    function changeAccount(p,id,action) {
        const data = fresh(p);
        const bank = bankData(data);
        const selected = bank.accounts.find(a=>a.id===id);
        if (id !== null && !selected) throw Error('This account no longer exists.');
        action(bank,selected);
        data.bank = bank;
        save(p,data);
    }
    function nameAccount(p,id) {
        const selected = id===null ? undefined : account(profile(p),id);
        input(p,id===null?'Open Bank Account':'Rename Account','Account name (1–24 characters)',selected?.name??'',name=>{
            if (!name || name.length>24 || /[§\x00-\x1f]/.test(name)) throw Error('Enter a valid account name of 1–24 characters.');
            changeAccount(p,id,(bank,current)=>{
                if (bank.accounts.some(a=>a.id!==id && a.name.toLowerCase()===name.toLowerCase())) throw Error('That name is already in use.');
                if (current) current.name=name;
                else {
                    if (bank.accounts.length>=ACCOUNT_LIMIT || bank.nextId===Number.MAX_SAFE_INTEGER) throw Error('Account limit reached.');
                    const newId=bank.nextId++;
                    bank.accounts.push({id:newId,name,credits:0});
                    bank.defaultId ??= newId;
                }
            });
            open(p);
        });
    }
    function move(p,id,deposit) {
        enterAmount(p,deposit?'Deposit Credits':'Withdraw Credits',amount=>{
            const data=fresh(p);
            const source=deposit?'wallet':id,destination=deposit?id:'wallet';
            const available=balance(data,source);
            if (!Number.isSafeInteger(available) || available<amount) throw Error('The source has insufficient Credits.');
            creditPayout(data,destination,amount);
            changeBalance(data,source,-amount);
            save(p,data);
            p.sendMessage('§aMoved '+money(amount)+' Credits to '+destinationName(data,destination)+'.');
            accountMenu(p,id);
        });
    }
    function accountMenu(p,id) {
        const selected=account(profile(p),id);
        if (!selected) return open(p);
        choices(p,selected.name,money(selected.credits)+' / '+money(CREDIT_CAP)+' Credits',[
            ['Deposit',()=>move(p,id,true)],['Withdraw',()=>move(p,id,false)],['Rename',()=>nameAccount(p,id)],
            ['Set as Default',()=>{changeAccount(p,id,bank=>{bank.defaultId=id;});open(p);}],
            ['Close Empty Account',()=>confirm(p,'Close Account',selected.name,()=>{
                changeAccount(p,id,(bank,current)=>{
                    if (current.credits!==0) throw Error('Withdraw the remaining Credits first.');
                    bank.accounts=bank.accounts.filter(a=>a.id!==id);
                    if (bank.defaultId===id) bank.defaultId=null;
                });
                open(p);
            })],['Back',()=>open(p)]
        ]);
    }
    function pickBalance(p,title,body,eligible,done,previous) {
        const data=profile(p);
        const options=['wallet',...bankData(data).accounts.map(a=>a.id)].filter(id=>eligible(data,id));
        choices(p,title,options.length?body:'No eligible destination or source is available.',[
            ...options.map(id=>[destinationName(data,id)+' · '+money(balance(data,id))+' Credits',()=>done(id)]),
            ['Back',previous]
        ]);
    }
    function sendMenu(p) {
        const recipients=world.getAllPlayers().filter(q=>q.id!==p.id);
        choices(p,'Send Credits','Choose an online player.',[
            ...recipients.map(q=>[q.name,()=>pickBalance(p,'Send Credits','Choose where to take the Credits.',
                (data,id)=>balance(data,id)>0,source=>enterAmount(p,'Send to '+q.name,amount=>{
                    confirm(p,'Confirm Transfer',q.name+' will receive '+money(amount)+' Credits from '+destinationName(profile(p),source)+'.',()=>{
                        send(p,q,source,amount);
                        open(p);
                    });
                }),()=>sendMenu(p))]),['Back',()=>open(p)]
        ]);
    }
    function transferMenu(p,record) {
        const {id,amount}=record;
        const body=record.fromName+' → '+record.toName+'\n'+money(amount)+' Credits · '+(record.reason??record.state);
        const options=[];
        if (record.state==='pending' && record.to===p.id) {
            options.push(['Accept',()=>pickBalance(p,'Accept Transfer',body,
                (data,destination)=>canReceive(data,destination,amount),destination=>{
                    accept(p,id,destination);transfers(p,true);
                },()=>transferMenu(p,record))]);
            options.push(['Decline',()=>confirm(p,'Decline Transfer',body,()=>{
                returnTransfer(pendingTransfer(p,id,'to'),'Declined');transfers(p,true);
            })]);
        }
        if (record.state==='pending' && record.from===p.id) {
            options.push(['Cancel Transfer',()=>confirm(p,'Cancel Transfer',body,()=>{
                returnTransfer(pendingTransfer(p,id,'from'),'Canceled');transfers(p,false);
            })]);
        }
        if (record.state==='refundable' && record.from===p.id) {
            options.push(['Collect Refund',()=>pickBalance(p,'Collect Refund',body,
                (data,destination)=>canReceive(data,destination,amount),destination=>{
                    refund(p,id,destination);transfers(p,false);
                },()=>transferMenu(p,record))]);
        }
        choices(p,'Transfer #'+id,body,[...options,['Back',()=>transfers(p,record.to===p.id)]]);
    }
    function transfers(p,incoming,page=0) {
        const entries=list(p).filter(r=>incoming?r.to===p.id:r.from===p.id);
        const last=Math.max(0,Math.ceil(entries.length/10)-1);
        page=Math.min(page,last);
        const options=entries.slice(page*10,page*10+10).map(r=>[
            '#'+r.id+' · '+(incoming?r.fromName:r.toName)+' · '+money(r.amount)+' · '+r.state,()=>transferMenu(p,r)
        ]);
        if (page>0) options.push(['Previous',()=>transfers(p,incoming,page-1)]);
        if (page<last) options.push(['Next',()=>transfers(p,incoming,page+1)]);
        choices(p,incoming?'Incoming Transfers':'Sent Transfers & Refunds','Page '+(page+1)+' / '+(last+1),
            [...options,['Back',()=>open(p)]]);
    }
    function open(p) {
        run(p,()=>{
            list(p);
            const data=profile(p),bank=bankData(data);
            const total=bank.accounts.reduce((sum,a)=>sum+a.credits,0);
            choices(p,'SkyGen Bank','Wallet: '+money(data.credits)+' Credits\nBank total: '+money(total)+' Credits\nDefault: '+
                (bank.defaultId===null?'None':destinationName(data,bank.defaultId)),[
                ...bank.accounts.map(a=>[a.name+' · '+money(a.credits)+' Credits',()=>accountMenu(p,a.id)]),
                ['Open Account',()=>nameAccount(p,null)],['Send Credits',()=>sendMenu(p)],
                ['Incoming Transfers',()=>transfers(p,true)],['Sent Transfers & Refunds',()=>transfers(p,false)],
                ['Collect Pending Payouts',()=>{collectPayouts(p);open(p);}],['Back',()=>back(p)]
            ]);
        });
    }
    return {open,recover: list};
}
