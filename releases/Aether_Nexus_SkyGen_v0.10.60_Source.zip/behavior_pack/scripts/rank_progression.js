// Aether Nexus Phase 2 — lossless exact integer XP storage (decimal strings).
export const MAX_RANK = 1000;
const COSTS=[0n];
for(let r=1;r<MAX_RANK;r++){
 if(r<50)COSTS[r]=1000n;
 else if(r===50)COSTS[r]=1100n;
 else COSTS[r]=(COSTS[r-1]*11n+9n)/10n;
}
const CUMULATIVE=[0n];
for(let r=1;r<MAX_RANK;r++)CUMULATIVE[r]=CUMULATIVE[r-1]+COSTS[r];
export function cumulativeXP(rank,progress){if(!Number.isSafeInteger(rank)||rank<1||rank>MAX_RANK)throw Error('Invalid rank');return CUMULATIVE[rank-1]+parseProgress(progress)}
export function transitionCost(rank){if(!Number.isSafeInteger(rank)||rank<1||rank>=MAX_RANK)throw Error('Invalid rank');return COSTS[rank]}
export function parseProgress(input){const value=String(input);if(!/^(0|[1-9][0-9]{0,80})$/.test(value))throw Error('Invalid XP string; operator recovery needed');return BigInt(value)}
export function legacyProgress(rank,xp){if(!Number.isSafeInteger(rank)||rank<1||rank>50||!Number.isSafeInteger(xp)||xp<0)throw Error('Unsafe legacy XP');return String(Math.max(0,xp-(rank-1)*1000))}
export function mirrorXP(rank,progress){const amount=parseProgress(progress);if(rank>=50)return 49000;return (rank-1)*1000+Number(amount>1000000n?1000000n:amount)}
export function advanceRank(rank,progress,award=0){if(!Number.isSafeInteger(rank)||rank<1||rank>MAX_RANK)throw Error('Invalid current rank');let xp=parseProgress(progress)+(rank===MAX_RANK?0n:parseProgress(award));let level=rank;while(level<MAX_RANK&&xp>=COSTS[level])xp-=COSTS[level++];return {rank:level,progress:xp.toString(),gained:level-rank}}
export function formattedXP(input){const str=parseProgress(input).toString();if(str.length<=12)return str.replace(/\B(?=(\d{3})+(?!\d))/g,',');return str[0]+'.'+str.slice(1,3)+'e+'+(str.length-1)}
