const MILLION = 1000000;
const materials = [
    {name: 'Deathnerite Ingot', price: 2500000, ids: ['true_dn:deathnerite_ingot']},
    {name: 'Darkness Upgrade Smithing Template', price: 5000000, ids: ['true_dn:darkness_upgrade_smithing_template']}
];
const tools = [['Shovel', 20], ['Hoe', 20], ['Axe', 25], ['Pickaxe', 25], ['Sword', 30], ['Spear', 30]];
const armor = [['Boots', 35], ['Helmet', 35], ['Leggings', 45], ['Chestplate', 55], ['Horse Armor', 60], ['Nautilus Armor', 60]];
const tiers = ['Deathnerite', 'Parcanite'];

function equipment(tier, entries, multiplier) {
    const prefix = 'true_dn:' + tier.toLowerCase() + '_';
    return entries.map(([name, millions]) => ({
        name: tier + ' ' + name,
        price: millions * multiplier * MILLION,
        ids: [prefix + name.toLowerCase().replaceAll(' ', '_')]
    }));
}

export const DEATHNERITE_SHOP = [
    {name: 'Materials & Ingredients', items: materials},
    ...tiers.flatMap((tier, index) => {
        const multiplier = index + 1;
        return [
            {name: tier + ' Tools', items: equipment(tier, tools, multiplier)},
            {name: tier + ' Armor', items: equipment(tier, armor, multiplier)}
        ];
    }),
    {name: 'Complete Armor Sets', items: tiers.map((tier, index) => {
        const pieces = equipment(tier, armor.slice(0, 4), index + 1);
        return {
            name: tier + ' Armor Set (4 pieces)',
            price: pieces.reduce((total, piece) => total + piece.price, 0),
            ids: pieces.flatMap(piece => piece.ids)
        };
    })}
];
