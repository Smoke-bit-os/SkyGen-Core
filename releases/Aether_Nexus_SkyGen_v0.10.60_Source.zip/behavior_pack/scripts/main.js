import {world,system,ItemStack,ItemLockMode,ItemTypes,BlockTypes,GameMode} from '@minecraft/server';
import {QUESTS,questDefinition,questState,recordQuestProgress,completeQuest} from './quests.js';
import {openWeeklyPreview,recordWeeklyPreviewActivity,weeklyPreviewStatus} from './weekly_preview_runtime.js';
import {openAscendedDailyPreview,recordAscendedDailyPreviewActivity,ascendedDailyStatus} from './ascended_daily_preview.js';
import {RANK_NAMES,rankLevel,rankName,sidebarStats,sidebarLines,updateNumericScores} from './numeric_scores.js';
import {equippedBadgeMarkers} from './cosmetic_badge_hud.js';
import {hudProgressMarkers} from './hud_xp_progress.js';
import {COSMETIC_BADGES,APPROVED_COSMETIC_BUNDLES,validateCosmetics,grantCosmetic,setCosmeticEquipped,validateBundle} from './cosmetic_entitlements.js';
import {DEATHNERITE_SHOP} from './deathnerite_shop.js';
import {createFarmingCatalog} from './farming_shop.js';
import {PRO_SHOP,enchantProItem,hasProEnchantments} from './pro_shop.js';
import {exactOrbitQuote} from './dual_currency_pricing.js';
import {approvedContractQuote} from './approved_economy_policy.js';
import {cumulativeXP,MAX_RANK,transitionCost,parseProgress,legacyProgress,mirrorXP,advanceRank,formattedXP} from './rank_progression.js';
import {allocateOrRecoverPlot} from './plot_claim_registry.js';
import {HELP_TOPICS,RULEBOOK_TOPIC} from './help_pages.js';
import {skyAction,skyModal,skyMessage} from './skyrealm_ui.js';
import {CREDIT_CAP,createBank,creditPayout,destinationName,payoutDestination} from './bank.js';
const C={spawn:{x:0,y:1,z:0},base:{x:512,y:106,z:512},spacing:128,columns:8,radius:24,warmup:100,cooldown:100,exchange:18000000};
const TOOLS=[{slot:6,type:'minecraft:compass',name:'§bSkyGen Menu'},{slot:7,type:'minecraft:goat_horn',name:'§6Go to Spawn'},{slot:8,type:'minecraft:goat_horn',name:'§aGo to Plot'}];
const GENS=[{"name":"Oak Logs","block":"minecraft:oak_log","cost":1800,"period":240,"category":"Starter","unlock":1},{"name":"Coal","block":"minecraft:coal_ore","cost":2500,"period":300,"category":"Starter","unlock":1},{"name":"Cobblestone","block":"minecraft:cobblestone","cost":500,"period":200,"category":"Starter","unlock":1},{"name":"Dirt","block":"minecraft:dirt","cost":500,"period":180,"category":"Starter","unlock":1},{"name":"Iron","block":"minecraft:iron_ore","cost":10000,"period":400,"category":"Mining","unlock":1},{"name":"Gold","block":"minecraft:gold_ore","cost":40000,"period":500,"category":"Mining","unlock":1},{"name":"Diamond","block":"minecraft:diamond_ore","cost":200000,"period":600,"category":"Mining","unlock":1},{"name":"Emerald","block":"minecraft:emerald_ore","cost":500000,"period":800,"category":"Mining","unlock":1},{"name":"Stone","block":"minecraft:stone","cost":700,"period":220,"category":"Mining","unlock":2},{"name":"Deepslate","block":"minecraft:deepslate","cost":1100,"period":220,"category":"Mining","unlock":3},{"name":"Gravel","block":"minecraft:gravel","cost":900,"period":220,"category":"Mining","unlock":3},{"name":"Sand","block":"minecraft:sand","cost":950,"period":220,"category":"Mining","unlock":3},{"name":"Clay","block":"minecraft:clay","cost":1200,"period":260,"category":"Mining","unlock":4},{"name":"Spruce Logs","block":"minecraft:spruce_log","cost":2200,"period":260,"category":"Nature","unlock":5},{"name":"Birch Logs","block":"minecraft:birch_log","cost":2200,"period":260,"category":"Nature","unlock":5},{"name":"Cherry Logs","block":"minecraft:cherry_log","cost":4500,"period":280,"category":"Nature","unlock":8},{"name":"Mangrove Logs","block":"minecraft:mangrove_log","cost":5200,"period":300,"category":"Nature","unlock":10},{"name":"Copper","block":"minecraft:copper_ore","cost":7500,"period":320,"category":"Mining","unlock":8},{"name":"Redstone","block":"minecraft:redstone_ore","cost":18000,"period":380,"category":"Mining","unlock":12},{"name":"Lapis Lazuli","block":"minecraft:lapis_ore","cost":24000,"period":440,"category":"Mining","unlock":16},{"name":"Nether Quartz","block":"minecraft:quartz_ore","cost":30000,"period":500,"category":"Mining","unlock":18},{"name":"Nether Gold","block":"minecraft:nether_gold_ore","cost":60000,"period":560,"category":"Mining","unlock":20},{"name":"Moss","block":"minecraft:moss_block","cost":15000,"period":300,"category":"Nature","unlock":15},{"name":"Netherrack","block":"minecraft:netherrack","cost":17500,"period":300,"category":"Nature","unlock":16},{"name":"Soul Sand","block":"minecraft:soul_sand","cost":21000,"period":360,"category":"Nature","unlock":18},{"name":"Basalt","block":"minecraft:basalt","cost":26000,"period":380,"category":"Nature","unlock":20},{"name":"Blackstone","block":"minecraft:blackstone","cost":32000,"period":400,"category":"Nature","unlock":22},{"name":"Glowstone","block":"minecraft:glowstone","cost":55000,"period":480,"category":"Nature","unlock":25},{"name":"Magma","block":"minecraft:magma","cost":65000,"period":500,"category":"Nature","unlock":27},{"name":"Calcite","block":"minecraft:calcite","cost":72000,"period":520,"category":"Nature","unlock":30},{"name":"Tuff","block":"minecraft:tuff","cost":76000,"period":520,"category":"Nature","unlock":30},{"name":"Amethyst Block","block":"minecraft:amethyst_block","cost":100000,"period":560,"category":"Nature","unlock":35},{"name":"Obsidian","block":"minecraft:obsidian","cost":150000,"period":650,"category":"Endgame","unlock":30},{"name":"Prismarine","block":"minecraft:prismarine","cost":165000,"period":660,"category":"Endgame","unlock":32},{"name":"Sea Lantern","block":"minecraft:sea_lantern","cost":190000,"period":700,"category":"Endgame","unlock":34},{"name":"End Stone","block":"minecraft:end_stone","cost":220000,"period":720,"category":"Endgame","unlock":36},{"name":"Purpur Block","block":"minecraft:purpur_block","cost":260000,"period":740,"category":"Endgame","unlock":38},{"name":"Sculk","block":"minecraft:sculk","cost":330000,"period":760,"category":"Endgame","unlock":40},{"name":"Crying Obsidian","block":"minecraft:crying_obsidian","cost":420000,"period":800,"category":"Endgame","unlock":42},{"name":"Gilded Blackstone","block":"minecraft:gilded_blackstone","cost":520000,"period":840,"category":"Endgame","unlock":44},{"name":"Shroomlight","block":"minecraft:shroomlight","cost":620000,"period":880,"category":"Endgame","unlock":46},{"name":"Ancient Debris","block":"minecraft:ancient_debris","cost":1900000,"period":1600,"category":"Endgame","unlock":48}];
for(const spec of GENS)spec.period=Math.max(20,Math.round(spec.period*0.85));
const GENERATOR_MAX_LEVEL=10;

// Stable namespaced item IDs. Keep these unchanged across future versions so
// previously purchased unused custom tokens remain valid.
const GENERATOR_ITEM_BY_NAME=new Map(GENS.map(g=>[g.name,'skygen:generator_'+g.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')]));
const GENERATOR_ITEM_TYPE_IDS=new Set(GENERATOR_ITEM_BY_NAME.values());
function generatorItemId(g){return GENERATOR_ITEM_BY_NAME.get(g.name)}
// BlockTypes.get is part of the stable Script API. A missing registry entry
// fails closed BEFORE purchase or token debit, not after the player is charged.
function validGeneratorOutput(g){
 try{return !!g&&!!BlockTypes.get(g.block)}catch(err){genError('Block registry unavailable: '+err,'catalog');return false}
}
function checkGeneratorCatalog(){
 const bad=GENS.filter(g=>!validGeneratorOutput(g));
 if(bad.length)console.warn('[SkyGen GENERATORS] UNAVAILABLE: '+bad.map(g=>g.name+'='+g.block).join('; '));
 else console.warn('[SkyGen GENERATORS] all '+GENS.length+' output blocks found in registry');
}
system.runTimeout(checkGeneratorCatalog,20);
// Names of the 42 registered in-world cores are stable; changing IDs would
// orphan already-placed custom blocks in saved Realm chunks.
const GENERATOR_CORE_BY_NAME=new Map(GENS.map(g=>[g.name,'skygen:'+g.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')+'_generator_core']));

// PUBLIC SKY REALM STARTER MINE: display blocks are at Y=2; their top face is Y=3.
// Ten mineable resources in each of five rows, with one empty column between slots.
// Core never creates these blocks before Builder has finished its last construction stage.
// Shared Minecraft scoreboard objectives, because pack dynamic properties are UUID-scoped.
const PUBLIC_MINE_SCOREBOARD='sg_public_mine',CITY_BUILD_SCOREBOARD='sg_city_build';
const PUBLIC_LEVEL_SCOREBOARD='sg_pub_gen_lv';
const PUBLIC_MINE_LEVEL_IDS=['wood','coal','cobblestone','dirt'];
function publicGeneratorLevel(block){
 const id=block==='minecraft:oak_log'?'wood':block==='minecraft:coal_ore'?'coal':block==='minecraft:cobblestone'?'cobblestone':'dirt';
 try{const raw=world.scoreboard.getObjective(PUBLIC_LEVEL_SCOREBOARD)?.getScore(id);return Math.min(10,Math.max(1,Number.isInteger(raw)?raw:1));}
 catch{return 1}
}
function publicGeneratorDelay(g){
 const lvl=publicGeneratorLevel(g.block);
 return lvl>=GENERATOR_MAX_LEVEL?1:Math.max(10,Math.round(g.delay*Math.pow(0.85,lvl-1)));
}
function publicMineAdminMenu(p){
 if(!isOperator(p))return p.sendMessage('§cRealm operator only.');
 const types=PUBLIC_STARTER_TYPES;
 form(p,'§bPUBLIC MINE LEVELS',`50 community generators • Level 1–10.
Set shared upgrades for each resource. Level 10 refills in about one tick after harvesting.`,
  [...types.map(t=>`${t.block.split(':')[1]} Lv${publicGeneratorLevel(t.block)}/10`),'Back to Admin'],i=>{
  if(i===types.length)return adminMenu(p);
  if(i>=0&&i<types.length)publicMineLevelMenu(p,types[i]);
 });
}
function publicMineLevelMenu(p,type){
 if(!isOperator(p))return p.sendMessage('§cRealm operator only.');
 const name=type.block.split(':')[1];
 form(p,'§bPUBLIC MINE: '+name,`Current level: ${publicGeneratorLevel(type.block)} / 10.
Higher levels reduce the community recharge timer.`,
  [...Array.from({length:10},(_,i)=>`Set Level ${i+1}`),'Back'],i=>{
    if(i===10)return publicMineAdminMenu(p);
    if(!isOperator(p)||i<0||i>9)return;
    try{
      let obj=world.scoreboard.getObjective(PUBLIC_LEVEL_SCOREBOARD);
      if(!obj)obj=world.scoreboard.addObjective(PUBLIC_LEVEL_SCOREBOARD,'SkyGen Community Mine Levels');
      const id=type.block==='minecraft:oak_log'?'wood':type.block==='minecraft:coal_ore'?'coal':type.block==='minecraft:cobblestone'?'cobblestone':'dirt';
      obj.setScore(id,i+1);
      if(publicGeneratorLevel(type.block)!==i+1)throw Error('Scoreboard did not save level');
      for(const g of PUBLIC_STARTER_GENERATORS)if(g.block===type.block)publicStarterDue.delete(`${g.x},${g.y},${g.z}`);
      p.sendMessage('§aPublic '+name+' generators now Level '+(i+1)+'.');
    }catch(err){p.sendMessage('§cCannot change public mine level: '+err)}
    menuAgain(p,()=>publicMineLevelMenu(p,type));
  });
}

const PUBLIC_STARTER_TYPES=[
 {block:'minecraft:oak_log',delay:60},
 {block:'minecraft:coal_ore',delay:130},
 {block:'minecraft:cobblestone',delay:100},
 {block:'minecraft:dirt',delay:80}
];
const PUBLIC_STARTER_GENERATORS=[57,61,65,69,73].flatMap(x=>
 Array.from({length:10},(_,slot)=>({x,y:2,z:72-2*slot,...PUBLIC_STARTER_TYPES[slot%4]}))
);
const PUBLIC_STARTER_MAP=new Map(PUBLIC_STARTER_GENERATORS.map(g=>[`${g.x},${g.y},${g.z}`,g]));
// Due ticks remain local to loaded chunks. On world restart, empty blocks wait a
// full delay before restoration, instead of immediately overwriting adjacent builds.
const publicStarterDue=new Map(),publicStarterBlockedWarnings=new Set();
function publicStarterAt(x,y,z){return PUBLIC_STARTER_MAP.get(`${x},${y},${z}`)}
function publicStarterEnabled(){try{return world.scoreboard.getObjective(PUBLIC_MINE_SCOREBOARD)?.getScore('ready')===1}catch{return false}}
function publicCityBuildRunning(){try{return world.scoreboard.getObjective(CITY_BUILD_SCOREBOARD)?.getScore('active')===1}catch{return false}}
function generatorCoreType(g){return GENERATOR_CORE_BY_NAME.get(g.type||g.name)||''}
function isGeneratorBase(g,base){return !!base&&(base.typeId===generatorCoreType(g)||base.typeId==='minecraft:bedrock')}
// Only migrate a bedrock block directly backed by an authenticated registry
// record; no chunk force-loading, scanning, or replacement of player builds.
function migrateGeneratorCore(g,base){
 const expected=generatorCoreType(g);
 if(!expected||!base)return false;
 if(base.typeId===expected)return true;
 if(base.typeId!=='minecraft:bedrock')return false;
 base.setType(expected);
 if(world.getDimension('overworld').getBlock({x:g.x,y:g.y,z:g.z})?.typeId!==expected)throw Error('Generator core migration not verified at '+g.x+','+g.y+','+g.z);
 return true;
}
function validTokenItemType(type,name){return type==='minecraft:goat_horn'||type===GENERATOR_ITEM_BY_NAME.get(name)}
const GEN_BY_NAME=new Map(GENS.map(g=>[g.name,g]));
const SHOP=[{name:'Cobblestone × 16',id:'minecraft:cobblestone',count:16,buy:80,sell:16},{name:'Oak Logs × 16',id:'minecraft:oak_log',count:16,buy:160,sell:32},{name:'Iron Ingots × 8',id:'minecraft:iron_ingot',count:8,buy:400,sell:80},{name:'Diamond × 1',id:'minecraft:diamond',count:1,buy:500,sell:100},{"name":"Stone","id":"minecraft:stone","count":16,"buy":128,"sell":32,"category":"Starter"},{"name":"Dirt","id":"minecraft:dirt","count":16,"buy":64,"sell":16,"category":"Starter"},{"name":"Gravel","id":"minecraft:gravel","count":16,"buy":128,"sell":32,"category":"Starter"},{"name":"Sand","id":"minecraft:sand","count":16,"buy":128,"sell":32,"category":"Starter"},{"name":"Clay","id":"minecraft:clay_ball","count":16,"buy":160,"sell":32,"category":"Starter"},{"name":"Spruce Logs","id":"minecraft:spruce_log","count":16,"buy":192,"sell":48,"category":"Starter"},{"name":"Birch Logs","id":"minecraft:birch_log","count":16,"buy":192,"sell":48,"category":"Starter"},{"name":"Cherry Logs","id":"minecraft:cherry_log","count":16,"buy":320,"sell":80,"category":"Starter"},{"name":"Copper Ingots","id":"minecraft:copper_ingot","count":8,"buy":280,"sell":64,"category":"Ores"},{"name":"Coal","id":"minecraft:coal","count":16,"buy":240,"sell":48,"category":"Ores"},{"name":"Gold Ingots","id":"minecraft:gold_ingot","count":8,"buy":800,"sell":160,"category":"Ores"},{"name":"Redstone Dust","id":"minecraft:redstone","count":16,"buy":240,"sell":64,"category":"Ores"},{"name":"Lapis Lazuli","id":"minecraft:lapis_lazuli","count":16,"buy":288,"sell":64,"category":"Ores"},{"name":"Emerald","id":"minecraft:emerald","count":1,"buy":1500,"sell":300,"category":"Ores"},{"name":"Nether Quartz","id":"minecraft:quartz","count":16,"buy":320,"sell":64,"category":"Nether"},{"name":"Netherrack","id":"minecraft:netherrack","count":16,"buy":128,"sell":32,"category":"Nether"},{"name":"Soul Sand","id":"minecraft:soul_sand","count":8,"buy":160,"sell":40,"category":"Nether"},{"name":"Blackstone","id":"minecraft:blackstone","count":16,"buy":480,"sell":128,"category":"Nether"},{"name":"Glowstone Dust","id":"minecraft:glowstone_dust","count":16,"buy":640,"sell":160,"category":"Nether"},{"name":"Magma Cream","id":"minecraft:magma_cream","count":8,"buy":800,"sell":200,"category":"Nether"},{"name":"Obsidian","id":"minecraft:obsidian","count":4,"buy":1200,"sell":320,"category":"Endgame"},{"name":"Prismarine","id":"minecraft:prismarine","count":8,"buy":1600,"sell":400,"category":"Endgame"},{"name":"End Stone","id":"minecraft:end_stone","count":8,"buy":1600,"sell":400,"category":"Endgame"},{"name":"Sculk","id":"minecraft:sculk","count":8,"buy":2400,"sell":640,"category":"Endgame"}];
// Simple vanilla food, no special NBT/dynamic properties: reuse the Server Shop transaction safeguards.
const FOOD_SHOP=[{"name":"Apple","id":"minecraft:apple","count":1,"buy":30,"sell":8,"category":"Basics"},{"name":"Bread","id":"minecraft:bread","count":1,"buy":40,"sell":10,"category":"Basics"},{"name":"Baked Potato","id":"minecraft:baked_potato","count":1,"buy":40,"sell":10,"category":"Basics"},{"name":"Carrot","id":"minecraft:carrot","count":1,"buy":18,"sell":4,"category":"Basics"},{"name":"Potato","id":"minecraft:potato","count":1,"buy":15,"sell":3,"category":"Basics"},{"name":"Beetroot","id":"minecraft:beetroot","count":1,"buy":18,"sell":4,"category":"Basics"},{"name":"Steak","id":"minecraft:cooked_beef","count":1,"buy":95,"sell":24,"category":"Cooked Meats"},{"name":"Porkchop","id":"minecraft:cooked_porkchop","count":1,"buy":85,"sell":20,"category":"Cooked Meats"},{"name":"Chicken","id":"minecraft:cooked_chicken","count":1,"buy":75,"sell":18,"category":"Cooked Meats"},{"name":"Mutton","id":"minecraft:cooked_mutton","count":1,"buy":75,"sell":18,"category":"Cooked Meats"},{"name":"Rabbit","id":"minecraft:cooked_rabbit","count":1,"buy":95,"sell":23,"category":"Cooked Meats"},{"name":"Cooked Cod","id":"minecraft:cooked_cod","count":1,"buy":65,"sell":15,"category":"Seafood"},{"name":"Cooked Salmon","id":"minecraft:cooked_salmon","count":1,"buy":85,"sell":20,"category":"Seafood"},{"name":"Dried Kelp","id":"minecraft:dried_kelp","count":1,"buy":15,"sell":3,"category":"Seafood"},{"name":"Melon Slice","id":"minecraft:melon_slice","count":1,"buy":20,"sell":4,"category":"Snacks"},{"name":"Sweet Berries","id":"minecraft:sweet_berries","count":1,"buy":20,"sell":4,"category":"Snacks"},{"name":"Glow Berries","id":"minecraft:glow_berries","count":1,"buy":28,"sell":6,"category":"Snacks"},{"name":"Cookie","id":"minecraft:cookie","count":1,"buy":24,"sell":5,"category":"Snacks"},{"name":"Pumpkin Pie","id":"minecraft:pumpkin_pie","count":1,"buy":70,"sell":15,"category":"Snacks"},{"name":"Golden Carrot","id":"minecraft:golden_carrot","count":1,"buy":180,"sell":45,"category":"Premium"},{"name":"Golden Apple","id":"minecraft:golden_apple","count":1,"buy":1400,"sell":350,"category":"Premium"},{"name":"Honey Bottle","id":"minecraft:honey_bottle","count":1,"buy":85,"sell":20,"category":"Premium"},{"name":"Mushroom Stew","id":"minecraft:mushroom_stew","count":1,"buy":90,"sell":20,"category":"Premium"},{"name":"Rabbit Stew","id":"minecraft:rabbit_stew","count":1,"buy":140,"sell":35,"category":"Premium"},{"name":"Beetroot Soup","id":"minecraft:beetroot_soup","count":1,"buy":75,"sell":18,"category":"Premium"}];
const FOOD_CATEGORIES=['Basics','Cooked Meats','Seafood','Snacks','Premium'];
const FARMING_SHOP=createFarmingCatalog([...SHOP,...FOOD_SHOP]);

const pending=new Map(),cooldowns=new Map(),generators=new Map(),trades=new Map(),visitRequests=new Map();
const genEmptySeconds=new Map();
// Limit player-initiated commands before scheduling forms or mutating state.
const playerCommandLastTick=new Map(),PLAYER_COMMAND_MIN_TICKS=10;
let genWatchdogRuns=0, genLastTick=-1, genLastError="none", genStartupTick=system.currentTick;
const genErrors=[];
// Register commands early so a later optional event subscription cannot disable them.
try{
 system.afterEvents.scriptEventReceive.subscribe(e=>{
  if(!['skygen:menu','skygen:help','skygen:adminaxe','skygen:admin','skygen:debug','skygen:marketreview','skygen:security','skygen:tokenrestore','skygen:creativeclear','skygen:tokenstatus','skygen:txnreview','skygen:txnclear','skygen:spawn','skygen:rankchat','skygen:raidstatus'].includes(e.id))return;
  const actor=e.sourceEntity;
  console.warn('[SkyGen CMD] received '+e.id+' source='+e.sourceType+' player='+(actor?.name||'none'));
  if(!actor||actor.typeId!=='minecraft:player'){console.warn('[SkyGen CMD] no player source; use command from player chat');return;}
  const last=playerCommandLastTick.get(actor.id),now=system.currentTick;
  if(last!==undefined&&now-last<PLAYER_COMMAND_MIN_TICKS)return;
  playerCommandLastTick.set(actor.id,now);
  try{actor.sendMessage('§7SkyGen received '+e.id);}catch{}
  system.run(()=>{
   try{
    if(e.id==='skygen:debug'&&!isOperator(actor))actor.sendMessage('§cRealm operator required.');
    else if(e.id==='skygen:help')helpCommand(actor,e.message);
    else if(e.id==='skygen:menu')menu(actor);
    else if(e.id==='skygen:adminaxe')issueAdminAxe(actor);
    else if(e.id==='skygen:admin')adminCommand(actor,e.message);
    else if(e.id==='skygen:marketreview')marketReviewCommand(actor);
    else if(e.id==='skygen:security')securityReviewCommand(actor);
    else if(e.id==='skygen:tokenrestore')adminTokenRestore(actor,e.message);
    else if(e.id==='skygen:tokenstatus')adminTokenStatus(actor,e.message);
    else if(e.id==='skygen:creativeclear')adminCreativeClear(actor,e.message);
    else if(e.id==='skygen:txnreview')economicTxnReviewCommand(actor,e.message);
    else if(e.id==='skygen:txnclear')economicTxnClearCommand(actor,e.message);
    else if(e.id==='skygen:spawn')spawnCommand(actor,e.message);
    else if(e.id==='skygen:rankchat')rankChatCommand(actor,e.message);
    else if(e.id==='skygen:raidstatus')raidStatusCommand(actor);
    else actor.sendMessage('§aSkyGen command handler active. OP='+isOperator(actor)+' Admin='+isAdmin(actor)+' PermissionLevel='+String(actor.playerPermissionLevel)+' isOpAPI='+String(typeof actor.isOp));
   }catch(err){console.warn('[SkyGen CMD] '+err);try{actor.sendMessage('§cSkyGen command error: '+err)}catch{}}
  });
 });
 console.warn('[SkyGen CMD] command listener registered');
}catch(err){console.warn('[SkyGen CMD] LISTENER REGISTRATION FAILED '+err)}

const GEN_REGISTRY_LIMIT=1200, GEN_REGISTRY_BYTES=12000, GEN_REGISTRY_SHARDS=24;
const GEN_STORAGE_META='sg_generators_v2_commit', GEN_STORAGE_LEGACY='sg_generators';
const GEN_BASE_SLOTS=20;
const genErrorTick=new Map();
function genError(message,key='general'){
 genLastError=String(message);
 const now=system.currentTick,last=genErrorTick.get(key)??-99999;
 if(now-last<1200)return;
 genErrorTick.set(key,now);
 genErrors.push(`${now}: ${genLastError}`);
 if(genErrors.length>20)genErrors.shift();
 console.warn('SkyGen generator: '+genLastError);
}
// Register the generator heartbeat BEFORE optional UI/event subscriptions.
// A later unsupported event must not prevent generator processing.
// Schedule independently with runTimeout; this path is independent of other intervals.
function generatorHeartbeat(){
 try{genWatchdog()}catch(e){genError('heartbeat '+e)}
 finally{system.runTimeout(generatorHeartbeat,4)}
}
system.runTimeout(generatorHeartbeat,4);
// Independent public mine loop: no dependency on a player-owned generator existing.
system.runTimeout(publicStarterHeartbeat,5);
system.runTimeout(()=>{try{genLoad()}catch(e){console.warn('SkyGen generator loading: '+e)}},40);
const MAX_LISTINGS=80, MARKET_KEY='sg_market_v1';
const keyForPlot=id=>'sg_plot_'+id;
function ownerId(id){return String(world.getDynamicProperty(keyForPlot(id))||'')}
function trusted(id){try{const a=JSON.parse(String(world.getDynamicProperty('sg_trust_'+id)||'[]'));return Array.isArray(a)?a.filter(x=>typeof x==='string'):[]}catch{return []}}
function canBuild(p,id){return id>=0&&(ownerId(id)===p.id||trusted(id).includes(p.id))}
function visitors(id){try{const a=JSON.parse(String(world.getDynamicProperty('sg_visitors_'+id)||'[]'));return Array.isArray(a)?a.filter(x=>typeof x==='string'):[]}catch{return []}}
let interactionGuardAvailable=false;
function canVisit(p,id){
 if(id<0)return false;
 if(ownerId(id)===p.id)return true;
 // Do not admit visitors when the stable container-interaction guard is missing.
 return interactionGuardAvailable&&(visitors(id).includes(p.id)||trusted(id).includes(p.id));
}
function setVisit(id,ids){world.setDynamicProperty('sg_visitors_'+id,JSON.stringify([...new Set(ids)]))}

function cityProtectionActive(){return publicStarterEnabled()||publicCityBuildRunning()}
function inBuiltSkyRealm(x,z){return cityProtectionActive()&&insideSquare({x,z},C.spawn,spawnLimit())}
const personalSpawnBuild=new Set();
function protectedAt(p,x,z,building=true){
 if(p.dimension?.id!=='minecraft:overworld')return false;
 if(inSpawn(x,z)){
  const id=plotAt(x,z);
  if(id>=0&&ownerId(id))return true;
  return !isOperator(p)||(building&&!personalSpawnBuild.has(p.id));
 }
 if(inBuiltSkyRealm(x,z))return !isOperator(p);
 const id=plotAt(x,z);
 return id>=0&&!canBuild(p,id);
}
function marketRead(){
 const raw=world.getDynamicProperty(MARKET_KEY);
 if(raw===undefined||raw===null)return [];
 let records;
 try{records=JSON.parse(String(raw))}catch{throw Error('Market data corrupt: preserving original data. Operator recovery required.')}
 if(!Array.isArray(records))throw Error('Market data has invalid structure; refusing overwrite.');
 return records;
}
function marketSave(v){
 const json=JSON.stringify(v);
 if(json.length>30000)throw Error('Marketplace persistence capacity exhausted');
 world.setDynamicProperty(MARKET_KEY,json);
 if(world.getDynamicProperty(MARKET_KEY)!==json)throw Error('Marketplace write verification failed');
 return true;
}
function inventory(p){return p.getComponent('minecraft:inventory')?.container}
function itemChoices(p){const inv=inventory(p),a=[];if(!inv)return a;for(let slot=0;slot<inv.size;slot++){const it=inv.getItem(slot);if(it&&!isTool(it)&&it.lockMode===ItemLockMode.none&&it.typeId!=='minecraft:air'&&!it.nameTag?.startsWith('§bSkyGen '))a.push({slot,it})}return a}
function fit(p,it){const inv=inventory(p);if(!inv)return false;for(let i=0;i<inv.size;i++){const q=inv.getItem(i);if(!q)return true;if(q.typeId===it.typeId&&!q.nameTag&&!it.nameTag&&q.amount+it.amount<=q.maxAmount)return true}return false}
function give(p,it){return !inventory(p)?.addItem(it)}
function removeExact(p,slot,id,count){const inv=inventory(p),it=inv?.getItem(slot);if(!it||it.typeId!==id||it.amount<count||isTool(it)||it.lockMode!==ItemLockMode.none)return false;if(it.amount===count)inv.setItem(slot,undefined);else{it.amount-=count;inv.setItem(slot,it)}return true}
function buildGenerator(g){
 const dim=world.getDimension('overworld');
 const base=dim.getBlock({x:g.x,y:g.y,z:g.z});
 const output=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
 if(!base||!output)return false;
 // New placements may NEVER overwrite player blocks or preexisting bedrock.
 // Registered legacy bedrock is migrated only in the watchdog below.
 if(!base.isAir||!output.isAir)return false;
 const core=generatorCoreType(g);
 if(!core)throw Error('Unknown generator core for '+g.type);
 try{
  base.setType(core);
  if(dim.getBlock({x:g.x,y:g.y,z:g.z})?.typeId!==core)throw Error('Generator base placement not verified');
  output.setType(g.block);
  if(dim.getBlock({x:g.x,y:g.y+1,z:g.z})?.typeId!==g.block)throw Error('Generator output placement not verified');
  return true;
 }catch(err){
  // Scope rollback to blocks this invocation created, never unrelated blocks.
  try{if(dim.getBlock({x:g.x,y:g.y+1,z:g.z})?.typeId===g.block)output.setType('minecraft:air')}catch{}
  try{if(dim.getBlock({x:g.x,y:g.y,z:g.z})?.typeId===core)base.setType('minecraft:air')}catch{}
  throw err;
 }
}
// Delete only the registered core and its expected output. On a failed block
// write, restore the previous state before the management UI restores registry.
function eraseGeneratorWorldBlocks(dim,g){
 const loc={x:g.x,y:g.y,z:g.z},above={x:g.x,y:g.y+1,z:g.z};
 const base=dim.getBlock(loc),output=dim.getBlock(above);
 if(!base||!output||!isGeneratorBase(g,base))throw Error('Registered generator base unavailable/mismatched');
 const oldBase=base.typeId,oldOutput=output.typeId;
 try{
  if(oldOutput===g.block){
   output.setType('minecraft:air');
   if(dim.getBlock(above)?.typeId!=='minecraft:air')throw Error('Output erase not verified');
  }
  base.setType('minecraft:air');
  if(dim.getBlock(loc)?.typeId!=='minecraft:air')throw Error('Core erase not verified');
 }catch(err){
  // Restore only if the current block is air; never overwrite player changes.
  try{if(dim.getBlock(loc)?.typeId==='minecraft:air')base.setType(oldBase)}catch(e){genError('CRITICAL core delete rollback '+e,'rollback')}
  try{if(oldOutput===g.block&&dim.getBlock(above)?.typeId==='minecraft:air')output.setType(oldOutput)}catch(e){genError('CRITICAL output delete rollback '+e,'rollback')}
  throw err;
 }
}
// Two-bank / multi-key registry. Never truncate records or overwrite the
// legacy sg_generators backup. The commit marker is the final atomic write.
let generatorRegistryLoaded=false;
function generatorChecksum(raw){
 let h=2166136261;for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}
 return (h>>>0).toString(16);
}
function generatorChunks(raw){
 const chunks=[];for(let i=0;i<raw.length;i+=GEN_REGISTRY_BYTES)chunks.push(raw.slice(i,i+GEN_REGISTRY_BYTES));
 return chunks.length?chunks:['[]'];
}
function generatorRead(){
 const metaRaw=world.getDynamicProperty(GEN_STORAGE_META);
 if(metaRaw===undefined||metaRaw===null){
  const legacy=world.getDynamicProperty(GEN_STORAGE_LEGACY);
  return legacy===undefined||legacy===null?[]:JSON.parse(String(legacy));
 }
 const meta=JSON.parse(String(metaRaw));
 if(!meta||meta.v!==2||![0,1].includes(meta.bank)||!Number.isSafeInteger(meta.chunks)||meta.chunks<1||meta.chunks>GEN_REGISTRY_SHARDS||typeof meta.checksum!=='string')throw Error('Invalid generator v2 manifest');
 let raw='';for(let i=0;i<meta.chunks;i++){
  const part=world.getDynamicProperty('sg_g2_'+meta.bank+'_'+i);
  if(typeof part!=='string')throw Error('Missing generator data shard '+i);
  raw+=part;
 }
 if(generatorChecksum(raw)!==meta.checksum)throw Error('Generator registry checksum failed; backup preserved');
 const records=JSON.parse(raw);
 if(!Array.isArray(records)||records.length!==meta.records)throw Error('Generator registry record count invalid');
 return records;
}
function genSave(){
 try{
  if(!generatorRegistryLoaded)throw Error('Generator registry has not loaded safely');
  if(generators.size>GEN_REGISTRY_LIMIT)throw Error('Generator registry limit reached');
  const raw=JSON.stringify([...generators]);
  const chunks=generatorChunks(raw);
  if(chunks.length>GEN_REGISTRY_SHARDS)throw Error('Generator registry storage full; no records discarded');
  const previous=world.getDynamicProperty(GEN_STORAGE_META);
  const previousMeta=previous===undefined||previous===null?null:JSON.parse(String(previous));
  const bank=previousMeta?.bank===0?1:0;
  for(let i=0;i<chunks.length;i++){
   const key='sg_g2_'+bank+'_'+i;
   world.setDynamicProperty(key,chunks[i]);
   if(world.getDynamicProperty(key)!==chunks[i])throw Error('Generator shard write not verified '+i);
  }
  const meta=JSON.stringify({v:2,bank,chunks:chunks.length,records:generators.size,checksum:generatorChecksum(raw)});
  world.setDynamicProperty(GEN_STORAGE_META,meta);
  if(world.getDynamicProperty(GEN_STORAGE_META)!==meta)throw Error('Generator commit marker write failed');
  return true;
 }catch(e){genError('save '+e,'save');return false}
}
function genLoad(){
 try{
  const records=generatorRead();
  if(!Array.isArray(records))throw Error('Invalid generator registry');
  const incoming=new Map();
  for(const entry of records){
   if(!Array.isArray(entry)||entry.length!==2)throw Error('Invalid generator entry');
   const [k,v]=entry;
   if(typeof k!=='string'||!v||!GENS.some(g=>g.name===v.type)||!Number.isFinite(v.x)||!Number.isFinite(v.y)||!Number.isFinite(v.z))throw Error('Invalid generator '+k);
   if(incoming.has(k))throw Error('Duplicate generator '+k);
   incoming.set(k,v);
  }
  if(incoming.size>GEN_REGISTRY_LIMIT)throw Error('Generator registry exceeds maximum; data preserved');
  // Change only the expected output field for authenticated old Quartz records;
  // NEVER replace any existing physical block during this data migration.
  let quartzMigrated=0;
  for(const [,v] of incoming)if(v.type==='Nether Quartz'&&v.block==='minecraft:nether_quartz_ore'){
   v.block='minecraft:quartz_ore';quartzMigrated++;
  }
  generators.clear();for(const [k,v] of incoming)generators.set(k,v);
  generatorRegistryLoaded=true;
  if(quartzMigrated){
   if(!genSave())throw Error('Quartz registry migration did not commit; generator editing disabled');
   console.warn('[SkyGen GENERATORS] migrated '+quartzMigrated+' Quartz registry output ID(s), without touching world blocks');
  }
 }catch(e){generatorRegistryLoaded=false;genError('CRITICAL registry load failed; persistence disabled: '+e,'load')}
}
function playerByName(name){return world.getAllPlayers().find(q=>q.name.toLowerCase()===String(name).toLowerCase())}

const SPAWN_PAD_RADIUS=12;
const forcefieldTickets=new Map();
const PLOT_TIERS=[{radius:24,cost:0,name:'Starter 49×49'},{radius:40,cost:250000,name:'Expanded 81×81'},{radius:56,cost:1000000,name:'Estate 113×113'}];
function plotRadius(id){const n=Number(world.getDynamicProperty('sg_plot_radius_'+id)??24);return [24,40,56].includes(n)?n:24}

// Independent from plot-owned generator registry. It runs even when no player
// has purchased a private generator, and it does not touch any other spawn block.
// Event-driven immediate refill for public Level 10 mine blocks.
function refillPublicInstant(g){
 try{
  if(!publicStarterEnabled()||publicGeneratorLevel(g.block)<GENERATOR_MAX_LEVEL)return;
  const key=`${g.x},${g.y},${g.z}`,dim=world.getDimension('overworld');
  const block=loadedPlotBlock(dim,g.x,g.y,g.z);
  if(!block||!block.isAir)return;
  block.setType(g.block);
  if(block.typeId!==g.block)throw Error('Public instant refill verification failed');
  publicStarterDue.delete(key);
 }catch(err){console.warn('[SkyGen PUBLIC MINE] fast refill failed '+err)}
}
function publicStarterHeartbeat(){
 try{
  if(!publicStarterEnabled()){publicStarterDue.clear();return}
  const dim=world.getDimension('overworld');
  for(const gen of PUBLIC_STARTER_GENERATORS){
   const key=`${gen.x},${gen.y},${gen.z}`;
   const block=loadedPlotBlock(dim,gen.x,gen.y,gen.z);
   if(!block)continue; // chunk unavailable; do not treat unloaded as an empty block
   if(block.typeId===gen.block){publicStarterDue.delete(key);publicStarterBlockedWarnings.delete(key);continue}
   if(!block.isAir){
    publicStarterDue.delete(key);
    if(!publicStarterBlockedWarnings.has(key)){
     publicStarterBlockedWarnings.add(key);
     console.warn('[SkyGen PUBLIC MINE] Non-air block at '+key+' ('+block.typeId+'); will not overwrite it.');
    }
    continue;
   }
   if(!publicStarterDue.has(key)){publicStarterDue.set(key,system.currentTick+publicGeneratorDelay(gen));continue}
   if(system.currentTick<publicStarterDue.get(key))continue;
   try{
    block.setType(gen.block);
    if(block.typeId!==gen.block)throw Error('Output type verification failed');
    publicStarterDue.delete(key);
   }catch(err){console.warn('[SkyGen PUBLIC MINE] Cannot regenerate '+key+': '+err)}
  }
 }catch(err){console.warn('[SkyGen PUBLIC MINE] heartbeat '+err)}
 finally{system.runTimeout(publicStarterHeartbeat,5)}
}

// Fixed original SkyGen spawn. Ignore older v0.9.7 movable-spawn settings;
// leave those legacy properties untouched for safe backup/rollback.
// Versioned, operator-verified arrival anchor. Previous movable-spawn keys are
// deliberately ignored; an OP must explicitly confirm the actual platform.
const SPAWN_ANCHOR_KEY='sg_spawn_anchor_v0103';
function spawnPosition(){
 try{
  const raw=world.getDynamicProperty(SPAWN_ANCHOR_KEY);
  if(typeof raw!=='string')return C.spawn;
  const c=JSON.parse(raw);
  if(c&&['x','y','z'].every(k=>Number.isSafeInteger(c[k]))&&Math.abs(c.x)<=29000000&&Math.abs(c.z)<=29000000&&c.y>=-63&&c.y<=317)return {x:c.x,y:c.y,z:c.z};
 }catch(e){console.warn('[SkyGen SPAWN] invalid anchor; using original '+e)}
 return C.spawn;
}
function spawnIsOriginal(){const s=spawnPosition();return s.x===C.spawn.x&&s.y===C.spawn.y&&s.z===C.spawn.z}
function spawnLimit(){return 116}
function plotUpgradeMenu(p){
 const d=profile(p),id=d.plot;
 if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cPlot owner required.');
 const radius=plotRadius(id);
 const summary=PLOT_TIERS.map(t=>(t.radius===radius?'§aCURRENT  ':t.radius<radius?'§8OWNED  ':'§dLOCKED  ')+t.name+'  §6'+(t.cost?t.cost.toLocaleString()+' Credits':'Free')).join('\n');
 const next=PLOT_TIERS.find(t=>t.radius>radius);
 form(p,'Plot Expansion','§6Royal Land Registry\n'+summary+'\n\n§eWallet: '+Number(d.credits).toLocaleString()+' Credits\n§7Upgrades increase the protected boundary without moving your plot.',
 [next?'Review Next Upgrade':'Maximum Tier Reached','Back to My Plot'],i=>{
  if(i===1)return plotMenu(p);
  if(i===0&&next)return plotUpgradeConfirmMenu(p);
  return plotMenu(p);
 });
}
function plotUpgradeConfirmMenu(p){const d=profile(p),id=d.plot;if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cPlot owner required.');const r=plotRadius(id);const next=PLOT_TIERS.find(t=>t.radius>r);if(!next)return p.sendMessage('§aMaximum plot size purchased.');
 try{recoverEconomicTxn(p);if(readEconomicTxn(p))return p.sendMessage('§cEconomic transaction pending operator review.')}catch(e){return p.sendMessage('§cEconomic recovery failed: '+e)}
 showUI(p,skyMessage().title('§aEXPAND YOUR PLOT').body(`Current: ${2*r+1}×${2*r+1}\nNext: ${next.name}\nUpgrade price: ${next.cost.toLocaleString()} Credits\nBalance: ${d.credits.toLocaleString()} Credits\nThe boundary expands without resetting your existing structures.`).button1('Cancel').button2('Buy Upgrade')).then(res=>{if(res.canceled)return;if(res.selection!==1)return menuAgain(p,()=>plotUpgradeMenu(p));try{const fresh=profile(p);if(fresh.plot!==id||ownerId(id)!==p.id||plotRadius(id)!==r)return p.sendMessage('§cPlot state changed. Retry.');if(fresh.credits<next.cost)return p.sendMessage('§cInsufficient Credits.');
 // Commit a pending world journal BEFORE changing the profile. Profile debit and
 // transaction ID are a single player dynamic-property write.
 if(plotOverlapsProtection(id,next.radius))return p.sendMessage('§cThis expansion would overlap protected spawn or city land. No Credits charged.');
 const tx=beginEconomicTxn(p,'plot',{plot:id,oldRadius:r,newRadius:next.radius,cost:next.cost});
 try{
  const balance=profile(p);if(balance.credits<next.cost)throw Error('Credits changed before payment');
  balance.credits-=next.cost;balance.sg_last_econ_txn=tx.id;save(p,balance);
  world.setDynamicProperty('sg_plot_radius_'+id,next.radius);
  if(plotRadius(id)!==next.radius)throw Error('Plot entitlement could not be verified');
  endEconomicTxn(p,tx,true);
 }catch(err){economicTxnReview(p,tx,'Upgrade interrupted: '+err);throw err}
 p.sendMessage(`§aPlot upgraded to ${next.name}! Credits charged: ${next.cost.toLocaleString()}.`);
 }catch(err){p.sendMessage('§cPlot upgrade failed: '+err)}finally{menuAgain(p,()=>plotUpgradeMenu(p))}}).catch(e=>p.sendMessage('§cUpgrade menu error: '+e));
}
const showTeleportText=(p,text)=>{raidAnnouncementUntil=Math.max(raidAnnouncementUntil,system.currentTick+35);try{p.onScreenDisplay.setTitle(text,{fadeInDuration:0,stayDuration:20,fadeOutDuration:0})}catch{}try{p.onScreenDisplay.setActionBar(text)}catch{}};
// Damage sanctuary is limited to the central citadel island, NOT its bridges.
// Citadel blueprint occupies x/z -48..48; use a conservative circular footprint
// so the four connecting paths are outside the no-kill boundary.
function isCentralIslandSanctuary(x,z){
 // Exact octagon footprint from the Sky Realm Builder citadel Y=0 floor.
 // Bridges begin beyond |x| or |z|=23; protect ALL elevations above/below floor.
 const dx=Math.abs(Math.floor(x)-C.spawn.x),dz=Math.abs(Math.floor(z)-C.spawn.z);
 return dx<=23&&dz<=23&&(dx+dz)<=37;
}
function insideSquare(point,center,radius){
 return Math.abs(point.x-center.x)<=radius&&Math.abs(point.z-center.z)<=radius;
}
function inSpawn(x,z){return insideSquare({x,z},spawnPosition(),spawnLimit())}
function plotOverlapsProtection(id,radius,anchor=spawnPosition()){
 const center=coords(id);
 return insideSquare(center,anchor,spawnLimit()+radius)||
  (cityProtectionActive()&&insideSquare(center,C.spawn,spawnLimit()+radius));
}
function overlappingPlots(anchor,radius,ownedOnly=false){
 const reach=spawnLimit()+radius;
 const firstCol=Math.max(0,Math.ceil((anchor.x-reach-C.base.x)/C.spacing));
 const lastCol=Math.min(C.columns-1,Math.floor((anchor.x+reach-C.base.x)/C.spacing));
 const firstRow=Math.max(0,Math.ceil((anchor.z-reach-C.base.z)/C.spacing));
 const lastRow=Math.min(Math.floor(64000/C.columns),Math.floor((anchor.z+reach-C.base.z)/C.spacing));
 const ids=[];
 for(let row=firstRow;row<=lastRow;row++)for(let col=firstCol;col<=lastCol;col++){
  const id=row*C.columns+col;
  if(id<=64000&&(!ownedOnly||(ownerId(id)&&insideSquare(coords(id),anchor,spawnLimit()+plotRadius(id)))))ids.push(id);
 }
 return ids;
}
function spawnFloorBlock(dim,x,y,z){return loadedPlotBlock(dim,x,y,z)}
function orderedLandingOffsets(radius){
 const points=[];
 for(let dx=-radius;dx<=radius;dx++)for(let dz=-radius;dz<=radius;dz++)points.push([dx,dz]);
 return points.sort((a,b)=>a[0]**2+a[1]**2-b[0]**2-b[1]**2);
}
const SPAWN_LANDING_OFFSETS=orderedLandingOffsets(SPAWN_PAD_RADIUS);
const PLOT_LANDING_OFFSETS=orderedLandingOffsets(8);
const UNSAFE_LANDING_FLOORS=new Set(['minecraft:water','minecraft:flowing_water','minecraft:lava',
 'minecraft:flowing_lava','minecraft:magma','minecraft:fire','minecraft:soul_fire','minecraft:cactus',
 'minecraft:powder_snow','minecraft:campfire','minecraft:soul_campfire','minecraft:sweet_berry_bush']);
// Stable runtimes may omit Block.isSolid. Use common full blocks as the conservative fallback.
const KNOWN_LANDING_FLOORS=new Set(['stone','cobblestone','stonebrick','stone_bricks','dirt','grass_block',
 'coarse_dirt','deepslate','cobbled_deepslate','polished_deepslate','blackstone','polished_blackstone','polished_blackstone_bricks',
 'bedrock','obsidian','crying_obsidian','glass','bricks','brick_block','netherrack','end_stone','smooth_stone',
 'quartz_block','purpur_block','prismarine','sea_lantern','terracotta','hardened_clay','sandstone','red_sandstone',
 'polished_andesite','polished_diorite','polished_granite','andesite','diorite','granite','grass']);
function safeLandingFloor(block){
 try{
  if(!block||block.isAir||block.isLiquid||block.isWaterlogged||UNSAFE_LANDING_FLOORS.has(block.typeId))return false;
  if(typeof block.isSolid==='boolean')return block.isSolid;
  if(!block.typeId.startsWith('minecraft:'))return false;
  const id=block.typeId.slice(10);
  return KNOWN_LANDING_FLOORS.has(id)||/_(planks|concrete|terracotta|wool|stained_glass|log|stem)$/.test(id);
 }catch{return false}
}
function findSafeLanding(center,offsets,floorLevels,isAllowed,arrivalOffset){
 const dim=world.getDimension('overworld');
 for(const [dx,dz] of offsets){
  const x=center.x+dx,z=center.z+dz;
  if(!isAllowed(x,z))continue;
  for(const floor of floorLevels){
   if(!safeLandingFloor(loadedPlotBlock(dim,x,floor,z)))continue;
   if([1,2,3].every(dy=>loadedPlotBlock(dim,x,floor+dy,z)?.isAir))
    return {x:x+0.5,y:floor+arrivalOffset,z:z+0.5};
  }
 }
 return undefined;
}
function spawnLanding(){
 const s=spawnPosition();
 return findSafeLanding(s,SPAWN_LANDING_OFFSETS,[s.y-1],(x,z)=>{
  const id=plotAt(x,z);
  return inSpawn(x,z)&&(id<0||!ownerId(id));
 },1);
}
function spawnDiagnostics(){
 const s=spawnPosition(),dim=world.getDimension('overworld');
 const floor=spawnFloorBlock(dim,s.x,s.y-1,s.z),feet=spawnFloorBlock(dim,s.x,s.y,s.z);
 return {anchor:s,chunkLoaded:!!floor&&!!feet,centerFloor:!!floor&&!floor.isAir,centerHeadroom:!!feet&&[0,1,2].every(dy=>spawnFloorBlock(dim,s.x,s.y+dy,s.z)?.isAir),landing:spawnLanding()};
}
// Create the original spawn platform once per world (air-only: no player builds overwritten).
// All protected spawn coordinates are fixed to x/z -12..12, with a floor at Y=0.
// This is designed for the SkyGen void-world origin. Natural terrain that blocks
// the landing is NOT cleared, and the script never silently moves spawn.
const FIXED_SPAWN_FLOOR_KEY='sg_fixed_spawn_floor_v098';
let fixedSpawnDefaultApplied=false,spawnAreaActive=false;
function createSpawn(){
 try{
  const dim=world.getDimension('overworld'),s=spawnPosition();
  // Avoid issuing commands against an unloaded destination.
  if(!spawnFloorBlock(dim,s.x,s.y-1,s.z))return false;
  try{dim.runCommand(`fill ${s.x-SPAWN_PAD_RADIUS} ${s.y-1} ${s.z-SPAWN_PAD_RADIUS} ${s.x+SPAWN_PAD_RADIUS} ${s.y-1} ${s.z+SPAWN_PAD_RADIUS} stone_bricks keep`)}
  catch(err){console.warn('[SkyGen] air-only spawn platform fill: '+err)}
  if(!spawnLanding())return false;
  world.setDynamicProperty(FIXED_SPAWN_FLOOR_KEY,true);
  return true;
 }catch(err){console.warn('[SkyGen] fixed spawn platform setup failed: '+err);return false}
}
function syncFixedDefaultSpawn(){
 if(fixedSpawnDefaultApplied)return true;
 const s=spawnPosition(),dim=world.getDimension('overworld');
 try{dim.runCommand(`setworldspawn ${s.x} ${s.y} ${s.z}`);fixedSpawnDefaultApplied=true;return true}
 catch(err){
  try{world.setDefaultSpawnLocation({...s});fixedSpawnDefaultApplied=true;return true}
  catch(fallback){console.warn('[SkyGen] fixed worldspawn failed '+err+' / '+fallback);return false}
 }
}
function ensureSpawn(){
 // Migrate worlds from v0.9.7 even if its stale sg_spawn_ready flag is true.
 if(spawnIsOriginal()&&world.getDynamicProperty(FIXED_SPAWN_FLOOR_KEY)!==true)createSpawn();
 const target=spawnLanding();
 if(!target)return undefined; // Never teleport into a blocked or absent platform.
 syncFixedDefaultSpawn();
 if(world.getDynamicProperty('sg_spawn_ready')!==true)world.setDynamicProperty('sg_spawn_ready',true);
 return target;
}
// Keep one fixed origin area loaded so that menu/horn teleports work from remote plots.
// Do not remove it when a teleport completes: this is the permanent public spawn.
// v0.10.7 targeted hotfix: never report success for a rejected command.
// A named ticking area survives reloads, so REUSE it on routine boots/horn use.
// Only deliberately replace it when an operator changes the spawn anchor.
function stageFixedSpawnArea(replace=false){
 const s=spawnPosition(),dim=world.getDimension('overworld');
 spawnAreaActive=false;
 try{
  if(replace){
   try{dim.runCommand('tickingarea remove sg_spawn_safe')}catch(err){
    console.warn('[SkyGen SPAWN] previous spawn area removal: '+err);
   }
  }else{
   // A previously registered area needs preload, not remove + recreate.
   // Never trust cached flags or a command that returned successCount:0.
   try{
    const existing=dim.runCommand('tickingarea preload sg_spawn_safe true');
    if(existing?.successCount>0){spawnAreaActive=true;return true}
   }catch(err){/* Missing named area: attempt to add it. */}
  }
  const added=dim.runCommand(`tickingarea add circle ${s.x} ${s.y} ${s.z} 1 sg_spawn_safe true`);
  if(!added||added.successCount<=0)throw Error('Minecraft rejected spawn ticking area creation (limit or duplicate name)');
  spawnAreaActive=true;return true;
 }catch(err){
  console.warn('[SkyGen SPAWN] unable to stage area at '+s.x+','+s.y+','+s.z+': '+err);
  spawnAreaActive=false;return false;
 }
}
const spawnStages=new Map();
function safeSpawnTravel(p,immediate=false){
 if(!p?.isValid)return;
 const begin=system.currentTick,id=p.id;
 if(spawnStages.has(id))return;
 if(!immediate&&pending.has(id))return p.sendMessage('§eTeleport already counting down.');
 if(!immediate&&system.currentTick<(cooldowns.get(id)||0))return p.sendMessage('§cTeleport cooldown is active.');
 const state={finished:false},dim=world.getDimension('overworld');
 spawnStages.set(id,state);
 function release(){
  if(state.finished)return;
  state.finished=true;
  if(spawnStages.get(id)===state)spawnStages.delete(id);
 }
 state.release=release;
 function check(){
  if(state.finished)return;
  if(!p.isValid){release();return}
  // Force loaded spawn before validating landing; retry while a stale plot
  // ticking area is being cleaned up. Never consume the warm-up on failure.
  if(!stageFixedSpawnArea()){
   if(system.currentTick-begin>240){
    p.sendMessage('§cSpawn ticking area could not be prepared. Operator: /tickingarea list all-dimensions');
    release();return;
   }
   system.runTimeout(check,10);return;
  }
  let target;
  try{target=ensureSpawn()}catch(e){console.warn('[SkyGen] fixed spawn verification '+e)}
  if(target){
   if(immediate){
    try{
     forcefieldTickets.set(id,{...target,expires:system.currentTick+5});
     if(typeof p.tryTeleport==='function'){if(!p.tryTeleport(target,{dimension:dim,checkForBlocks:false}))throw Error('Spawn chunk not ready')}
     else p.teleport(target,{dimension:dim,checkForBlocks:false});
     cooldowns.set(id,system.currentTick+teleportCooldown(p));
     p.sendMessage('§aSafe SkyGen spawn reached.');
    }catch(e){forcefieldTickets.delete(id);p.sendMessage('§cSpawn rescue unavailable; verify origin chunks: '+e)}
    release();
   }else{
    if(!tpRequest(p,target,'spawn',undefined,release,true))release();
   }
   return;
  }
  if(system.currentTick-begin>240){const s=spawnPosition();p.sendMessage('§cSpawn unavailable at '+s.x+', '+s.y+', '+s.z+'. Realm operator: /scriptevent skygen:spawn status');release();return}
  system.runTimeout(check,10);
 }
 system.runTimeout(check,immediate?1:10);
}
function bootFixedSpawn(attempt=0){
 const staged=stageFixedSpawnArea();
 try{if(staged&&ensureSpawn())return}catch(err){console.warn('[SkyGen] boot spawn check '+err)}
 if(attempt<39)system.runTimeout(()=>bootFixedSpawn(attempt+1),10);
 else console.warn('[SkyGen] spawn at '+JSON.stringify(spawnPosition())+' is blocked/unloaded. Operator can check /scriptevent skygen:spawn status.');
}
function profile(p){
 const defaults={credits:1000,orbits:0,rank:1,xp:0,xpProgress:'0',plot:-1};
 const raw=p.getDynamicProperty('sg_profile');
 if(raw===undefined||raw===null)return defaults;
 if(typeof raw!=='string')throw Error('SkyGen profile storage is invalid; refusing to reset player data');
 let data;try{data=JSON.parse(raw)}catch{throw Error('SkyGen player profile is corrupt. Operator recovery required; data not overwritten.')}
 if(!data||typeof data!=='object'||Array.isArray(data))throw Error('SkyGen profile has invalid structure');
 for(const name of ['credits','orbits','rank','xp','plot']){
  const v=data[name];if(v!==undefined&&(!Number.isSafeInteger(v)||v< (name==='plot'?-1:0)))throw Error('SkyGen profile has invalid '+name+'; data not overwritten');
 }
 if(data.rank!==undefined&&(data.rank<1||data.rank>MAX_RANK))throw Error('Invalid rank; profile unchanged');
 const level=data.rank||1;
 const xpProgress=data.xpProgress===undefined?legacyProgress(Math.min(level,50),data.xp??0):data.xpProgress;
 parseProgress(xpProgress);
 // Numeric XP is a compatibility mirror, not the 1,000-rank source of truth.
 const xp=data.xpProgress===undefined?mirrorXP(level,xpProgress):(data.xp??mirrorXP(level,xpProgress));
 return {...defaults,...data,xp,xpProgress};
}
function save(p,d){
 // A review lock blocks unrelated credit changes, including rank rewards,
 // conversions and purchases, until an operator reconciles the journal.
 const journal=readEconomicTxn(p);
 if(journal&&journal.state!=='complete'&&!activeEconomicTxns.has(p.id)&&!economicReconcileBypass.has(p.id)){
  const before=profile(p);
  if(d.credits!==before.credits||JSON.stringify(d.bank)!==JSON.stringify(before.bank)||
     JSON.stringify(d.bankTransferReceipt)!==JSON.stringify(before.bankTransferReceipt))
   throw Error('Credits locked by pending economic review '+journal.id);
 }
 if(d.xpProgress===undefined)d.xpProgress=legacyProgress(Math.min(d.rank,50),d.xp||0);
 parseProgress(d.xpProgress);
 const json=JSON.stringify(d);
 p.setDynamicProperty('sg_profile',json);
 if(p.getDynamicProperty('sg_profile')!==json)throw Error('Player profile did not persist');
}
// v0.9.10 durable, fail-closed economic transaction journal. An ambiguous
// crash never triggers an automatic item or Credits refund; staff reconcile.
// One record per player and one in-flight mutation per tick/callback.
const activeEconomicTxns=new Set();
const economicReconcileBypass=new Set();
let economicTxnSequence=0;
function economicTxnKey(p){return 'sg_econ_journal_'+p.id}
function readEconomicTxn(p){
 const raw=world.getDynamicProperty(economicTxnKey(p));
 if(raw===undefined||raw===null)return null;
 const tx=JSON.parse(String(raw));
 if(!tx||tx.v!==1||typeof tx.id!=='string'||!['plot','buy','sell','gen','quest_fish','contract'].includes(tx.kind)||typeof tx.state!=='string')throw Error('Economic journal damaged; staff review needed');
 return tx;
}
function assertBankUnlocked(p){
 const journal=readEconomicTxn(p);
 if(journal&&journal.state!=='complete')throw Error('Economy locked by pending review '+journal.id);
}
function writeEconomicTxn(p,tx){
 const raw=tx===null?undefined:JSON.stringify(tx);
 world.setDynamicProperty(economicTxnKey(p),raw);
 if(world.getDynamicProperty(economicTxnKey(p))!==raw)throw Error('Economic journal write not verified');
}
function beginEconomicTxn(p,kind,details){
 if(activeEconomicTxns.has(p.id))throw Error('Another transaction is active');
 recoverEconomicTxn(p);
 if(readEconomicTxn(p))throw Error('Transaction awaiting operator reconciliation: /scriptevent skygen:txnreview');
 activeEconomicTxns.add(p.id);
 try{
  const tx={v:1,id:'t'+Date.now()+'_'+system.currentTick+'_'+(++economicTxnSequence)+'_'+p.id,kind,state:'prepared',before:profile(p).credits,...details};
  writeEconomicTxn(p,tx);
  return tx;
 }catch(e){activeEconomicTxns.delete(p.id);throw e}
}
function advanceEconomicTxn(p,tx,state){
 const current=readEconomicTxn(p);
 if(!current||current.id!==tx.id)throw Error('Economic journal changed during transaction');
 writeEconomicTxn(p,{...current,state});
}
function endEconomicTxn(p,tx,complete){
 try{
  if(complete){advanceEconomicTxn(p,tx,'complete');writeEconomicTxn(p,null)}
 }finally{activeEconomicTxns.delete(p.id)}
}
function economicTxnReview(p,tx,reason){
 try{const current=readEconomicTxn(p);if(current?.id===tx.id)writeEconomicTxn(p,{...current,state:'review',reason:String(reason).slice(0,140)})}
 catch(e){console.warn('[SkyGen SECURITY] journal review write failed '+p.id+' '+e)}
 activeEconomicTxns.delete(p.id);
 console.warn('[SkyGen ECON] LOCKED '+p.id+' tx='+tx.id+' '+reason);
 try{p.sendMessage('§cEconomic transaction '+tx.id+' requires operator reconciliation. Do not retry the transaction.')}catch{}
}
function recoverEconomicTxn(p){
 const tx=readEconomicTxn(p);
 if(!tx)return;
 if(tx.state==='complete'){writeEconomicTxn(p,null);return}
 const d=profile(p),paid=d.sg_last_econ_txn===tx.id;
 if(tx.kind==='plot'&&tx.state==='prepared'){
  const current=plotRadius(tx.plot);
  if(paid&&d.credits===tx.before-tx.cost&&[tx.oldRadius,tx.newRadius].includes(current)){
   // The debit and nonce are in ONE profile write. Never debit a second time.
   if(current===tx.oldRadius){
    if(plotOverlapsProtection(tx.plot,tx.newRadius)){economicTxnReview(p,tx,'Pending paid upgrade overlaps spawn or city; resolve before applying.');return}
    world.setDynamicProperty('sg_plot_radius_'+tx.plot,tx.newRadius);
   }
   if(plotRadius(tx.plot)!==tx.newRadius)throw Error('Plot entitlement recovery failed');
   advanceEconomicTxn(p,tx,'complete');writeEconomicTxn(p,null);return;
  }
  if(!paid&&d.credits===tx.before&&current===tx.oldRadius){writeEconomicTxn(p,null);return}
 }
 if(tx.kind==='contract'&&tx.state==='prepared'){
  try{
   const field=contractClaimField(tx.kindContract),record=d[field];
   const claimed=record?.period===tx.period&&Array.isArray(record.ids)&&record.ids.includes(tx.quest);
   const balance=tx.destination==='wallet'?d.credits:d.bank?.accounts?.find(a=>a.id===tx.destination)?.credits;
   if(paid&&claimed&&balance===tx.destinationBefore+tx.total&&d.orbits===tx.beforeOrbits+tx.orbits){
    advanceEconomicTxn(p,tx,'complete');writeEconomicTxn(p,null);return;
   }
   if(!paid&&!claimed&&d.credits===tx.before&&d.orbits===tx.beforeOrbits&&balance===tx.destinationBefore){
    writeEconomicTxn(p,null);return;
   }
  }catch(err){console.warn('[SkyGen CONTRACT] Recovery needs review '+err)}
 }
 if((tx.kind==='buy'||tx.kind==='gen')&&tx.state==='prepared'&&!paid&&d.credits===tx.before){writeEconomicTxn(p,null);return}
 // A seller may have already had inventory removed; NEVER auto-restore.
 // A buyer may have received items; NEVER auto-refund or redeliver.
 if(tx.state!=='review')economicTxnReview(p,tx,'Interrupted transaction; inspect inventory and wallet before manually clearing');
}
function economicTxnClearCommand(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cRealm operator required.');
 const m=/^\s*(\S+)\s*\|\s*(\S+)\s*$/.exec(String(message||''));
 if(!m)return actor.sendMessage('§eUsage: /scriptevent skygen:txnclear PlayerName | ExactTransactionID (after manually reconciling)');
 const target=playerByName(m[1]);if(!target)return actor.sendMessage('§cTarget must be online.');
 const tx=readEconomicTxn(target);if(!tx||tx.id!==m[2])return actor.sendMessage('§cNo matching pending transaction.');
 if(tx.state!=='review')return actor.sendMessage('§cOnly review-state transactions can be cleared.');
 writeEconomicTxn(target,null);activeEconomicTxns.delete(target.id);
 adminAudit(actor,'CLEAR ECON REVIEW',target,tx.id+' '+tx.kind+' '+tx.reason);
 actor.sendMessage('§eReview lock cleared for '+target.name+'; settlement must already be completed manually.');
 target.sendMessage('§eYour SkyGen economic review lock has been cleared by an operator.');
}
function economicTxnReviewCommand(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cRealm operator required.');
 const name=String(message||'').trim();
 const targets=name?[playerByName(name)].filter(Boolean):world.getAllPlayers();
 if(!targets.length)return actor.sendMessage('§cPlayer must be online.');
 let found=0;
 for(const p of targets){let tx;try{tx=readEconomicTxn(p)}catch(e){actor.sendMessage('§c'+p.name+': corrupted journal '+e);continue}
  if(tx){found++;actor.sendMessage('§e'+p.name+' '+tx.kind+' '+tx.id+' ['+tx.state+'] before='+tx.before+' amount='+(tx.cost??tx.total??'n/a')+' reason='+(tx.reason||''));
   if(tx.kind==='quest_fish')actor.sendMessage('§7Quest '+(tx.quest+1)+' assigned '+tx.assigned+' · fish slots [slot, item, original, debit]: '+JSON.stringify(tx.slots));
  }}
 if(!found)actor.sendMessage('§aNo outstanding economic reviews for selected online players.');
}
const SKILL_BRANCHES=["Mining", "Mobility", "Survival", "Exploration", "Economy", "Engineering"];
const SKILLS=[{"id":"miner_haste_1","name":"Quick Hands I","desc":"Haste I on your plot","cost":1,"rank":2,"branch":"Mining","prev":null},{"id":"miner_haste_2","name":"Quick Hands II","desc":"Haste II on your plot","cost":2,"rank":10,"branch":"Mining","prev":"miner_haste_1"},{"id":"miner_xp_1","name":"Prospector I","desc":"+10% generator mining XP","cost":1,"rank":12,"branch":"Mining","prev":"miner_haste_2"},{"id":"miner_xp_2","name":"Prospector II","desc":"+25% generator mining XP","cost":2,"rank":20,"branch":"Mining","prev":"miner_xp_1"},{"id":"miner_luck_1","name":"Lucky Strikes I","desc":"2% chance of a bonus material","cost":2,"rank":25,"branch":"Mining","prev":"miner_xp_2"},{"id":"miner_luck_2","name":"Lucky Strikes II","desc":"4% chance of a bonus material","cost":3,"rank":35,"branch":"Mining","prev":"miner_luck_1"},{"id":"miner_master","name":"Master Miner","desc":"+50% generator mining XP total","cost":4,"rank":45,"branch":"Mining","prev":"miner_luck_2"},{"id":"move_speed_1","name":"Swift Steps I","desc":"Speed I on your plot","cost":1,"rank":2,"branch":"Mobility","prev":null},{"id":"move_speed_2","name":"Swift Steps II","desc":"Speed II on your plot","cost":2,"rank":12,"branch":"Mobility","prev":"move_speed_1"},{"id":"move_jump_1","name":"High Jumper I","desc":"Jump Boost I, toggleable","cost":1,"rank":8,"branch":"Mobility","prev":"move_speed_2"},{"id":"move_jump_2","name":"High Jumper II","desc":"Jump Boost II, toggleable","cost":2,"rank":18,"branch":"Mobility","prev":"move_jump_1"},{"id":"move_fall","name":"Feather Foot","desc":"Slow Falling, toggleable","cost":2,"rank":25,"branch":"Mobility","prev":"move_jump_2"},{"id":"move_tp_1","name":"Fast Traveler","desc":"Teleport cooldown 20% shorter","cost":3,"rank":35,"branch":"Mobility","prev":"move_fall"},{"id":"move_tp_2","name":"Wayfinder","desc":"Teleport cooldown 40% shorter","cost":4,"rank":45,"branch":"Mobility","prev":"move_tp_1"},{"id":"surv_resist","name":"Stone Skin","desc":"Resistance I on your plot","cost":1,"rank":5,"branch":"Survival","prev":null},{"id":"surv_regen","name":"Vitality","desc":"Regeneration I on your plot","cost":2,"rank":15,"branch":"Survival","prev":"surv_resist"},{"id":"surv_health","name":"Fortified","desc":"Health Boost I on your plot","cost":2,"rank":20,"branch":"Survival","prev":"surv_regen"},{"id":"surv_fire","name":"Flameproof","desc":"Fire Resistance on your plot","cost":2,"rank":25,"branch":"Survival","prev":"surv_health"},{"id":"surv_absorb","name":"Second Wind","desc":"Active Absorption, 2-minute cooldown","cost":2,"rank":30,"branch":"Survival","prev":"surv_fire"},{"id":"surv_regen2","name":"Greater Vitality","desc":"Regeneration II on your plot","cost":3,"rank":40,"branch":"Survival","prev":"surv_absorb"},{"id":"surv_saturate","name":"Survival Feast","desc":"Active Saturation, 5-minute cooldown","cost":4,"rank":48,"branch":"Survival","prev":"surv_regen2"},{"id":"explore_night","name":"Night Owl","desc":"Night Vision on your plot","cost":1,"rank":2,"branch":"Exploration","prev":null},{"id":"explore_water","name":"Deep Diver","desc":"Water Breathing on your plot","cost":1,"rank":10,"branch":"Exploration","prev":"explore_night"},{"id":"explore_conduit","name":"Tidal Power","desc":"Conduit Power while underwater","cost":2,"rank":18,"branch":"Exploration","prev":"explore_water"},{"id":"explore_dolphin","name":"Ocean Runner","desc":"Speed I while underwater","cost":2,"rank":25,"branch":"Exploration","prev":"explore_conduit"},{"id":"explore_invisible","name":"Shadow Step","desc":"Active invisibility, 4-minute cooldown","cost":2,"rank":30,"branch":"Exploration","prev":"explore_dolphin"},{"id":"explore_reward","name":"Expedition Rewards","desc":"+20% Daily Quest Credits","cost":2,"rank":35,"branch":"Exploration","prev":"explore_invisible"},{"id":"explore_master","name":"Expedition Master","desc":"All exploration passives work across your plot, even on land","cost":4,"rank":45,"branch":"Exploration","prev":"explore_reward"},{"id":"econ_sell_1","name":"Merchant I","desc":"+2% ordinary shop sale price","cost":1,"rank":2,"branch":"Economy","prev":null},{"id":"econ_buy_1","name":"Bargain Hunter I","desc":"2% off ordinary shop purchases","cost":1,"rank":8,"branch":"Economy","prev":"econ_sell_1"},{"id":"econ_sell_2","name":"Merchant II","desc":"+5% ordinary shop sale price","cost":2,"rank":15,"branch":"Economy","prev":"econ_buy_1"},{"id":"econ_buy_2","name":"Bargain Hunter II","desc":"5% off ordinary shop purchases","cost":2,"rank":22,"branch":"Economy","prev":"econ_sell_2"},{"id":"econ_rank","name":"Rank Rewards","desc":"+10% future rank Credits","cost":2,"rank":28,"branch":"Economy","prev":"econ_buy_2"},{"id":"econ_sell_3","name":"Master Merchant","desc":"+10% shop sale prices","cost":3,"rank":36,"branch":"Economy","prev":"econ_rank"},{"id":"econ_buy_3","name":"Master Negotiator","desc":"10% off shop purchases","cost":4,"rank":45,"branch":"Economy","prev":"econ_sell_3"},{"id":"eng_speed_1","name":"Tuned Pistons I","desc":"5% quicker generator recovery","cost":1,"rank":3,"branch":"Engineering","prev":null},{"id":"eng_speed_2","name":"Tuned Pistons II","desc":"10% quicker generator recovery","cost":2,"rank":12,"branch":"Engineering","prev":"eng_speed_1"},{"id":"eng_slots_1","name":"Builder Permit I","desc":"5 additional generator slots","cost":1,"rank":15,"branch":"Engineering","prev":"eng_speed_2"},{"id":"eng_speed_3","name":"Tuned Pistons III","desc":"15% quicker generator recovery","cost":2,"rank":25,"branch":"Engineering","prev":"eng_slots_1"},{"id":"eng_slots_2","name":"Builder Permit II","desc":"10 additional generator slots","cost":2,"rank":30,"branch":"Engineering","prev":"eng_speed_3"},{"id":"eng_price_1","name":"Factory Contracts I","desc":"5% off generator purchases and upgrades","cost":3,"rank":38,"branch":"Engineering","prev":"eng_slots_2"},{"id":"eng_price_2","name":"Factory Contracts II","desc":"10% off generator purchases and upgrades","cost":4,"rank":47,"branch":"Engineering","prev":"eng_price_1"}];

// v0.9.0: skill point entitlement derives from rank: old players automatically
// receive points without a one-time grant that could duplicate on reinstall.
function teleportCooldown(p){
 try{const d=profile(p);return Math.max(40,Math.floor(C.cooldown*(hasSkill(d,'move_tp_2')?0.6:hasSkill(d,'move_tp_1')?0.8:1)))}
 catch{return C.cooldown}
}
// Preserve 59 points at Rank 50; grant up to 31 more to finish the 90-point tree.
function skillEntitlement(rank){const n=Math.max(1,Math.min(MAX_RANK,rank));return Math.min(90,Math.max(0,Math.min(50,n)-1)+2*Math.floor(Math.min(50,n)/10)+Math.max(0,n-50))}
function purchasedSkills(d){return Array.isArray(d.skills)?d.skills:[]}
function hasSkill(d,id){return purchasedSkills(d).includes(id)}
function skillSpent(d){return purchasedSkills(d).reduce((sum,id)=>sum+(SKILLS.find(s=>s.id===id)?.cost||0),0)}
function skillAvailable(d){return Math.max(0,skillEntitlement(d.rank)-skillSpent(d))}
function perkValue(d,kind){
 const values={
  sell:[['econ_sell_3',10],['econ_sell_2',5],['econ_sell_1',2]],
  buy:[['econ_buy_3',10],['econ_buy_2',5],['econ_buy_1',2]],
  generatorPrice:[['eng_price_2',10],['eng_price_1',5]],
  generatorSpeed:[['eng_speed_3',15],['eng_speed_2',10],['eng_speed_1',5]],
  miningXp:[['miner_master',50],['miner_xp_2',25],['miner_xp_1',10]],
  luck:[['miner_luck_2',4],['miner_luck_1',2]]
 };
 return values[kind]?.find(([id])=>hasSkill(d,id))?.[1]||0;
}
function discountedPrice(price,percent){return Math.max(1,Math.floor(price*(100-percent)/100))}
function generatorSlots(p){const d=profile(p);return GEN_BASE_SLOTS+(hasSkill(d,'eng_slots_2')?10:hasSkill(d,'eng_slots_1')?5:0)}
function generatorOwnerCount(p){let count=0;for(const g of generators.values())if(g.owner===p.id)count++;return count}
function effectivePeriod(g, heartbeat=null){
 // The heartbeat caches owner profiles only for its current tick; purchases, skill
 // changes and disconnects therefore cannot leave persistent stale bonuses.
 let bonus=0;
 try{
  if(heartbeat){
   if(!heartbeat.speedBonuses.has(g.owner)){
    const owner=heartbeat.players.get(g.owner);
    heartbeat.speedBonuses.set(g.owner,owner?perkValue(profile(owner),'generatorSpeed'):0);
   }
   bonus=heartbeat.speedBonuses.get(g.owner)||0;
  }else{
   const owner=world.getAllPlayers().find(p=>p.id===g.owner);
   if(owner)bonus=perkValue(profile(owner),'generatorSpeed');
  }
 }catch{}
 return (g.level||1)>=GENERATOR_MAX_LEVEL?1:Math.max(10,Math.floor((Number(g.period)||200)*(100-bonus)/100));
}
function affordableSkill(d,s){
 return !hasSkill(d,s.id)&&d.rank>=s.rank&&(!s.prev||hasSkill(d,s.prev))&&skillAvailable(d)>=s.cost;
}
function skillTree(p){
 const d=profile(p),spent=skillSpent(d),total=skillEntitlement(d.rank);
 form(p,'§dSKILL TREE',`Rank ${d.rank}/1000  §ePoints: ${total-spent}/${total}\n§7Permanent on-plot buffs, toggles and abilities. Combat buffs are restricted to your own plot.`,
 [...SKILL_BRANCHES.map(b=>b+' — '+purchasedSkills(d).filter(id=>SKILLS.some(s=>s.id===id&&s.branch===b)).length+'/7'),'Active Abilities / Toggles','Reset Skills','Back'],i=>{
  if(i<SKILL_BRANCHES.length)return skillBranchMenu(p,SKILL_BRANCHES[i]);
  if(i===SKILL_BRANCHES.length)return skillAbilities(p);
  if(i===SKILL_BRANCHES.length+1)return skillReset(p);
  skyMenuRanksSkills(p);
 });
}
function skillBranchMenu(p,branch){
 const d=profile(p),nodes=SKILLS.filter(s=>s.branch===branch);
 const status=s=>hasSkill(d,s.id)?'§aOWNED':affordableSkill(d,s)?'§eBUY':'§8LOCKED';
 form(p,'§d'+branch+' Skills',`Available points: ${skillAvailable(d)}\nUnlock skills in order. Rank and point requirements apply.`,
 [...nodes.map(s=>`${status(s)} §f${s.name} (${s.cost} SP, R${s.rank})`),'Back'],i=>{
  if(i>=nodes.length)return skillTree(p);
  const skill=nodes[i],current=profile(p);
  if(!affordableSkill(current,skill)){p.sendMessage('§cSkill locked: need prerequisite, rank and available Skill Points.');return menuAgain(p,()=>skillBranchMenu(p,branch));}
  showUI(p,skyMessage().title('§dLEARN '+skill.name).body(`${skill.desc}\nCost: ${skill.cost} Skill Point(s)\nRemaining: ${skillAvailable(current)-skill.cost}`).button1('Cancel').button2('Learn Skill')).then(r=>{
   if(r.canceled)return;
   if(r.selection!==1)return menuAgain(p,()=>skillBranchMenu(p,branch));
   try{
    const latest=profile(p);if(!affordableSkill(latest,skill))return p.sendMessage('§cSkill requirements have changed.');
    latest.skills=[...purchasedSkills(latest),skill.id];save(p,latest);
    p.sendMessage(`§aUnlocked ${skill.name}. ${skillAvailable(latest)} Skill Points remain.`);
   }catch(e){p.sendMessage('§cSkill could not save: '+String(e).slice(0,100))}
   finally{menuAgain(p,()=>skillBranchMenu(p,branch))}
  }).catch(e=>p.sendMessage('§cSkill menu error '+e));
 });
}
function skillReset(p){
 const d=profile(p);if(skillSpent(d)===0)return p.sendMessage('§eNo purchased skills to reset.');
 const cost=10000+d.rank*200;
 showUI(p,skyMessage().title('§cRESET ALL SKILLS').body(`Refund all spent Skill Points for ${cost} Credits? Rank and earned points are retained.\nCurrent Skill Points spent: ${skillSpent(d)}`).button1('Keep Skills').button2('Reset')).then(r=>{
  if(r.canceled)return;
  if(r.selection!==1)return menuAgain(p,()=>skillTree(p));
  try{const fresh=profile(p);if(fresh.credits<cost)return p.sendMessage('§cNot enough Credits.');
   fresh.credits-=cost;fresh.skills=[];save(p,fresh);p.sendMessage('§aSkill points refunded. Your rank stays unchanged.');
  }catch(e){p.sendMessage('§cReset could not save: '+e)}finally{menuAgain(p,()=>skillTree(p))}
 });
}
const skillCooldowns=new Map(),skillLastEffects=new Map(),skillActiveEffects=new Map();
function skillToggles(d){return d.skillToggles&&typeof d.skillToggles==='object'&&!Array.isArray(d.skillToggles)?d.skillToggles:{}}
function onOwnPlot(p){try{return p.dimension?.id==='minecraft:overworld'&&belongs(p,p.location.x,p.location.z)}catch{return false}}
// Nine island district centers; bridges and player plots are excluded.
function inCityDistrict(p){
 if(p.dimension?.id!=='minecraft:overworld')return false;
 const {x,z}=p.location,dx=Math.round(x/65),dz=Math.round(z/63);
 return Math.abs(dx)<=1&&Math.abs(dz)<=1&&Math.abs(x-dx*65)<=22&&Math.abs(z-dz*63)<=22;
}
function activeAbilityAllowed(p){return onOwnPlot(p)||inCityDistrict(p)}
function useAbility(p,id,effect,duration,cooldown){
 const d=profile(p);if(!hasSkill(d,id))return p.sendMessage('§cUnlock this ability in the skill tree first.');
 if(!activeAbilityAllowed(p))return p.sendMessage('§cActive skills require your plot or one of the nine districts.');
 const key=p.id+':'+id,now=system.currentTick,until=skillCooldowns.get(key)||0;
 const timestamp=Date.now(),persistent=Number(d.skillCooldownUntil?.[id])||0;
 if(now<until||timestamp<persistent)return p.sendMessage('§eAbility cooldown: '+Math.ceil(Math.max((until-now)/20,(persistent-timestamp)/1000))+' seconds.');
 try{
  p.addEffect(effect,duration,{amplifier:0,showParticles:false});
  d.skillCooldownUntil={...(d.skillCooldownUntil||{}),[id]:timestamp+cooldown*50};
  save(p,d);
  if(!skillActiveEffects.has(p.id))skillActiveEffects.set(p.id,new Set());
  skillActiveEffects.get(p.id).add(effect);skillCooldowns.set(key,now+cooldown);
  p.sendMessage('§aAbility activated!');
 }catch(e){try{p.removeEffect?.(effect)}catch{}p.sendMessage('§cAbility could not activate or save: '+String(e).slice(0,90))}
}
function skillAbilities(p){
 const d=profile(p),toggles=skillToggles(d);
 const list=[['move_jump_1','Jump Boost',true],['move_fall','Slow Falling',true],['explore_night','Exploration Effects',true],['surv_absorb','Second Wind',false],['surv_saturate','Survival Feast',false],['explore_invisible','Shadow Step',false]];
 form(p,'§bSKILL ABILITIES','Passive buffs stay on your plot; active abilities work on your plot or nine districts with cooldowns.',
 [...list.map(([id,label,toggle])=>`${hasSkill(d,id)?'§a':'§8'}${label}${toggle?' ['+(toggles[id]===false?'OFF':'ON')+']':' [ACTIVATE]'}`),'Back'],i=>{
  if(i>=list.length)return skillTree(p);
  const [id,label,toggle]=list[i];if(!hasSkill(profile(p),id)){p.sendMessage('§cSkill not unlocked.');return menuAgain(p,()=>skillAbilities(p));}
  if(toggle){try{const fresh=profile(p);fresh.skillToggles={...skillToggles(fresh),[id]:skillToggles(fresh)[id]===false};save(p,fresh);p.sendMessage('§a'+label+' toggled '+(fresh.skillToggles[id]?'ON':'OFF'))}catch(e){p.sendMessage('§cToggle save failed '+e)}return menuAgain(p,()=>skillAbilities(p));}
  if(id==='surv_absorb')useAbility(p,id,'minecraft:absorption',200,2400);
  if(id==='surv_saturate')useAbility(p,id,'minecraft:saturation',100,6000);
  if(id==='explore_invisible')useAbility(p,id,'minecraft:invisibility',200,4800);
  menuAgain(p,()=>skillAbilities(p));
 });
}
const PASSIVE_SKILLS=[
 ['miner_haste_1','minecraft:haste',0,'miner_haste_2'],
 ['move_speed_1','minecraft:speed',0,'move_speed_2'],
 ['move_jump_1','minecraft:jump_boost',0,'move_jump_2'],
 ['move_fall','minecraft:slow_falling',0],
 ['surv_resist','minecraft:resistance',0],
 ['surv_regen','minecraft:regeneration',0,'surv_regen2'],
 ['surv_health','minecraft:health_boost',0],
 ['surv_fire','minecraft:fire_resistance',0],
 ['explore_night','minecraft:night_vision',0],
 ['explore_water','minecraft:water_breathing',0],
 ['explore_conduit','minecraft:conduit_power',0],
 ['explore_dolphin','minecraft:speed',0]
];
// Short 0.5-second polling is NOT the effect duration. For actual infinite
// effects use Bedrock's /effect infinite, with the stable Script API's maximum
// duration as a fallback if commands are unavailable in a particular Realm.
const PLOT_PASSIVE_LEDGER='sg_plot_passives_v1';
const PLOT_PASSIVE_MAX_TICKS=20000000; // 20 ticks/sec; API upper bound
const PLOT_PASSIVE_RENEW_BELOW=19000000; // renew fallback before it expires
const PLOT_PASSIVE_PULSE_TICKS=5; // check plot boundaries at most 0.25 sec apart
const KNOWN_PASSIVE_EFFECTS=new Set(PASSIVE_SKILLS.map(s=>s[1]));
function readPlotPassiveLedger(p){
 const raw=p.getDynamicProperty(PLOT_PASSIVE_LEDGER);
 if(raw===undefined||raw===null||raw==='')return new Map();
 let saved;
 try{saved=JSON.parse(String(raw))}catch(e){throw Error('Damaged passive effect ledger: '+e)}
 if(!Array.isArray(saved))throw Error('Invalid passive effect ledger');
 const result=new Map();
 for(const entry of saved){
  if(!Array.isArray(entry)||entry.length!==2||!KNOWN_PASSIVE_EFFECTS.has(entry[0])||![0,1].includes(entry[1]))throw Error('Invalid passive effect ledger entry');
  result.set(entry[0],entry[1]);
 }
 return result;
}
function savePlotPassiveLedger(p,ledger){
 const raw=ledger.size?JSON.stringify([...ledger]):undefined;
 p.setDynamicProperty(PLOT_PASSIVE_LEDGER,raw);
 if(p.getDynamicProperty(PLOT_PASSIVE_LEDGER)!==raw)throw Error('Plot effect ledger write was not verified');
}
function grantInfinitePlotPassive(p,effect,amplifier){
 // Bedrock's native infinite form shows Infinity in the status UI.
 // The command can be unavailable under some Realm/Script API contexts.
 let commandWorked=false;
 if(typeof p.runCommand==='function'){
  try{const result=p.runCommand('effect @s '+effect.replace(/^minecraft:/,'')+' infinite '+amplifier+' true');commandWorked=!!result&&result.successCount>0}catch{}
 }
 if(!commandWorked)p.addEffect(effect,PLOT_PASSIVE_MAX_TICKS,{amplifier,showParticles:false});
}
function removeOwnedPlotPassive(p,effect,ownedAmp){
 const current=p.getEffect?.(effect);
 if(!current)return true;
 // A stronger external potion is not owned by SkyGen. Same-strength effects
 // cannot be distinguished by the API; prioritize plot-boundary enforcement.
 if(current.amplifier>ownedAmp)return true;
 p.removeEffect(effect);
 return !p.getEffect?.(effect);
}
function skillPulsePlayer(p){
 const own=onOwnPlot(p),district=inCityDistrict(p),d=profile(p),toggles=skillToggles(d);
 // Only explicitly toggleable active effects may persist in the nine districts.
 const districtToggles=new Set(['move_jump_1','move_fall','explore_night','explore_water','explore_conduit','explore_dolphin']);
 const owned=readPlotPassiveLedger(p),desired=new Map();
 if(own||district){
  for(const [skill,effect,amp,upgraded] of PASSIVE_SKILLS){
   if(!own&&!districtToggles.has(skill))continue;
   if(!hasSkill(d,skill))continue;
   if(skill==='move_jump_1'&&toggles.move_jump_1===false)continue;
   if(skill==='move_fall'&&toggles.move_fall===false)continue;
   if(skill.startsWith('explore_')&&toggles.explore_night===false&&!hasSkill(d,'explore_master'))continue;
   if((skill==='explore_conduit'||skill==='explore_dolphin')&&!p.isInWater&&!hasSkill(d,'explore_master'))continue;
   const strength=upgraded&&hasSkill(d,upgraded)?1:amp;
   desired.set(effect,Math.max(desired.get(effect)??-1,strength));
  }
 }
 // Revoke plot buffs immediately upon the next boundary check (also on skill
 // reset/toggle). The persistent ledger survives script reloads and reconnects.
 for(const [effect,amp] of [...owned]){
  if(desired.get(effect)===amp)continue;
  if(removeOwnedPlotPassive(p,effect,amp)){
   owned.delete(effect);
   savePlotPassiveLedger(p,owned);
  }
 }
 if(own||district){
  for(const [effect,amp] of desired){
   try{
    const current=p.getEffect?.(effect);
    // Respect stronger effects from other sources, even on a plot.
    if(current&&current.amplifier>amp)continue;
    const tracked=owned.has(effect)&&owned.get(effect)===amp;
    const sufficientlyLong=current&&(!Number.isFinite(current.duration)||current.duration<=0||current.duration>=PLOT_PASSIVE_RENEW_BELOW);
    if(tracked&&current&&current.amplifier===amp&&sufficientlyLong)continue;
    if(!tracked&&current&&current.amplifier===amp&&sufficientlyLong)continue;
    // Record ownership before creating an infinite effect; crash/rejoin will
    // then know what to remove outside the player's own plot.
    owned.set(effect,amp);
    savePlotPassiveLedger(p,owned);
    grantInfinitePlotPassive(p,effect,amp);
   }catch(e){
    if(!skillEffectWarnings.has(effect)){
     skillEffectWarnings.add(effect);console.warn('[SkyGen SKILLS] Infinite plot passive '+effect+' failed: '+e)
    }
   }
  }
 }
 if(!activeAbilityAllowed(p)&&skillActiveEffects.has(p.id)){
  for(const effect of skillActiveEffects.get(p.id))try{p.removeEffect?.(effect)}catch{}
  skillActiveEffects.delete(p.id);
 }
 skillLastEffects.set(p.id,new Set(owned.keys()));
}
function skillPulse(){
 for(const p of world.getAllPlayers()){
  try{skillPulsePlayer(p)}catch(e){console.warn('[SkyGen SKILLS] plot effect pulse '+e)}
 }
 system.runTimeout(skillPulse,PLOT_PASSIVE_PULSE_TICKS);
}
const skillEffectWarnings=new Set();
system.runTimeout(skillPulse,PLOT_PASSIVE_PULSE_TICKS);
function dailyDate(){return new Date().toISOString().slice(0,10)}
function recordDaily(p,d,keys,amount=1,subject=undefined){
 if(p.getGameMode()===GameMode.Creative)return false;
 const dailyChanged=recordQuestProgress(questState(d,p.id,dailyDate(),publicStarterEnabled()),keys,amount,false,subject);
 let weeklyChanged=false,ascendedChanged=false;
 try{weeklyChanged=recordWeeklyPreviewActivity(d,p.id,keys,subject,amount,new Date())}
 catch(err){console.warn('[SkyGen WEEKLY PREVIEW] activity ignored: '+err)}
 try{ascendedChanged=recordAscendedDailyPreviewActivity(d,p.id,keys,subject,amount,new Date())}
 catch(err){console.warn('[SkyGen ASCENDED PREVIEW] activity ignored: '+err)}
 return dailyChanged||weeklyChanged||ascendedChanged;
}
function recordQuestActivity(p,key,subject=undefined){
 try{
  const d=profile(p);
  if(recordDaily(p,d,[key],1,subject))save(p,d);
 }catch(e){console.warn('[SkyGen QUEST] '+key+': '+e)}
}
const QUEST_FISH=new Set(['minecraft:cod','minecraft:salmon','minecraft:tropical_fish','minecraft:pufferfish','minecraft:clownfish']);
function eligibleQuestFish(item){
 return QUEST_FISH.has(item?.typeId)&&eligibleShopItem(item,item.typeId);
}
function fishHeld(p){
 const inv=inventory(p);
 if(!inv||p.getGameMode()===GameMode.Creative)return 0;
 let total=0;
 for(let i=0;i<inv.size;i++){
  const item=inv.getItem(i);
  if(eligibleQuestFish(item))total+=item.amount;
 }
 return total;
}
function planQuestClaim(p,selected){
 const fresh=profile(p),mineReady=publicStarterEnabled();
 const today=questState(fresh,p.id,dailyDate(),mineReady);
 const q=questDefinition(selected.id);
 if(q.pendingEconomy)throw Error('This Ascended Contract is a catalog preview; payouts are not activated.');
 let slots;
 if(q.key==='fish'){
  const entry=today.active.find(item=>item.id===selected.id&&item.assigned===selected.assigned);
  if(!entry)throw Error('Quest expired or already claimed.');
  if(p.getGameMode()===GameMode.Creative)throw Error('Fish turn-ins require survival gameplay.');
  slots=planInventoryDebit(inventory(p),q.need,eligibleQuestFish);
  if(!slots)throw Error('Not enough eligible fish. Check your inventory.');
  // This is a temporary readiness flag on the copy that will be committed.
  entry.progress=q.need;
 }
 if(!completeQuest(today,selected,fresh.rank,mineReady))throw Error('Quest is incomplete, expired, or already claimed.');
 const reward=hasSkill(fresh,'explore_reward')?Math.floor(q.credits*1.2):q.credits;
 assertBankUnlocked(p);
 fresh.xp+=q.xp;
 const {oldRank,bonus,orbits}=rankRewards(fresh);
 const credits=reward+bonus,destination=payoutDestination(fresh,credits);
 if(destination===undefined)throw Error(noPayoutRoom(fresh,credits)+' Your quest remains claimable.');
 if(orbits&&orbits>CREDIT_CAP-fresh.orbits)throw Error('Free room for '+orbits+' milestone Orbits. Your quest remains claimable.');
 creditPayout(fresh,destination,credits);
 fresh.orbits+=orbits;
 return {fresh,oldRank,slots,credits,orbits,xp:q.xp,destination};
}
function claimQuest(p,selected,quote){
 const plan=planQuestClaim(p,selected);
 if(quote&&['credits','orbits','xp','destination'].some(key=>quote[key]!==plan[key]))throw Error('Your reward changed. Open a new quote.');
 if(plan.slots){
  const info={quest:selected.id,assigned:selected.assigned,total:plan.credits,count:selected.quest.need,destination:plan.destination};
  const committed=commitInventoryDebit(p,plan.slots,'quest_fish',info,(latest,tx)=>{
   if(latest.credits!==tx.before)throw Error('Wallet changed');
   plan.fresh.sg_last_econ_txn=tx.id;
   save(p,plan.fresh);
  });
  if(!committed)return;
 }else save(p,plan.fresh);
 announceRank(p,plan.fresh,plan.oldRank);
 p.sendMessage(`§aQuest reward: ${plan.credits} Credits to ${destinationName(plan.fresh,plan.destination)} + ${plan.xp} XP${plan.orbits?' + '+plan.orbits+' Orbits':''}.`);
}
function updateExplorationQuest(p,d){
 if(!publicStarterEnabled()||p.dimension?.id!=='minecraft:overworld'||p.getGameMode()===GameMode.Creative)return;
 const {x,z}=p.location;
 const dx=Math.round(x/65),dz=Math.round(z/63);
 if(Math.abs(dx)>1||Math.abs(dz)>1||Math.abs(x-dx*65)>16||Math.abs(z-dz*63)>16)return;
 const state=questState(d,p.id,dailyDate(),publicStarterEnabled());
 const hasDailyVisit=state.active.some(entry=>{const q=questDefinition(entry.id);return q.key==='visits'||q.secondary?.key==='visits'});
 let hasWeeklyVisit=false,hasAscendedVisit=false;
 try{
  const draft=openWeeklyPreview(d,p.id,new Date()).state;
  hasWeeklyVisit=!!draft?.entries?.some(e=>e.primaryKey==='visits'||e.secondaryKey==='visits');
 }catch(err){console.warn('[SkyGen WEEKLY PREVIEW] district state requires review: '+err)}
 try{
  const draft=openAscendedDailyPreview(d,p.id,new Date()).state;
  hasAscendedVisit=!!draft?.entries?.some(e=>e.primaryKey==='visits'||e.secondaryKey==='visits');
 }catch(err){console.warn('[SkyGen ASCENDED PREVIEW] district state requires review: '+err)}
 if(!hasDailyVisit&&!hasWeeklyVisit&&!hasAscendedVisit)return;
 const zone=dx+','+dz,now=Date.now();
 if(state.lastZone===zone||now-(state.lastVisitAt??0)<30000)return;
 const dailyChanged=hasDailyVisit&&recordQuestProgress(state,['visits'],1,false,zone);
 let weeklyChanged=false,ascendedChanged=false;
 try{if(hasWeeklyVisit)weeklyChanged=recordWeeklyPreviewActivity(d,p.id,['visits'],zone,1,new Date())}
 catch(err){console.warn('[SkyGen WEEKLY PREVIEW] district update ignored: '+err)}
 try{if(hasAscendedVisit)ascendedChanged=recordAscendedDailyPreviewActivity(d,p.id,['visits'],zone,1,new Date())}
 catch(err){console.warn('[SkyGen ASCENDED PREVIEW] district update ignored: '+err)}
 if(dailyChanged||weeklyChanged||ascendedChanged){
  state.lastZone=zone;state.lastVisitAt=now;save(p,d);
 }
}
function dailyQuests(p){
 const d=profile(p),day=dailyDate(),state=questState(d,p.id,day,publicStarterEnabled());
 const fish=fishHeld(p);
 save(p,d);
 const active=state.active.map(entry=>({
  ...entry,quest:questDefinition(entry.id),
  progress:questDefinition(entry.id).key==='fish'?Math.min(fish,questDefinition(entry.id).need):entry.progress
 }));
 const number=quest=>quest.id<0?'Legacy '+(-quest.id):'#'+(quest.id+1);
 const buttons=active.map(({quest,progress})=>
  `${progress>=quest.need?'§aCLAIM':'§e'} ${quest.group} ${number(quest)}: ${progress}/${quest.need}`);
 const details=active.map(({quest})=>
  `§e${number(quest)} §r${quest.label} ×${quest.need} · ${quest.credits} Credits + ${quest.xp} XP`).join('\n');
 form(p,'§eDAILY QUESTS',`UTC rotation: ${day} · 00:00 UTC\nCompleted quests stay until claimed.\n${details||'All available quests claimed for this rotation.'}`,
  [...buttons,'Browse Quest Catalog','Ascended Contracts','Weekly Elite','Back'],i=>{
  if(i===active.length)return questCatalog(p);
  if(i===active.length+1)return ascendedDailyPreviewMenu(p);
  if(i===active.length+2)return weeklyElitePreview(p);
  if(i===active.length+3)return menu(p);
  const selected=active[i];
  if(!selected)return;
  const reopen=()=>menuAgain(p,()=>dailyQuests(p));
  if(selected.quest.key==='fish'){
   try{
    const quote=planQuestClaim(p,selected);
    const confirm=skyMessage().title('Confirm Fishing Turn-in')
     .body(`Turn in ${selected.quest.need} eligible fish for ${quote.credits.toLocaleString()} Credits and ${quote.xp} XP${quote.orbits?' plus '+quote.orbits+' Orbits':''}? Credits go to ${destinationName(quote.fresh,quote.destination)}.`)
     .button1('Cancel').button2('Turn In');
    showUI(p,confirm).then(r=>{
     if(r.canceled)return;
     try{if(r.selection===1)claimQuest(p,selected,quote)}
     catch(e){p.sendMessage('§cCould not claim quest: '+e.message)}
     finally{reopen()}
    }).catch(e=>p.sendMessage('§cFishing turn-in menu failed: '+e));
   }catch(e){p.sendMessage('§cCould not claim quest: '+e.message);reopen()}
   return;
  }
  try{claimQuest(p,selected)}
  catch(e){p.sendMessage('§cCould not claim quest: '+e.message)}
  finally{reopen()}
 });
}
// v0.10.52 approved contracts: atomic monetary/rank/claim updates. The quest
// objective state remains independently validated by the existing preview
// modules; a separate period claim marker is written in the SAME sg_profile
// mutation as balances and XP. One in-flight economic journal per player.
function contractClaimField(kind){return kind==='daily'?'ascendedClaimed':'weeklyEliteClaimed'}
function contractPeriod(kind,status){return kind==='daily'?status.day:status.week}
function contractClaims(d,kind,period){
 const record=d[contractClaimField(kind)];
 if(record!==undefined){
  if(!record||typeof record!=='object'||Array.isArray(record)||typeof record.period!=='string'||
     !/^\d{4}-\d\d-\d\d$/.test(record.period)||!Array.isArray(record.ids)||record.ids.length>3||
     record.ids.some(x=>!Number.isSafeInteger(x)||x<500||x>=1000)||new Set(record.ids).size!==record.ids.length)
   throw Error('Contract claim ledger requires operator review');
  if(record.period>period)throw Error('Contract claim ledger is ahead of UTC calendar');
  if(record.period===period)return record.ids;
 }
 return [];
}
function planNewContractClaim(p,kind,questId){
 if(!['daily','weekly'].includes(kind))throw Error('Invalid contract claim kind');
 if(p.getGameMode()===GameMode.Creative||creativeEconomyBlocked(p))throw Error('Contract claims require survival gameplay');
 const d=profile(p),now=new Date();
 const status=kind==='daily'?ascendedDailyStatus(d,p.id,now):weeklyPreviewStatus(d,p.id,now);
 if(status.locked)throw Error('This contract board has not unlocked');
 const period=contractPeriod(kind,status),entryIndex=status.entries.findIndex(e=>e.questId===questId);
 if(entryIndex<0)throw Error('Contract not assigned to this player');
 const entry=status.entries[entryIndex];
 if(!entry.ready)throw Error('Complete both objectives before claiming');
 const claims=contractClaims(d,kind,period);
 if(claims.includes(questId))throw Error('Contract already claimed this period');
 const q=questDefinition(questId),quote=approvedContractQuote(q,status.lockedRank,kind,entryIndex);
 const multiplier=hasSkill(d,'econ_rank')?110:100;
 const oldRank=d.rank;
 const change=advanceRank(oldRank,d.xpProgress,quote.xp);
 let rankCredits=0,rankOrbits=0;
 for(let level=oldRank+1;level<=change.rank;level++){
  rankCredits+=level*multiplier;
  if(level%10===0)rankOrbits++;
 }
 const questCredits=kind==='daily'&&hasSkill(d,'explore_reward')?Math.floor(quote.credits*1.2):quote.credits;
 const totalCredits=questCredits+rankCredits;
 const totalOrbits=quote.orbits+rankOrbits;
 if(!Number.isSafeInteger(totalCredits)||totalCredits<1||totalCredits>CREDIT_CAP)throw Error('Unsafe Credit reward');
 if(!Number.isSafeInteger(totalOrbits)||totalOrbits<0||totalOrbits>CREDIT_CAP-d.orbits)throw Error('Not enough Orbit wallet capacity; reward remains claimable');
 const destination=payoutDestination(d,totalCredits);
 if(destination===undefined)throw Error('No wallet/bank capacity for '+totalCredits+' Credits; reward remains claimable');
 return {kind,questId,entryIndex,period,lockedRank:status.lockedRank,oldRank,quote,destination,
   totalCredits,totalOrbits,rankCredits,rankOrbits,questCredits,rankChange:change,claims,profile:d};
}
function claimNewContract(p,kind,questId){
 const initial=planNewContractClaim(p,kind,questId); // no write before readiness and payout checks
 assertBankUnlocked(p);
 let tx;
 try{
  tx=beginEconomicTxn(p,'contract',{kindContract:kind,quest:questId,period:initial.period,
   total:initial.totalCredits,orbits:initial.totalOrbits,destination:initial.destination,
   destinationBefore:initial.destination==='wallet'?initial.profile.credits:
     initial.profile.bank?.accounts?.find(a=>a.id===initial.destination)?.credits,
   beforeOrbits:initial.profile.orbits,oldRank:initial.oldRank});
  const latest=planNewContractClaim(p,kind,questId); // recalc against authoritative saved profile
  if(latest.period!==initial.period||latest.lockedRank!==initial.lockedRank||
     latest.destination!==tx.destination||latest.totalCredits!==tx.total||
     latest.totalOrbits!==tx.orbits||latest.quote.xp!==initial.quote.xp)
   throw Error('Contract quote changed during confirmation');
  const d=latest.profile;
  if(d.credits!==tx.before||d.orbits!==tx.beforeOrbits)throw Error('Balances changed');
  const balance=tx.destination==='wallet'?d.credits:d.bank?.accounts?.find(a=>a.id===tx.destination)?.credits;
  if(balance!==tx.destinationBefore)throw Error('Payout destination changed');
  creditPayout(d,tx.destination,tx.total);
  d.orbits+=tx.orbits;
  d.rank=latest.rankChange.rank;d.xpProgress=latest.rankChange.progress;d.xp=mirrorXP(d.rank,d.xpProgress);
  d[contractClaimField(kind)]={period:latest.period,ids:[...latest.claims,questId]};
  d.sg_last_econ_txn=tx.id;
  save(p,d); // exact-once profile write: Credits, Orbits, XP and claim marker
  endEconomicTxn(p,tx,true);
  announceRank(p,d,latest.oldRank);
  p.sendMessage('§a'+(kind==='weekly'?'Weekly Elite':'Ascended')+' contract #'+(questId+1)+
   ' claimed: '+tx.total+' Credits to '+destinationName(d,tx.destination)+' + '+
   formattedXP(latest.quote.xp)+' XP'+(tx.orbits?' + '+tx.orbits+' Orbits':'')+'.');
  return true;
 }catch(err){
  if(tx){
   try{
    const d=profile(p),hasClaim=contractClaims(d,kind,initial.period).includes(questId);
    if(!hasClaim&&d.sg_last_econ_txn!==tx.id&&d.credits===tx.before&&d.orbits===tx.beforeOrbits){
     const balance=tx.destination==='wallet'?d.credits:d.bank?.accounts?.find(a=>a.id===tx.destination)?.credits;
     if(balance===tx.destinationBefore){endEconomicTxn(p,tx,true);throw Error('Contract not paid; please retry');}
    }
   }catch(cleanupError){
    if(String(cleanupError).includes('Contract not paid; please retry'))throw cleanupError;
   }
   economicTxnReview(p,tx,'Contract settlement uncertain: '+err);
  }
  throw err;
 }
}
function ascendedDailyPreviewMenu(p){
 try{
  const d=profile(p),status=ascendedDailyStatus(d,p.id,new Date());
  if(status.changed)save(p,d);
  if(status.locked)return form(p,'§bASCENDED CONTRACTS','Ascended contracts unlock at Rank 51.',['Back to Quests'],()=>dailyQuests(p));
  const claimed=new Set(contractClaims(d,'daily',status.day));
  const details=status.entries.map((entry,i)=>{
   const q=questDefinition(entry.questId),isClaimed=claimed.has(entry.questId);
   const quote=approvedContractQuote(q,status.lockedRank,'daily');
   return `§e${i+1}. #${entry.questId+1} — ${isClaimed?'§aCLAIMED':entry.ready?'§aREADY':'§7IN PROGRESS'}\n`+
    `${q.label}\nPrimary ${entry.primary}/${entry.target} · Secondary ${entry.secondary}/${entry.secondaryTarget}\n`+
    `${formattedXP(quote.xp)} XP + ${quote.credits.toLocaleString()} Credits (${q.difficulty})`;
  }).join('\n\n');
  const buttons=[...status.entries.map((entry,i)=>claimed.has(entry.questId)?'Claimed #'+(entry.questId+1):
   entry.ready?'Claim #'+(entry.questId+1):'Inspect #'+(entry.questId+1)),'Back to Quests'];
  form(p,'§bASCENDED CONTRACTS',`UTC day: ${status.day} · Locked rank: ${status.lockedRank}\n`+
   'Three daily Ascended contracts. Reward amounts are fixed at assignment.\n\n'+details,buttons,i=>{
    if(i===status.entries.length)return dailyQuests(p);
    const entry=status.entries[i];if(!entry)return;
    if(!entry.ready||claimed.has(entry.questId))return ascendedDailyPreviewMenu(p);
    showUI(p,skyMessage().title('Claim Ascended Contract').body('Claim #'+(entry.questId+1)+'? Credits may go to your default bank when the wallet is full.').button1('Cancel').button2('Claim')).then(r=>{
     if(!r.canceled&&r.selection===1)try{claimNewContract(p,'daily',entry.questId)}catch(err){p.sendMessage('§cClaim unavailable: '+String(err).slice(0,130))}
     menuAgain(p,()=>ascendedDailyPreviewMenu(p));
    }).catch(err=>p.sendMessage('§cContract claim menu failed: '+err));
  });
 }catch(err){console.warn('[SkyGen ASCENDED] board failed: '+err);p.sendMessage('§cAscended contracts require operator review: '+String(err).slice(0,100))}
}
function weeklyElitePreview(p){
 try{
  const d=profile(p),status=weeklyPreviewStatus(d,p.id,new Date());
  if(status.changed)save(p,d);
  if(status.locked)return form(p,'§dWEEKLY ELITE','Weekly Elite contracts unlock at Rank 101.',['Back to Quests'],()=>dailyQuests(p));
  const claimed=new Set(contractClaims(d,'weekly',status.week));
  const details=status.entries.map((entry,i)=>{
   const q=questDefinition(entry.questId),isClaimed=claimed.has(entry.questId);
   const quote=approvedContractQuote(q,status.lockedRank,'weekly',i);
   return `§e${i+1}. #${entry.questId+1} — ${isClaimed?'§aCLAIMED':entry.ready?'§aREADY':'§7IN PROGRESS'}\n`+
    `${q.label}\nPrimary ${entry.primary}/${entry.target} · Secondary ${entry.secondary}/${entry.secondaryTarget}\n`+
    `${formattedXP(quote.xp)} XP + ${quote.credits.toLocaleString()} Credits + ${quote.orbits} Orbits`;
  }).join('\n\n');
  form(p,'§dWEEKLY ELITE',`UTC week: ${status.week} · Locked rank: ${status.lockedRank}\n`+
   'Three weekly Elite rewards; each can be claimed once per week.\n\n'+details,
   [...status.entries.map((entry,i)=>claimed.has(entry.questId)?'Claimed #'+(entry.questId+1):
    entry.ready?'Claim #'+(entry.questId+1):'Inspect #'+(entry.questId+1)),'Back to Quests'],i=>{
    if(i===status.entries.length)return dailyQuests(p);
    const entry=status.entries[i];if(!entry)return;
    if(!entry.ready||claimed.has(entry.questId))return weeklyElitePreview(p);
    showUI(p,skyMessage().title('Claim Weekly Elite Contract').body('Claim #'+(entry.questId+1)+'? Orbit and Credit capacity will be rechecked.').button1('Cancel').button2('Claim')).then(r=>{
     if(!r.canceled&&r.selection===1)try{claimNewContract(p,'weekly',entry.questId)}catch(err){p.sendMessage('§cClaim unavailable: '+String(err).slice(0,130))}
     menuAgain(p,()=>weeklyElitePreview(p));
    }).catch(err=>p.sendMessage('§cWeekly claim menu failed: '+err));
  });
 }catch(err){console.warn('[SkyGen WEEKLY] board failed: '+err);p.sendMessage('§cWeekly contracts require operator review: '+String(err).slice(0,100))}
}

function questCatalog(p,group=null,page=0){
 const groups=[...new Set(QUESTS.map(q=>q.group))];
 if(!group)return form(p,'QUEST CATALOG',`${QUESTS.length} definitions · 500 legacy quests and 500 Ascended/Weekly contracts.`,[...groups,'Back'],i=>{
  if(i===groups.length)return dailyQuests(p);
  questCatalog(p,groups[i]);
 });
 const results=QUESTS.filter(q=>q.group===group);
 const rows=results.slice(page*6,page*6+6);
 const level=rankLevel(profile(p).rank);
 const actions=[];
 if(page>0)actions.push(['Previous Page',()=>questCatalog(p,group,page-1)]);
 if((page+1)*6<results.length)actions.push(['Next Page',()=>questCatalog(p,group,page+1)]);
 actions.push(['Back',()=>questCatalog(p)]);
 form(p,group,`Page ${page+1}/${Math.ceil(results.length/6)}\n`+rows.map(q=>
  `#${q.id+1} · Rank ${q.rank}${q.id>=500?' (Ascended/Weekly)':q.rank>level?' (Locked)':''} · ${q.label} ×${q.need}${q.secondary?' + '+q.secondary.label+' ×'+q.secondary.need:''}`).join('\n'),
  actions.map(([label])=>label),i=>actions[i]?.[1]());
}
function coords(id){return {x:C.base.x+(id%C.columns)*C.spacing,y:C.base.y,z:C.base.z+Math.floor(id/C.columns)*C.spacing}}
function belongs(p,x,z){if(p.dimension?.id!=='minecraft:overworld')return false;const d=profile(p);if(d.plot<0)return false;const c=coords(d.plot);return Math.abs(x-c.x)<=plotRadius(d.plot)&&Math.abs(z-c.z)<=plotRadius(d.plot)}
function plotAt(x,z){const dx=x-C.base.x,dz=z-C.base.z;if(dx< -56||dz< -56)return -1;const col=Math.round(dx/C.spacing),row=Math.round(dz/C.spacing);if(col<0||col>=C.columns||row<0)return -1;const id=row*C.columns+col,c=coords(id);return Math.abs(x-c.x)<=plotRadius(id)&&Math.abs(z-c.z)<=plotRadius(id)?id:-1}
// v0.9.10 VISIBLE FORCEFIELDS. These are script-enforced particle walls, not
// placed glass: installing the add-on never overwrites player structures.
// All enforcement is server-side. Spawn is fixed; claim boundaries follow paid tiers.
// Only operators can walk across spawn AND plot perimeters. Plot owners,
// trusted players and invited visitors ENTER via normal permissioned teleports.
// Realm-wide OP walk-bypass settings. Missing values preserve legacy ON defaults.
const OP_SPAWN_BYPASS_KEY='sg_op_spawn_walk_bypass';
const OP_PLOT_BYPASS_KEY='sg_op_plot_walk_bypass';
function operatorBoundaryBypass(kind){
 const value=world.getDynamicProperty(kind==='spawn'?OP_SPAWN_BYPASS_KEY:OP_PLOT_BYPASS_KEY);
 return value!==false;
}
function operatorMayCrossField(p,field){
 return isOperator(p)&&operatorBoundaryBypass(field?.kind==='spawn'?'spawn':'plot');
}
const forcefieldPrevious=new Map(),forcefieldNotices=new Map();
const FORCEFIELD_STEP_LIMIT=8; // distinguish walking/flying from long-distance teleports
function fieldAt(x,z){
 const bx=Math.floor(x),bz=Math.floor(z);
 if(inSpawn(bx,bz))return {kind:'spawn',id:-1};
 const id=plotAt(bx,bz);
 return id>=0?{kind:'plot',id}:null;
}
function sameField(a,b){return a?.kind===b?.kind&&a?.id===b?.id}
function fieldAccess(p,field){
 if(!field||isOperator(p))return true;
 if(field.kind==='spawn')return false; // Spawn horn is allowed; walking across is not.
 return canVisit(p,field.id); // visit access, NOT permission to build
}
function forcefieldWarn(p,message){
 const tick=system.currentTick,last=forcefieldNotices.get(p.id)??-9999;
 if(tick-last<40)return;
 forcefieldNotices.set(p.id,tick);
 try{p.onScreenDisplay.setActionBar('§c'+message)}catch{}
 try{p.sendMessage('§c'+message)}catch{}
}
function forcefieldReturn(p,previous){
 try{
  const at={x:previous.x,y:previous.y,z:previous.z};
  if(typeof p.tryTeleport==='function'){
   if(p.tryTeleport(at,{dimension:p.dimension,checkForBlocks:false}))return true;
  }else{p.teleport(at,{dimension:p.dimension,checkForBlocks:false});return true;}
 }catch(e){console.warn('[SkyGen] forcefield return failed: '+e)}
 return false;
}
function enforceForcefield(p){
 const loc=p.location,id=p.id,dimension=p.dimension.id;
 if(dimension!=='minecraft:overworld'){forcefieldPrevious.delete(id);return}
 const prev=forcefieldPrevious.get(id),nowField=fieldAt(loc.x,loc.z);
 // Fresh join or dimension transfer: uninvited players inside a private plot
 // are evacuated. Legitimate spawn/plot horn arrivals remain permitted.
 if(!prev||prev.dim!==dimension){
  if(nowField?.kind==='plot'&&!fieldAccess(p,nowField)){
   forcefieldWarn(p,'Private plot: access denied. Returning to spawn.');
   safeSpawnTravel(p,true);
  }
  forcefieldPrevious.set(id,{x:loc.x,y:loc.y,z:loc.z,dim:dimension});
  return;
 }
 const prevField=fieldAt(prev.x,prev.z);
 const delta=Math.hypot(loc.x-prev.x,loc.y-prev.y,loc.z-prev.z);
 let denied=false,reason='';
 // Every edge physically contains non-operators, including plot owners.
 // Our scripted teleport system issues a short-lived one-use travel ticket.
 const ticket=forcefieldTickets.get(id);
 const validTicket=!!ticket&&ticket.expires>=system.currentTick&&
  Math.hypot(loc.x-ticket.x,loc.y-ticket.y,loc.z-ticket.z)<2;
 if(validTicket)forcefieldTickets.delete(id);
 else if(ticket&&ticket.expires<system.currentTick)forcefieldTickets.delete(id);
 if(!validTicket&&!sameField(prevField,nowField)&&
     !(isOperator(p)&&(!prevField||operatorMayCrossField(p,prevField))&&(!nowField||operatorMayCrossField(p,nowField)))&&
     (prevField||nowField)) {
  denied=true;reason='Forcefield: use your teleport horn to travel.';
 }
 // Unauthorized plot occupancy is always denied, even on spawn/relogin,
 // after permission revocation, or following an external /tp command.
 if(nowField?.kind==='plot'&&!fieldAccess(p,nowField)){
  denied=true;reason='Private plot forcefield: access denied.';
 }
 if(denied){
  // Never return to a position already inside a private plot from which
  // permissions have been revoked, and never bounce across a huge distance.
  const safePrevious=delta<=FORCEFIELD_STEP_LIMIT&&
    !(prevField?.kind==='plot'&&!fieldAccess(p,prevField));
  if(safePrevious&&forcefieldReturn(p,prev)){
   forcefieldPrevious.set(id,{...prev});
  }else{
   // No safe walking-side to return to (teleport exploit, revoked visit, login).
   // Use the established, validated original-spawn rescue routine.
   safeSpawnTravel(p,true);
   const updated=p.location;
   forcefieldPrevious.set(id,{x:updated.x,y:updated.y,z:updated.z,dim:dimension});
  }
  forcefieldWarn(p,reason);
  return;
 }
 forcefieldPrevious.set(id,{x:loc.x,y:loc.y,z:loc.z,dim:dimension});
}
// v0.9.12: render a visible nearby SEGMENT of each perimeter instead of
// requiring the player to stand within nine blocks of one plot edge.
// Protection/movement rules are intentionally unchanged.
const FORCEFIELD_VISUAL_RANGE=32;
function nearestForcefield(loc){
 const x=loc.x,z=loc.z,candidates=[{kind:'spawn',id:-1,c:spawnPosition(),radius:spawnLimit()}];
 const col=Math.round((x-C.base.x)/C.spacing),row=Math.round((z-C.base.z)/C.spacing);
 if(col>=0&&col<C.columns&&row>=0){
  const id=row*C.columns+col;
  candidates.push({kind:'plot',id,c:coords(id),radius:plotRadius(id)});
 }
 let best;
 for(const field of candidates){
  const dx=x-field.c.x,dz=z-field.c.z,r=field.radius;
  const sides=[
   {side:'x',sign:1,score:Math.hypot(x-(field.c.x+r+0.5),Math.max(0,Math.abs(dz)-r))},
   {side:'x',sign:-1,score:Math.hypot(x-(field.c.x-r-0.5),Math.max(0,Math.abs(dz)-r))},
   {side:'z',sign:1,score:Math.hypot(z-(field.c.z+r+0.5),Math.max(0,Math.abs(dx)-r))},
   {side:'z',sign:-1,score:Math.hypot(z-(field.c.z-r-0.5),Math.max(0,Math.abs(dx)-r))}
  ];
  for(const candidate of sides){
   if(candidate.score>FORCEFIELD_VISUAL_RANGE||best&&best.score<=candidate.score)continue;
   best={...field,...candidate};
  }
 }
 return best;
}
function renderForcefield(p){
 const loc=p.location,field=nearestForcefield(loc);
 if(!field)return false;
 const {c,radius:r,side,sign,kind,id}=field;
 const visibleType=kind==='spawn'?'minecraft:basic_flame_particle':'minecraft:blue_flame_particle';
 // Render the original dense wall close to the boundary, but a sparser
 // wall at greater distance. Movement/permissions are still checked every tick.
 // This reduces visual work without affecting forcefield collision or access.
 const near=field.score<=12;
 const step=near?2:4;
 const levels=near?5:3;
 for(let offset=-17;offset<=17;offset+=step){
  for(let height=0;height<levels;height++){
   const pos=side==='x'
    ?{x:c.x+(sign>0?r+1:-r),y:loc.y+0.3+height*0.85,z:Math.max(c.z-r,Math.min(c.z+r,loc.z+offset))}
    :{x:Math.max(c.x-r,Math.min(c.x+r,loc.x+offset)),y:loc.y+0.3+height*0.85,z:c.z+(sign>0?r+1:-r)};
   try{p.dimension.spawnParticle(visibleType,pos)}catch{}
  }
 }
 const access=fieldAccess(p,field);
 const plotMode=isOperator(p)?(operatorBoundaryBypass('plot')?'§aOP WALK ACCESS':'§cOP BYPASS OFF'):access?'§bTELEPORT ONLY':'§cLOCKED';
 try{p.onScreenDisplay.setActionBar(kind==='spawn'
  ?'§6SPAWN FORCEFIELD §7(233×233) §f| '+(isOperator(p)&&operatorBoundaryBypass('spawn')?'§aOP WALK ACCESS':'§cNO WALK-THROUGH')
  :`§bPLOT #${id+1} FORCEFIELD §7(${r*2+1}×${r*2+1}) §f| ${plotMode}`)}catch{}
 return true;
}
// Even at the center of a maximum-size plot, show which boundary is closest.
function plotBoundaryDistanceBar(p){
 if(p.dimension?.id!=='minecraft:overworld')return;
 const d=profile(p);if(d.plot<0)return;
 const c=coords(d.plot),r=plotRadius(d.plot),x=p.location.x-c.x,z=p.location.z-c.z;
 if(Math.abs(x)>r+.5||Math.abs(z)>r+.5)return;
 const dist=Math.max(0,Math.floor(Math.min(r+.5-Math.abs(x),r+.5-Math.abs(z))));
 try{p.onScreenDisplay.setActionBar(`§bPLOT BOUNDARY §7(${2*r+1}×${2*r+1}) §f| nearest edge §e${dist} blocks`)}catch{}
}
// Movement check every tick, wall particles twice per second. Does not
// place/remove blocks, interfere with horn cooldown, or alter world spawn.
system.runInterval(()=>{
 const online=new Set();
 for(const p of world.getAllPlayers()){
  online.add(p.id);
  try{enforceForcefield(p)}catch(err){console.warn('[SkyGen] forcefield enforcement error: '+err)}
  if(system.currentTick%10===0&&p.dimension?.id==='minecraft:overworld'){
   try{if(!renderForcefield(p))plotBoundaryDistanceBar(p)}catch(err){console.warn('[SkyGen] forcefield display error: '+err)}
  }
 }
 for(const id of forcefieldPrevious.keys())if(!online.has(id)){forcefieldPrevious.delete(id);forcefieldNotices.delete(id)}
},1);
// v0.8.1: Load the destination, generate/verify its floor, and KEEP that
// chunk loaded until the teleport completes (or the request is cancelled).
// In v0.8.0 the ticking area was removed before the Plot Horn teleport,
// making previously created islands appear to be missing while unloaded.
const plotBuilds=new Map(),plotRepairNotice=new Map();
const ACTIVE_PLOT_AREAS='sg_active_plot_areas_v1',MAX_PLOT_STAGES=6;
let plotStartupSweepDone=false;
function areaRegistry(){
 try{const a=JSON.parse(String(world.getDynamicProperty(ACTIVE_PLOT_AREAS)||'[]'));return Array.isArray(a)?a.filter(x=>/^sg_p\d+$/.test(x)):[]}catch{return []}
}
function trackArea(name,active){
 const names=new Set(areaRegistry());if(active)names.add(name);else names.delete(name);
 world.setDynamicProperty(ACTIVE_PLOT_AREAS,JSON.stringify([...names].slice(0,100)));
}
function sweepSkyGenAreas(){
 const dim=world.getDimension('overworld');
 const names=new Set(areaRegistry());
 // Also find legacy v0.8.1 leftovers where no registry existed.
 try{const result=dim.runCommand('tickingarea list');const txt=String(result?.statusMessage||'');
  for(const match of txt.matchAll(/sg_p\d+/g))names.add(match[0]);
 }catch(e){console.warn('[SkyGen] tickingarea enumeration unavailable '+e)}
 for(const name of names){
  if([...plotBuilds.values()].some(x=>x.areaName===name))continue;
  try{dim.runCommand('tickingarea remove '+name)}catch(e){console.warn('[SkyGen] stale plot area '+name+' '+e)}
 }
 try{world.setDynamicProperty(ACTIVE_PLOT_AREAS,JSON.stringify([...plotBuilds.values()].map(x=>x.areaName).filter(Boolean)))}catch(e){console.warn('[SkyGen] tickingarea registry '+e)}
 plotStartupSweepDone=true;
}
system.runTimeout(sweepSkyGenAreas,20);
const PLOT_RETRY_TICKS=10,PLOT_MAX_TRIES=40;
function plotNotice(p,msg){
 const last=plotRepairNotice.get(p.id)??-99999;
 if(system.currentTick-last>200){plotRepairNotice.set(p.id,system.currentTick);p.sendMessage(msg)}
}
function loadedPlotBlock(dim,x,y,z){
 try{return dim.getBlock({x,y,z})}catch{return undefined}
}
function solidPlotFloor(b){return !!b&&!b.isAir&&!['minecraft:water','minecraft:lava'].includes(b.typeId)}
function plotFloorReady(id){
 const c=coords(id),dim=world.getDimension('overworld');
 // Verify the permanent support layer. The surface can be mined by the owner.
 for(let dx=-8;dx<=8;dx++)for(let dz=-8;dz<=8;dz++){
  if(!solidPlotFloor(loadedPlotBlock(dim,c.x+dx,c.y-2,c.z+dz)))return false;
 }
 return true;
}
function findPlotLanding(id){
 const c=coords(id);
 return findSafeLanding(c,PLOT_LANDING_OFFSETS,[c.y-1,c.y-2],
  (x,z)=>plotAt(x,z)===id&&!inSpawn(x,z)&&!inBuiltSkyRealm(x,z),2);
}
function buildPlotInLoadedChunk(id){
 const c=coords(id),dim=world.getDimension('overworld');
 // Do not run fill against chunks that have not loaded yet.
 if(!loadedPlotBlock(dim,c.x,c.y-1,c.z))return false;
 if(plotFloorReady(id))return true;
 // 'keep' fills AIR ONLY. Existing buildings / chests / custom plot flooring
 // are not overwritten. A no-blocks-filled command may fail harmlessly.
 for(const [offset,block] of [[-1,'minecraft:grass_block'],[-3,'minecraft:dirt'],[-2,'minecraft:dirt']]){
  const y=c.y+offset;
  try{dim.runCommand(`fill ${c.x-8} ${y} ${c.z-8} ${c.x+8} ${y} ${c.z+8} ${block} keep`)}
  catch(e){if(!plotFloorReady(id))console.warn('[SkyGen] plot '+id+' floor layer '+offset+': '+e)}
 }
 return plotFloorReady(id);
}
function stageAndBuildPlot(p,id,teleportAfter=true){
 if(!p?.isValid)return;
 if(!canVisit(p,id))return p.sendMessage('§cYou do not have permission to use this plot.');
 if(teleportAfter){
  const now=system.currentTick,until=cooldowns.get(p.id)||0;
  if(now<until)return p.sendMessage('§cTeleport cooldown: '+Math.ceil((until-now)/20)+'s');
  if(pending.has(p.id))return p.sendMessage('§eTeleport already counting down.');
 }
 if(!plotStartupSweepDone){system.runTimeout(()=>{if(p.isValid)stageAndBuildPlot(p,id,teleportAfter)},25);return}
 const active=plotBuilds.get(id);
 if(active){
  // Claim-time pre-generation can be upgraded into a Plot Horn teleport.
  if(active.playerId===p.id&&teleportAfter){active.teleportAfter=true;p.sendMessage('§eSkyGen: Your plot is loading. Teleport will start when ready.');}
  else if(teleportAfter)plotNotice(p,'§eSkyGen: That plot is currently loading. Try again shortly.');
  return;
 }
 if(plotBuilds.size>=MAX_PLOT_STAGES){
  plotNotice(p,'§eSkyGen: Too many islands loading. Please retry the Plot Horn shortly.');return;
 }
 const dim=world.getDimension('overworld'),c=coords(id),name='sg_p'+id;
 const session={playerId:p.id,teleportAfter,finished:false,areaName:name};
 plotBuilds.set(id,session);
 let areaActive=false,tries=0,lastError='Plot chunk not loaded';
 function cleanup(){
  if(session.finished)return;
  session.finished=true;
  if(plotBuilds.get(id)===session)plotBuilds.delete(id);
  if(areaActive){try{dim.runCommand(`tickingarea remove ${name}`)}catch(e){console.warn('[SkyGen] plot tickingarea cleanup '+id+': '+e)}}
  try{trackArea(name,false)}catch(e){console.warn('[SkyGen] area registry cleanup '+e)}
 }
 session.cancel=cleanup;
 try{
  // Track the area BEFORE creating it, so startup can reclaim a crash orphan.
  trackArea(name,true);
  // Clear only a stale area from a previous interrupted SkyGen run.
  try{dim.runCommand(`tickingarea remove ${name}`)}catch{}
  // A radius of 1 chunk is enough for the 17x17 starter island.
  // false avoids permanent preload overhead on Realm restarts.
  const added=dim.runCommand(`tickingarea add circle ${c.x} ${c.y} ${c.z} 1 ${name} false`);
  if(added?.successCount===0)throw Error('Plot ticking area rejected or limit reached');
  areaActive=true;
  if(teleportAfter)p.sendMessage('§eSkyGen: Preparing plot #'+(id+1)+' safely. Stay where you are.');
 }catch(e){
  lastError=String(e);cleanup();
  console.warn('[SkyGen] cannot load plot '+id+': '+lastError);
  p.sendMessage('§cSkyGen cannot load plot chunks. Check that cheats are enabled and there is a free ticking-area slot. '+lastError.slice(0,120));
  return;
 }
 function check(){
  if(session.finished)return;
  if(!p.isValid){cleanup();return}
  if(!canVisit(p,id)){cleanup();p.sendMessage('§cPlot access was revoked.');return}
  try{
   if(buildPlotInLoadedChunk(id)){
    const target=findPlotLanding(id);
    if(!target){cleanup();p.sendMessage('§cPlot floor is present, but the landing area is blocked. Clear some space at the plot center.');return}
    if(!session.teleportAfter){cleanup();p.sendMessage('§aSkyGen: Plot #'+(id+1)+' is ready. Use the Plot Horn to teleport.');return}
    // IMPORTANT: keep the ticking area alive throughout the 5-second
    // countdown. tpRequest releases it on success, failure or cancellation.
    if(!tpRequest(p,target,id===profile(p).plot?'your plot':'plot #'+(id+1),id,cleanup))cleanup();
    return;
   }
  }catch(e){lastError=String(e);if(tries===0||tries===PLOT_MAX_TRIES-1)console.warn('[SkyGen] plot '+id+' build error: '+lastError)}
  tries++;
  if(tries>=PLOT_MAX_TRIES){
   cleanup();p.sendMessage('§cSkyGen: Plot chunks could not be prepared. No teleport attempted. '+lastError.slice(0,120));return;
  }
  system.runTimeout(check,PLOT_RETRY_TICKS);
 }
 system.runTimeout(check,10);
}
function claim(p){
 const d=profile(p);
 if(d.plot>=0){
  const owner=ownerId(d.plot);
  if(owner&&owner!==p.id)throw Error('Plot owner mismatch; assignment locked for operator review');
  if(!owner)world.setDynamicProperty(keyForPlot(d.plot),p.id);
  return d;
 }
 // A single recoverable global intent prevents a failed write from stalling
 // onboarding or assigning one plot to two players. Existing owners are kept.
 const id=allocateOrRecoverPlot({
  get:key=>world.getDynamicProperty(key),
  set:(key,value)=>world.setDynamicProperty(key,value),
  owner:ownerId,
  ownerKey:keyForPlot,
  overlaps:id=>plotOverlapsProtection(id,PLOT_TIERS.at(-1).radius)
 },p.id);
 d.plot=id;save(p,d);
 p.sendMessage('§aSkyGen: Plot #'+(id+1)+' assigned. Building starter island...');
 system.runTimeout(()=>{if(p.isValid&&!plotBuilds.has(id))stageAndBuildPlot(p,id,false)},10);
 return d;
}
function toolmatch(i,t){return i?.typeId===t.type&&i?.nameTag===t.name}
function isTool(i){return !!i&&TOOLS.some(t=>toolmatch(i,t))}
function syncSkyGenPlotPermission(p){
 try{
  const d=profile(p),id=d.plot;
  const desired=Number.isInteger(id)&&id>=0&&ownerId(id)===p.id?'sg_owner_'+id+'_'+plotRadius(id):'';
  for(const tag of p.getTags())if(tag.startsWith('sg_owner_')&&tag!==desired)p.removeTag(tag);
  if(desired&&!p.hasTag(desired))p.addTag(desired);
 }catch(err){console.warn('[SkyGen SECURITY] plot permission tags: '+err)}
}
function ensure(p){try{syncSkyGenPlotPermission(p);const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return;for(const t of TOOLS){const old=inv.getItem(t.slot);if(toolmatch(old,t)&&old.lockMode===ItemLockMode.slot&&old.keepOnDeath)continue;if(old&&!isTool(old)){let free=-1;for(let i=9;i<inv.size;i++)if(!inv.getItem(i)){free=i;break}if(free<0)for(let i=0;i<6;i++)if(!inv.getItem(i)){free=i;break}if(free<0)continue;inv.setItem(free,old)}const item=new ItemStack(t.type,1);item.nameTag=t.name;item.lockMode=ItemLockMode.slot;item.keepOnDeath=true;inv.setItem(t.slot,item)}for(let i=0;i<inv.size;i++)if((i<6||i>8)&&isTool(inv.getItem(i)))inv.setItem(i,undefined)}catch(e){console.warn('SkyGen tools: '+e)}}
function finishPendingTeleport(t,success=false){
 if(!t||t.finished)return;
 t.finished=true;
 if(typeof t.onFinish==='function'){
  // After success keep the destination loaded briefly for client chunk handoff.
  if(success)system.runTimeout(()=>{try{t.onFinish()}catch(e){console.warn('[SkyGen] plot release '+e)}},40);
  else try{t.onFinish()}catch(e){console.warn('[SkyGen] plot release '+e)}
 }
}
function teleportWatchdog(p,id,token){
 const t=pending.get(id);
 if(!t||t.token!==token)return;
 try{
  if(!p.isValid){pending.delete(id);finishPendingTeleport(t);return}
  const now=system.currentTick,loc=p.location;
  if(p.dimension.id!==t.dim||Math.abs(loc.x-t.start.x)>0.15||Math.abs(loc.y-t.start.y)>0.15||Math.abs(loc.z-t.start.z)>0.15){
   pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cTELEPORT CANCELLED');p.sendMessage('§cTeleport cancelled: you moved.');return;
  }
  if(now-t.created>C.warmup+120){pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cTELEPORT TIMED OUT');p.sendMessage('§cDestination chunks did not become ready; try again later. Operator: /tickingarea list all-dimensions');return;}
  if(now<t.end){
   const n=Math.max(1,Math.ceil((t.end-now)/20));
   try{p.onScreenDisplay.setTitle('§e'+n,{fadeInDuration:0,stayDuration:5,fadeOutDuration:0})}catch{}
   try{p.onScreenDisplay.setActionBar('§eTeleport in '+n+' seconds — stand still')}catch{}
   if(t.lastShown!==n){t.lastShown=n;p.sendMessage('§e'+n+'...')}
   system.runTimeout(()=>teleportWatchdog(p,id,token),1);return;
  }
  if(t.nextTeleportTry&&now<t.nextTeleportTry){system.runTimeout(()=>teleportWatchdog(p,id,token),Math.max(1,t.nextTeleportTry-now));return;}
  if(t.visitPlot!==undefined&&!canVisit(p,t.visitPlot)){
   pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cACCESS REVOKED');p.sendMessage('§cPlot access was revoked.');return;
  }
  if(t.safeSpawn){
   const safe=ensureSpawn();
   if(!safe){pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cSPAWN NOT READY');p.sendMessage('§cSpawn is not verified. Teleport canceled.');return}
   t.target=safe;
  }
  if(t.visitPlot!==undefined){
   // Re-select a landing just before teleport. Someone could have built in
   // the original arrival spot while the countdown was running.
   const safe=findPlotLanding(t.visitPlot);
   if(!safe){pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cPLOT NOT READY');p.sendMessage('§cPlot landing is not safe; teleport cancelled. Try the Plot Horn again.');return;}
   t.target=safe;
  }
  try{
   const destination=world.getDimension('overworld');
   // tryTeleport reports false if Bedrock still cannot load the destination.
   // NEVER fall back to a blind /tp into a void chunk.
   forcefieldTickets.set(id,{...t.target,expires:system.currentTick+5});
   if(typeof p.tryTeleport==='function'){
    if(!p.tryTeleport(t.target,{dimension:destination,checkForBlocks:false}))throw new Error('Destination chunk is not ready');
   }else p.teleport(t.target,{dimension:destination,checkForBlocks:false});
   pending.delete(id);cooldowns.set(id,system.currentTick+teleportCooldown(p));
   finishPendingTeleport(t,true);
   showTeleportText(p,'§aTELEPORTED!');p.sendMessage('§aTeleport successful.');
  }catch(err){
   forcefieldTickets.delete(id);
   // Keep the source-side movement guard and the destination ticking area
   // active for a bounded retry window after the 5-second countdown.
   if(system.currentTick-t.end<100){
    if(!t.waitingNotice){t.waitingNotice=true;p.sendMessage('§eDestination is still loading. Stand still; retrying safely.');}
    t.nextTeleportTry=system.currentTick+10;
    system.runTimeout(()=>teleportWatchdog(p,id,token),10);
   }else{
    pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cTELEPORT FAILED');
    p.sendMessage('§cTeleport failed safely: '+String(err).slice(0,120));
   }
  }
 }catch(err){pending.delete(id);finishPendingTeleport(t);try{p.sendMessage('§cTeleport timer error: '+String(err))}catch{};console.warn('SkyGen watchdog '+err)}
}
function tpRequest(p,target,label,visitPlot,onFinish,safeSpawn=false){
 const now=system.currentTick,id=p.id,until=cooldowns.get(id)||0;
 if(now<until){p.sendMessage('§cTeleport cooldown: '+Math.ceil((until-now)/20)+'s');return false}
 if(pending.has(id)){p.sendMessage('§eTeleport already counting down.');return false}
 const start={x:p.location.x,y:p.location.y,z:p.location.z};
 const token=now+'-'+id;
 pending.set(id,{start,dim:p.dimension.id,target,label,visitPlot,onFinish,safeSpawn,created:now,end:now+C.warmup,token,lastShown:5});
 p.sendMessage('§eTeleport to '+label+' in 5 seconds. Stand still!');
 showTeleportText(p,'§e5');
 system.runTimeout(()=>teleportWatchdog(p,id,token),1);
 return true;
}
function tpPlot(p){
 let d=profile(p);
 // The Horn can recover a first-join plot assignment without forcing a rejoin.
 if(d.plot<0){try{d=claim(p)}catch(e){return p.sendMessage('§cPlot assignment needs operator review: '+String(e).slice(0,120))}}
 stageAndBuildPlot(p,d.plot,true);
}
// The original 50 ordered SkyGen ranks remain unchanged; 51-1000 extend them.
// The original 50 ordered SkyGen ranks are authoritative. Never trust player
// chat, nametags, or user-set tags to assign a title or player permissions.
const rankNativeUnsupported=new Set();
function rankColor(level){const n=rankLevel(level);return n>=50?'§5':n>=41?'§6':n>=31?'§d':n>=21?'§b':n>=11?'§a':'§7'}
function rankBadge(level){return rankColor(level)+'['+rankName(level)+']§r'}
function nativeRankPrefixAvailable(p){return !!p&&'chatNamePrefix' in p}
function applyRankIdentity(p,level){
 const badge=rankBadge(level),head=badge+' '+p.name;
 // Bedrock Entity.nameTag is the visible overhead label, not a permission.
 if(p.nameTag!==head)p.nameTag=head;
 // Native chat prefix preserves normal player chat delivery and moderation.
 // This is a pre-release API, so do not assume it exists on Xbox/Realms.
 if(nativeRankPrefixAvailable(p)){
  try{if(p.chatNamePrefix!==badge+' ')p.chatNamePrefix=badge+' ';rankNativeUnsupported.delete(p.id);return}
  catch(err){if(!rankNativeUnsupported.has(p.id))console.warn('[SkyGen RANK] native chat prefix not usable: '+String(err).slice(0,120));rankNativeUnsupported.add(p.id)}
 }
}
function rankChatCommand(actor){
 const d=profile(actor);
 const mode=nativeRankPrefixAvailable(actor)&&!rankNativeUnsupported.has(actor.id)?'native rank prefix':'normal Bedrock chat';
 actor.sendMessage('§dSkyGen rank: §r'+rankName(d.rank)+' §7('+rankLevel(d.rank)+'/1000).');
 actor.sendMessage('§7Overhead rank tag active. Chat mode: §e'+mode+'.');
}
function noPayoutRoom(d,amount){
 const shortage=amount-Math.max(0,CREDIT_CAP-d.credits);
 return 'Free '+shortage.toLocaleString()+' Credits of wallet space or make room in your default bank account.';
}
function rankRewards(d){
 const oldRank=d.rank||1;
 const progress=d.xpProgress===undefined?legacyProgress(Math.min(oldRank,50),d.xp||0):d.xpProgress;
 const mirror=mirrorXP(oldRank,progress);
 const delta=Math.max(0,d.xp-mirror);
 if(!Number.isSafeInteger(delta))throw Error('Unsafe incoming XP; profile must be reviewed');
 const change=advanceRank(oldRank,progress,delta);
 d.rank=change.rank;d.xpProgress=change.progress;d.xp=mirrorXP(d.rank,d.xpProgress);
 const multiplier=hasSkill(d,'econ_rank')?110:100;
 let bonus=0,orbits=0;
 for(let n=oldRank+1;n<=d.rank;n++){
  bonus+=n*multiplier;
  if(n%10===0)orbits++;
 }
 return {oldRank,bonus,orbits};
}
function announceRank(p,d,old){
 if(d.rank>old)p.sendMessage(`§dRank up! ${old} → ${d.rank}. §e+${skillEntitlement(d.rank)-skillEntitlement(old)} Skill Points!`);
 applyRankIdentity(p,d.rank);
}
function rank(p,d){
 const {oldRank,bonus,orbits}=rankRewards(d);
 const journal=readEconomicTxn(p);
 const unlocked=!journal||journal.state==='complete';
 const destination=bonus&&unlocked?payoutDestination(d,bonus):undefined;
 const paidOrbits=unlocked&&orbits<=CREDIT_CAP-d.orbits?orbits:0;
 if(destination!==undefined)creditPayout(d,destination,bonus);
 else if(bonus)d.pendingRankCredits=(d.pendingRankCredits??0)+bonus;
 if(paidOrbits)d.orbits+=paidOrbits;
 else if(orbits)d.pendingRankOrbits=(d.pendingRankOrbits??0)+orbits;
 save(p,d);
 announceRank(p,d,oldRank);
 if(bonus)p.sendMessage(destination===undefined?'§eRank Credits are pending in Compass → Bank.':
  '§aRank reward: '+bonus+' Credits to '+destinationName(d,destination)+'.');
 if(orbits)p.sendMessage(paidOrbits?'§aRank milestone: +'+paidOrbits+' Orbits.':'§eMilestone Orbits are pending in Compass → Bank.');
}
function collectBankPayouts(p){
 assertBankUnlocked(p);
 const d=profile(p);
 const credits=d.pendingRankCredits??0,orbits=d.pendingRankOrbits??0;
 if(!Number.isSafeInteger(credits)||credits<0||!Number.isSafeInteger(orbits)||orbits<0)
  throw Error('Pending rank rewards require operator review.');
 const destination=credits?payoutDestination(d,credits):undefined;
 const claimOrbits=orbits>0&&orbits<=CREDIT_CAP-d.orbits;
 if(destination!==undefined){
  creditPayout(d,destination,credits);
  delete d.pendingRankCredits;
 }
 if(claimOrbits){
  d.orbits+=orbits;
  delete d.pendingRankOrbits;
 }
 if(destination!==undefined||claimOrbits)save(p,d);
 if(credits)p.sendMessage(destination===undefined?'§e'+noPayoutRoom(d,credits):
  '§aCollected '+credits+' rank Credits in '+destinationName(d,destination)+'.');
 if(orbits)p.sendMessage(claimOrbits?'§aCollected '+orbits+' milestone Orbits.':'§eFree room for '+orbits+' milestone Orbits.');
 const marketPaid=settleSellerProceeds(p,d);
 if(!credits&&!orbits&&!marketPaid)p.sendMessage('§7No sale or rank payouts collected.');
}

function showUI(p,ui,attempt=0){
 return new Promise((resolve,reject)=>{
  system.runTimeout(()=>{
   if(p?.isValid===false)return resolve({canceled:true});
   try{ui.show(p).then(r=>{
    if(r.canceled&&/UserBusy/i.test(String(r.cancelationReason||''))&&attempt<5){showUI(p,ui,attempt+1).then(resolve,reject);return}
    resolve(r);
   }).catch(e=>{
    if(attempt<5&&/busy/i.test(String(e)))showUI(p,ui,attempt+1).then(resolve,reject);
    else reject(e);
   })}catch(e){reject(e)}
  },attempt?20*(attempt+1):8);
 });
}
// Keep the player in their current shopping/upgrade workflow after a completed
// action. Respect manual UserClosed/Esc cancellation; only action handlers call
// this helper, and no transaction is ever retried automatically.
function menuAgain(p,open){
 system.runTimeout(()=>{
  if(p?.isValid===false)return;
  try{open()}catch(err){console.warn('[SkyGen MENU] return navigation '+err)}
 },12);
}
function form(p,title,body,buttons,cb,onClose){
 let f=skyAction().title(title).body(body);
 for(const b of buttons)f=f.button(b);
 showUI(p,f).then(r=>{if(!r.canceled&&Number.isInteger(r.selection))cb(r.selection);else onClose?.()}).catch(e=>{onClose?.();console.warn('SkyGen UI '+e)});
}
// Admin privileges require both a server-issued axe and a persistent grant.
// Operator bootstrap: /scriptevent skygen:adminaxe
const ADMIN_AXE='§4§lSkyGen Admin Manager';
function isOperator(p){try{if(typeof p.isOp==="function"&&p.isOp()===true)return true}catch{}try{return p.playerPermissionLevel===2}catch{return false}}
function isAdmin(p){return isOperator(p)||world.getDynamicProperty('sg_admin_'+p.id)===true}
function adminAxe(i){return i?.typeId==='minecraft:wooden_axe'&&i.nameTag===ADMIN_AXE&&i.getLore()?.includes('§8SkyGen issued admin tool')}
function issueAdminAxe(p,attempt=0){
 try{
  if(!p)return;
  if(!isAdmin(p))return p.sendMessage('§cSkyGen Admin permission not active. Ask an operator to grant access.');
  const inv=inventory(p);
  if(!inv){if(attempt<3)return system.runTimeout(()=>issueAdminAxe(p,attempt+1),20);return p.sendMessage('§cAdmin axe: inventory unavailable.');}
  let existing=-1;
  for(let i=0;i<inv.size;i++){if(adminAxe(inv.getItem(i))){existing=i;break;}}
  if(existing>=0&&existing<6)return p.sendMessage('§aAdmin axe is in hotbar slot '+(existing+1)+'.');
  let slot=-1;
  for(let i=0;i<Math.min(6,inv.size);i++){if(!inv.getItem(i)){slot=i;break;}}
  if(existing>=0){
   if(slot>=0){const axe=inv.getItem(existing);inv.setItem(slot,axe);inv.setItem(existing,undefined);return p.sendMessage('§aAdmin axe moved to hotbar slot '+(slot+1)+'.');}
   return p.sendMessage('§eAdmin axe is in inventory slot '+(existing+1)+'. Free a hotbar slot 1–6 to move it.');
  }
  if(slot<0)return p.sendMessage('§cFree one of hotbar slots 1–6, then run /scriptevent skygen:adminaxe again.');
  const axe=new ItemStack('minecraft:wooden_axe',1);
  axe.nameTag=ADMIN_AXE;axe.setLore(['§8SkyGen issued admin tool','§cAdmin access required']);
  axe.lockMode=ItemLockMode.inventory;
  inv.setItem(slot,axe);
  const actual=inv.getItem(slot);
  if(!adminAxe(actual))throw Error('Item verification failed after insertion');
  p.sendMessage('§aSkyGen Admin axe delivered to hotbar slot '+(slot+1)+'.');
 }catch(err){
  console.warn('[SkyGen ADMIN] axe delivery: '+err);
  if(attempt<3)system.runTimeout(()=>issueAdminAxe(p,attempt+1),20);
  else try{p.sendMessage('§cAdmin axe delivery failed: '+err)}catch{}
 }
}
function adminAudit(actor,action,target,detail){console.warn('[SkyGen ADMIN] '+actor.name+' '+action+' '+target.name+' '+detail)}
// All admin UI transitions are deferred: Bedrock rejects forms opened in the same tick
// as the previous form's completion (often returning UserBusy).
function adminLater(fn){system.runTimeout(()=>{try{fn()}catch(e){console.warn('[SkyGen ADMIN UI] '+e);}},12)}
function adminShow(p,ui,step,attempt=0){
 return new Promise((resolve,reject)=>{
  system.runTimeout(()=>{
   ui.show(p).then(r=>{
    if(r.canceled&&String(r.cancelationReason||'').includes('UserBusy')&&attempt<5){
     adminNotice(p,'§eAdmin menu busy; retrying '+step+'...');
     adminShow(p,ui,step,attempt+1).then(resolve,reject);return;
    }
    if(r.canceled)adminNotice(p,'§7Admin '+step+' closed ('+String(r.cancelationReason||'cancelled')+').');
    else adminNotice(p,'§7Admin '+step+' selection received.');
    resolve(r);
   }).catch(e=>{
    if(attempt<3&&/busy/i.test(String(e)))return adminShow(p,ui,step,attempt+1).then(resolve,reject);
    adminNotice(p,'§cAdmin '+step+' failed: '+e);reject(e);
   });
  },attempt?20*(attempt+1):8);
 });
}
function adminNotice(p,msg){try{p.sendMessage(msg)}catch(e){console.warn('[SkyGen ADMIN NOTICE] '+e)}}
function adminOnline(target){return world.getAllPlayers().some(x=>x.id===target.id)}
function adminFormError(p,where,e){console.warn('[SkyGen ADMIN '+where+'] '+e);adminNotice(p,'§cAdmin '+where+' error: '+e)}
function adminAction(p,title,body,buttons,cb){
 let ui=skyAction().title(title).body(body);
 for(const label of buttons)ui=ui.button(label);
 adminShow(p,ui,title).then(r=>{if(!r.canceled)adminLater(()=>cb(r.selection))}).catch(e=>adminFormError(p,title,e));
}
function adminBoundaryMenu(p){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators can change boundary bypass settings.');
 const spawn=operatorBoundaryBypass('spawn'),plots=operatorBoundaryBypass('plot');
 adminAction(p,'§6BOUNDARY CONTROLS',
  '§7Walk bypass settings apply to all operators.\n§eAdmin Build Mode is personal, spawn-only, and resets on logout.',
  ['Spawn OP Bypass: '+(spawn?'§aON':'§cOFF'),
   'Plot OP Bypass: '+(plots?'§aON':'§cOFF'),'Admin Build Mode: '+(personalSpawnBuild.has(p.id)?'§aON':'§cOFF'),'Back to Admin Manager'],
  i=>{
   if(!isOperator(p))return adminNotice(p,'§cRealm operator permission required.');
   if(i===3)return adminMenu(p);
   if(i===2){if(personalSpawnBuild.has(p.id))personalSpawnBuild.delete(p.id);else personalSpawnBuild.add(p.id);adminNotice(p,'§ePersonal spawn placing/breaking '+(personalSpawnBuild.has(p.id)?'ENABLED':'DISABLED')+'.');return adminBoundaryMenu(p)}
   if(i!==0&&i!==1)return;
   const kind=i===0?'spawn':'plot',key=kind==='spawn'?OP_SPAWN_BYPASS_KEY:OP_PLOT_BYPASS_KEY;
   const newValue=!operatorBoundaryBypass(kind);
   try{
    world.setDynamicProperty(key,newValue);
    if(world.getDynamicProperty(key)!==newValue)throw Error('Setting did not persist');
   }catch(err){adminNotice(p,'§cCould not save boundary setting: '+err);return adminBoundaryMenu(p)}
   // Invalidate prior walking sample so operators already outside a wall
   // are not automatically bounced during a permission change.
   for(const op of world.getAllPlayers())if(isOperator(op))forcefieldPrevious.delete(op.id);
   adminNotice(p,'§a'+kind.toUpperCase()+' operator walk bypass '+(newValue?'ENABLED':'DISABLED')+'.');
   adminBoundaryMenu(p);
  });
}
// OP-only recovery: register the actual lobby instead of blindly teleporting
// everyone to obsolete fixed-Y coordinates. Changes do not alter builds or player data.
function spawnCandidateSafe(pos){
 if(!pos||!['x','y','z'].every(k=>Number.isSafeInteger(pos[k])))return 'Invalid coordinates';
 if(Math.abs(pos.x)>29000000||Math.abs(pos.z)>29000000||pos.y<-63||pos.y>317)return 'Outside safe world boundaries';
 const overlaps=overlappingPlots(pos,PLOT_TIERS.at(-1).radius);
 if(overlaps.length)return 'Spawn protection would overlap reserved plot #'+(overlaps[0]+1);
 const dim=world.getDimension('overworld'),floor=spawnFloorBlock(dim,pos.x,pos.y-1,pos.z);
 if(!floor)return 'Destination chunk is not loaded';
 if(!safeLandingFloor(floor))return 'No safe solid floor immediately beneath your feet';
 if(![0,1,2].every(dy=>spawnFloorBlock(dim,pos.x,pos.y+dy,pos.z)?.isAir))return 'Three air blocks of headroom are required';
 return '';
}
function updateSpawnAnchor(p,pos){
 if(publicCityBuildRunning())return adminNotice(p,'§cSpawn changes are disabled while Sky Realm city construction is active.');
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators can change spawn.');
 const err=spawnCandidateSafe(pos);if(err)return adminNotice(p,'§cSpawn not changed: '+err);
 const old=spawnPosition(),oldRaw=world.getDynamicProperty(SPAWN_ANCHOR_KEY),oldArea=spawnAreaActive;
 try{
  world.setDynamicProperty(SPAWN_ANCHOR_KEY,JSON.stringify(pos));
  const now=spawnPosition();if(now.x!==pos.x||now.y!==pos.y||now.z!==pos.z)throw Error('Spawn settings could not be verified');
  spawnAreaActive=false;
  if(!stageFixedSpawnArea(true))throw Error('Could not keep destination chunks loaded; check tickingarea limit');
  if(!spawnLanding())throw Error('Spawn landing could not be verified after save');
  fixedSpawnDefaultApplied=false;
  if(!syncFixedDefaultSpawn())throw Error('World spawn could not be updated');
  for(const op of world.getAllPlayers())forcefieldPrevious.delete(op.id);
  adminAudit(p,'SET SPAWN',p,`${old.x},${old.y},${old.z} -> ${pos.x},${pos.y},${pos.z}`);
  adminNotice(p,`§aSkyGen spawn verified: ${pos.x}, ${pos.y}, ${pos.z}. Protected spawn area follows this location.`);
  return true;
 }catch(e){
  console.warn('[SkyGen SPAWN] anchor change rolled back: '+e);
  try{world.setDynamicProperty(SPAWN_ANCHOR_KEY,oldRaw)}catch(rollback){console.warn('[SkyGen SPAWN] rollback failed '+rollback)}
  spawnAreaActive=false;stageFixedSpawnArea(true);fixedSpawnDefaultApplied=false;syncFixedDefaultSpawn();
  adminNotice(p,'§cSpawn change canceled and previous settings restored: '+e);
  return false;
 }
}
function spawnStatus(p){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may inspect spawn settings.');
 const d=spawnDiagnostics(),s=d.anchor,areaVerified=stageFixedSpawnArea();
 const overlaps=new Set(overlappingPlots(s,PLOT_TIERS.at(-1).radius,true));
 if(cityProtectionActive())for(const id of overlappingPlots(C.spawn,PLOT_TIERS.at(-1).radius,true))overlaps.add(id);
 if(overlaps.size)p.sendMessage('§cProtected land overlaps owned plots: '+[...overlaps].map(id=>'#'+(id+1)).join(', '));
 p.sendMessage(`§6SkyGen SPAWN STATUS §7X:${s.x} Y:${s.y} Z:${s.z} (${spawnIsOriginal()?'original':'operator-set'})`);
 p.sendMessage(`§7Chunk: ${d.chunkLoaded?'§aloaded':'§cunloaded'} §7Center floor: ${d.centerFloor?'§aexists':'§cmissing'} §7Headroom: ${d.centerHeadroom?'§aclear':'§cblocked/unloaded'}`);
 p.sendMessage('§7Verified landing: '+(d.landing?'§a'+d.landing.x+', '+d.landing.y+', '+d.landing.z:'§cNONE'));
 p.sendMessage('§7Spawn ticking area staged: '+(areaVerified?'§ayes':'§cno')+'. If blocked, stand at your real lobby and run /scriptevent skygen:spawn set');
}
function spawnAtOperator(p){
 if(!isOperator(p)||p.dimension?.id!=='minecraft:overworld')return adminNotice(p,'§cRealm operator must stand at the spawn platform in the Overworld.');
 const pos={x:Math.floor(p.location.x),y:Math.floor(p.location.y),z:Math.floor(p.location.z)},problem=spawnCandidateSafe(pos);
 if(problem)return adminNotice(p,'§cCannot set spawn here: '+problem);
 const old=spawnPosition();
 const confirm=skyMessage().title('§6CONFIRM SPAWN LOCATION')
  .body(`§eNew location: ${pos.x}, ${pos.y}, ${pos.z}\n§7Current location: ${old.x}, ${old.y}, ${old.z}\n\nThis changes the protected 233×233 spawn center for all players. Existing blocks will not be deleted. Confirm only while standing on your finished lobby.`)
  .button1('Cancel').button2('Set Spawn Here');
 adminShow(p,confirm,'spawn location confirmation').then(r=>{
  if(r.canceled||r.selection!==1)return;
  adminLater(()=>{if(isOperator(p))updateSpawnAnchor(p,pos)});
 }).catch(e=>adminFormError(p,'spawn location',e));
}
function spawnControls(p){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may manage spawn.');
 const s=spawnPosition();
 adminAction(p,'§6SPAWN CONTROLS',`§7Active spawn: §e${s.x}, ${s.y}, ${s.z}\n§7Must have solid floor and 3 blocks of air above. All teleport horns and menus use the verified destination.`,
 ['Set Spawn at My Location','Check Spawn Status','Restore Original Spawn (0, 1, 0)','Back to Admin Manager'],i=>{
  if(i===0)return spawnAtOperator(p);
  if(i===1){spawnStatus(p);return spawnControls(p)}
  if(i===2){
   const confirm=skyMessage().title('§cRESTORE ORIGINAL SPAWN').body('Restore 0, 1, 0 as the protected spawn center? The old area must load and have a safe landing.').button1('Cancel').button2('Restore');
   adminShow(p,confirm,'restore spawn confirmation').then(r=>{if(!r.canceled&&r.selection===1)adminLater(()=>updateSpawnAnchor(p,{...C.spawn}))}).catch(e=>adminFormError(p,'restore spawn',e));
   return;
  }
  if(i===3)return adminMenu(p);
 });
}
function spawnCommand(p,message){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may manage spawn.');
 const action=String(message||'').trim().toLowerCase();
 if(action==='status'||action==='check')return spawnStatus(p);
 if(action==='set')return spawnAtOperator(p);
 if(action==='reset')return adminNotice(p,'§eFor safety, use Admin Axe → Spawn Controls → Restore Original Spawn.');
 p.sendMessage('§eUse /scriptevent skygen:spawn status OR /scriptevent skygen:spawn set (at your lobby).');
}
function adminMenu(p){
 if(!isAdmin(p))return adminNotice(p,'§cAdmin access denied.');
 adminAction(p,'§4SKYGEN ADMIN MANAGER','Select an action. Changes are logged.',
 [isOperator(p)?'Manage Player Wallet':'Wallet (operator only)',isOperator(p)?'Give Player Items':'Items (operator only)',isOperator(p)?'Grant/Revoke Admin Access':'Admin Access (operator only)','Get My Admin Axe','Boundary Controls (operator only)','Spawn Controls (operator only)','Public Mine Levels (operator only)','Close'],
 i=>adminLater(()=>{
  if(!isAdmin(p))return adminNotice(p,'§cAdmin access expired.');
  if(i===0)return isOperator(p)?adminChoosePlayer(p,'wallet'):adminNotice(p,'§cRealm operator required.');
  if(i===1)return isOperator(p)?adminChoosePlayer(p,'items'):adminNotice(p,'§cRealm operator required.');
  if(i===2)return isOperator(p)?adminChoosePlayer(p,'access'):adminNotice(p,'§cOnly Realm operators can manage admin access.');
  if(i===3)return issueAdminAxe(p);
  if(i===4)return isOperator(p)?adminBoundaryMenu(p):adminNotice(p,'§cRealm operator required.');
  if(i===5)return isOperator(p)?spawnControls(p):adminNotice(p,'§cRealm operator required.');
  if(i===6)return isOperator(p)?publicMineAdminMenu(p):adminNotice(p,'§cRealm operator required.');
 }));
}
function adminChoosePlayer(p,mode){
 if(!isAdmin(p))return adminNotice(p,'§cAdmin access denied.');
 const online=world.getAllPlayers();
 adminAction(p,'§4SELECT PLAYER','Choose an online player.',[...online.map(x=>x.name),'Back'],i=>adminLater(()=>{
  if(i===online.length)return adminMenu(p);
  const target=online[i];if(!target||!adminOnline(target))return adminNotice(p,'§cPlayer is no longer online.');
  if(mode==='wallet')return adminWallet(p,target);
  if(mode==='items')return adminGive(p,target);
  return adminAccess(p,target);
 }));
}
function adminWallet(p,target){
 if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access denied or player offline.');
 const d=profile(target);
 adminAction(p,'§6PLAYER WALLET',target.name+'\\nCredits: '+d.credits+'\\nOrbits: '+d.orbits,
 ['Add Credits','Remove Credits','Add Orbits','Remove Orbits','Back'],i=>{
  if(i===4)return adminChoosePlayer(p,'wallet');
  if(i<0||i>3)return;
  const key=i<2?'credits':'orbits',sign=i%2===0?1:-1;
  const operation=(sign>0?'Add ':'Remove ')+(key==='credits'?'Credits':'Orbits');
  const ui=skyModal().title(operation).textField('Amount (whole number)','Enter amount',{defaultValue:'1000'});
  adminShow(p,ui,'wallet amount').then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();
   const amount=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   if(!Number.isSafeInteger(amount)||amount>2000000000)return adminNotice(p,'§cEnter 1 to 2,000,000,000.');
   if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access lost or player offline.');
   const current=profile(target),balance=Number(current[key])||0,next=balance+sign*amount;
   if(!Number.isSafeInteger(next)||next<0||next>2000000000)return adminNotice(p,'§cInsufficient balance or limit exceeded.');
   const confirm=skyMessage().title('Confirm '+operation)
    .body(target.name+'\\nAmount: '+amount+'\\nBefore: '+balance+'\\nAfter: '+next)
    .button1('Cancel').button2('Confirm');
   adminShow(p,confirm,'wallet confirmation').then(c=>{
    if(c.canceled||c.selection!==1)return adminNotice(p,'§7Wallet change canceled.');
    try{
     if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAccess lost or player disconnected.');
     const fresh=profile(target),now=Number(fresh[key])||0,updated=now+sign*amount;
     if(!Number.isSafeInteger(updated)||updated<0||updated>2000000000)return adminNotice(p,'§cBalance limit exceeded.');
     fresh[key]=updated;
     economicReconcileBypass.add(target.id);
     try{save(target,fresh)}finally{economicReconcileBypass.delete(target.id)}
     const verified=profile(target);
     if(Number(verified[key])!==updated)throw Error('Balance verification failed');
     adminAudit(p,sign>0?'ADD':'REMOVE',target,amount+' '+key);
     adminNotice(p,'§aSUCCESS: '+target.name+' '+key+' '+now+' → '+updated);
     adminNotice(target,'§aAdmin '+(sign>0?'added ':'removed ')+amount+' '+key+'. New balance: '+updated);
    }catch(e){adminFormError(p,'wallet save',e)}
   }).catch(e=>adminFormError(p,'wallet confirmation',e));
  }).catch(e=>adminFormError(p,'wallet amount',e));
 });
}
function adminGive(p,target){
 if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access denied or player offline.');
 const ui=skyModal().title('Give Item to '+target.name)
  .textField('Minecraft item ID','minecraft:diamond',{defaultValue:'minecraft:diamond'})
  .textField('Quantity (1–64)','1',{defaultValue:'1'});
 adminShow(p,ui,'give item').then(r=>{
  if(r.canceled)return;
  const id=String(r.formValues?.[0]??'').trim().toLowerCase();
  const raw=String(r.formValues?.[1]??'').trim();
  const qty=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
  if(!/^[a-z0-9_]+:[a-z0-9_]+$/.test(id)||!Number.isSafeInteger(qty)||qty>64)
   return adminNotice(p,'§cInvalid item ID or quantity.');
  let stack;
  try{stack=new ItemStack(id,qty)}catch(e){return adminFormError(p,'item creation',e)}
  const confirm=skyMessage().title('Confirm Item Delivery')
   .body('Player: '+target.name+'\\nItem: '+id+'\\nQuantity: '+qty)
   .button1('Cancel').button2('Give Items');
  adminShow(p,confirm,'give item confirmation').then(c=>{
   if(c.canceled||c.selection!==1)return adminNotice(p,'§7Item delivery canceled.');
   if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access lost or player offline.');
   try{
    const inv=inventory(target);
    if(!inv)return adminNotice(p,'§cTarget inventory unavailable.');
    if(!inventoryCapacity(target,stack))return adminNotice(p,'§cNot enough room in target inventory. No items delivered.');
    const leftover=inv.addItem(stack);
    if(leftover)return adminNotice(p,'§cInventory changed; some items could not be delivered.');
    adminAudit(p,'GIVE',target,qty+' '+id);
    adminNotice(p,'§aSUCCESS: Gave '+qty+' '+id+' to '+target.name);
    adminNotice(target,'§aSkyGen Admin gave you '+qty+' '+id);
   }catch(e){adminFormError(p,'item delivery',e)}
  }).catch(e=>adminFormError(p,'item confirmation',e));
 }).catch(e=>adminFormError(p,'give item form',e));
}
function adminAccess(p,target){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may manage admin access.');
 const granted=world.getDynamicProperty('sg_admin_'+target.id)===true;
 adminAction(p,'§4ADMIN ACCESS',target.name+'\\nAccess: '+(granted?'Granted':'Not granted'),
 [granted?'Revoke Admin':'Grant Admin','Back'],i=>{
  if(i===1)return adminMenu(p);
  if(i!==0)return;
  if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cOperator access required; player must be online.');
  const next=!granted;
  const confirm=skyMessage().title('Confirm Admin Access')
   .body((next?'Grant':'Revoke')+' SkyGen Admin for '+target.name+'?')
   .button1('Cancel').button2('Confirm');
  adminShow(p,confirm,'admin permission confirmation').then(c=>{
   if(c.canceled||c.selection!==1)return adminNotice(p,'§7Admin change canceled.');
   if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cOperator access required; player offline.');
   try{
    world.setDynamicProperty('sg_admin_'+target.id,next);
    if(world.getDynamicProperty('sg_admin_'+target.id)!==next)throw Error('Permission verification failed');
    adminAudit(p,next?'GRANT ADMIN':'REVOKE ADMIN',target,'');
    adminNotice(target,next?'§aSkyGen Admin access granted.':'§cSkyGen Admin access revoked.');
    if(next)system.runTimeout(()=>issueAdminAxe(target),30);
    adminNotice(p,'§aSUCCESS: Admin access '+(next?'granted to ':'revoked from ')+target.name+'.');
   }catch(e){adminFormError(p,'access update',e)}
  }).catch(e=>adminFormError(p,'admin permission confirmation',e));
 });
}
function back(p){menu(p)}
const bank=createBank({world,system,profile,save,assertUnlocked:assertBankUnlocked,collectPayouts:collectBankPayouts,
 form,showUI,skyModal,skyMessage,back:skyMenuBankWallet});
function bankMenu(p){bank.open(p)}
// v0.10.55: Xbox-first, owner-approved player navigation. The form action list
// and callback table share ONE source of truth, avoiding hard-coded index drift.
// The older purchase, rank, quest and permissions engines are not changed here.
function navForm(p,title,body,entries,onBack){
 const actions=[...entries,['Back',onBack]];
 form(p,title,body,actions.map(([name])=>name),i=>{
  if(!Number.isInteger(i)||i<0||i>=actions.length)return;
  // Permissions are enforced again in the destination, never by button hiding alone.
  actions[i][1](p);
 });
}
function skyMenuRanksSkills(p){
 const d=profile(p);
 navForm(p,'§dRANKS & SKILLS',`Rank: ${d.rank}/1000 — ${rankName(d.rank)}\nAvailable Skill Points: ${skillAvailable(d)}\nXP toward next: ${formattedXP(d.xpProgress)}`,
  [['Rank Codex · 1,000 Ranks',ranks],['Skill Tree',skillTree],['Active Abilities',skillAbilities]],menu);
}
function skyMenuTravelVisitors(p){
 navForm(p,'§bTRAVEL & VISITORS','Teleports retain their five-second stand-still warm-up and cooldown.',
  [['Teleport to Spawn / Plot',teleports],['Visit Other Plots',visitMenu],['My Visitor Permissions',visitorOwnerMenu],['My Plot & Trust',plotMenu]],menu);
}
function skyMenuBankWallet(p){
 const d=profile(p);
 navForm(p,'§eBANK & WALLET',`Credits: ${d.credits.toLocaleString()}\nOrbits: ${d.orbits.toLocaleString()}\n1 Orbit = 18,000,000 Credits`,
  [['View Bank / Accounts / Transfers',bankMenu],['Exchange Credits for Orbits',wallet],['Collect Pending Rank Rewards',p=>{
   try{collectBankPayouts(p)}catch(err){p.sendMessage('§cPending rewards require review: '+String(err).slice(0,90))}
   menuAgain(p,()=>skyMenuBankWallet(p));
  }]],menu);
}
function skyMenuProfileCosmetics(p){
 let badges='';
 try{const c=validateCosmetics(profile(p));badges=Object.entries(COSMETIC_BADGES).map(([id,v])=>
  v.name+': '+(c.equipped.includes(id)?'Equipped':c.owned.includes(id)?'Owned':'Locked')).join('\n');}
 catch{badges='Cosmetics require review.'}
 navForm(p,'§bPROFILE & COSMETICS',badges,
  [['My Cosmetics · Equip / Unequip',myCosmetics],['Personal Sidebar · Show / Hide',sidebarMenu],['View My Rank',ranks]],menu);
}
function skyMenuHelpRulebook(p){
 navForm(p,'§bHELP & RULEBOOK','Guides, rules, and operator-only commands where permitted.',
  [['Getting Started / Help & Commands',helpMenu],['Player Rulebook',rulebookMenu]],menu);
}
function skyMenuShops(p){
 navForm(p,'§6SHOPS & TRADING','Choose a shop or player-commerce feature. Purchases retain balance and ownership checks.',
  [['Pro Shop · Premium & Cosmetics',proShop],['Server Shop',shop],['Food Shop',foodShop],
   ['Farming Shop',farmingShop],['Deathnerite Shop',deathneriteShop],
   ['Player Marketplace',market],['Player Trading',trade]],menu);
}
function menu(p){
 const d=profile(p);
 const body=`§6Royal Ledger  §8|  §dRank ${d.rank}/1000  §eXP ${formattedXP(d.xpProgress)}\n§eCredits: ${Number(d.credits).toLocaleString()}  §5Orbits: ${Number(d.orbits).toLocaleString()}\n§aPlot: #${d.plot+1}  §bSkill points: ${skillAvailable(d)}\n§7Select a SkyGen destination:`;
 const actions=[['§aMy Plot',plotMenu],['§bGenerators',genMenu],['§eQuests',dailyQuests],
  ['§dRanks & Skills',skyMenuRanksSkills],['§6Shops & Trading',skyMenuShops],
  ['§eBank & Wallet',skyMenuBankWallet],['§bTravel & Visitors',skyMenuTravelVisitors],
  ['§dProfile & Cosmetics',skyMenuProfileCosmetics],['§7Help & Rulebook',skyMenuHelpRulebook]];
 if(isOperator(p))actions.push(['§4Admin Dashboard',adminMenu]);
 form(p,'SkyGen Core',body,actions.map(([label])=>label),i=>{
  if(!Number.isInteger(i)||i<0||i>=actions.length)return;
  // Do not accept a stale operator-only button after permissions change.
  if(actions[i][1]===adminMenu&&!isOperator(p))return p.sendMessage('§cOperator access required.');
  actions[i][1](p);
 });
}
const HELP_SHORTCUTS={
 plot:['Open My Plot',plotMenu],visit:['Open Visit Other Plots',visitMenu],teleport:['Open Teleport Menu',teleports],
 generators:['Open Generators',genMenu],farming:['Open Farming Shop',farmingShop],shops:['Open Server Shop',shop],
 food:['Open Food Shop',foodShop],pro:['Open Pro Shop',proShop],wallet:['Open Wallet / Exchange',wallet],
 bank:['Open Bank',bankMenu],ranks:['Open Ranks',ranks],skills:['Open Skill Tree',skillTree],quests:['Open Daily Quests',dailyQuests],
 market:['Open Marketplace',market],trade:['Open Player Trading',trade],sidebar:['Open Personal Sidebar',sidebarMenu]
};
function helpLines(page){
 if(!page.branch)return page.lines;
 return [...page.lines,...SKILLS.filter(skill=>skill.branch===page.branch).map(skill=>
  `${skill.name} (Rank ${skill.rank}, ${skill.cost} SP) · ${skill.desc}`)];
}
function helpMenu(p){
 const topics=HELP_TOPICS.filter(topic=>!topic.operator||isOperator(p));
 form(p,'Help & Commands','Pick a topic to see steps, tips, and shortcuts.',
  [...topics.map(topic=>topic.title),'Back to Help & Rulebook'],i=>{
   if(i===topics.length)return skyMenuHelpRulebook(p);
   if(topics[i])helpTopic(p,topics[i]);
  });
}
function rulebookMenu(p){helpTopic(p,RULEBOOK_TOPIC,skyMenuHelpRulebook)}
function helpTopic(p,topic,returnTo=helpMenu){
 if(topic.operator&&!isOperator(p))return helpMenu(p);
 form(p,topic.title,topic.intro??'Choose the task you want help with.',
  [...topic.pages.map(page=>page.title),returnTo===skyMenuHelpRulebook?'Back to Help & Rulebook':'Back to Help Topics'],i=>{
   if(i===topic.pages.length)return returnTo(p);
   if(topic.pages[i])helpPage(p,topic,i,returnTo);
  });
}
function helpPage(p,topic,index,returnTo){
 if(topic.operator&&!isOperator(p))return helpMenu(p);
 const page=topic.pages[index];
 const actions=[];
 if(page.shortcut)actions.push(HELP_SHORTCUTS[page.shortcut]);
 if(index>0)actions.push(['Previous Page',()=>helpPage(p,topic,index-1,returnTo)]);
 if(index+1<topic.pages.length)actions.push(['Next Page',()=>helpPage(p,topic,index+1,returnTo)]);
 actions.push(['Back to '+topic.title,()=>helpTopic(p,topic,returnTo)],['Help Topics',helpMenu],['Main Menu',menu]);
 form(p,page.title,`Page ${index+1}/${topic.pages.length}\n\n`+helpLines(page).join('\n'),
  actions.map(([label])=>label),i=>{
   if(topic.operator&&!isOperator(p))return helpMenu(p);
   actions[i]?.[1](p);
  });
}

function plotMenu(p){
 const d=profile(p);
 if(d.plot<0)return p.sendMessage('§cYour plot is not assigned. Rejoin to retry.');
 const c=coords(d.plot),r=plotRadius(d.plot);
 const details=`§aPlot #${d.plot+1} (permanently assigned)\n§fCenter: ${c.x}, ${c.y}, ${c.z}\n§fProtected X: ${c.x-r} to ${c.x+r}\n§fProtected Z: ${c.z-r} to ${c.z+r}\n§eOnly you and trusted players can build here.
§bForcefield: only operators walk across. Use teleport menus for authorized visits.\n§7One plot per player; claiming another is disabled.`;
 form(p,'§aMY PLOT',details,['Go to Plot','Buy Plot Expansion','Show Boundaries in Chat','Manage Trusted Players','Manage Visitors','Visit Other Plots','Back'],i=>{
  if(i===0)tpPlot(p);
  if(i===1)return plotUpgradeMenu(p);
  if(i===2){p.sendMessage('§a'+details.replaceAll('\n',' §7| '));plotMenu(p)}
  if(i===3)trustMenu(p);
  if(i===4)visitorOwnerMenu(p);
  if(i===5)visitMenu(p);
  if(i===6)back(p);
 });
}

function trustMenu(p){
 const d=profile(p),id=d.plot;
 if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cOnly the plot owner can manage trust.');
 const list=trusted(id),online=world.getAllPlayers().filter(q=>q.id!==p.id);
 const buttons=[...online.map(q=>(list.includes(q.id)?'§aTrusted: ':'§7Visitor: ')+q.name),'Remove All Trust','Back'];
 form(p,'§aPLOT PERMISSIONS',`Plot #${id+1}\nTrusted IDs: ${list.length}\nSelect an online player to toggle build permission.`,buttons,i=>{
  if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. No trust permissions altered.');
  if(i===online.length){
   return showUI(p,skyMessage().title('Revoke All Trusted Players').body('Remove all trusted builder permissions from plot #'+(id+1)+'?').button1('Cancel').button2('Revoke All')).then(r=>{
    if(r.canceled||r.selection!==1)return;
    if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. Nothing revoked.');
    world.setDynamicProperty('sg_trust_'+id,'[]');p.sendMessage('§eAll plot trust revoked.');trustMenu(p);
   }).catch(e=>console.warn('[Sky Realm] trust removal: '+e));
  }
  if(i===online.length+1)return plotMenu(p);
  const q=online[i];if(!q||!world.getAllPlayers().some(x=>x.id===q.id))return;
  const latest=trusted(id),n=latest.includes(q.id)?latest.filter(v=>v!==q.id):[...latest,q.id];
  world.setDynamicProperty('sg_trust_'+id,JSON.stringify([...new Set(n)]));
  p.sendMessage(`§a${q.name}: ${n.includes(q.id)?'trusted':'untrusted'}`);trustMenu(p);
 });
}


// Visiting permissions are separate from building permissions. Owner grants are
// stored in world dynamic properties so they persist after restart and logout.
function visitTeleport(p,id){
 if(!canVisit(p,id))return p.sendMessage('§cYou do not have permission to visit this plot.');
 stageAndBuildPlot(p,id,true);
}
function visitorOwnerMenu(p){
 const id=profile(p).plot;if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cOnly the plot owner can manage visitors.');
 const list=visitors(id),online=world.getAllPlayers().filter(q=>q.id!==p.id);
 const choices=[...online.map(q=>`${list.includes(q.id)?'§aAllowed':'§7Not allowed'}: ${q.name}`),'Revoke All Visitors','Back'];
 form(p,'§aPLOT VISIT PERMISSIONS',`Plot #${id+1} | ${list.length} invited player(s)
Granting visit access does NOT grant building access.
Select a player to allow or revoke access.`,choices,i=>{
  if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. No visitor permissions altered.');
  if(i===online.length){
   return showUI(p,skyMessage().title('Revoke All Visitors').body('Remove every visitor from plot #'+(id+1)+'? Building permissions are separate.').button1('Cancel').button2('Revoke All')).then(r=>{
    if(r.canceled||r.selection!==1)return;
    if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. Nothing revoked.');
    setVisit(id,[]);p.sendMessage('§eAll visitor access revoked.');visitorOwnerMenu(p);
   }).catch(e=>console.warn('[Sky Realm] visitor removal: '+e));
  }
  if(i===online.length+1)return plotMenu(p);
  const q=online[i];if(!q)return;
  const latest=visitors(id),allowed=!latest.includes(q.id);setVisit(id,allowed?[...latest,q.id]:latest.filter(v=>v!==q.id));
  p.sendMessage(`${allowed?'§aGranted':'§eRevoked'} visit access: ${q.name}`);
  q.sendMessage(allowed?`§a${p.name} allowed you to visit plot #${id+1}. Open SkyGen Menu → Visit Other Plots.`:`§e${p.name} revoked your access to plot #${id+1}.`);
  visitorOwnerMenu(p);
 });
}
function visitMenu(p){
 const accessible=world.getAllPlayers().filter(q=>q.id!==p.id&&profile(q).plot>=0&&canVisit(p,profile(q).plot));
 const online=world.getAllPlayers().filter(q=>q.id!==p.id&&profile(q).plot>=0&&!canVisit(p,profile(q).plot));
 const choices=[...accessible.map(q=>`§aVisit ${q.name} — #${profile(q).plot+1}`),'Request Access from Player','Incoming Requests','Back'];
 form(p,'§bVISIT PLAYER PLOTS',`You may teleport only to plots whose owners have allowed you.
Visits use the normal 5-second countdown and cooldown.
Visitors cannot build unless separately trusted.`,choices,i=>{
  if(i<accessible.length){const q=accessible[i];return visitTeleport(p,profile(q).plot)}
  if(i===accessible.length)return requestVisitMenu(p,online);
  if(i===accessible.length+1)return incomingVisits(p);
  back(p);
 });
}
function requestVisitMenu(p,online){
 form(p,'§bREQUEST PLOT ACCESS','Choose an online player. They must accept before you can visit.',[...online.map(q=>`${q.name} — Plot #${profile(q).plot+1}`),'Back'],i=>{
  if(i>=online.length)return visitMenu(p);
  const owner=online[i],id=profile(owner).plot;
  if(id<0||ownerId(id)!==owner.id)return p.sendMessage('§cPlot owner unavailable.');
  const key=`${owner.id}:${p.id}`;
  visitRequests.set(key,{ownerId:owner.id,requesterId:p.id,plot:id,expires:system.currentTick+1200});
  p.sendMessage(`§aVisit request sent to ${owner.name}.`);
  owner.sendMessage(`§e${p.name} requests permission to visit your plot. Open SkyGen Menu → Visit Other Plots → Incoming Requests to respond.`);
 });
}
function incomingVisits(p){
 const id=profile(p).plot;
 if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cOnly plot owners can approve requests.');
 const requests=[...visitRequests.entries()].filter(([key,r])=>r.ownerId===p.id&&r.plot===id&&r.expires>=system.currentTick&&world.getAllPlayers().some(q=>q.id===r.requesterId));
 form(p,'§aINCOMING VISIT REQUESTS',`Requests expire after 60 seconds.
Pending: ${requests.length}`,[...requests.map(([key,r])=>world.getAllPlayers().find(q=>q.id===r.requesterId)?.name||'Offline'),'Back'],i=>{
  if(i>=requests.length)return visitMenu(p);
  const [key,r]=requests[i],requester=world.getAllPlayers().find(q=>q.id===r.requesterId);
  if(!requester||r.expires<system.currentTick||profile(p).plot!==r.plot||ownerId(r.plot)!==p.id){visitRequests.delete(key);return p.sendMessage('§cRequest expired.');}
  showUI(p,skyMessage().title('Allow Plot Visit?').body(`Allow ${requester.name} to visit plot #${id+1}?
They will not receive building permission.
You can revoke access any time.`).button1('Deny').button2('Allow')).then(res=>{
   if(res.canceled)return;
   visitRequests.delete(key);
   if(res.selection===1&&profile(p).plot===id&&ownerId(id)===p.id){setVisit(id,[...visitors(id),requester.id]);p.sendMessage(`§a${requester.name} may now visit your plot.`);requester.sendMessage(`§a${p.name} approved your visit! SkyGen Menu → Visit Other Plots.`)}
   else requester.sendMessage(`§c${p.name} denied your visit request.`);
  }).catch(e=>console.warn('SkyGen visit approval '+e));
 });
}

function genMenu(p){
 const count=generatorOwnerCount(p),cap=generatorSlots(p);
 form(p,'§bGENERATORS',`42 generator types across four categories.\nOwned: ${count}/${cap} slots. Upgrade production to Level 10.\n§7Use the custom generator token while looking at an open plot floor block.`,
 ['Buy Generator','My Generators / Upgrade','Back'],i=>{if(i===0)return genCategories(p);if(i===1)return myGenerators(p);back(p)});
}
function genCategories(p){
 const categories=['Starter','Mining','Nature','Endgame'];
 form(p,'§bGENERATOR TYPES',`42 types. Original generator purchases and tokens remain valid. Unlock new tiers as you rank up.`,
 [...categories.map(c=>`${c} (${GENS.filter(g=>g.category===c).length})`),'Back'],i=>{
  if(i>=categories.length)return genMenu(p);
  buyGen(p,categories[i],0);
 });
}
function myGenerators(p,page=0){
 const all=[...generators.entries()].filter(([key,g])=>g.owner===p.id);
 const pageSize=8,pages=Math.max(1,Math.ceil(all.length/pageSize)),current=Math.max(0,Math.min(page,pages-1));
 const a=all.slice(current*pageSize,current*pageSize+pageSize);
 form(p,'§bMY GENERATORS',`Owned: ${all.length}/${generatorSlots(p)} • Page ${current+1}/${pages}`,
 [...a.map(([key,g])=>`${g.type} Lv${g.level||1} @ ${g.x},${g.y},${g.z}`),
 ...(current>0?['Previous Page']:[]),...(current<pages-1?['Next Page']:[]),'Back'],i=>{
  if(i<a.length){const [key,g]=a[i];return manageGenerator(p,key,g)}
  let j=a.length;if(current>0){if(i===j)return myGenerators(p,current-1);j++}
  if(current<pages-1){if(i===j)return myGenerators(p,current+1)}
  genMenu(p);
 });
}
function manageGenerator(p,key,g){
 if(g.owner!==p.id||generators.get(key)!==g)return myGenerators(p);
 const lv=g.level||1;
 const spec=GEN_BY_NAME.get(g.type);
 const rawCost=spec?spec.cost*lv*2:0;
 const cost=discountedPrice(rawCost,perkValue(profile(p),'generatorPrice'));
 form(p,'§bMANAGE GENERATOR',`${g.type} • Level ${lv}/${GENERATOR_MAX_LEVEL}\nLocation: ${g.x}, ${g.y}, ${g.z}\nUpgrade cost: ${lv>=GENERATOR_MAX_LEVEL?'MAX LEVEL':cost+' Credits'}\nDeletion permanently removes the generator; no refund.`,['Upgrade','Delete Generator','Diagnose Generator','Admin: Force Output Test','Back'],i=>{
  if(i===2){
   const dim=world.getDimension('overworld');
   let base='unloaded',output='unloaded';
   try{base=dim.getBlock({x:g.x,y:g.y,z:g.z})?.typeId||'unloaded';output=dim.getBlock({x:g.x,y:g.y+1,z:g.z})?.typeId||'unloaded'}catch(e){genError('inspect '+e)}
   const interval=(effectivePeriod(g)/20).toFixed(2);
   const age=genLastTick<0?'never':String(system.currentTick-genLastTick)+' ticks ago';
   const lines=[`§bSkyGen Generator Diagnostics v0.10.25`,`Generator: ${g.type} level ${lv} at ${g.x},${g.y},${g.z}`,`Registered: ${generators.get(key)===g} | Registry size: ${generators.size}`,`Base: ${base} | Output: ${output} | Expected: ${spec?.block||g.block}`,`Target interval: ${interval}s | Empty since tick: ${genEmptySeconds.get(key)??"none"}`,`Watchdog runs: ${genWatchdogRuns} | Last heartbeat: ${age}`,`Script uptime: ${system.currentTick-genStartupTick} ticks | Current tick: ${system.currentTick}`,`Last error: ${genLastError}`,`Recent errors: ${genErrors.slice(-3).join(' ; ')||'none'}`];
   for(const line of lines)p.sendMessage(line);
   return menuAgain(p,()=>manageGenerator(p,key,g));
  }
  if(i===3){
   if(!isOperator(p)){p.sendMessage('§cOperator only.');return menuAgain(p,()=>manageGenerator(p,key,g));}
   try{
    const dim=world.getDimension('overworld');const base=dim.getBlock({x:g.x,y:g.y,z:g.z}),out=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
    if(!base||!out||!isGeneratorBase(g,base)||out.typeId!=='minecraft:air')return p.sendMessage('§cForce test requires registered generator base and empty output.');
    out.setType(spec?.block||g.block);genEmptySeconds.delete(key);p.sendMessage('§aForce output succeeded. Block write works; if automatic regeneration fails, heartbeat scheduling is the issue.');
   }catch(e){genError('force test '+e);p.sendMessage('§cForce test failed: '+e)}finally{menuAgain(p,()=>manageGenerator(p,key,g))}return;
  }
  if(i===0){
   if(lv>=GENERATOR_MAX_LEVEL){p.sendMessage('§eAlready max level.');return menuAgain(p,()=>manageGenerator(p,key,g));}
   showUI(p,skyMessage().title('Upgrade Generator').body(`Level ${lv} → ${lv+1}\nCost: ${cost} Credits\nProduction interval reduced by 15%; level 10 is instant.`).button1('Cancel').button2('Upgrade')).then(r=>{
    if(r.canceled)return;
    if(r.selection!==1)return menuAgain(p,()=>manageGenerator(p,key,g));
    try{
    if(g.owner!==p.id||generators.get(key)!==g||g.level!==undefined&&g.level!==lv)return p.sendMessage('§cGenerator changed. Open the menu again.');
    const d=profile(p);if(d.credits<cost)return p.sendMessage('§cNot enough Credits.');
    if(!generatorRegistryLoaded)return p.sendMessage('§cGenerator registry unavailable. No charge.');
    let tx;
    try{tx=beginEconomicTxn(p,'gen',{generator:key,cost,levelBefore:lv,levelAfter:lv+1})}
    catch(err){return p.sendMessage('§cUpgrade locked: '+err)}
    const oldPeriod=g.period,oldLevel=g.level;
    try{
     const fresh=profile(p);
     if(fresh.credits!==tx.before||fresh.credits<cost)throw Error('Generator Credits changed');
     fresh.credits-=cost;fresh.sg_last_econ_txn=tx.id;save(p,fresh);
     g.level=lv+1;g.period=Math.max(10,Math.round(g.period*0.85));
     if(!genSave())throw Error('Generator upgrade save unavailable');
     endEconomicTxn(p,tx,true);
     p.sendMessage(`§a${g.type} upgraded to level ${g.level}.`);
    }catch(err){
     // Registry may already have committed; never automatically refund or
     // reapply the upgrade when uncertain. Require manual operator review.
     g.level=oldLevel;g.period=oldPeriod;
     economicTxnReview(p,tx,'Generator upgrade charge/save uncertain: '+err);
     p.sendMessage('§cGenerator upgrade requires operator review.');
    }
    }finally{menuAgain(p,()=>manageGenerator(p,key,g))}
   }).catch(e=>console.warn('SkyGen upgrade UI '+e));
  }else if(i===1){
   showUI(p,skyMessage().title('§cDELETE GENERATOR?').body(`Permanently delete ${g.type} Lv${lv} at ${g.x}, ${g.y}, ${g.z}?\nThis cannot be undone. No Credits or egg will be refunded.`).button1('Keep Generator').button2('DELETE')).then(r=>{
    if(r.canceled)return;
    if(r.selection!==1)return menuAgain(p,()=>manageGenerator(p,key,g));
    try{
    if(g.owner!==p.id||generators.get(key)!==g)return p.sendMessage('§cGenerator changed. Open the menu again.');
    try{
     const dim=world.getDimension('overworld');
     const base=dim.getBlock({x:g.x,y:g.y,z:g.z});
     const output=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
     if(!base||!output)return p.sendMessage('§cGenerator chunk is not loaded. Stand near it and try again.');
     if(!isGeneratorBase(g,base))return p.sendMessage('§cGenerator base missing/mismatched. Deletion cancelled to protect nearby blocks.');
     // Remove the registry first and verify. If block removal fails, restore registry.
     generators.delete(key);genEmptySeconds.delete(key);generatorOutputReady.delete(key);
     if(!genSave()){generators.set(key,g);return p.sendMessage('§cCannot save registry; nothing deleted.')}
     try{
      eraseGeneratorWorldBlocks(dim,g);
     }catch(err){generators.set(key,g);if(!genSave())genError('CRITICAL: generator rollback save failed '+key,'rollback');throw err}
     p.sendMessage(`§a${g.type} generator deleted. No refund issued.`);
    }catch(e){p.sendMessage('§cCould not delete generator. Stand near it and retry.');console.warn('SkyGen delete generator '+e)}
    }finally{menuAgain(p,()=>manageGenerator(p,key,g))}
   }).catch(e=>console.warn('SkyGen delete UI '+e));
  }else myGenerators(p);
 });
}
function buyGen(p,category='Starter',page=0){
 const d=profile(p),list=GENS.filter(g=>g.category===category);
 const stay=()=>menuAgain(p,()=>buyGen(p,category,current));
 const pages=Math.ceil(list.length/8),current=Math.max(0,Math.min(page,pages-1));
 const slice=list.slice(current*8,current*8+8);
 const heading=`${category} • Page ${current+1}/${pages}\nRank ${d.rank} / 1000\nCredits ${d.credits}`;
 form(p,'§bBUY '+category.toUpperCase(),heading,
 [...slice.map(g=>`${d.rank<g.unlock?'§8LOCKED ':'§a'}${g.name} — ${discountedPrice(g.cost,perkValue(d,'generatorPrice'))} Credits (Rank ${g.unlock})`),
 ...(current>0?['Previous Page']:[]),...(current<pages-1?['Next Page']:[]),'Back'],i=>{
  if(i>=slice.length){let idx=slice.length;
   if(current>0){if(i===idx)return buyGen(p,category,current-1);idx++}
   if(current<pages-1){if(i===idx)return buyGen(p,category,current+1)}
   return genCategories(p);
  }
  try{recoverEconomicTxn(p);if(readEconomicTxn(p)){p.sendMessage('§cPending economic review; purchases are locked.');return stay();}}catch(err){p.sendMessage('§cCannot verify economy: '+err);return stay();}
  if(!generatorRegistryLoaded){p.sendMessage('§cGenerators still loading or registry corrupt. Purchases disabled.');return stay();}
  const g=slice[i],latest=profile(p),cost=discountedPrice(g.cost,perkValue(latest,'generatorPrice'));
  if(latest.rank<g.unlock){p.sendMessage(`§c${g.name} requires Rank ${g.unlock}.`);return stay();}
  if(latest.credits<cost){p.sendMessage('§cNot enough Credits.');return stay();}
  if(!generatorTokenCustomReady){p.sendMessage('§cGenerator custom-item use handler unavailable. Purchases disabled.');return stay();}
  showUI(p,skyMessage().title('Generator Purchase')
   .body('§6'+g.name+' Generator Token\n§7Category: '+g.category+'\n§ePrice: '+cost.toLocaleString()+' Credits\n§dRequired Rank: '+g.unlock+'\n§7The token is placed on your plot. No generator is placed automatically.')
   .button1('Cancel').button2('Buy Token')).then(r=>{
    if(r.canceled)return;
    if(r.selection!==1)return stay();
    try{
    const fresh=profile(p);
    if(fresh.rank<g.unlock)return p.sendMessage('§cRank requirement not met.');
    if(fresh.credits<discountedPrice(g.cost,perkValue(fresh,'generatorPrice')))return p.sendMessage('§cInsufficient Credits.');
    if(!generatorRegistryLoaded||!generatorTokenCustomReady||!validGeneratorOutput(g))return p.sendMessage('§cGenerator block or system unavailable; no purchase made.');
    issueGeneratorToken(p,g,discountedPrice(g.cost,perkValue(fresh,'generatorPrice')));
    }finally{stay()}
  }).catch(e=>console.warn('[Sky Realm] generator confirmation: '+e));
 });
}
function plainCommerceMetadata(it){
 try{
  if(!it||typeof it.getDynamicPropertyIds!=='function'||it.getDynamicPropertyIds().length)return false;
  if(typeof it.getCanPlaceOn!=='function'||it.getCanPlaceOn().length)return false;
  if(typeof it.getCanDestroy!=='function'||it.getCanDestroy().length)return false;
  const en=it.getComponent?.('minecraft:enchantable');
  if(en?.getEnchantments?.().length)return false;
  const dura=it.getComponent?.('minecraft:durability');
  if(dura&&dura.damage>0)return false;
  // Potion & dye components have value-bearing variants; plain shop goods
  // never need to destroy their custom forms.
  if(it.getComponent?.('minecraft:potion')||it.getComponent?.('minecraft:dyeable'))return false;
  return true;
 }catch{return false}
}
function eligibleShopItem(it,id){return !!it&&it.typeId===id&&!it.nameTag&&!it.keepOnDeath&&it.lockMode===ItemLockMode.none&&!isTool(it)&&(!it.getLore||it.getLore().length===0)&&plainCommerceMetadata(it)}
function inventoryCapacity(p,stack){const inv=inventory(p);if(!inv)return false;let free=0;for(let i=0;i<inv.size;i++){const it=inv.getItem(i);if(!it){free+=stack.maxAmount;continue}if(it.typeId===stack.typeId&&!it.nameTag&&it.lockMode===ItemLockMode.none&&(!it.getLore||it.getLore().length===0)&&plainCommerceMetadata(it))free+=Math.max(0,it.maxAmount-it.amount)}return free>=stack.amount}
function shopTotal(item,buying,count,d){
 if(buying)return count*discountedPrice(item.buy/item.count,perkValue(d,'buy'));
 return Math.floor(count*item.sell*(100+perkValue(d,'sell'))/(item.count*100));
}
// Preflight all destinations before debiting. Bundles and single items share
// one journal and one debit. An ambiguous inventory write stays review-locked.
function buyShopItems(p,lines,total){
 const inv=inventory(p);
 if(!inv)return p.sendMessage('§cInventory unavailable.');
 if(!Number.isSafeInteger(total)||total<1||total>2000000000)return p.sendMessage('§cInvalid purchase total.');
 if(profile(p).credits<total)return p.sendMessage('§cNot enough Credits.');
 const available=[];
 for(let slot=0;slot<inv.size;slot++){
  const original=inv.getItem(slot);
  available.push({slot,original,next:original});
 }
 for(const {id,count,enchantments} of lines){
  const sample=new ItemStack(id,1);
  if(enchantments){
   try{enchantProItem(sample,enchantments)}
   catch(err){p.sendMessage('§cPro Shop gear is unavailable: '+err.message);return false}
  }
  let remaining=count;
  for(const entry of available){
   if(!remaining)break;
   if(enchantments||!eligibleShopItem(entry.next,id)||!entry.next.isStackableWith(sample))continue;
   const amount=Math.min(remaining,entry.next.maxAmount-entry.next.amount);
   if(!amount)continue;
   const stack=entry.next.clone();stack.amount+=amount;
   entry.next=stack;remaining-=amount;
  }
  for(const entry of available){
   if(!remaining)break;
   if(entry.next)continue;
   const amount=Math.min(remaining,sample.maxAmount);
   entry.next=enchantments?sample.clone():new ItemStack(id,amount);
   if(enchantments){
    entry.next.amount=amount;
    entry.enchantments=enchantments;
   }
   remaining-=amount;
  }
  if(remaining)return p.sendMessage('§cNot enough inventory space.');
 }
 const changes=available.filter(entry=>entry.original!==entry.next);
 let tx;
 try{
  tx=beginEconomicTxn(p,'buy',{item:lines.map(line=>line.id).join(', '),
   count:lines.reduce((sum,line)=>sum+line.count,0),total,
   slots:changes.map(({slot,original,next,enchantments})=>
    [slot,original?.amount??0,next.typeId,next.amount,...(enchantments?[enchantments]:[])])});
 }catch(e){return p.sendMessage('§cPurchase locked: '+e)}
 try{
  const d=profile(p);
  if(d.credits!==tx.before||d.credits<total)throw Error('Credits changed');
  d.credits-=total;d.sg_last_econ_txn=tx.id;save(p,d);
 }catch(e){
  try{
   const state=profile(p);
   if(state.credits!==tx.before)economicTxnReview(p,tx,'Payment verification failed: '+e);
   else endEconomicTxn(p,tx,true);
  }catch(err){economicTxnReview(p,tx,err)}
  return p.sendMessage('§cPayment could not be verified. No items delivered.');
 }
 const written=[];
 try{
  for(const change of changes){
   written.push(change);
   inv.setItem(change.slot,change.next);
   const actual=inv.getItem(change.slot);
   if(actual?.typeId!==change.next.typeId||actual.amount!==change.next.amount||
      (change.enchantments&&!hasProEnchantments(actual,change.enchantments)))
    throw Error('Inventory delivery verification failed');
  }
 }catch(e){
  let restored=true;
  for(const {slot,original,next} of written.reverse()){
   try{
    const actual=inv.getItem(slot);
    const same=(expected)=>expected===undefined?actual===undefined:
     eligibleShopItem(actual,expected.typeId)&&actual.amount===expected.amount;
    if(same(original))continue;
    if(!same(next)){restored=false;continue}
    inv.setItem(slot,original);
    const verified=inv.getItem(slot);
    if(verified?.typeId!==original?.typeId||verified?.amount!==original?.amount)restored=false;
   }catch{restored=false}
  }
  try{
   if(!restored)throw e;
   const d=profile(p);
   if(d.sg_last_econ_txn!==tx.id||d.credits!==tx.before-total)throw Error('Refund cannot be verified');
   d.credits=tx.before;save(p,d);
   endEconomicTxn(p,tx,true);
   return p.sendMessage('§cPurchase failed. Credits returned and inventory restored.');
  }catch(err){economicTxnReview(p,tx,err);return false}
 }
 try{endEconomicTxn(p,tx,true);return true}
 catch(e){economicTxnReview(p,tx,'Delivery completed; journal cleanup uncertain: '+e);return false}
}
function planInventoryDebit(inv,count,eligible){
 if(!inv||!Number.isSafeInteger(count)||count<1)return null;
 const slots=[];
 let remaining=count;
 for(let i=0;i<inv.size&&remaining>0;i++){
  const item=inv.getItem(i);
  if(!eligible(item))continue;
  const quantity=Math.min(remaining,item.amount);
  slots.push([i,quantity,item.clone()]);
  remaining-=quantity;
 }
 return remaining===0?slots:null;
}
function safeShopSell(p,s){
 if(creativeEconomyBlocked(p)){p.sendMessage('§cSelling disabled: Creative inventory requires operator clearance.');return false;}

 const slots=planInventoryDebit(inventory(p),s.count,item=>eligibleShopItem(item,s.id));
 if(!slots){p.sendMessage('§cNot enough ordinary unlocked items.');return false}
 if(!Number.isSafeInteger(s.sell)||s.sell<1||s.sell>CREDIT_CAP){
  p.sendMessage('§cInvalid sale payout.');return false;
 }
 const d=profile(p),destination=payoutDestination(d,s.sell);
 if(destination===undefined){
  p.sendMessage('§cSale could not be paid. '+noPayoutRoom(d,s.sell));return false;
 }
 const committed=commitInventoryDebit(p,slots,'sell',{item:s.id,count:s.count,total:s.sell,destination},(latest,tx)=>{
  if(latest.credits!==tx.before)throw Error('Wallet changed');
  creditPayout(latest,destination,s.sell);
  latest.sg_last_econ_txn=tx.id;
  recordDaily(p,latest,['sold'],s.count,s.id);save(p,latest);
 });
 if(committed&&destination!=='wallet')p.sendMessage('§aSale Credits deposited into '+destinationName(d,destination)+'.');
 return committed;
}
function commitInventoryDebit(p,slots,kind,details,commit){
 const inv=inventory(p);
 if(!inv)return false;
 const slotDetails=slots.map(([slot,amount,item])=>[slot,item.typeId,item.amount,amount]);
 let tx;
 try{tx=beginEconomicTxn(p,kind,{...details,slots:slotDetails})}
 catch(e){p.sendMessage('§cTransaction locked: '+e);return false}
 const changed=[];
 try{
  for(const [slot,n,expected] of slots){
   const current=inv.getItem(slot);
   if(!current||!eligibleShopItem(current,expected.typeId)||current.amount!==expected.amount)throw Error('Inventory changed');
   changed.push([slot,expected]);
   if(n===current.amount)inv.setItem(slot,undefined);
   else{const reduced=current.clone();reduced.amount-=n;inv.setItem(slot,reduced)}
   const after=inv.getItem(slot),expectedAmount=expected.amount-n;
   if(expectedAmount===0?after!==undefined:!eligibleShopItem(after,expected.typeId)||after.amount!==expectedAmount)
    throw Error('Inventory removal was not verified');
  }
  commit(profile(p),tx);
  endEconomicTxn(p,tx,true);
  return true;
 }catch(e){
  // If the credit was committed, NEVER restore inventory: that duplicates items.
  // A failed complete marker is review-only, not a rollback instruction.
  let latest;
  try{latest=profile(p)}catch(err){economicTxnReview(p,tx,'Could not verify payout: '+err);return false}
  if(latest.sg_last_econ_txn===tx.id||latest.credits!==tx.before){
   economicTxnReview(p,tx,'Payout state uncertain: '+e);return false;
  }
  // Restore exactly ONLY if every affected slot still matches the write we
  // performed. If uncertain, do not overwrite another item or credit twice.
  let restored=true;
  for(const [slot,original] of changed){
   try{const current=inv.getItem(slot),n=slots.find(x=>x[0]===slot)[1];
    // The failed write may have left the original stack unchanged.
    if(current&&eligibleShopItem(current,original.typeId)&&current.amount===original.amount)continue;
    if(current&&(!eligibleShopItem(current,original.typeId)||current.amount!==original.amount-n)){restored=false;continue}
    if(!current&&original.amount!==n){restored=false;continue}
    inv.setItem(slot,original);
    const verified=inv.getItem(slot);
    if(!eligibleShopItem(verified,original.typeId)||verified.amount!==original.amount)restored=false;
   }catch{restored=false}
  }
  if(restored){try{endEconomicTxn(p,tx,true)}catch(err){economicTxnReview(p,tx,err)}}
  else economicTxnReview(p,tx,'Inventory or wallet uncertain: '+e);
  p.sendMessage('§cTransaction failed; '+(restored?'items restored.':'operator review required.'));
  return false;
 }
}
function countShopInventory(p,id){
 const inv=inventory(p);if(!inv)return 0;let count=0;
 for(let slot=0;slot<inv.size;slot++){const it=inv.getItem(slot);if(eligibleShopItem(it,id))count+=it.amount;}
 return count;
}
function deathneriteShop(p){
 const groups=DEATHNERITE_SHOP.map(group=>({
  name:group.name,
  items:group.items.filter(item=>item.ids.every(id=>ItemTypes.get(id)))
 })).filter(group=>group.items.length);
 const money=amount=>amount.toLocaleString()+' Credits';
 form(p,'DEATHNERITE SHOP','Buy materials, finished gear and armor sets with Credits.',
  [...groups.map(group=>group.name),'Back'],i=>{
  if(i===groups.length)return skyMenuShops(p);
  const group=groups[i];
  const browse=()=>form(p,group.name,'Balance: '+money(profile(p).credits),
   [...group.items.map(item=>item.name+' · '+money(item.price)),'Back'],selected=>{
    if(selected===group.items.length)return deathneriteShop(p);
    const item=group.items[selected];
    const confirm=skyMessage().title('Confirm Deathnerite Purchase')
     .body(item.name+'\n'+money(item.price)+'\n'+item.ids.join('\n')).button1('Back').button2('Buy');
    showUI(p,confirm).then(r=>{
     if(r.canceled)return;
     try{
      if(r.selection!==1)return;
      const lines=item.ids.map(id=>({id,count:1}));
      if(buyShopItems(p,lines,item.price))p.sendMessage('§aPurchased '+item.name+' for '+money(item.price)+'.');
     }finally{menuAgain(p,browse)}
    }).catch(e=>p.sendMessage('§cDeathnerite purchase failed: '+e));
   });
  browse();
 });
}
// Phase 4: separate Orbit purchase; reserved journal prevents double delivery.
// A dual-currency Pro Shop item is eligible for Orbit checkout only after
// its owner-approved 10% integer discount is re-verified at confirmation.
// Enchanted delivery is inspected before debit and verified after delivery.
function purchaseOrbitItem(p,item){
 let amount;
 try{
  if(!item||!Number.isSafeInteger(item.orbitPrice)||item.orbitPrice<=0||
     !Number.isSafeInteger(item.price)||item.lines?.length!==1||item.lines[0].count!==1)
   throw Error('Orbit SKU not approved');
  exactOrbitQuote(item.price,item.orbitPrice);
  amount=item.orbitPrice;
 }catch(e){p.sendMessage('§cOrbit price needs review: '+e.message);return false}
 const inv=inventory(p);if(!inv)return false;
 let sample;
 try{
  sample=new ItemStack(item.lines[0].id,1);
  if(item.lines[0].enchantments)enchantProItem(sample,item.lines[0].enchantments);
 }catch(e){p.sendMessage('§cPro Shop gear is unavailable: '+e.message);return false}
 let slot=-1;for(let i=0;i<inv.size;i++)if(!inv.getItem(i)){slot=i;break}
 if(slot<0)return p.sendMessage('§cFree one inventory slot first.');
 const pre=profile(p);if(creativeEconomyBlocked(p))return p.sendMessage('§cCreative inventory requires operator clearance.');
 if(pre.orbits<amount)return p.sendMessage('§cNot enough Orbits.');
 let tx;
 try{
  tx=beginEconomicTxn(p,'buy',{currency:'orbits',cost:amount,item:sample.typeId,slot,beforeOrbits:pre.orbits,
    enchanted:!!item.lines[0].enchantments,sku:item.name});
  const d=profile(p);
  if(d.orbits!==tx.beforeOrbits||d.orbits<amount)throw Error('Orbit balance changed');
  if(inv.getItem(slot)!==undefined)throw Error('Delivery slot changed');
  d.orbits-=amount;d.sg_last_econ_txn=tx.id;save(p,d);
  if(inv.getItem(slot)!==undefined)throw Error('Purchase destination changed');
  inv.setItem(slot,sample);
  const received=inv.getItem(slot);
  if(received?.typeId!==sample.typeId||received.amount!==1||
    (item.lines[0].enchantments&&!hasProEnchantments(received,item.lines[0].enchantments)))
   throw Error('Orbit delivery or enchantments not verified');
  endEconomicTxn(p,tx,true);p.sendMessage('§aPurchased '+item.name+' for '+amount+' Orbits.');return true;
 }catch(e){
  if(tx){
   try{
    const d=profile(p);
    // Reverse only when the entire delivery slot is still empty and the
    // exact transaction debit can be proven. Never erase a delivered item.
    if(d.sg_last_econ_txn===tx.id&&inv.getItem(slot)===undefined&&d.orbits===tx.beforeOrbits-amount){
     d.orbits=tx.beforeOrbits;save(p,d);endEconomicTxn(p,tx,true);
     p.sendMessage('§ePurchase reversed; Orbits restored.');return false;
    }
    // If prepared but never debited, no payment or item can be refunded.
    if(d.sg_last_econ_txn!==tx.id&&d.orbits===tx.beforeOrbits&&inv.getItem(slot)===undefined){
     endEconomicTxn(p,tx,true);p.sendMessage('§cOrbit purchase canceled; no debit.');return false;
    }
   }catch{}
   economicTxnReview(p,tx,'Orbit purchase needs reconciliation: '+e);
  }
  p.sendMessage('§cOrbit purchase incomplete; contact operator if paid: '+String(e).slice(0,100));return false;
 }
}

function purchaseSellChest(p){
 const inv=inventory(p),before=profile(p);
 if(before.sellChestLicense)return p.sendMessage('§eYou already own a Sell-All Chest license. Open its manager.');
 if(!inv||before.credits<55000)return p.sendMessage('§cRequires 55,000 Credits and inventory space.');
 let slot=-1;for(let i=0;i<inv.size;i++)if(!inv.getItem(i)){slot=i;break}
 if(slot<0)return p.sendMessage('§cFree one inventory slot first.');
 let tx;
 try{
  tx=beginEconomicTxn(p,'buy',{currency:'credits',cost:55000,item:'sell_chest_license',slot});
  const d=profile(p);if(d.credits!==tx.before||d.sellChestLicense)throw Error('Purchase eligibility changed');
  d.credits-=55000;d.sellChestLicense=true;d.sg_last_econ_txn=tx.id;save(p,d);
  if(inv.getItem(slot))throw Error('Destination changed');
  inv.setItem(slot,new ItemStack('minecraft:chest',1));
  if(inv.getItem(slot)?.typeId!=='minecraft:chest')throw Error('Chest not delivered');
  endEconomicTxn(p,tx,true);p.sendMessage('§aSell-All Chest purchased. Place it on your plot, look at it, then open Pro Shop → Manage Sell-All Chest to bind.');return true;
 }catch(e){if(tx){
   try{const d=profile(p);if(d.sg_last_econ_txn===tx.id&&inv.getItem(slot)===undefined&&d.credits===tx.before-55000){d.credits=tx.before;d.sellChestLicense=false;save(p,d);endEconomicTxn(p,tx,true);p.sendMessage('§eChest purchase rolled back.');return false}}catch{}
   economicTxnReview(p,tx,e);
  }p.sendMessage('§cChest purchase needs review: '+String(e).slice(0,100));return false}
}
function sellChestKey(loc){return 'sg_sale_chest_'+loc.x+'_'+loc.y+'_'+loc.z}
function chestBlockAt(loc){return world.getDimension('overworld').getBlock(loc)}
function boundSaleChestOwner(loc){return world.getDynamicProperty(sellChestKey(loc))}
function chestContents(block){return block?.getComponent('minecraft:inventory')?.container}
function chestEnvironmentSafe(block,dimension){
 try{
  if(block?.typeId!=='minecraft:chest'||chestContents(block)?.size!==27)return false;
  const loc=block.location;
  const offsets=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  const machine=/^minecraft:(?:hopper|piston|sticky_piston|moving_block|dropper|dispenser|chest|trapped_chest)$/;
  if(offsets.some(([dx,dy,dz])=>{const b=dimension.getBlock({x:loc.x+dx,y:loc.y+dy,z:loc.z+dz});return !b||machine.test(b.typeId)}))return false;
  // Automated hopper minecarts can reach into ordinary vanilla containers.
  // Fail closed rather than pretending that player-interaction guards stop them.
  const carts=dimension.getEntities({type:'minecraft:hopper_minecart',location:{x:loc.x+.5,y:loc.y+.5,z:loc.z+.5},maxDistance:3});
  if(carts.length)return false;
  return true;
 }catch{return false}
}
function manageSellChest(p){
 const d=profile(p);
 if(!d.sellChestLicense)return p.sendMessage('§eBuy a Sell-All Chest in the Pro Shop first.');
 form(p,'§eSELL-ALL CHEST',`Owner-only chest · sales begin when you close it.\nUnsellable items stay inside.\n${d.sellChestPos?'Bound at '+JSON.stringify(d.sellChestPos):'Not bound yet'}`,
  ['Bind Chest I Am Looking At','Unbind Empty Chest','Back'],i=>{
   if(i===2)return proShop(p);
   try{
    const fresh=profile(p),old=fresh.sellChestPos;
    if(i===1){
     if(!old)return p.sendMessage('§7No chest is bound.');
     const block=chestBlockAt(old),inv=chestContents(block);
     if(block?.typeId==='minecraft:chest'&&(!inv||Array.from({length:inv.size},(_,j)=>inv.getItem(j)).some(Boolean)))return p.sendMessage('§cEmpty the bound chest before unbinding.');
     // If the original block was destroyed by an external mechanism, owner
     // may recover the license only after its authoritative owner key is checked.
     const key=sellChestKey(old);if(world.getDynamicProperty(key)!==p.id)throw Error('Owner registry mismatch');
     // Fail closed: losing an index cannot transfer the license to anyone else.
     delete fresh.sellChestPos;save(p,fresh);
     world.setDynamicProperty(key,undefined);p.sendMessage('§aEmpty chest unbound; license retained.');return;
    }
    if(old)return p.sendMessage('§eUnbind the old empty chest before moving it.');
    const block=p.getBlockFromViewDirection?.({maxDistance:5})?.block,loc=block?.location;
    if(block?.typeId!=='minecraft:chest'||!loc||p.dimension?.id!=='minecraft:overworld')return p.sendMessage('§cLook directly at a single chest on your plot.');
    if(!belongs(p,loc.x,loc.z))return p.sendMessage('§cChest must be on your own plot.');
    const inv=chestContents(block);    if(!inv||inv.size!==27||!chestEnvironmentSafe(block,p.dimension))return p.sendMessage('§cBind only a single chest away from hoppers, pistons, and hopper minecarts.');
    if(Array.from({length:inv.size},(_,j)=>inv.getItem(j)).some(Boolean))return p.sendMessage('§cBind an empty chest before depositing items.');
    const neighbors=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
    if(neighbors.some(([dx,dy,dz])=>p.dimension.getBlock({x:loc.x+dx,y:loc.y+dy,z:loc.z+dz})?.typeId==='minecraft:hopper'))return p.sendMessage('§cRemove all adjacent hoppers before binding this chest.');
    const key=sellChestKey(loc),current=world.getDynamicProperty(key);
    if(current&&current!==p.id)return p.sendMessage('§cAnother player owns this chest.');
    world.setDynamicProperty(key,p.id);
    if(world.getDynamicProperty(key)!==p.id)throw Error('Owner index could not be verified');
    fresh.sellChestPos={x:loc.x,y:loc.y,z:loc.z};save(p,fresh);
    p.sendMessage('§aChest bound to you. Close it to sell eligible items.');
   }catch(e){p.sendMessage('§cChest binding needs operator review: '+String(e).slice(0,110))}
  });
}
function payoutBalance(d,destination){
 if(destination==='wallet')return d.credits;
 return d.bank?.accounts?.find(a=>a.id===destination)?.credits;
}
function chestShopPrice(id,count,d){
 const catalogs=[...SHOP,...FOOD_SHOP,...Object.values(FARMING_SHOP).flat()];
 const entry=catalogs.find(t=>t.id===id&&t.sell>0);
 if(!entry)return 0;
 return shopTotal(entry,false,count,d);
}
// All-or-none chest sale with same prepared/review journal semantics as inventory sales.
function sellBoundChestOnClose(e){
 const block=e.block,loc=block?.location,source=e.closeSource?.entity;
 if(block?.typeId!=='minecraft:chest'||!loc||!source||source.typeId!=='minecraft:player')return;
 if(e.dimension?.id!=='minecraft:overworld'||boundSaleChestOwner(loc)!==source.id)return;
 const p=source,d=profile(p),position=d.sellChestPos;
 if(!d.sellChestLicense||!position||sellChestKey(position)!==sellChestKey(loc)||!belongs(p,loc.x,loc.z))return;
 if(creativeEconomyBlocked(p))return p.sendMessage('§cSell-All Chest disabled: Creative inventory requires operator clearance.');
 const inv=chestContents(block);if(!inv||inv.size!==27||!chestEnvironmentSafe(block,p.dimension))return p.sendMessage('§cSell chest unsafe: check double chests, hoppers, minecarts, and pistons; contents retained.');
 const slots=[];let total=0,count=0;
 for(let i=0;i<inv.size;i++){
  const item=inv.getItem(i);
  if(!item||!eligibleShopItem(item,item.typeId))continue;
  const sell=chestShopPrice(item.typeId,item.amount,d);
  if(!Number.isSafeInteger(sell)||sell<=0)continue;
  total+=sell;count+=item.amount;slots.push([i,item.clone()]);
 }
 if(!slots.length)return;
 if(!Number.isSafeInteger(total)||total>CREDIT_CAP)return p.sendMessage('§cSale value exceeded limit. Contents untouched.');
 const destination=payoutDestination(d,total);
 const destinationBefore=payoutBalance(d,destination);
 if(destination===undefined)return p.sendMessage('§cNo wallet/bank room for '+total+' Credits. Chest contents retained.');
 let tx;const changed=[];
 try{
  tx=beginEconomicTxn(p,'sell',{source:'chest',chest:loc,owner:p.id,slots:slots.map(([i,it])=>[i,it.typeId,it.amount]),count,total,destination,destinationBefore,destinationAfter:destinationBefore+total});
  const live=profile(p);
  if(boundSaleChestOwner(loc)!==p.id||live.credits!==tx.before||payoutBalance(live,destination)!==destinationBefore)throw Error('Owner or destination changed');
  if(!chestEnvironmentSafe(block,p.dimension))throw Error('Unsafe automation beside sale chest');
  for(const [i,item] of slots){
   const current=inv.getItem(i);
   if(!current||!eligibleShopItem(current,item.typeId)||current.amount!==item.amount)throw Error('Chest inventory changed');
   changed.push([i,item]);inv.setItem(i,undefined);
   if(inv.getItem(i)!==undefined)throw Error('Chest item removal not verified');
  }
  const latest=profile(p);
  if(payoutBalance(latest,destination)!==destinationBefore)throw Error('Payout destination changed during sale');
  creditPayout(latest,destination,total);latest.sg_last_econ_txn=tx.id;
  for(const [,soldItem] of slots)recordDaily(p,latest,['sold'],soldItem.amount,soldItem.typeId);save(p,latest);
  endEconomicTxn(p,tx,true);p.sendMessage('§aChest sold '+count+' eligible items for '+total+' Credits.');
 }catch(err){
  if(!tx){p.sendMessage('§cChest sale was not started: '+String(err).slice(0,95));return}
  try{
   const latest=profile(p);
   if(latest.sg_last_econ_txn!==tx.id&&latest.credits===tx.before&&payoutBalance(latest,tx.destination)===tx.destinationBefore){
    let restored=true;
    for(const [i,item] of changed){const current=inv.getItem(i);if(current===undefined){inv.setItem(i,item);if(inv.getItem(i)?.amount!==item.amount)restored=false}else if(current.typeId!==item.typeId||current.amount!==item.amount)restored=false}
    if(restored){endEconomicTxn(p,tx,true);p.sendMessage('§cChest sale aborted; items restored.');return}
   }
  }catch{}
  economicTxnReview(p,tx,'Chest settlement uncertain: '+err);
 }
}
try{world.afterEvents.blockContainerClosed?.subscribe(e=>{try{sellBoundChestOnClose(e)}catch(err){console.warn('[SkyGen CHEST] Close error '+err)}})}
catch(err){console.warn('[SkyGen CHEST] Close event unavailable '+err)}

// v0.10.52: owner-only cosmetic toggles. Rendering still requires the personal
// HUD ownership gate and never grants the player a spendable/tradeable token.
function myCosmetics(p,returnTo=skyMenuProfileCosmetics){
 let c;try{c=validateCosmetics(profile(p))}catch(err){return p.sendMessage('§cCosmetics require operator review: '+String(err).slice(0,100))}
 const ids=Object.keys(COSMETIC_BADGES);
 const list=ids.map(id=>COSMETIC_BADGES[id].name+' — '+(!c.owned.includes(id)?'Locked':c.equipped.includes(id)?'Equipped':'Owned'));
 form(p,'§bMY COSMETICS','Owned badges remain yours when you rejoin. Equip any or all three together, or unequip individually. They appear below the right-side personal scoreboard.',[...list,'Back'],i=>{
  if(i>=ids.length)return returnTo(p);
  const id=ids[i];
  try{
   const fresh=profile(p),v=validateCosmetics(fresh);
   if(!v.owned.includes(id)){const offer=APPROVED_COSMETIC_BUNDLES.find(b=>b.badge===id);return offer?cosmeticBundleMenu(p,offer):myCosmetics(p,returnTo)}
   fresh.cosmetics=setCosmeticEquipped(fresh,id,!v.equipped.includes(id));
   save(p,fresh);
   p.sendMessage('§a'+COSMETIC_BADGES[id].name+' '+(fresh.cosmetics.equipped.includes(id)?'equipped.':'unequipped.'));
  }catch(err){p.sendMessage('§cCosmetic selection failed: '+String(err).slice(0,100))}
  menuAgain(p,()=>myCosmetics(p,returnTo));
 });
}
// v0.10.54: Cosmetic checkout grants ONLY a permanent badge entitlement.
// No inventory delivery, Totems, Enchanted Apples, chest or chest license.
// The economic journal still protects exact-once debits/ownership.
function purchaseCosmeticBundle(p,bundle,withOrbit){
 let tx;
 try{
  validateBundle(bundle);
  if(creativeEconomyBlocked(p))throw Error('Creative inventory requires operator clearance');
  const first=profile(p),owned=validateCosmetics(first);
  if(owned.owned.includes(bundle.badge))throw Error('You already own this badge');
  const amount=withOrbit?bundle.orbitPrice:bundle.price;
  if((withOrbit?first.orbits:first.credits)<amount)throw Error('Insufficient '+(withOrbit?'Orbits':'Credits'));
  tx=beginEconomicTxn(p,'buy',{sku:bundle.id,badge:bundle.badge,badgeOnly:true,
   currency:withOrbit?'orbits':'credits',cost:amount,beforeOrbits:first.orbits,slots:[]});
  const fresh=profile(p);
  if(validateCosmetics(fresh).owned.includes(bundle.badge))throw Error('Ownership changed');
  if(fresh.credits!==tx.before||fresh.orbits!==tx.beforeOrbits)throw Error('Currency balance changed');
  fresh.cosmetics=grantCosmetic(fresh,bundle.badge);
  if(withOrbit)fresh.orbits-=amount;else fresh.credits-=amount;
  fresh.sg_last_econ_txn=tx.id;
  save(p,fresh); // Ownership, debit, nonce: one persisted profile write.
  endEconomicTxn(p,tx,true);
  p.sendMessage('§aUnlocked '+bundle.name+' for '+amount.toLocaleString()+' '+(withOrbit?'Orbits':'Credits')+'. Open My Cosmetics to equip it.');
  return true;
 }catch(err){
  if(tx){
   try{
    const now=profile(p);
    const unpaid=now.sg_last_econ_txn!==tx.id&&now.credits===tx.before&&
     now.orbits===tx.beforeOrbits&&!validateCosmetics(now).owned.includes(bundle.badge);
    if(unpaid){endEconomicTxn(p,tx,true);p.sendMessage('§cBadge purchase canceled without payment.');return false}
   }catch{}
   // Fail closed after an ambiguous profile write; never refund twice.
   economicTxnReview(p,tx,'Badge-only cosmetic requires reconciliation: '+err);
  }
  p.sendMessage('§cBadge purchase unavailable: '+String(err).slice(0,110));return false;
 }
}
function cosmeticBundleMenu(p,bundle){
 try{validateBundle(bundle)}catch(err){p.sendMessage('§cBadge not ready: '+err);return}
 let current;
 try{current=profile(p)}catch(err){return p.sendMessage('§cCould not read balance: '+err)}
 const owned=validateCosmetics(current).owned.includes(bundle.badge);
 const available='§eCredits: '+current.credits.toLocaleString()+' / '+bundle.price.toLocaleString()+
  '  §5Orbits: '+current.orbits.toLocaleString()+' / '+bundle.orbitPrice;
 form(p,'PRO SHOP · '+bundle.name,
  '§bPermanent collectible HUD badge ONLY. No Totems, Enchanted Golden Apples, chest, license or other items.\n'+
  available+'\n§7Pay 20,000,000 Credits OR 1 Orbit (10% Orbit savings).\n'+
  (owned?'§aAlready owned — equip from My Cosmetics.':'§7One purchase per player; cannot be traded.'),
  owned?['Open My Cosmetics','Back']:['Buy with Credits','Buy with Orbits','Back'],i=>{
   if(owned)return i===0?myCosmetics(p,proShopBadges):proShopBadges(p);
   if(i===2)return proShopBadges(p);
   const withOrbit=i===1,cost=withOrbit?bundle.orbitPrice:bundle.price;
   let fresh;try{fresh=profile(p)}catch(err){return p.sendMessage('§cCould not read your wallet: '+err)}
   if((withOrbit?fresh.orbits:fresh.credits)<cost){
    p.sendMessage('§eNot enough '+(withOrbit?'Orbits':'Credits')+'. You need '+
     (cost-(withOrbit?fresh.orbits:fresh.credits)).toLocaleString()+' more. No purchase was attempted.');
    return menuAgain(p,()=>cosmeticBundleMenu(p,bundle));
   }
   showUI(p,skyMessage().title('Confirm Badge Unlock').body(bundle.name+'\n'+
    (withOrbit?'1 Orbit':'20,000,000 Credits')+'\nBadge only. No inventory items.').button1('Cancel').button2('Purchase')).then(r=>{
    if(!r.canceled&&r.selection===1)purchaseCosmeticBundle(p,bundle,withOrbit);
    menuAgain(p,()=>proShopBadges(p));
   }).catch(err=>p.sendMessage('§cBadge confirmation failed: '+err));
  });
}
// Four-piece Elite armor requires multiple verified slots, unlike one-piece
// Elytra. Use a journal and lock ambiguous deliveries for operator review.
function purchaseOrbitArmor(p,item){
 let tx,delivery=[];
 try{
  if(!item||item.lines?.length!==4||!Number.isSafeInteger(item.orbitPrice))throw Error('Unknown Orbit armor SKU');
  exactOrbitQuote(item.price,item.orbitPrice);
  if(creativeEconomyBlocked(p))throw Error('Creative inventory requires operator clearance');
  const inv=inventory(p),first=profile(p);
  if(!inv||first.orbits<item.orbitPrice)throw Error('Insufficient Orbits or unavailable inventory');
  const free=[];for(let i=0;i<inv.size;i++)if(inv.getItem(i)===undefined)free.push(i);
  if(free.length<4)throw Error('Requires four empty inventory slots');
  delivery=item.lines.map((line,i)=>{
   if(line.count!==1||!line.enchantments)throw Error('Unsupported armor set');
   const stack=new ItemStack(line.id,1);enchantProItem(stack,line.enchantments);
   if(!hasProEnchantments(stack,line.enchantments))throw Error('Enchantment verification failed');
   return {slot:free[i],item:stack,enchants:line.enchantments};
  });
  tx=beginEconomicTxn(p,'buy',{currency:'orbits',beforeOrbits:first.orbits,
   sku:item.name,armorSet:true,cost:item.orbitPrice,slots:delivery.map(v=>[v.slot,v.item.typeId])});
  const fresh=profile(p);
  if(fresh.orbits!==tx.beforeOrbits||fresh.orbits<item.orbitPrice)throw Error('Orbit balance changed');
  for(const x of delivery)if(inv.getItem(x.slot)!==undefined)throw Error('Destination occupied');
  fresh.orbits-=item.orbitPrice;fresh.sg_last_econ_txn=tx.id;save(p,fresh);
  for(const x of delivery){
   if(inv.getItem(x.slot)!==undefined)throw Error('Delivery slot changed');
   inv.setItem(x.slot,x.item);
   const actual=inv.getItem(x.slot);
   if(actual?.typeId!==x.item.typeId||actual.amount!==1||!hasProEnchantments(actual,x.enchants))throw Error('Armor delivery or enchantments incorrect');
  }
  endEconomicTxn(p,tx,true);
  p.sendMessage('§aPurchased '+item.name+' for '+item.orbitPrice+' Orbits.');return true;
 }catch(err){
  if(tx){
   try{const fresh=profile(p);if(fresh.sg_last_econ_txn!==tx.id&&fresh.orbits===tx.beforeOrbits&&fresh.credits===tx.before&&delivery.every(x=>inventory(p).getItem(x.slot)===undefined)){
    endEconomicTxn(p,tx,true);p.sendMessage('§cArmor purchase canceled without payment.');return false;
   }}catch{}
   economicTxnReview(p,tx,'Armor set purchase needs reconciliation: '+err);
  }
  p.sendMessage('§cArmor purchase unavailable: '+String(err).slice(0,110));return false;
 }
}
function proShop(p){
 navForm(p,'§6PRO SHOP',
  'Choose a premium category. All three cosmetic badges are permanent, badge-only purchases.\n§7Approved Orbit prices save exactly 10% at the wallet exchange rate.',
  [['Wings / Elytra',p=>proShopCatalog(p,'wings')],
   ['Elite Armor Sets',p=>proShopCatalog(p,'armor')],
   ['Cosmetic Badges',proShopBadges],
   ['Utility Items & Sell-All Chest',p=>proShopCatalog(p,'utility')],
   ['My Cosmetics',p=>myCosmetics(p,proShop)]],skyMenuShops);
}
function proShopBadges(p){
 const bundles=APPROVED_COSMETIC_BUNDLES;
 navForm(p,'§dCOSMETIC BADGES',
  'Badge-only permanent HUD cosmetics. No bonus inventory items or Sell-All Chest licenses.\n20,000,000 Credits or 1 Orbit each.',
  bundles.map(bundle=>[bundle.name+' · 20M Credits / 1 Orbit',p=>cosmeticBundleMenu(p,bundle)]),proShop);
}
function proShopCatalog(p,category){
 const valid=PRO_SHOP.filter(item=>item.lines.every(({id})=>ItemTypes.get(id)));
 const items=valid.filter(item=>category==='wings'?item.name.includes('Elytra'):
  category==='armor'?item.lines.length===4:category==='utility'&&item.lines.length!==4&&!item.name.includes('Elytra'));
 const title=category==='wings'?'WINGS / ELYTRA':category==='armor'?'ELITE ARMOR':'UTILITY ITEMS';
 const priceLabel=item=>item.price.toLocaleString()+' Credits'+(item.orbitPrice?' or '+item.orbitPrice+' Orbits':'');
 const entries=items.map(item=>[item.name+' · '+priceLabel(item),p=>proShopItem(p,item,category)]);
 if(category==='utility'){
  entries.push(['Sell-All Chest · 55,000 Credits',p=>{
   showUI(p,skyMessage().title('Buy Sell-All Chest').body('55,000 Credits for one owner-bound chest license. Items sell on close; unsellable contents remain.').button1('Cancel').button2('Buy')).then(r=>{
    if(!r.canceled&&r.selection===1)purchaseSellChest(p);
    menuAgain(p,()=>proShopCatalog(p,category));
   }).catch(err=>p.sendMessage('§cSell-All Chest confirmation failed: '+err));
  }],['Manage Sell-All Chest',manageSellChest]);
 }
 navForm(p,'§6PRO SHOP · '+title,'§7Review the exact item and currency before confirming.\n§eCredits: '+profile(p).credits.toLocaleString()+'  §5Orbits: '+profile(p).orbits.toLocaleString(),entries,proShop);
}
function proShopItem(p,item,category){
 const price=item.price.toLocaleString()+' Credits';
 const gear=item.lines.map(line=>line.id.split(':').at(-1).replaceAll('_',' ')+(line.enchantments?' • '+line.enchantments.map(([id,level])=>id+' '+level).join(', '):''));
 let approvedOrbits=false;
 if(item.orbitPrice){
  try{exactOrbitQuote(item.price,item.orbitPrice);approvedOrbits=true}
  catch(err){console.warn('[SkyGen PRO SHOP] Inconsistent Orbit quote '+item.name+': '+err)}
 }
 const actions=approvedOrbits?['Buy with Credits','Buy with Orbits','Back']:['Buy with Credits','Back'];
 form(p,'PRO SHOP · '+item.name,price+(approvedOrbits?' or '+item.orbitPrice+' Orbits':'')+'\n'+gear.join('\n')+'\n'+
  (approvedOrbits?'Orbit checkout saves exactly 10% versus Credit payment at the wallet exchange rate.':'No approved Orbit price for this item.'),actions,choice=>{
  if(choice>=actions.length-1)return proShopCatalog(p,category);
  const withOrbit=approvedOrbits&&choice===1;
  showUI(p,skyMessage().title('Confirm Pro Shop Purchase').body(item.name+'\n'+(withOrbit?item.orbitPrice+' Orbits':price)+'\n'+gear.join('\n')).button1('Cancel').button2('Buy')).then(r=>{
   if(!r.canceled&&r.selection===1){
    if(withOrbit){if(item.lines.length===4)purchaseOrbitArmor(p,item);else purchaseOrbitItem(p,item)}
    else if(buyShopItems(p,item.lines,item.price))p.sendMessage('§aPurchased '+item.name+' for '+price+'.');
   }
   menuAgain(p,()=>proShopCatalog(p,category));
  }).catch(err=>p.sendMessage('§cPro Shop purchase failed: '+err));
 });
}

function foodShop(p){shopCatalog(p,true,'food')}
function farmingShop(p){
 form(p,'FARMING SHOP','Buy farm supplies or sell eligible harvests for Credits.',
  ['Buy Supplies','Sell Harvest','Back'],i=>{
   if(i===2)return skyMenuShops(p);
   shopCatalog(p,i===0,'farming');
  });
}
function shop(p){
 form(p,'§6SERVER SHOP','Buy goods or sell eligible items from your inventory.',
  ['Buy','Sell From Inventory','Back'],i=>{
   if(i===2)return skyMenuShops(p);
   shopCatalog(p,i===0);
  });
}
function shopCatalog(p,buying,catalog='server'){
 const food=catalog==='food',farming=catalog==='farming';
 const returnShop=()=>food?skyMenuShops(p):farming?farmingShop(p):shop(p);
 const groupMap=farming?Object.fromEntries(Object.entries(FARMING_SHOP).map(([category,items])=>
  [category,items.filter(item=>ItemTypes.get(item.id)&&(buying?item.buy>0:item.sell>0))])):
  food?Object.fromEntries(FOOD_CATEGORIES.map(category=>[category,FOOD_SHOP.filter(item=>item.category===category)])):
  {Starter:[...SHOP.slice(0,2),...SHOP.filter(item=>item.category==='Starter')],
   Ores:[...SHOP.slice(2,4),...SHOP.filter(item=>item.category==='Ores')],
   Nether:SHOP.filter(item=>item.category==='Nether'),Endgame:SHOP.filter(item=>item.category==='Endgame')};
 if(catalog==='server'&&!buying){
  const serverIds=new Set(SHOP.map(item=>item.id));
  groupMap.Food=FOOD_SHOP.filter(item=>!serverIds.has(item.id));
 }
 function showCategories(){
  const groups=Object.entries(groupMap).map(([name,items])=>
   [name,items.filter(item=>buying||countShopInventory(p,item.id)>0)]).filter(([,items])=>items.length);
  const title=farming?(buying?'BUY FARM SUPPLIES':'SELL HARVEST'):food?'FOOD SHOP':buying?'BUY ITEMS':'SELL FROM INVENTORY';
  form(p,title,groups.length?'Choose a category.':'No eligible items in your inventory.',
   [...groups.map(([name,items])=>`${name} (${items.length})`),'Back'],i=>{
    if(i===groups.length)return returnShop();
    showPage(groups[i][0],0);
   });
 }
 function showPage(category,page){
  const items=groupMap[category].filter(item=>buying||countShopInventory(p,item.id)>0);
  if(!items.length)return showCategories();
  const last=Math.ceil(items.length/8)-1;
  page=Math.min(page,last);
  const slice=items.slice(page*8,page*8+8);
  const actions=slice.map(item=>[
   `${item.name} · ${buying?item.buy:item.sell} Credits / ${item.count}${buying?'':' · Owned: '+countShopInventory(p,item.id)}`,
   ()=>shopQuantity(p,item,buying,()=>showPage(category,page))
  ]);
  if(page>0)actions.push(['Previous Page',()=>showPage(category,page-1)]);
  if(page<last)actions.push(['Next Page',()=>showPage(category,page+1)]);
  actions.push(['Back',showCategories]);
  form(p,buying?'BUY ITEMS':'SELL ITEMS',`${category} · Page ${page+1}/${last+1}`,
   actions.map(([label])=>label),i=>actions[i]?.[1]());
 }
 showCategories();
}
function shopQuantity(p,item,buying,returnToList){
 const stay=()=>menuAgain(p,returnToList);
 const confirm=(count)=>{
  const d=profile(p),total=shopTotal(item,buying,count,d);
  if(total<1||!Number.isSafeInteger(total)||total>2000000000){
   p.sendMessage('§cTransaction price must be at least 1 Credit and within wallet limits.');return stay();
  }
  const ui=skyMessage().title('Confirm Shop Transaction')
   .body(`${buying?'Buy':'Sell'} ${count} × ${item.id}\n${total} Credits`).button1('Back').button2('Confirm');
  showUI(p,ui).then(r=>{
   if(r.canceled)return;
   try{
    if(r.selection!==1)return;
    if(shopTotal(item,buying,count,profile(p))!==total)return p.sendMessage('§eThe price changed. Open a new quote.');
    if(!buying&&count>countShopInventory(p,item.id))return p.sendMessage('§cInventory changed. Open a new quote.');
    const success=buying?buyShopItems(p,[{id:item.id,count}],total):safeShopSell(p,{id:item.id,count,sell:total});
    if(success)p.sendMessage(`§a${buying?'Purchased':'Sold'} ${count} × ${item.id} for ${total} Credits.`);
   }finally{stay()}
  }).catch(e=>p.sendMessage('§cShop confirmation failed: '+e));
 };
 const custom=()=>{
  const max=buying?2304:countShopInventory(p,item.id);
  const ui=skyModal().title(buying?'Buy Quantity':'Sell Quantity')
   .textField('Enter a quantity (1–'+max+')','16',{defaultValue:String(Math.min(16,max))});
  showUI(p,ui).then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();
   const count=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   if(!Number.isSafeInteger(count)||count<1||count>max||(!buying&&count>countShopInventory(p,item.id))){
    p.sendMessage('§cEnter a whole quantity within the available limit.');return stay();
   }
   confirm(count);
  }).catch(e=>p.sendMessage('§cShop quantity failed: '+e));
 };
 if(buying)return custom();
 form(p,'SELL QUANTITY',`${item.id} · Eligible inventory: ${countShopInventory(p,item.id)}`,
  ['Custom Amount','Sell All','Back'],i=>{
   if(i===0)return custom();
   if(i===1)return confirm(countShopInventory(p,item.id));
   if(i===2)return stay();
  });
}
function wallet(p){
 const d=profile(p);
 form(p,'§eWALLET',`Credits: ${d.credits}\nOrbits: ${d.orbits}\nExchange: ${C.exchange} Credits = 1 Orbit`,['Convert Credits to Orbits','Back'],i=>{
  if(i===1)return skyMenuBankWallet(p);
  if(i!==0)return;
  try{recoverEconomicTxn(p);if(readEconomicTxn(p))return p.sendMessage('§cWallet conversion locked pending transaction review.')}catch(e){return p.sendMessage('§cTransaction recovery: '+e)}
  const latest=profile(p),max=Math.floor(Number(latest.credits||0)/C.exchange);
  const ui=skyModal().title('§eEXCHANGE CREDITS')
   .textField('How many Orbits do you want? (Max affordable: '+max+')','Enter whole number',{defaultValue:'1'});
  adminShow(p,ui,'exchange quantity').then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();
   const count=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   const cost=count*C.exchange;
   if(!Number.isSafeInteger(count)||!Number.isSafeInteger(cost)||count<1||cost>2000000000)
    return p.sendMessage('§cEnter a valid whole number of Orbits.');
   const now=profile(p);
   if(!Number.isSafeInteger(Number(now.credits))||now.credits<cost)
    return p.sendMessage('§cInsufficient Credits. Need '+cost+', have '+now.credits+'.');
   if(!Number.isSafeInteger(Number(now.orbits))||now.orbits+count>2000000000)
    return p.sendMessage('§cOrbit wallet limit exceeded.');
   const confirm=skyMessage().title('§eCONFIRM EXCHANGE')
    .body('Receive: '+count+' Orbits\nCost: '+cost+' Credits\nRemaining Credits: '+(now.credits-cost))
    .button1('Cancel').button2('Confirm Exchange');
   adminShow(p,confirm,'exchange confirmation').then(c=>{
    if(c.canceled)return;
    if(c.selection!==1)return menuAgain(p,()=>wallet(p));
    try{
     const fresh=profile(p);
     if(!Number.isSafeInteger(Number(fresh.credits))||fresh.credits<cost)
      return p.sendMessage('§cInsufficient Credits; exchange canceled.');
     if(!Number.isSafeInteger(Number(fresh.orbits))||fresh.orbits+count>2000000000)
      return p.sendMessage('§cOrbit wallet limit exceeded; exchange canceled.');
     fresh.credits-=cost;fresh.orbits+=count;save(p,fresh);
     p.sendMessage('§aExchanged '+cost+' Credits for '+count+' Orbits.');
    }catch(e){p.sendMessage('§cExchange failed: '+e)}finally{menuAgain(p,()=>wallet(p))}
   }).catch(e=>p.sendMessage('§cExchange confirmation error: '+e));
  }).catch(e=>p.sendMessage('§cExchange quantity form error: '+e));
 });
}
// One 10-button entry menu; each section has 100 selectable rank rows.
// A 100-button list is only constructed for the selected section, not for all 1,000 ranks.
function ranks(p){
 const d=profile(p),progress=parseProgress(d.xpProgress),next=d.rank>=MAX_RANK?null:transitionCost(d.rank);
 const remaining=next===null?null:next>progress?next-progress:0n;
 const choices=Array.from({length:10},(_,i)=>'Ranks '+(i*100+1)+'–'+((i+1)*100));
 form(p,'§dRANK CODEX',`Current: ${d.rank}/${MAX_RANK} — ${rankName(d.rank)}\nXP: ${formattedXP(progress)} / ${next===null?'MAX':formattedXP(next)}\nTo Next: ${remaining===null?'MAX':formattedXP(remaining)}\nSkill Points available: ${skillAvailable(d)}\nSelect a group to browse its 100 ranks.`,[...choices,'Back'],i=>{
  if(i===10)return skyMenuRanksSkills(p);
  if(i>=0&&i<10)return rankGroup(p,i);
 });
}
function rankGroup(p,group){
 if(!Number.isInteger(group)||group<0||group>9)return ranks(p);
 const start=group*100+1,end=start+99,current=profile(p).rank;
 const buttons=Array.from({length:100},(_,i)=>{
  const n=start+i,req=n===MAX_RANK?'MAX RANK':formattedXP(transitionCost(n))+' XP';
  const status=n<current?'§a✓ ':n===current?'§e➤ ':'§7';
  return status+'#'+n+' '+rankName(n)+' §8• '+req;
 });
 form(p,'§dRANKS '+start+'–'+end,'Select any rank to view its requirements. Scroll to see all 100 ranks.',[...buttons,'Back to Rank Codex'],i=>{
  if(i===100)return ranks(p);
  if(i>=0&&i<100)return rankDetails(p,start+i,group);
 });
}
function rankDetails(p,n,group){
 if(!Number.isSafeInteger(n)||n<1||n>MAX_RANK)return rankGroup(p,group);
 const d=profile(p),currentXP=cumulativeXP(d.rank,d.xpProgress);
 const required=cumulativeXP(n,'0');
 const toReach=required>currentXP?required-currentXP:0n;
 const next=n===MAX_RANK?null:transitionCost(n);
 const status=n<d.rank?'Completed':n===d.rank?'Current rank':'Locked';
 form(p,'§dRANK '+n+' — '+rankName(n),
  'Status: '+status+'\nXP to reach this rank: '+formattedXP(required)+
  '\nRemaining XP to reach: '+formattedXP(toReach)+
  '\nXP to next rank: '+(next===null?'MAX RANK':formattedXP(next))+
  '\nCurrent rank: '+d.rank+' — '+rankName(d.rank),
  ['Back to Ranks '+(group*100+1)+'–'+((group+1)*100),'Back to Rank Codex'],i=>{
   if(i===0)return rankGroup(p,group);
   if(i===1)return ranks(p);
  });
}
function teleports(p){form(p,'§bTELEPORTS','All teleports have a 5-second stand-still warmup and 5-second cooldown.',['Go to Spawn','Go to Plot','Back'],i=>{if(i===0)safeSpawnTravel(p);if(i===1)tpPlot(p);if(i===2)skyMenuTravelVisitors(p)})}
// Only these ordinary materials can be reconstructed by type without losing
// enchantments, damage, or other complex item data. Legacy unknown items are
// quarantined, not sold as replacements.
const MARKET_COMMODITIES=new Set([
 'minecraft:cobblestone','minecraft:stone','minecraft:dirt','minecraft:grass_block',
 'minecraft:oak_log','minecraft:oak_planks','minecraft:spruce_log','minecraft:birch_log',
 'minecraft:iron_ingot','minecraft:gold_ingot','minecraft:copper_ingot',
 'minecraft:coal','minecraft:charcoal','minecraft:diamond','minecraft:emerald',
 'minecraft:redstone','minecraft:lapis_lazuli','minecraft:quartz',
 'minecraft:coal_ore','minecraft:iron_ore','minecraft:gold_ore',
 'minecraft:diamond_ore','minecraft:emerald_ore',
 'minecraft:obsidian','minecraft:deepslate','minecraft:gravel','minecraft:sand'
]);
for(const item of SHOP)MARKET_COMMODITIES.add(item.id);
for(const g of GENS)MARKET_COMMODITIES.add(g.block);
const MARKET_LOCK=new Set();
function marketLock(id,fn){
 if(MARKET_LOCK.has(id))return false;
 MARKET_LOCK.add(id);
 try{return fn()}catch(e){console.warn('[SkyGen MARKET] operation failed '+e);return false}
 finally{MARKET_LOCK.delete(id)}
}
function validListing(l){return !!l&&typeof l==='object'&&typeof l.id==='string'&&l.id.length>0&&typeof l.seller==='string'&&l.seller.length>0&&typeof l.type==='string'&&Number.isSafeInteger(l.count)&&l.count>=1&&l.count<=64&&Number.isSafeInteger(l.price)&&l.price>0&&l.price<=2000000000}
function marketPlain(it){
 try{
  // Marketplace reconstructs by type+quantity only. Reject all optional item
  // metadata that would otherwise disappear on purchase or cancellation.
  return !!it&&MARKET_COMMODITIES.has(it.typeId)&&it.amount>=1&&it.amount<=64&&
   !it.nameTag&&!it.keepOnDeath&&it.lockMode===ItemLockMode.none&&
   (!it.getLore||it.getLore().length===0)&&
   (!it.getCanPlaceOn||it.getCanPlaceOn().length===0)&&
   (!it.getCanDestroy||it.getCanDestroy().length===0)&&
   plainCommerceMetadata(it);
 }catch(e){return false}
}
// Seller payout queue: each entry has a unique, increasing sequence number.
// The paid watermark is saved in the SAME player profile write as the Credits.
// Clearing the world queue afterward can fail without issuing duplicate Credits.
function sellerQueueKey(id){return 'sg_proceeds_v2_'+id}
function sellerSeqKey(id){return 'sg_proceeds_seq_'+id}
function queueSellerPayout(seller,listingId,price){
 if(!Number.isSafeInteger(price)||price<=0||price>2000000000)throw Error('Invalid proceeds amount');
 const key=sellerQueueKey(seller),raw=world.getDynamicProperty(key);
 let queue=raw===undefined||raw===null?[]:JSON.parse(String(raw));
 if(!Array.isArray(queue))throw Error('Invalid seller proceeds queue');
 if(queue.some(x=>x.id===listingId))return true; // retry cannot enqueue twice
 const seq=Number(world.getDynamicProperty(sellerSeqKey(seller))||0);
 if(!Number.isSafeInteger(seq)||seq<0||seq>=2000000000)throw Error('Seller settlement sequence exhausted');
 const entry={id:listingId,seq:seq+1,price};
 const value=JSON.stringify([...queue,entry]);
 if(value.length>24000)throw Error('Seller payout queue capacity reached; operator review');
 world.setDynamicProperty(sellerSeqKey(seller),seq+1);
 if(world.getDynamicProperty(sellerSeqKey(seller))!==seq+1)throw Error('Payout sequence write failed');
 world.setDynamicProperty(key,value);
 if(world.getDynamicProperty(key)!==value)throw Error('Seller payout queue verification failed');
 return true;
}
function settleSellerProceeds(p,d){
 const legacyKey='sg_proceeds_'+p.id,legacy=Number(world.getDynamicProperty(legacyKey)||0);
 const key=sellerQueueKey(p.id),raw=world.getDynamicProperty(key);
 if(!legacy&&(raw===undefined||raw===null||raw==='[]'))return 0;
 assertBankUnlocked(p);
 let paid=0;
 if(legacy>0){
  if(!Number.isSafeInteger(legacy)||legacy>CREDIT_CAP)throw Error('Invalid legacy seller proceeds');
  if(!d.marketLegacyProceedsApplied){
   const destination=payoutDestination(d,legacy);
   if(destination===undefined){p.sendMessage('§eSale Credits pending. '+noPayoutRoom(d,legacy));return 0;}
   creditPayout(d,destination,legacy);
   d.marketLegacyProceedsApplied=true;
   save(p,d);
   paid+=legacy;
  }
  world.setDynamicProperty(legacyKey,0);
  if(world.getDynamicProperty(legacyKey)!==0)throw Error('Legacy proceeds clear not verified');
 }
 if(raw!==undefined&&raw!==null){
  const entries=JSON.parse(String(raw));
  if(!Array.isArray(entries)||entries.some(entry=>!entry||!Number.isSafeInteger(entry.seq)||entry.seq<1||
     !Number.isSafeInteger(entry.price)||entry.price<1||entry.price>CREDIT_CAP))throw Error('Invalid seller payout list');
  entries.sort((a,b)=>a.seq-b.seq);
  let watermark=Number(d.marketPayoutSeq||0);
  for(const entry of entries){
   if(entry.seq<=watermark)continue;
   const destination=payoutDestination(d,entry.price);
   if(destination===undefined){
    p.sendMessage('§eSale Credits pending. '+noPayoutRoom(d,entry.price));
    break;
   }
   creditPayout(d,destination,entry.price);
   d.marketPayoutSeq=entry.seq;
   save(p,d); // Balance and replay marker persist together.
   watermark=entry.seq;
   paid+=entry.price;
  }
  const value=JSON.stringify(entries.filter(x=>x.seq>watermark));
  if(value!==raw){
   world.setDynamicProperty(key,value);
   if(world.getDynamicProperty(key)!==value)throw Error('Seller payout cleanup needs review (safe to retry)');
  }
 }
 if(paid)p.sendMessage('§aMarketplace sales collected: '+paid+' Credits.');
 return paid;
}
function securityReviewCommand(actor){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 try{
  const ids=world.getDynamicPropertyIds();let flagged=0;
  for(const key of ids){
   if(key.startsWith('sg_token_')&&key!==TOKEN_SEQ_KEY){
    let r;try{r=JSON.parse(String(world.getDynamicProperty(key)))}catch{}
    if(!r||['pending','redeeming','review'].includes(r.status)){
     flagged++;if(flagged<=20)actor.sendMessage('§eTOKEN '+key+' '+String(r?.status||'corrupt')+' owner='+String(r?.owner||'?')+' '+String(r?.reason||''));
    }
   }else if(key.startsWith('sg_trade_review_')){
    flagged++;if(flagged<=20)actor.sendMessage('§cTRADE '+key+' '+String(world.getDynamicProperty(key)).slice(0,130));
   }
  }
  actor.sendMessage('§eSkyGen security review: '+flagged+' flagged records (showing first 20). Review logs and player inventories before changing them.');
 }catch(err){actor.sendMessage('§cSecurity records unavailable: '+String(err).slice(0,100))}
}
function marketReviewCommand(actor){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 const flagged=marketRead().filter(l=>l.status==='review'||l.status==='reserved'||l.status==='returning'||l.status==='creating'||l.status==='sold');
 actor.sendMessage('§eSkyGen market transactions needing review: '+flagged.length);
 for(const l of flagged.slice(0,25))actor.sendMessage('§6'+l.id+' §7'+l.status+' seller='+l.sellerName+' buyer='+(l.buyer||'none')+' '+l.type+' ×'+l.count+' Credits='+l.price+' '+String(l.reviewReason||''));
}
function marketRecover(){
 const records=marketRead();let dirty=false;
 for(const l of records){
  if(!l||typeof l!=='object')throw Error('Invalid market entry; refusing to modify saved marketplace without manual backup');
  if(!validListing(l)||!MARKET_COMMODITIES.has(l.type)){
   if(l.status!=='review'){l.status='review';l.reviewReason='Legacy/unsupported item; do not reconstruct metadata';dirty=true}
  }else if(['reserved','sold','returning','creating'].includes(l.status)){
   l.reviewReason='Interrupted '+l.status+' transaction; operator must reconcile inventory and wallet';l.status='review';dirty=true;
  }
 }
 if(dirty){try{marketSave(records)}catch(e){console.warn('[SkyGen MARKET] recovery markers could not save '+e)}}
}
system.runTimeout(()=>{try{marketRecover()}catch(e){console.warn('[SkyGen MARKET] Recovery blocked; data preserved '+e)}},60);
function market(p){
 const d=profile(p),all=marketRead(),reviews=all.filter(l=>l.status==='review').length;
 form(p,'§6PLAYER MARKET',`Active listings: ${all.filter(l=>!l.status||l.status==='active').length}/${MAX_LISTINGS}\nCredits: ${d.credits}\nRestricted to plain commodity items.${reviews?'\n§c'+reviews+' listing(s) need operator review.':''}`,
 ['Browse Listings','List an Item','My Listings / Cancel','Back'],i=>{if(i===0)marketBrowse(p);if(i===1)marketCreate(p);if(i===2)marketMine(p);if(i===3)skyMenuShops(p)});
}
function marketCreate(p){
 if(creativeEconomyBlocked(p))return p.sendMessage('§cCreative inventory cannot enter the Marketplace.');
 const choices=itemChoices(p).filter(x=>marketPlain(x.it));
 if(!choices.length){p.sendMessage('§cNo ordinary supported commodity items to list.');return menuAgain(p,()=>market(p));}
 form(p,'LIST COMMODITY','Only plain, unlocked commodity stacks are eligible.',
  [...choices.map(x=>`${x.it.typeId} ×${x.it.amount}`),'Back'],i=>{
  if(i>=choices.length)return market(p);
  const x=choices[i];const ui=skyModal().title('Set Listing Price').textField('Credits (1–2,000,000,000)','Example: 1000');
  showUI(p,ui).then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();const price=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   if(!Number.isSafeInteger(price)||price>2000000000){p.sendMessage('§cInvalid whole-number listing price.');return menuAgain(p,()=>marketCreate(p));}
   try{marketLock('market',()=>{
    if(creativeEconomyBlocked(p))return p.sendMessage('§cCreative inventory cannot enter the Marketplace.');
    let all=marketRead();if(all.filter(l=>!l.status||l.status==='active').length>=MAX_LISTINGS)return p.sendMessage('§cMarket active listing capacity reached.');
    if(all.filter(l=>l.seller===p.id&&(!l.status||l.status==='active')).length>=5)return p.sendMessage('§cYou may have at most five active listings.');
    const it=inventory(p)?.getItem(x.slot);
    if(!marketPlain(it)||it.typeId!==x.it.typeId||it.amount!==x.it.amount)return p.sendMessage('§cItem changed. Try again.');
    const stack=it.clone(),id=p.id+':'+system.currentTick+':'+Math.floor(Math.random()*100000);
    const listing={id,seller:p.id,sellerName:p.name,type:it.typeId,count:it.amount,price,status:'creating'};
    try{marketSave([...all,listing])}catch(e){return p.sendMessage('§cMarketplace storage unavailable; item retained.')} 
    try{
     if(!removeExact(p,x.slot,it.typeId,it.amount))throw Error('Item changed during escrow');
    }catch(e){
     // setItem can throw AFTER a partial write. Never erase the escrow proof
     // when removal status is uncertain: that would permanently lose items.
     try{
      const entries=marketRead(),record=entries.find(l=>l?.id===id);
      if(record){record.status='review';record.reviewReason='Escrow item removal uncertain; inspect inventory before restoring or clearing';marketSave(entries)}
     }catch(err){console.warn('[SkyGen MARKET] escrow review marker failed '+err)}
     console.warn('[SkyGen MARKET] ESCROW REVIEW '+id+' '+e);
     return p.sendMessage('§cListing escrow requires operator review. Do not retry this listing. ID: '+id);
    }
    all=marketRead();const record=all.find(l=>l.id===id);
    if(!record){console.warn('[SkyGen MARKET] CRITICAL: escrow record disappeared '+id);return p.sendMessage('§cEscrow needs operator review: '+id)}
    record.status='active';
    try{marketSave(all);p.sendMessage('§aCommodity listed and securely escrowed.')}
    catch(e){
     // Do not place item back into inventory if storage state is uncertain,
     // because another process could still see the active listing.
     console.warn('[SkyGen MARKET] CRITICAL: listing activation failed '+id+' '+e);
     p.sendMessage('§cEscrow pending review; contact an operator with listing '+id);
    }
   });}finally{menuAgain(p,()=>market(p))}
  }).catch(e=>p.sendMessage('§cListing UI error: '+e));
 });
}
function marketBrowse(p){
 const a=marketRead().filter(validListing).filter(l=>(!l.status||l.status==='active')&&MARKET_COMMODITIES.has(l.type));
 if(!a.length)return form(p,'MARKET','No available commodity listings.',['Back'],()=>market(p));
 form(p,'§6BUY COMMODITIES','Select a listing to purchase.',[...a.map(x=>`${x.type} ×${x.count} — ${x.price} Credits (${x.sellerName})`),'Back'],i=>{
  if(i>=a.length)return market(p);
  const listing=a[i];if(listing.seller===p.id){p.sendMessage('§eCannot buy your own listing.');return menuAgain(p,()=>marketBrowse(p));}
  showUI(p,skyMessage().title('Confirm Purchase').body(`${listing.type} ×${listing.count}\nCost: ${listing.price} Credits`).button1('Cancel').button2('Buy')).then(r=>{
   if(r.canceled)return;
   if(r.selection!==1)return menuAgain(p,()=>marketBrowse(p));
   try{marketLock('market',()=>{
    const all=marketRead(),idx=all.findIndex(l=>l.id===listing.id&&(!l.status||l.status==='active'));
    if(idx<0)return p.sendMessage('§cListing unavailable.');
    const l=all[idx];if(!validListing(l)||!MARKET_COMMODITIES.has(l.type))return p.sendMessage('§cListing needs operator review.');
    const d=profile(p);if(d.credits<l.price)return p.sendMessage('§cNot enough Credits.');
    const stack=new ItemStack(l.type,l.count);if(!inventoryCapacity(p,stack))return p.sendMessage('§cFree inventory space first.');
    l.status='reserved';l.buyer=p.id;l.buyerName=p.name;
    try{marketSave(all)}catch(e){return p.sendMessage('§cCannot reserve listing; no payment taken.')} 
    try{d.credits-=l.price;save(p,d)}catch(e){
     l.status='review';l.reviewReason='Buyer debit status uncertain; operator review required';
     try{marketSave(all)}catch{}return p.sendMessage('§cPayment error; operator review required. No automatic retry.');
    }
    try{if(inventory(p).addItem(stack))throw Error('Inventory capacity changed during delivery')}
    catch(e){
     l.status='review';l.reviewReason='Buyer charged; item delivery uncertain. Check inventory before any refund';
     try{marketSave(all)}catch{}return p.sendMessage('§cDelivery requires operator review. Do not repurchase listing.');
    }
    l.status='sold';
    try{marketSave(all)}catch(e){return p.sendMessage('§cItem delivered; seller settlement requires operator review.')} 
    try{
     queueSellerPayout(l.seller,l.id,l.price);
     // Delete the sold listing only after the settlement is in the verified queue.
     marketSave(marketRead().filter(x=>x.id!==l.id));
     p.sendMessage('§aPurchase complete!');
     const seller=world.getAllPlayers().find(q=>q.id===l.seller);
     if(seller){
      try{settleSellerProceeds(seller,profile(seller));}
      catch(err){
       console.warn('[SkyGen MARKET] Seller payout #'+l.id+': '+err);
       seller.sendMessage('§eSale Credits are pending. Check Compass → Bank → Collect Pending Payouts.');
      }
     }
    }catch(err){
     console.warn('[SkyGen MARKET] SALE REVIEW: '+l.id+' '+err);
     p.sendMessage('§eDelivered. Seller payment needs operator review; do not rebuy this listing.');
    }
   });}finally{menuAgain(p,()=>marketBrowse(p))}
  }).catch(e=>p.sendMessage('§cPurchase form error: '+e));
 });
}
function marketMine(p){
 const mine=marketRead().filter(l=>l.seller===p.id);
 const active=mine.filter(l=>(!l.status||l.status==='active')&&validListing(l)&&MARKET_COMMODITIES.has(l.type));
 const needsReview=mine.filter(l=>l.status==='review');
 form(p,'MY MARKET LISTINGS',needsReview.length?'§c'+needsReview.length+' item(s) require operator review. Use /scriptevent skygen:marketreview as operator.':'Cancel active listings to recover commodity items.',
 [...active.map(x=>`${x.type} ×${x.count} — ${x.price} Credits`),'Back'],i=>{
  if(i>=active.length)return market(p);
  const selected=active[i];
  marketLock('market',()=>{
   const all=marketRead(),idx=all.findIndex(l=>l.id===selected.id&&l.seller===p.id&&(!l.status||l.status==='active'));
   if(idx<0)return p.sendMessage('§cListing unavailable.');
   const l=all[idx];const stack=new ItemStack(l.type,l.count);
   if(!inventoryCapacity(p,stack))return p.sendMessage('§cFree inventory space first.');
   l.status='returning';try{marketSave(all)}catch(e){return p.sendMessage('§cCould not reserve cancellation.')} 
   try{if(inventory(p).addItem(stack))throw Error('Inventory changed during return')}
   catch(e){
    l.status='review';l.reviewReason='Return delivery uncertain; inspect inventory before reactivation';
    try{marketSave(all)}catch{}return p.sendMessage('§cCancellation needs operator review.');
   }
   try{marketSave(marketRead().filter(x=>x.id!==l.id));p.sendMessage('§aListing cancelled; commodity returned.')}
   catch(e){p.sendMessage('§cReturn delivered; listing cleanup needs operator review.');console.warn('[SkyGen MARKET] return listing cleanup '+l.id+' '+e)}
  });
 });
}
function tradeBusy(p){const t=trades.get(p.id);if(!t)return false;const online=world.getAllPlayers();if(t.closed||system.currentTick-t.created>600||!online.some(x=>x.id===t.a)||!online.some(x=>x.id===t.b)){tradeClose(t,'Expired or abandoned trade cleared.');return false;}return true}
function trade(p){const online=world.getAllPlayers().filter(q=>q.id!==p.id);form(p,'§dDIRECT TRADING','Select an online player to propose an item-for-item trade. Both must confirm the exact offers.',[...online.map(q=>q.name),'Back'],i=>{if(i>=online.length)return skyMenuShops(p);const q=online[i];if(tradeBusy(p)||tradeBusy(q))return p.sendMessage('§cOne player is already trading. Ask them to cancel or wait up to 30 seconds.');tradeOffer(p,q)})}
function eligibleTradeItem(item){
 try{
  return !!item&&!item.nameTag&&!item.keepOnDeath&&item.lockMode===ItemLockMode.none&&
   (!item.getLore||item.getLore().length===0)&&
   // Trade cannot promise preservation of opaque data it cannot fingerprint.
   typeof item.getDynamicPropertyIds==='function'&&item.getDynamicPropertyIds().length===0;
 }catch{return false}
}
function tradeGearDetails(item){
 const enchantable=item.getComponent('minecraft:enchantable');
 const durability=item.getComponent('minecraft:durability');
 const dyeable=item.getComponent('minecraft:dyeable');
 const dye=dyeable?.color;
 const potion=item.getComponent('minecraft:potion');
 return {
  enchantments:enchantable?.getEnchantments().map(({type,level})=>type.id+' '+level).sort()??[],
  durability:durability?[durability.damage,durability.maxDurability]:null,
  dye:dye?[dye.red,dye.green,dye.blue]:null,
  potion:potion?[potion.potionDeliveryType.id,potion.potionEffectType.id]:null,
  canPlaceOn:typeof item.getCanPlaceOn==='function'?item.getCanPlaceOn().slice().sort():[],
  canDestroy:typeof item.getCanDestroy==='function'?item.getCanDestroy().slice().sort():[]
 };
}
function tradeItemLabel(type,count,details){
 const traits=details.enchantments.map(enchantment=>enchantment.replace(/^minecraft:/,'').replaceAll('_',' '));
 if(details.durability){
  const [damage,maximum]=details.durability;
  traits.push(`Durability ${maximum-damage}/${maximum}`);
 }
 if(details.dye)traits.push('Dye '+details.dye.join('/'));
 if(details.potion)traits.push('Potion '+details.potion.join('/'));
 return `${type} ×${count}${traits.length?' · '+traits.join(', '):''}`;
}
function tradeChoices(p){
 return itemChoices(p).filter(({it})=>eligibleTradeItem(it)).map(({slot,it})=>{
  const details=tradeGearDetails(it);
  return {slot,type:it.typeId,count:it.amount,details,label:tradeItemLabel(it.typeId,it.amount,details)};
 });
}
function tradeOffer(p,q){
 if(creativeEconomyBlocked(p)||creativeEconomyBlocked(q))return p.sendMessage('§cCreative inventory cannot be traded until cleared by an operator.');
 const items=tradeChoices(p);
 if(!items.length)return p.sendMessage('§cNo eligible item stacks.');
 form(p,'OFFER ITEM',`Trading with ${q.name}. Select the stack to offer.`,[...items.map(x=>x.label),'Cancel'],i=>{
  const offer=items[i];
  if(offer)tradeInvite(p,q,offer.slot,offer.type,offer.count,offer.details);
 });
}
function tradeInvite(p,q,slot,type,count,details){
 if(tradeBusy(p)||tradeBusy(q))return p.sendMessage('§cA trade is already active.');
 if(!details){
  const item=inventory(p)?.getItem(slot);
  if(!eligibleTradeItem(item)||item.typeId!==type||item.amount!==count)return p.sendMessage('§cThe offered item changed.');
  details=tradeGearDetails(item);
 }
 const t={id:`${p.id}-${system.currentTick}`,a:p.id,b:q.id,aSlot:slot,aType:type,aCount:count,aDetails:details,created:system.currentTick,closed:false};
 trades.set(p.id,t);trades.set(q.id,t);
 const current=()=>trades.get(p.id)===t&&trades.get(q.id)===t;
 const cancel=()=>{if(current())tradeClose(t,'Trade cancelled.')};
 system.runTimeout(()=>{if(current())tradeClose(t,'Trade timed out after 30 seconds.');},600);
 form(q,'§dTRADE REQUEST',`${p.name} offers ${tradeItemLabel(type,count,t.aDetails)}. Choose a stack to exchange.`,['Choose My Item','Decline'],i=>{
  if(!current())return;
  if(i!==0)return cancel();
  const items=tradeChoices(q);
  if(!items.length)return tradeClose(t,'No eligible trade items.');
  form(q,'YOUR OFFER',`Exchange with ${p.name}`,[...items.map(x=>x.label),'Cancel'],j=>{
   if(!current())return;
   const offer=items[j];if(!offer)return cancel();
   t.bSlot=offer.slot;t.bType=offer.type;t.bCount=offer.count;t.bDetails=offer.details;t.aOK=false;t.bOK=false;
   tradeConfirm(p,q,t);
  },cancel);
 },cancel);
}
function tradeClose(t,message){if(t.closed)return;t.closed=true;if(trades.get(t.a)===t)trades.delete(t.a);if(trades.get(t.b)===t)trades.delete(t.b);for(const p of world.getAllPlayers())if(p.id===t.a||p.id===t.b)p.sendMessage('§e'+message)}
function tradeConfirm(p,q,t){const body=`${p.name}: ${tradeItemLabel(t.aType,t.aCount,t.aDetails)}\n${q.name}: ${tradeItemLabel(t.bType,t.bCount,t.bDetails)}\nBoth players must accept. No currency is transferred.`;for(const [player,field] of [[p,'aOK'],[q,'bOK']])showUI(player,skyMessage().title('§dCONFIRM TRADE').body(body).button1('Decline').button2('Accept')).then(r=>{if(trades.get(player.id)!==t)return;if(r.canceled||r.selection!==1)return tradeClose(t,'Trade cancelled.');t[field]=true;if(t.aOK&&t.bOK)system.run(()=>tradeExecute(p,q,t))}).catch(()=>tradeClose(t,'Trade UI closed.'))}
function tradeExecute(p,q,t){
 if(trades.get(p.id)!==t||trades.get(q.id)!==t||t.executing||t.closed)return;
 t.executing=true;
 try{
  if(p.isValid===false||q.isValid===false)return tradeClose(t,'Trade canceled: player disconnected.');
  if(creativeEconomyBlocked(p)||creativeEconomyBlocked(q))return tradeClose(t,'Trade canceled: Creative inventory needs operator clearance.');
  const aInv=inventory(p),bInv=inventory(q);
  const ai=aInv?.getItem(t.aSlot),bi=bInv?.getItem(t.bSlot);
  if(!eligibleTradeItem(ai)||!eligibleTradeItem(bi)||ai.typeId!==t.aType||bi.typeId!==t.bType||
     ai.amount!==t.aCount||bi.amount!==t.bCount)return tradeClose(t,'An offered item or quantity changed; trade canceled.');
  if(JSON.stringify(tradeGearDetails(ai))!==JSON.stringify(t.aDetails)||
     JSON.stringify(tradeGearDetails(bi))!==JSON.stringify(t.bDetails))
   return tradeClose(t,'An offered item’s enchantments or durability changed; trade canceled.');
  if(typeof aInv.swapItems!=='function')return tradeClose(t,'Trade unavailable: atomic slot swapping not supported by this server.');
  try{
   aInv.swapItems(t.aSlot,t.bSlot,bInv);
   // Verify post-swap shape, including quantity and type, before reporting success.
   const aNow=aInv.getItem(t.aSlot),bNow=bInv.getItem(t.bSlot);
   if(!aNow||!bNow||aNow.typeId!==t.bType||aNow.amount!==t.bCount||bNow.typeId!==t.aType||bNow.amount!==t.aCount||
      JSON.stringify(tradeGearDetails(aNow))!==JSON.stringify(t.bDetails)||
      JSON.stringify(tradeGearDetails(bNow))!==JSON.stringify(t.aDetails))throw Error('Swap verification uncertain');
   return tradeClose(t,'Trade completed successfully!');
  }catch(err){
   console.warn('[SkyGen TRADE] operator review '+t.id+' '+err);
   try{world.setDynamicProperty('sg_trade_review_'+t.id,JSON.stringify({a:t.a,b:t.b,at:Date.now(),aSlot:t.aSlot,bSlot:t.bSlot,aType:t.aType,bType:t.bType,reason:String(err).slice(0,100)}))}catch(e){console.warn('[SkyGen TRADE] failed to record review '+e)}
   return tradeClose(t,'Trade result needs operator review. Do not repeat this trade until inventories are checked.');
  }
 }catch(e){return tradeClose(t,'Trade canceled safely: '+e)}
}
function removeItemType(p,type,count){const inv=inventory(p);for(let i=0;i<inv.size&&count>0;i++){const it=inv.getItem(i);if(it?.typeId!==type||it.nameTag)continue;const n=Math.min(count,it.amount);removeExact(p,i,type,n);count-=n}}
// v0.10.6: Login must not override vanilla Bedrock's saved position.
// Our checkpoint is a fail-safe for servers that previously forced spawn on join.
// All location checkpoints are per-player, never shared by name, rank or plot ID.
const LAST_SAFE_KEY='sg_last_safe_location_v0106';
const RETURN_AREAS_KEY='sg_login_areas_v0106';
const lastSafeWriteTick=new Map(),loginPending=new Set(),returnStages=new Map(),returnCheckpointHold=new Map();
const MAX_RETURN_STAGES=2,RETURN_MAX_WAIT=240;
const VALID_RETURN_DIMS=new Set(['minecraft:overworld','minecraft:nether','minecraft:the_end']);
function validReturnRecord(record){
 return !!record&&record.v===1&&VALID_RETURN_DIMS.has(record.dim)&&
  ['x','y','z'].every(k=>typeof record[k]==='number'&&Number.isFinite(record[k]))&&
  Math.abs(record.x)<29000000&&Math.abs(record.z)<29000000&&record.y>=-63&&record.y<=319;
}
function lastSafeRecord(p){
 try{
  const raw=p.getDynamicProperty(LAST_SAFE_KEY);
  if(typeof raw!=='string')return undefined;
  const d=JSON.parse(raw);
  return validReturnRecord(d)?d:undefined;
 }catch(e){console.warn('[SkyGen LOGIN] invalid last-location checkpoint for '+p.id+': '+e);return undefined}
}
function lastLocationAllowed(p,d){
 if(!validReturnRecord(d))return false;
 if(d.dim==='minecraft:overworld'){
  const area=fieldAt(d.x,d.z);
  if(area?.kind==='plot'&&!fieldAccess(p,area))return false;
 }
 return true;
}
function safeStandingLocation(dim,location){
 if(!dim||!location||!Number.isFinite(location.x)||!Number.isFinite(location.y)||!Number.isFinite(location.z))return false;
 const x=Math.floor(location.x),y=Math.floor(location.y),z=Math.floor(location.z);
 if(y<-63||y>319)return false;
 // Reject unloaded chunks, void, fire, dangerous surfaces and obstructed headroom.
 const floor=loadedPlotBlock(dim,x,y-1,z),feet=loadedPlotBlock(dim,x,y,z),head=loadedPlotBlock(dim,x,y+1,z),upper=loadedPlotBlock(dim,x,y+2,z);
 const deadly=new Set(['minecraft:water','minecraft:lava','minecraft:magma','minecraft:fire','minecraft:soul_fire','minecraft:cactus','minecraft:powder_snow','minecraft:campfire','minecraft:soul_campfire','minecraft:sweet_berry_bush']);
 return !!floor&&!floor.isAir&&!deadly.has(floor.typeId)&&!!feet&&feet.isAir&&!!head&&head.isAir&&!!upper&&upper.isAir;
}
function checkpointPlayer(p){
 if(!p?.isValid||loginPending.has(p.id)||returnStages.has(p.id)||pending.has(p.id)||spawnStages.has(p.id))return false;
 const dim=p.dimension,loc=p.location;
 const hold=returnCheckpointHold.get(p.id);
 // If the destination failed to load, do not quietly overwrite the old saved
 // location with the fallback spawn while the user is standing still.
 if(hold){
  if(dim?.id===hold.dim&&Math.hypot(loc.x-hold.x,loc.y-hold.y,loc.z-hold.z)<3)return false;
  returnCheckpointHold.delete(p.id);
 }
 if(!VALID_RETURN_DIMS.has(dim?.id)||!safeStandingLocation(dim,loc))return false;
 const d={v:1,dim:dim.id,x:loc.x,y:loc.y,z:loc.z};
 if(!lastLocationAllowed(p,d))return false;
 const current=lastSafeRecord(p);
 if(current&&current.dim===d.dim&&Math.hypot(d.x-current.x,d.y-current.y,d.z-current.z)<.25)return true;
 try{
  const value=JSON.stringify(d);p.setDynamicProperty(LAST_SAFE_KEY,value);
  if(p.getDynamicProperty(LAST_SAFE_KEY)!==value)throw Error('checkpoint verification failed');
  lastSafeWriteTick.set(p.id,system.currentTick);return true;
 }catch(e){console.warn('[SkyGen LOGIN] last location persistence failed for '+p.id+': '+e);return false}
}
// A live player's safe location is checkpointed every 2s. The before-leave
// callback cannot write dynamic properties (restricted execution), so we never
// depend on an unreliable write during disconnect. Worst-case lag is ~2s.
system.runInterval(()=>{
 for(const p of world.getAllPlayers()){
  try{checkpointPlayer(p)}catch(e){console.warn('[SkyGen LOGIN] checkpoint error: '+e)}
 }
},40);
function returnAreaEntries(){
 try{
  const v=JSON.parse(String(world.getDynamicProperty(RETURN_AREAS_KEY)||'[]'));
  return Array.isArray(v)?v.filter(x=>x&&/^(sg_ret_[a-f0-9]{8})$/.test(x.name)&&VALID_RETURN_DIMS.has(x.dim)).slice(0,25):[];
 }catch{return []}
}
function trackReturnArea(name,dim,add){
 const list=returnAreaEntries().filter(v=>v.name!==name);
 if(add)list.push({name,dim});
 world.setDynamicProperty(RETURN_AREAS_KEY,JSON.stringify(list));
}
function returnAreaName(p){
 let hash=2166136261;
 for(const c of String(p.id)){hash^=c.charCodeAt(0);hash=Math.imul(hash,16777619)}
 return 'sg_ret_'+(hash>>>0).toString(16).padStart(8,'0');
}
function sweepReturnAreas(){
 for(const r of returnAreaEntries()){
  try{world.getDimension(r.dim.replace('minecraft:','')).runCommand('tickingarea remove '+r.name)}catch(e){console.warn('[SkyGen LOGIN] orphan return area '+r.name+': '+e)}
  try{trackReturnArea(r.name,r.dim,false)}catch(e){console.warn('[SkyGen LOGIN] return registry cleanup: '+e)}
 }
}
system.runTimeout(sweepReturnAreas,25);
function rescueIfVoid(p){
 if(p.isValid&&p.dimension?.id==='minecraft:overworld'&&p.location.y<-50&&!spawnStages.has(p.id))safeSpawnTravel(p,true);
}
function restorePlayerLocation(p){
 if(!p?.isValid)return;
 if(returnStages.has(p.id))return;
 const saved=lastSafeRecord(p),id=p.id;
 if(!saved){loginPending.delete(id);rescueIfVoid(p);return}
 if(!lastLocationAllowed(p,saved)){
  returnCheckpointHold.set(id,{dim:p.dimension.id,...p.location});
  loginPending.delete(id);p.sendMessage('§eYour saved location is no longer accessible. A private plot may have changed permissions.');
  rescueIfVoid(p);return;
 }
 const here=p.location;
 if(p.dimension?.id===saved.dim&&Math.hypot(here.x-saved.x,here.y-saved.y,here.z-saved.z)<1.25){
  // Vanilla has already done the correct thing. Do not add a ticking area.
  loginPending.delete(id);return;
 }
 // A loaded, permitted non-spawn position from vanilla is more precise than
 // our 2-second checkpoint. Trust the normal server's reconnect location
 // instead of rewinding a legitimate player to an older sample.
 const currentPermitted={v:1,dim:p.dimension.id,x:here.x,y:here.y,z:here.z};
 if(lastLocationAllowed(p,currentPermitted)&&safeStandingLocation(p.dimension,here)&&
    (p.dimension.id!=='minecraft:overworld'||!inSpawn(here.x,here.z))){
  loginPending.delete(id);checkpointPlayer(p);return;
 }
 const stage={name:returnAreaName(p),dim:saved.dim,created:system.currentTick,areaActive:false,finished:false};
 returnStages.set(id,stage);
 function finish(success=false){
  if(stage.finished)return;
  stage.finished=true;
  loginPending.delete(id);
  const release=()=>{
   if(returnStages.get(id)===stage)returnStages.delete(id);
   if(stage.areaActive){
    try{world.getDimension(stage.dim.replace('minecraft:','')).runCommand('tickingarea remove '+stage.name)}catch(e){console.warn('[SkyGen LOGIN] could not release return area: '+e)}
   }
   try{trackReturnArea(stage.name,stage.dim,false)}catch(e){console.warn('[SkyGen LOGIN] could not clean return registry: '+e)}
  };
  // Keep the destination loaded for 2s to support client chunk handoff.
  if(success)system.runTimeout(release,40);else release();
 }
 function poll(){
  if(stage.finished)return;
  if(!p.isValid){finish();return}
  if(!lastLocationAllowed(p,saved)){finish();p.sendMessage('§cSaved location access was revoked; return cancelled.');rescueIfVoid(p);return}
  if(system.currentTick-stage.created>RETURN_MAX_WAIT){
   returnCheckpointHold.set(id,{dim:p.dimension.id,...p.location});
   finish();p.sendMessage('§eYour saved location could not be loaded. You have not been teleported into an unsafe chunk.');
   rescueIfVoid(p);return;
  }
  try{
   const dim=world.getDimension(saved.dim.replace('minecraft:',''));
   if(!stage.areaActive){
    const active=[...returnStages.values()].filter(v=>v.areaActive).length;
    if(active>=MAX_RETURN_STAGES){system.runTimeout(poll,10);return}
    trackReturnArea(stage.name,stage.dim,true); // Journal before any chunk allocation.
    const r=dim.runCommand(`tickingarea add circle ${Math.floor(saved.x)} ${Math.floor(saved.y)} ${Math.floor(saved.z)} 0 ${stage.name} false`);
    if(r?.successCount===0)throw Error('Destination ticking area rejected or limit reached');
    stage.areaActive=true;
   }
   if(!safeStandingLocation(dim,saved)){system.runTimeout(poll,10);return}
   if(typeof p.tryTeleport!=='function')throw Error('Safe teleport capability is not available');
   forcefieldTickets.set(id,{x:saved.x,y:saved.y,z:saved.z,expires:system.currentTick+20});
   if(!p.tryTeleport({x:saved.x,y:saved.y,z:saved.z},{dimension:dim,checkForBlocks:false})){
    forcefieldTickets.delete(id);system.runTimeout(poll,10);return;
   }
   forcefieldPrevious.delete(id);
   returnCheckpointHold.delete(id);
   p.sendMessage('§aWelcome back! Returned to your last safe location.');
   finish(true);
  }catch(e){
   forcefieldTickets.delete(id);
   returnCheckpointHold.set(id,{dim:p.dimension.id,...p.location});
   const message=String(e);
   // Ticking-area exhaustion is not a reason to use unsafe /tp or overwrite the save.
   finish();p.sendMessage('§eCould not prepare your last location: '+message.slice(0,100)+'. Operator: /tickingarea list all-dimensions');
   rescueIfVoid(p);
  }
 }
 system.runTimeout(poll,1);
}
world.afterEvents.playerSpawn.subscribe(e=>{
 const p=e.player,initial=!!e.initialSpawn;
 forcefieldPrevious.delete(p.id);
 if(initial){
  loginPending.add(p.id);
  // Delay long enough to let vanilla restore the player and recover old
  // plot ticking-area orphans. Never teleport all logins to spawn.
  system.runTimeout(()=>{try{restorePlayerLocation(p)}catch(err){loginPending.delete(p.id);console.warn('[SkyGen LOGIN] safe return failed: '+err);rescueIfVoid(p)}},30);
 }
 system.runTimeout(()=>{try{
  // Death respawns are vanilla unless the player is falling into SkyGen void.
  // Fresh joins without a saved location are also rescued only if unsafe.
  if(!initial)rescueIfVoid(p);
  try{recoverEconomicTxn(p)}catch(err){p.sendMessage('§cPending economic review: contact a Realm operator.');console.warn('[SkyGen ECON] join recovery '+err)}
  const d=claim(p);
  try{settleSellerProceeds(p,d)}catch(err){console.warn('[SkyGen MARKET] Seller proceeds need operator review '+p.id+' '+err);p.sendMessage('§cMarketplace proceeds settlement needs operator review.');}
  rank(p,profile(p));ensure(p);
  if(initial)try{bank.recover(p)}catch(err){console.warn('[SkyGen BANK] deferred recovery while index rebuilds '+err)}
  p.sendMessage('§bSkyGen: menu compass slot 7, spawn horn slot 8, plot horn slot 9.');
 }catch(err){console.warn('SkyGen join '+err)}},35);
});
try{
 world.afterEvents.playerDimensionChange?.subscribe(e=>{
  const p=e.player;if(!p||p.dimension?.id!=='minecraft:overworld'||isOperator(p))return;
  forcefieldPrevious.delete(p.id);
  system.runTimeout(()=>{
   if(!p.isValid||p.dimension?.id!=='minecraft:overworld')return;
   const region=fieldAt(p.location.x,p.location.z);
   if(region?.kind==='plot'&&!fieldAccess(p,region))safeSpawnTravel(p,true);
  },5);
 });
}catch(err){console.warn('[SkyGen SECURITY] dimension return guard unavailable '+err)}
world.afterEvents.itemUse.subscribe(e=>{
 const p=e.source,i=e.itemStack;
 if(adminAxe(i)){system.run(()=>adminMenu(p));return}
 if(toolmatch(i,TOOLS[0]))system.run(()=>menu(p));
 if(toolmatch(i,TOOLS[1]))system.run(()=>{if(p.location.y<-50){const t=pending.get(p.id);pending.delete(p.id);finishPendingTeleport(t);safeSpawnTravel(p,true)}else safeSpawnTravel(p)});
 if(toolmatch(i,TOOLS[2]))system.run(()=>tpPlot(p));
});
// Generator tokens must be issued, uniquely identified, and redeemed by the server.
// The token record is authoritative, not the egg's display name or its lore.
// ItemStack dynamic properties require non-stackable items in Bedrock stable.
// Goat horns are non-stackable and reliably fire the existing itemUse event on Xbox.
// Legacy v0.9.2 goat horns remain redeemable; v0.9.3 purchases use custom items.
const GENERATOR_TOKEN_ITEM='minecraft:goat_horn';
let generatorTokenCustomReady=false;
const TOKEN_SEQ_KEY='sg_token_seq';
const generatorOutputReady=new Set();
function tokenKey(id){return 'sg_token_'+id}
function tokenId(it){try{return String(it?.getDynamicProperty?.('sg_token_id')||'')}catch{return ''}}
function tokenRead(id){
 if(!/^[1-9][0-9]*$/.test(String(id)))return null;
 const raw=world.getDynamicProperty(tokenKey(id));
 if(typeof raw!=='string')return null;
 const r=JSON.parse(raw);
 if(!r||r.v!==1||!['pending','issued','redeeming','spent','review'].includes(r.status)||typeof r.owner!=='string'||typeof r.type!=='string')return null;
 return r;
}
function tokenWrite(id,r){
 const value=JSON.stringify(r);world.setDynamicProperty(tokenKey(id),value);
 if(world.getDynamicProperty(tokenKey(id))!==value)throw Error('Generator token ledger write not verified');
}
function issueGeneratorToken(p,g,price){
 if(!generatorTokenCustomReady)return p.sendMessage('§cGenerator custom-item use handler is not active; cannot issue tokens.');
 if(!validGeneratorOutput(g))return p.sendMessage('§cGenerator output block is unavailable on this Bedrock version. No charge.');
 const latest=profile(p),inv=inventory(p);
 if(!inv||latest.rank<g.unlock||latest.credits<price)return p.sendMessage('§cNot eligible or Credits changed.');
 const egg=new ItemStack(generatorItemId(g),1);
 if(egg.maxAmount!==1)return p.sendMessage('§cSecure generator token item is not non-stackable; purchase blocked without charge.');
 egg.nameTag=`§bSkyGen ${g.name} Generator`;
 egg.setLore([`Generator type: ${g.name}`,'Server-verified token. Use on your plot.']);
 const seq=Number(world.getDynamicProperty(TOKEN_SEQ_KEY)||0);
 if(!Number.isSafeInteger(seq)||seq<0||seq>=2000000000)return p.sendMessage('§cGenerator issuance registry limit.');
 const id=String(seq+1);
 try{egg.setDynamicProperty('sg_token_id',id);if(tokenId(egg)!==id)throw Error('Token identity did not survive an item read')}catch(err){return p.sendMessage('§cItem token identity unavailable; purchase disabled. '+String(err).slice(0,90))}
 if(!inventoryCapacity(p,egg))return p.sendMessage('§cInventory full. No charge.');
 try{
  world.setDynamicProperty(TOKEN_SEQ_KEY,seq+1);
  if(world.getDynamicProperty(TOKEN_SEQ_KEY)!==seq+1)throw Error('Token sequence not saved');
  tokenWrite(id,{v:1,status:'pending',owner:p.id,type:g.name,price});
 }catch(err){return p.sendMessage('§cToken registry unavailable. No Credits spent. '+String(err).slice(0,90))}
 try{latest.credits-=price;save(p,latest)}catch(err){return p.sendMessage('§cWallet unavailable. Token issuance reserved but disabled; no item delivered.')}
 try{tokenWrite(id,{v:1,status:'issued',owner:p.id,type:g.name,price})}catch(err){
  genError('CRITICAL: paid generator token '+id+' cannot activate '+err,'token');
  return p.sendMessage('§cToken activation needs operator review: #'+id);
 }
 try{
  if(inv.addItem(egg))throw Error('Inventory full or item delivery uncertain');
  p.sendMessage(`§aPurchased ${g.name} generator token (#${id}) for ${price} Credits.`);
 }catch(err){
  // NO AUTOMATIC REFUND: the item may already be delivered on an ambiguous write.
  try{tokenWrite(id,{v:1,status:'review',owner:p.id,type:g.name,price,reason:'Delivery uncertain'})}catch{}
  genError('CRITICAL: generator token delivery review '+id+' '+err,'token');
  p.sendMessage('§cToken delivery needs operator review #'+id+'. Do not purchase another.');
 }
}
// Operator-reviewed migration path for genuine legacy generator eggs without issued IDs.
// The operator must verify the customer's older purchase; no name-only automatic redemption.
// Read-only reconciliation helper: IDs #25 and #26 remain locked until
// a human verifies wallets, inventory and world block/registry state.
function adminTokenStatus(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 const id=String(message||'').trim();
 if(!/^[1-9][0-9]*$/.test(id))return actor.sendMessage('§eUsage: /scriptevent skygen:tokenstatus 25');
 try{
  const r=tokenRead(id);
  if(!r)return actor.sendMessage('§cToken #'+id+' not found or invalid.');
  const matched=[...generators.values()].filter(g=>g.owner===r.owner&&g.type===r.type);
  actor.sendMessage('§eToken #'+id+' status='+r.status+' type='+r.type+' price='+r.price+' owner='+r.owner+' reason='+String(r.reason||'none'));
  actor.sendMessage('§7Owner has '+matched.length+' registered generator(s) of that type; compare with receipts and world blocks before settlement.');
 }catch(err){actor.sendMessage('§cToken read failed: '+String(err).slice(0,130))}
}
// Creative-taint removal requires a manual verified quarantine of *all*
// Creative-origin inventory/container items. The operator cannot infer origin.
function adminCreativeClear(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 const target=playerByName(String(message||'').trim());
 if(!target)return actor.sendMessage('§cTarget player must be online: /scriptevent skygen:creativeclear PlayerName');
 if(target.getGameMode()===GameMode.Creative)return actor.sendMessage('§cSwitch target to Survival and quarantine Creative items first.');
 const inv=inventory(target);
 if(!inv||Array.from({length:inv.size},(_,i)=>inv.getItem(i)).some(it=>it&&!isTool(it)))return actor.sendMessage('§cClear target ordinary inventory and check armor, offhand, Ender chest, storage before staff clearance.');
 const key=creativeEconomyKey(target);
 world.setDynamicProperty(key,false);
 if(world.getDynamicProperty(key)!==false)return actor.sendMessage('§cCreative clearance could not be verified.');
 console.warn('[SkyGen SECURITY] Creative economy taint cleared by operator '+actor.name+' for '+target.name+' after stated manual inventory review');
 actor.sendMessage('§aCreative economy restriction cleared for '+target.name+'.');
}
function adminTokenRestore(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOnly operators can reissue verified generator tokens.');
 const match=/^\s*(.+?)\s*\|\s*(.+?)\s*$/.exec(String(message||''));
 if(!match)return actor.sendMessage('§eUsage: /scriptevent skygen:tokenrestore PlayerName | Generator Name');
 const target=playerByName(match[1]),g=GENS.find(x=>x.name.toLowerCase()===match[2].toLowerCase());
 if(!target||!g)return actor.sendMessage('§cOnline player or generator type not found.');
 try{
  if(profile(target).rank<g.unlock)return actor.sendMessage('§cTarget player has not unlocked this generator rank.');
  const before=Number(world.getDynamicProperty(TOKEN_SEQ_KEY)||0);
  issueGeneratorToken(target,g,0);
  const after=Number(world.getDynamicProperty(TOKEN_SEQ_KEY)||0);
  const delivered=after>before&&!![...Array(inventory(target)?.size||0).keys()].some(slot=>tokenId(inventory(target).getItem(slot))===String(after));
  if(delivered){console.warn('[SkyGen SECURITY] operator '+actor.name+' reissued '+g.name+' token to '+target.name+' #'+after);actor.sendMessage('§aIssued verified replacement token #'+after+'; inspect player inventory and records.');}
  else actor.sendMessage('§cToken restoration not verified; check player inventory and security records before retrying.');
 }catch(e){actor.sendMessage('§cToken restoration failed: '+String(e).slice(0,100))}
}
function rollbackGeneratorBlocks(dim,loc,spec,baseWasAir){
 try{const out=dim.getBlock({x:loc.x,y:loc.y+1,z:loc.z});if(out?.typeId===spec.block)out.setType('minecraft:air')}catch(e){genError('Generator output rollback '+e,'rollback')}
 if(baseWasAir)try{const base=dim.getBlock(loc),core=GENERATOR_CORE_BY_NAME.get(spec.name);if(base?.typeId===core)base.setType('minecraft:air')}catch(e){genError('Generator base rollback '+e,'rollback')}
}
// Staff Creative provenance guard. Once a player uses Creative, item origins
// cannot reliably be proven from vanilla inventory; refuse commerce until
// operator clears the flag after separately clearing acquired inventory.
function creativeEconomyKey(p){return 'sg_creative_econ_tainted_'+p.id}
function taintCreativePlayer(p){
 try{world.setDynamicProperty(creativeEconomyKey(p),true)}catch(err){console.warn('[SkyGen CREATIVE] could not mark '+p.id+': '+err)}
}
function creativeEconomyBlocked(p){
 try{
  if(p.getGameMode()===GameMode.Creative){taintCreativePlayer(p);return true}
  return world.getDynamicProperty(creativeEconomyKey(p))===true;
 }catch{return true}
}
try{world.afterEvents.playerGameModeChange?.subscribe(e=>{
 if(e.toGameMode===GameMode.Creative)taintCreativePlayer(e.player);
})}catch(err){console.warn('[SkyGen CREATIVE] mode event unavailable '+err)}
const completedGeneratorEvents=new Map();
function recentConsumedGeneratorEvent(p,id,stack,record){
 const key=p.id+':'+id,until=completedGeneratorEvents.get(key);
 if(until===undefined||system.currentTick>until)return false;
 return !!record&&['spent','review'].includes(record.status)&&tokenId(stack)!==id;
}
function placeGeneratorToken(p,selected,id){
 let record;
 try{
  if(!p?.isValid)return;
  const inv=inventory(p),stack=inv?.getItem(selected);record=tokenRead(id);
  if(recentConsumedGeneratorEvent(p,id,stack,record))return; // stale second event, not a forged token
  if(!record||record.status!=='issued'||record.owner!==p.id||!stack||!validTokenItemType(stack.typeId,record.type)||stack.amount!==1||tokenId(stack)!==id){
   return p.sendMessage('§cInvalid, already used, or unissued generator token. Ask an operator for help.');
  }
  const g=GEN_BY_NAME.get(record.type);
  if(g&&!validGeneratorOutput(g))return p.sendMessage('§cGenerator block unavailable; token kept. Report '+g.block+' to an operator.');
  if(!g||stack.nameTag!==`§bSkyGen ${g.name} Generator`)return p.sendMessage('§cGenerator token identity mismatch.');
  const d=profile(p);
  if(d.rank<g.unlock||!belongs(p,p.location.x,p.location.z)||ownerId(d.plot)!==p.id||p.dimension?.id!=='minecraft:overworld')return p.sendMessage('§cGenerator requires its unlock rank and your own Overworld plot.');
  if(!generatorRegistryLoaded||generators.size>=GEN_REGISTRY_LIMIT)return p.sendMessage('§cGenerator registry unavailable or full. Token retained.');
  if(generatorOwnerCount(p)>=generatorSlots(p))return p.sendMessage('§cGenerator slot limit reached.');
  if(g.name==='Ancient Debris'&&[...generators.values()].some(x=>x.owner===p.id&&x.type===g.name))return p.sendMessage('§cOnly one Ancient Debris generator per player.');
  const hit=p.getBlockFromViewDirection({maxDistance:6,includeLiquidBlocks:false,includePassableBlocks:false});
  if(!hit?.block)return p.sendMessage('§cLook directly at a block inside your plot.');
  const target=hit.block.location,loc={x:target.x,y:target.y+1,z:target.z};
  if(plotAt(loc.x,loc.z)!==d.plot||loc.y<1||loc.y>300)return p.sendMessage('§cInvalid generator placement location.');
  const key=`${loc.x},${loc.y},${loc.z}`;
  if(generators.has(key))return p.sendMessage('§cGenerator already registered at that location.');
  const dim=world.getDimension('overworld'),base=dim.getBlock(loc),out=dim.getBlock({x:loc.x,y:loc.y+1,z:loc.z});
  if(!base||!out||!base.isAir||!out.isAir)return p.sendMessage('§cTwo free spaces required; existing blocks are never replaced. Token retained.');
  const baseWasAir=base.isAir;
  // Reserve first, then debit the exact event slot before granting anything.
  tokenWrite(id,{...record,status:'redeeming'});
  try{
   const current=inv.getItem(selected);
   if(!current||current.amount!==1||tokenId(current)!==id)throw Error('Token changed before debit');
   inv.setItem(selected,undefined);
   if(inv.getItem(selected))throw Error('Token debit could not be verified');
  }catch(e){
   // The slot may be uncertain. Quarantine the token instead of allowing reuse.
   try{tokenWrite(id,{...record,status:'review',reason:'Debit uncertain'})}catch{}
   return p.sendMessage('§cToken debit uncertain. Operator review required #'+id);
  }
  const gen={...loc,owner:p.id,type:g.name,period:g.period,block:g.block,last:system.currentTick,elapsed:0};
  let committed=false;
  try{
   if(!buildGenerator(gen))throw Error('Generator placement blocked');
   generators.set(key,gen);
   if(!genSave())throw Error('Generator storage commit failed');
   committed=true;
  }catch(err){
   generators.delete(key);generatorOutputReady.delete(key);
   rollbackGeneratorBlocks(dim,loc,g,baseWasAir);
   // Do not refund if the registry commit might have reached disk despite a failed verification.
   // Hold the original token in a review ledger for manual reconciliation.
   try{tokenWrite(id,{...record,status:'review',reason:'Generator commit/rollback uncertain: '+String(err).slice(0,70)})}catch{}
   completedGeneratorEvents.set(p.id+':'+id,system.currentTick+10);
   genError('Generator redemption requires review #'+id+' '+err,'redemption');
   return p.sendMessage('§cGenerator placement failed. Token #'+id+' held for operator recovery; no automatic duplicate item.');
  }
  if(committed){
   generatorOutputReady.add(key);
   completedGeneratorEvents.set(p.id+':'+id,system.currentTick+10);
   try{tokenWrite(id,{...record,status:'spent'})}catch(err){genError('Token spent marker unavailable #'+id+' '+err,'token')}
   try{const pd=profile(p);recordDaily(p,pd,['placements'],1,g.name);save(p,pd)}catch(err){console.warn('[SkyGen DAILY] generator placement '+err)}
   p.sendMessage(`§aPlaced ${g.name} custom-core generator at ${loc.x},${loc.y},${loc.z}.`);
  }
 }catch(err){
  genError('CRITICAL generator token redemption #'+id+' '+err,'redemption');
  p?.sendMessage?.('§cGenerator redemption failed safely; operator review #'+id);
 }
}
// Namespaced component shared by 42 distinct non-stackable custom items.
// Handler registration occurs in Bedrock's early startup event, not on a join.
// Both controller 'use in air' and 'use on block' enter the same secured path.
const customTokenUsePending=new Set();
function queueCustomGeneratorUse(event){
 const p=event.source,item=event.itemStack;
 if(!p||!item||!GENERATOR_ITEM_TYPE_IDS.has(item.typeId))return;
 const id=tokenId(item),slot=p.selectedSlotIndex;
 const dedupe=p.id+':'+slot+':'+id;
 if(customTokenUsePending.has(dedupe))return;
 customTokenUsePending.add(dedupe);
 system.run(()=>{
  try{placeGeneratorToken(p,slot,id)}
  finally{customTokenUsePending.delete(dedupe)}
 });
}
try {
 if(!system.beforeEvents?.startup?.subscribe)throw Error('Script API startup registry unavailable');
 system.beforeEvents.startup.subscribe(ev=>{
  try{
   ev.itemComponentRegistry.registerCustomComponent('skygen:generator_token_use',{
    onUse:queueCustomGeneratorUse,
    onUseOn:queueCustomGeneratorUse
   });
   generatorTokenCustomReady=true;
  }catch(err){generatorTokenCustomReady=false;console.warn('[SkyGen] CRITICAL custom generator item registration failed '+err)}
 });
}catch(err){console.warn('[SkyGen] CRITICAL custom item startup unavailable '+err)}
// Keep the v0.9.2 horn event subscribed so outstanding valid horns still redeem.
let generatorTokenUseGuardReady=false;
try{
 if(!world.beforeEvents.itemUse?.subscribe)throw Error('beforeEvents.itemUse is unavailable');
 world.beforeEvents.itemUse.subscribe(e=>{
  const i=e.itemStack;
  // Block legacy name-only eggs but never accept them as authenticated tokens.
  if(i?.typeId==='minecraft:egg'&&i.nameTag?.startsWith('§bSkyGen ')){
   e.cancel=true;
   system.run(()=>e.source?.sendMessage?.('§cOld generator egg cannot be verified. Ask an operator to inspect and replace it.'));
   return;
  }
  // Controller compatibility fallback: if Bedrock emits a normal use event
  // for a custom item, cancel vanilla behavior and use the same deduplicated path.
  if(i&&GENERATOR_ITEM_TYPE_IDS.has(i.typeId)){
   e.cancel=true;
   queueCustomGeneratorUse({source:e.source,itemStack:i});
   return;
  }
  if(i?.typeId!==GENERATOR_TOKEN_ITEM||(!i.nameTag?.startsWith('§bSkyGen ')&&!tokenId(i)))return;
  e.cancel=true; // Stop vanilla horn use; the token is consumed only after validation.
  const player=e.source,selected=player?.selectedSlotIndex,id=tokenId(i);
  queueCustomGeneratorUse({source:player,itemStack:i});
 });
 generatorTokenUseGuardReady=true;
}catch(err){console.warn('[SkyGen] CRITICAL generator token use guard unavailable; redemption disabled '+err)}
try{
 if(!world.beforeEvents.explosion?.subscribe)throw Error('explosion guard unavailable');
 world.beforeEvents.explosion.subscribe(e=>{
  try{
   if(e.dimension?.id!=='minecraft:overworld')return;
   const blocks=e.getImpactedBlocks();
   const allowed=blocks.filter(b=>{const loc=b.location;return !inSpawn(loc.x,loc.z)&&plotAt(loc.x,loc.z)<0&&!boundSaleChestOwner(loc)});
   if(allowed.length!==blocks.length)e.setImpactedBlocks(allowed);
  }catch(err){e.cancel=true;console.warn('[SkyGen] explosion filter failed closed '+err)}
 });
}catch(err){console.warn('[SkyGen] CRITICAL: explosion guard not installed '+err)}
// Stable pre-action security controls: cancel interacting with entities
// inside protected land, and cancel unauthorized damage including projectiles.
try{
 world.beforeEvents.playerInteractWithEntity?.subscribe(e=>{
  if(!e.player||!e.target||e.target.dimension?.id!=='minecraft:overworld')return;
  const loc=e.target.location;
  if(protectedAt(e.player,Math.floor(loc.x),Math.floor(loc.z),false))e.cancel=true;
 });
}catch(err){console.warn('[SkyGen SECURITY] Entity interaction guard unavailable '+err)}
// Raid Night: Bedrock @minecraft/server 2.9+ supports world.gameRules.pvp and
// cancellable world.beforeEvents.entityHurt (added in stable 2.6.0).
// Server-side pvp controls indirect player attacks too, including arrows.
// Citadel sanctuary is a separate per-damage cancellation, 24 hours a day.
let raidNightActive=null;
let raidAnnouncementUntil=0;
let raidSecurityErrorTick=-100000;
let raidDamageGuardActive=false;
function raidStatusCommand(p){
 if(!isOperator(p))return p.sendMessage('§cRealm operator only.');
 try{p.sendMessage('§bSKYGEN RAID STATUS v0.10.25 | Clock: '+world.getTimeOfDay()+' | Night: '+isRaidNight()+' | PvP: '+world.gameRules.pvp+' | Center guard: '+raidDamageGuardActive+' | Public mine: '+PUBLIC_STARTER_GENERATORS.length+' positions');}
 catch(err){p.sendMessage('§cRaid diagnostics failed: '+err)}
}
function isRaidNight(){const t=world.getTimeOfDay();return t>=13000&&t<23000}
function raidNightHeartbeat(){
 try{
  const active=raidDamageGuardActive&&isRaidNight();
  // Fail closed: preserve PvP OFF if the center-island damage guard failed to register.
  if(world.gameRules.pvp!==active)world.gameRules.pvp=active;
  if(world.gameRules.pvp!==active)throw Error('PvP gamerule verification failed');
  if(active!==raidNightActive){
   raidNightActive=active;
   raidAnnouncementUntil=system.currentTick+160;
   for(const p of world.getAllPlayers()){
    p.onScreenDisplay.setTitle(active?'§4§lRAID NIGHT':'§a§lDAYTIME SAFE', {fadeInDuration:10,stayDuration:90,fadeOutDuration:30,subtitle:active?'§cPvP ON outside central island':'§aPvP OFF across the Realm'});
    p.sendMessage(active?'§4RAID NIGHT §7— PvP is ON; the center island remains safe.':'§aDAYTIME §7— PvP is OFF across the Realm.');
   }
  }
 }catch(err){
  if(system.currentTick-raidSecurityErrorTick>=1200){console.warn('[SkyGen RAID] CRITICAL gamerule enforcement failed: '+err);raidSecurityErrorTick=system.currentTick}
 }
 system.runTimeout(raidNightHeartbeat,10);
}
system.runTimeout(raidNightHeartbeat,1);
try{
 const signal=world.beforeEvents.entityHurt;
 if(!signal?.subscribe)throw Error('Damage pre-event unavailable. Target @minecraft/server 2.9.0 or later.');
 signal.subscribe(e=>{
  const victim=e.hurtEntity;
  if(!victim||victim.dimension?.id!=='minecraft:overworld')return;
  const loc=victim.location;
  if(!loc)return;
  if(victim.typeId==='minecraft:player'){
   if(isCentralIslandSanctuary(loc.x,loc.z))e.cancel=true;
   return;
  }
  // Environmental blast damage must not kill protected plot livestock.
  // Players still take normal explosion damage; Raid Night PvP policy remains.
  const source=e.damageSource;
  const protectedLivestock=victim.matches({families:['animal']})||victim.matches({families:['villager']})||victim.matches({families:['golem']});
  const blast=String(source?.cause||'').toLowerCase().includes('explosion');
  if(blast&&protectedLivestock&&(plotAt(loc.x,loc.z)>=0||inSpawn(loc.x,loc.z))){e.cancel=true;return}
  // Only player-originated attacks against protected passive livestock.
  // Hostile mobs, ordinary natural damage, and owner-operated farms are unchanged.
  const attacker=source?.damagingEntity?.typeId==='minecraft:player'?source.damagingEntity:
   source?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
  if(attacker?.typeId!=='minecraft:player')return;
  const passive=victim.matches({families:['animal']})||victim.matches({families:['villager']})||victim.matches({families:['golem']});
  if(!passive)return;
  const id=plotAt(loc.x,loc.z);
  if(id>=0 && ownerId(id)!==attacker.id){e.cancel=true;return;}
  if(inSpawn(loc.x,loc.z)&&!isOperator(attacker))e.cancel=true;
 });
 raidDamageGuardActive=true;
}catch(err){console.warn('[SkyGen SECURITY] CRITICAL sanctuary damage guard unavailable: '+err)}
world.beforeEvents.playerBreakBlock.subscribe(e=>{
 const {x,y,z}=e.block.location;
 if(e.player.dimension?.id==='minecraft:overworld'&&boundSaleChestOwner({x,y,z})){
  e.cancel=true;e.player.sendMessage('§cUnbind the empty Sell-All Chest through Pro Shop before breaking it.');return;
 }
 if(e.player.dimension?.id!=='minecraft:overworld')return;
 const publicGen=publicStarterAt(x,y,z);
 if(publicGen&&publicStarterEnabled()&&e.block.typeId===publicGen.block)return;
 const registered=generators.get(`${x},${y},${z}`);
 if(registered&&isGeneratorBase(registered,e.block)){
  e.cancel=true;
  return;
 }
 const id=plotAt(x,z);
 // The owner can edit the top layer, including replacements; generator cores are checked above.
 if(id>=0){const c=coords(id);if(Math.abs(x-c.x)<=8&&Math.abs(z-c.z)<=8&&y>=c.y-3&&y<=c.y-1){const ownerSurface=y===c.y-1&&ownerId(id)===e.player.id;if(!ownerSurface){e.cancel=true;return;}}}
 if(protectedAt(e.player,x,z))e.cancel=true;
});
try{
 // Available only in some (beta/newer) runtimes; do not rely on it in stable 2.0.0.
 world.beforeEvents.playerPlaceBlock?.subscribe(e=>{
  if(!e.player||!e.block)return;
  const {x,y,z}=e.block.location;
  if(protectedAt(e.player,x,z)){e.cancel=true;return}
  // Placement within one block of a bound sale chest must not attach a
  // new container or automate withdrawal. No after-the-fact item deletion.
  const placed=e.permutationToPlace?.type?.id||e.itemStack?.typeId||'';
  const unsafe=/^minecraft:(?:chest|trapped_chest|hopper|piston|sticky_piston|dropper|dispenser)$/;
  if(unsafe.test(placed)&&[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]
    .some(([dx,dy,dz])=>boundSaleChestOwner({x:x+dx,y:y+dy,z:z+dz}))){e.cancel=true}
 });
}catch(err){console.warn('[SkyGen] Optional pre-place guard not supported: '+err)}
try{
 // Stable 2.0 pre-interaction protects chests and most block placements.
 if(world.beforeEvents.playerInteractWithBlock?.subscribe){
  world.beforeEvents.playerInteractWithBlock.subscribe(e=>{
   if(!e.player||!e.block)return;
   const {x,y,z}=e.block.location;
   const chestOwner=boundSaleChestOwner({x,y,z});
   if(chestOwner&&chestOwner!==e.player.id){e.cancel=true;return;}
   if(/^minecraft:(?:hopper|chest|trapped_chest|piston|sticky_piston|dropper|dispenser)$/.test(e.itemStack?.typeId||'')&&
      [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]].some(([dx,dy,dz])=>boundSaleChestOwner({x:x+dx,y:y+dy,z:z+dz}))){e.cancel=true;return;}
   // At the four starter-kit spots, allow opening a shulker box with an empty hand.
   if(e.player.dimension?.id==='minecraft:overworld'&&!e.itemStack&&y===1&&Math.abs(x)===3&&Math.abs(z)===8&&
      /^minecraft:(?:(?:undyed|white|orange|magenta|light_blue|yellow|lime|pink|gray|light_gray|cyan|purple|blue|brown|green|red|black)_)?shulker_box$/.test(e.block.typeId))return;
   if(protectedAt(e.player,x,z)||[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dz])=>protectedAt(e.player,x+dx,z+dz)))e.cancel=true;
  });
  interactionGuardAvailable=true;
 }else console.warn('[SkyGen] CRITICAL: block interaction protection unavailable; plot visiting disabled.');
}catch(e){interactionGuardAvailable=false;console.warn('[SkyGen] CRITICAL: interaction guard failed: '+e)}
try{
 // Defense in depth for placement actions not routed through interaction.
 // Only removes the newly placed unauthorized block; use a world copy to test boundary cases.
 world.afterEvents.playerPlaceBlock?.subscribe(e=>{
  if(e.block){const loc=e.block.location;generatorOutputReady.delete(`${loc.x},${loc.y-1},${loc.z}`)}
  if(!e.player||!e.block)return;
  const {x,z}=e.block.location;
  if(protectedAt(e.player,x,z)){
   try{e.block.setType('minecraft:air');e.player.sendMessage('§cCannot build in this protected area.')}catch(err){console.warn('[SkyGen] unauthorized placed block could not be reverted: '+err)}
   return;
  }
  if(belongs(e.player,x,z))recordQuestActivity(e.player,'build',e.block.typeId);
 });
}catch(e){console.warn('[SkyGen] post-placement repair unavailable: '+e)}
world.afterEvents.entityDie.subscribe(({deadEntity,damageSource})=>{
 try{
  const player=damageSource.damagingEntity;
  if(player?.typeId==='minecraft:player'&&deadEntity.matches({families:['monster']}))recordQuestActivity(player,'kills',deadEntity.typeId);
 }catch(e){console.warn('[SkyGen QUEST] combat: '+e)}
});
const normalXpGate=new Map(),normalXpWindow=new Map();
world.afterEvents.playerBreakBlock.subscribe(e=>{
 try{
  const p=e.player,loc=e.block.location;
  const publicGen=publicStarterAt(loc.x,loc.y,loc.z);
  if(publicGen&&p.dimension?.id==='minecraft:overworld'&&publicStarterEnabled()){
   const mined=e.brokenBlockPermutation?.type?.id||e.brokenBlockPermutation?.typeId||'';
   if(mined!==''&&mined!==publicGen.block)return;
   publicStarterDue.set(`${loc.x},${loc.y},${loc.z}`,system.currentTick+publicGeneratorDelay(publicGen));
   if(publicGeneratorLevel(publicGen.block)>=GENERATOR_MAX_LEVEL)system.runTimeout(()=>refillPublicInstant(publicGen),1);
   const d=profile(p);recordDaily(p,d,['blocks','public'],1,publicGen.block);d.xp+=1;rank(p,d);return;
  }
  if(!belongs(p,loc.x,loc.z))return;
  const d=profile(p);
  const key=`${loc.x},${loc.y-1},${loc.z}`,g=generators.get(key);
  const type=e.brokenBlockPermutation?.type?.id||e.brokenBlockPermutation?.typeId||'';
  const mature=['minecraft:wheat','minecraft:carrots','minecraft:potatoes','minecraft:beetroot'].includes(type)&&e.brokenBlockPermutation.getState('growth')===7;
  recordDaily(p,d,mature?['blocks','crops']:['blocks'],1,type);
  const validHarvest=!!g&&g.owner===p.id&&(loc.y===g.y+1)&&(type===(GEN_BY_NAME.get(g.type)?.block||g.block));
  if(validHarvest){
   genEmptySeconds.set(key,system.currentTick);
   if(Number(g.level||1)>=GENERATOR_MAX_LEVEL)system.runTimeout(()=>refillPrivateInstant(key,g),1);
  }
  if(validHarvest&&generatorOutputReady.delete(key)){
   const bonus=perkValue(d,'miningXp');d.xp+=Math.ceil(5*(100+bonus)/100);
   recordDaily(p,d,['harvests'],1,type);
   const lucky=perkValue(d,'luck');
   if(lucky>0&&Math.random()*100<lucky){
    const prize=new ItemStack(g.block,1);
    if(inventoryCapacity(p,prize)){try{inventory(p)?.addItem(prize);p.sendMessage('§aLucky Strikes! +1 bonus block.')}catch{}}
   }
  }else{
   const last=normalXpGate.get(p.id)??-99999;
   const window=normalXpWindow.get(p.id);
   const current=(!window||system.currentTick-window.start>=1200)?{start:system.currentTick,count:0}:window;
   if(system.currentTick-last>=5&&current.count<10){d.xp+=1;current.count++;normalXpGate.set(p.id,system.currentTick)}
   normalXpWindow.set(p.id,current);
  }
  rank(p,d);
 }catch(err){console.warn('[SkyGen XP] could not record block break: '+err)}
});
function refillPrivateInstant(key,record){
 try{
  if(generators.get(key)!==record||!generatorRegistryLoaded||Number(record.level||1)<GENERATOR_MAX_LEVEL)return;
  const dim=world.getDimension('overworld');
  const base=dim.getBlock({x:record.x,y:record.y,z:record.z});
  const output=dim.getBlock({x:record.x,y:record.y+1,z:record.z});
  if(!base||!output||!isGeneratorBase(record,base)||!output.isAir)return;
  const expected=GEN_BY_NAME.get(record.type)?.block||record.block;
  if(!expected)return;
  output.setType(expected);
  if(output.typeId!==expected)throw Error('Private instant refill verification failed');
  generatorOutputReady.add(key);
  genEmptySeconds.delete(key);
 }catch(err){genError('Level 10 refill '+key+' '+err,key)}
}
// Self-rescheduling generator watchdog. A generator's empty state is tracked in
// memory and is reset when an output block is present. No stale saved ticks.
let genRotation=0;
function genWatchdog(){
 genWatchdogRuns++;genLastTick=system.currentTick;
 try{
  const dim=world.getDimension('overworld'),records=[...generators.entries()];
  if(!records.length)return;
  const heartbeat={players:new Map(world.getAllPlayers().map(player=>[player.id,player])),speedBonuses:new Map()};
  // Never perform 1200 block reads every second. Process at most 100 generators
  // per heartbeat with absolute tick-based regeneration timing.
  const count=Math.min(100,records.length);
  for(let n=0;n<count;n++){
   const [key,g]=records[(genRotation+n)%records.length];
   try{
    const base=dim.getBlock({x:g.x,y:g.y,z:g.z}),output=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
    if(!base||!output||!migrateGeneratorCore(g,base)){genEmptySeconds.delete(key);continue}
    const spec=GEN_BY_NAME.get(g.type),expected=spec?.block||g.block;
    if(!expected){genEmptySeconds.delete(key);continue}
    if(output.typeId!=='minecraft:air'){genEmptySeconds.delete(key);continue}
    const detected=genEmptySeconds.get(key);
    if(!Number.isFinite(detected)){genEmptySeconds.set(key,system.currentTick);continue}
    if(system.currentTick-detected>=effectivePeriod(g,heartbeat)){
     output.setType(expected);generatorOutputReady.add(key);genEmptySeconds.delete(key);
    }
   }catch(err){genError(key+' '+err,key)}
  }
  genRotation=(genRotation+count)%records.length;
 }catch(err){genError('watchdog '+err)}
}

try{
 world.afterEvents.playerLeave?.subscribe(e=>{
  const id=e.playerId||e.player?.id;
  personalSpawnBuild.delete(id);forcefieldTickets.delete(id);forcefieldPrevious.delete(id);forcefieldNotices.delete(id);playerCommandLastTick.delete(id);rankNativeUnsupported.delete(id);loginPending.delete(id);lastSafeWriteTick.delete(id);returnCheckpointHold.delete(id);
  const t=pending.get(id);pending.delete(id);finishPendingTeleport(t);
  const s=spawnStages.get(id);s?.release?.();
  // Return staging cleans up during its next scheduled tick; never delete
  // another player's temporary ticking area on this leave event.
  for(const [plot,session] of plotBuilds){if(session.playerId===id){try{session.cancel?.()}catch(err){console.warn('[SkyGen] plot cleanup on leave '+err)}}}
  const trade=trades.get(id);if(trade)tradeClose(trade,'Trade cancelled: player disconnected.');
  normalXpGate.delete(id);normalXpWindow.delete(id);skillLastEffects.delete(id);skillActiveEffects.delete(id);for(const key of skillCooldowns.keys())if(key.startsWith(id+':'))skillCooldowns.delete(key);
 });
}catch(e){console.warn('[SkyGen] leave cleanup unavailable '+e)}
system.runInterval(()=>{
 for(const p of world.getAllPlayers()){
  ensure(p);
  try{updateExplorationQuest(p,profile(p))}
  catch(e){console.warn('[SkyGen QUEST] Exploration '+p.name+': '+e)}
 }
},200);
// Chat help uses the same pages as the Compass, with operator checks at the entry point.
function helpCommand(actor,message){
 const topic=String(message||'').trim().toLowerCase(),operator=isOperator(actor);
 const send=page=>{
  actor.sendMessage('§b§lSKYGEN HELP §r· '+page.title);
  for(const line of helpLines(page))actor.sendMessage('§7'+line);
 };
 const commandPages=HELP_TOPICS.find(section=>section.title==='Commands').pages;
 const operatorPages=HELP_TOPICS.find(section=>section.operator).pages;
 if(!topic||topic==='player'||topic==='all'){
  for(const page of commandPages)send(page);
  if(topic==='all'&&operator)for(const page of operatorPages)send(page);
  return;
 }
 if(topic==='admin'||topic==='security'){
  if(!operator)return actor.sendMessage('§cOperator permission required for this help page.');
  for(const page of operatorPages)send(page);
  return;
 }
 const page=HELP_TOPICS.filter(section=>!section.operator).flatMap(section=>section.pages).find(page=>page.id===topic);
 if(page){send(page);return;}
 actor.sendMessage('§eUnknown help topic: '+topic.slice(0,30));
 actor.sendMessage('§7Try /scriptevent skygen:help player for chat topics, or open Compass → Help & Commands.');
}
function adminCommand(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOnly Realm operators may grant or revoke SkyGen admin access.');
 const match=/^\s*(grant|revoke)\s+(.+?)\s*$/i.exec(String(message||''));
 if(!match)return actor.sendMessage('§eUsage: /scriptevent skygen:admin grant PlayerName  OR  /scriptevent skygen:admin revoke PlayerName');
 const action=match[1].toLowerCase(),name=match[2];
 const matches=world.getAllPlayers().filter(p=>p.name.toLowerCase()===name.toLowerCase());
 if(matches.length!==1)return actor.sendMessage('§cPlayer must be online. Check the exact name: '+name);
 const target=matches[0];
 const grant=action==='grant';
 try{world.setDynamicProperty('sg_admin_'+target.id,grant)}catch(err){return actor.sendMessage('§cUnable to save admin permission: '+err)}
 adminAudit(actor,grant?'GRANT ADMIN':'REVOKE ADMIN',target,'via command');
 actor.sendMessage('§aSkyGen admin '+(grant?'granted to ':'revoked from ')+target.name+'.');
 target.sendMessage(grant?'§aYou now have SkyGen Admin access.':'§cYour SkyGen Admin access was revoked.');
 if(grant)system.runTimeout(()=>issueAdminAxe(target),30);
}

system.runTimeout(()=>bootFixedSpawn(),1);
console.warn('[SkyGen] v0.10.12 fresh-city security interlock + v0.10.9 menu continuity, v0.10.8 infinite plot passives and v0.10.7 spawn horn repair with v0.10.6 persistent safe rejoin and chunk staging; rank badges and v0.10.4 security audit hardening with operator spawn location, Xbox UI fit, 42 generators, food shop and boundary forcefields loaded');


// ---- SkyGen v0.10.26: safe personal HUD + Monkey's Floating Text ----
// The legacy Personal Sidebar RP previously replaced hud_title_text globally,
// making personal stats cover the screen and hijacking normal Raid Night titles.
// Personal stats use an [SGHUD] title-keyword bridge to the right-side JSON UI panel.
// Other titles and combat systems remain untouched.
function sidebarEnabled(p){
 try{return p.getDynamicProperty('sg_sidebar_enabled')!==false}catch{return true}
}
function sidebarMenu(p){
 form(p,'§bPERSONAL SIDEBAR',
  '§7Shows your personal SkyGen stats on the right side of the screen.\n§7Raid Night and teleport titles stay in the center.\n§7Current status: '+(sidebarEnabled(p)?'§aEnabled':'§cDisabled'),
  ['Enable Sidebar','Disable Sidebar','Back to Profile'],i=>{
   if(i===2)return skyMenuProfileCosmetics(p);
   try{
    p.setDynamicProperty('sg_sidebar_enabled',i===0);
    if(i===1)p.onScreenDisplay.setTitle('[SGHUD]',{fadeInDuration:0,stayDuration:5,fadeOutDuration:0,subtitle:''});
    p.sendMessage(i===0?'§aPersonal sidebar enabled.':'§ePersonal sidebar disabled.');
   }catch(err){p.sendMessage('§cSidebar setting failed: '+err)}
   menuAgain(p,()=>sidebarMenu(p));
  });
}
function giveFloatingTextTool(p){
 if(!isOperator(p))return p.sendMessage('§cOnly Realm operators can create or edit floating texts/leaderboards.');
 try{
  const inv=inventory(p);
  if(!inv)throw Error('Inventory unavailable');
  for(let i=0;i<inv.size;i++){
   if(inv.getItem(i)?.typeId==='monkey:textmenu'){
    p.sendMessage('§aYour Floating Text Menu is already in your inventory. Use the item to open it.');
    return;
   }
  }
  const item=new ItemStack('monkey:textmenu',1);
  const leftover=inv.addItem(item);
  if(leftover)return p.sendMessage('§cInventory full; free one slot and try again.');
  p.sendMessage('§aFloating Text Menu added. Use the book for text signs and floating scoreboards.');
 }catch(err){p.sendMessage('§cCould not deliver floating text tool: '+err)}
}
// The [SGHUD] title marker is saved by the right-side JSON UI property bag.
// Actionbar messages keep their vanilla position; ordinary title messages
// (Raid Night, teleport countdown) are not re-positioned by the sidebar.
export function readSidebarStats(p){return sidebarStats(profile(p));}
function updatePersonalSidebar(p){
  try{
   // Reuse one authoritative profile snapshot for numeric scores, text and
   // entitlement markers. The previous implementation parsed sg_profile twice
   // per player every HUD refresh. Do not cache this between refresh cycles:
   // credits, quest rewards, rank and badge equips must update immediately.
   const currentProfile=profile(p);
   const stats=sidebarStats(currentProfile);
   try{updateNumericScores(p,stats)}catch(err){console.warn('[SkyGen STATS] '+p.name+': '+err)}
   if(!sidebarEnabled(p)||pending.has(p.id)||system.currentTick<raidAnnouncementUntil)return;
   const text='[SGHUD]'+sidebarLines(stats,true).join('\n')+equippedBadgeMarkers(currentProfile)+hudProgressMarkers(currentProfile.rank,currentProfile.xpProgress);
   // [SGHUD] is consumed by the existing independent right-side RP panel.
   // Other game titles retain their normal on-screen placement.
   p.onScreenDisplay.setTitle(text,{fadeInDuration:0,stayDuration:10,fadeOutDuration:0,subtitle:''});
  }catch(err){console.warn('[SkyGen SIDEBAR] '+err)}
}
system.runInterval(()=>{
  try{for(const p of world.getAllPlayers())updatePersonalSidebar(p)}
  catch(err){console.warn('[SkyGen SIDEBAR] update failed: '+err)}
},40);
// ---- End extension ----
