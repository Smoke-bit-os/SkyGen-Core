// v0.10.52 — Owner-approved monetary schedule, source level only.
// Call sites must still enforce credit/bank wallet limits, durable settlement,
// per-period claim limits, and a fresh authorization check.
// Does not itself mutate balances or pay a quest.
import {transitionCost, MAX_RANK} from './rank_progression.js';
import {percentageQuestXP} from './quest_expansion.js';
export const CREDIT_BANDS=Object.freeze([
 Object.freeze({start:51,end:100,easy:250000,normal:750000,hard:2000000,elite:6000000}),
 Object.freeze({start:101,end:249,easy:500000,normal:1500000,hard:3000000,elite:7500000}),
 Object.freeze({start:250,end:499,easy:1000000,normal:2500000,hard:5000000,elite:10000000}),
 Object.freeze({start:500,end:749,easy:1500000,normal:3500000,hard:7000000,elite:12000000}),
 Object.freeze({start:750,end:1000,easy:2000000,normal:5000000,hard:10000000,elite:15000000})
]);
export const WEEKLY_ORBIT_BANDS=Object.freeze([
 Object.freeze({start:101,end:249,perQuest:Object.freeze([1,1,1])}),
 Object.freeze({start:250,end:499,perQuest:Object.freeze([1,1,2])}),
 Object.freeze({start:500,end:749,perQuest:Object.freeze([1,2,2])}),
 Object.freeze({start:750,end:999,perQuest:Object.freeze([2,2,3])}),
 Object.freeze({start:1000,end:1000,perQuest:Object.freeze([2,3,3])})
]);
const VALID_DIFFICULTIES=Object.freeze(['easy','normal','hard','elite']);
function assertRank(rank){if(!Number.isSafeInteger(rank)||rank<1||rank>MAX_RANK)throw Error('Invalid locked rank')}
export function approvedQuestCredits(lockedRank,difficulty){
 assertRank(lockedRank);
 if(!VALID_DIFFICULTIES.includes(difficulty))throw Error('Invalid quest difficulty');
 if(lockedRank<51)throw Error('Legacy Rank 1–50 quest rewards remain unchanged');
 const band=CREDIT_BANDS.find(b=>lockedRank>=b.start&&lockedRank<=b.end);
 if(!band)throw Error('Credit band missing');
 return band[difficulty];
}
export function approvedWeeklyOrbits(lockedRank,weeklySlot){
 assertRank(lockedRank);
 if(!Number.isInteger(weeklySlot)||weeklySlot<0||weeklySlot>=3)throw Error('Weekly reward slot out of bounds');
 if(lockedRank<101)throw Error('Weekly Orbit rewards unlock at Rank 101');
 const band=WEEKLY_ORBIT_BANDS.find(b=>lockedRank>=b.start&&lockedRank<=b.end);
 if(!band)throw Error('Weekly Orbit band missing');
 return band.perQuest[weeklySlot];
}
export function approvedContractQuote(quest,lockedRank,kind,slot=null){
 assertRank(lockedRank);
 if(!quest||!Number.isSafeInteger(quest.id)||quest.id<500||quest.id>=1000||!VALID_DIFFICULTIES.includes(quest.difficulty)||quest.rank>lockedRank)throw Error('Invalid/locked contract');
 if(kind!=='daily'&&kind!=='weekly')throw Error('Invalid contract type');
 if(kind==='daily'&&quest.difficulty==='elite')throw Error('Elite contracts are reserved for weekly quests');
 if(kind==='weekly'&&quest.difficulty!=='elite')throw Error('Weekly contract must be Elite');
 const credits=approvedQuestCredits(lockedRank,quest.difficulty);
 const orbits=kind==='weekly'?approvedWeeklyOrbits(lockedRank,slot):0;
 const xp=lockedRank===MAX_RANK?'0':percentageQuestXP(transitionCost(lockedRank),quest.difficulty);
 return Object.freeze({questId:quest.id,lockedRank,kind,weeklySlot:kind==='weekly'?slot:null,credits,orbits,xp,previewOnly:true});
}
