// SkyGen Core Phase 2: Xbox-compatible Sky Realm presentation adapter.
// Only wraps public @minecraft/server-ui form methods. No player data or
// transaction state is stored or modified here.
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

const ICON_ROOT = 'textures/ui/skyrealm/';
const ICON_PATTERNS = [
  [/boundary|forcefield|bypass|protected/i,'boundary'],
  [/operator|admin|permission|grant|revoke/i,'admin'],
  [/trusted|trust|builder|build rights/i,'trusted'],
  [/visitor|visit|guest|incoming|access request/i,'visitor'],
  [/expan|upgrade plot|estate|81\s*[x×]\s*81|113\s*[x×]\s*113/i,'expand'],
  [/my plot|go to plot|plot #|plot tier|plot settings|plot information/i,'plot'],
  [/spawn|teleport|portal|travel|home/i,'portal'],
  [/generator|forge|production|output|diagnos|starter|nature|endgame|mining/i,'generator'],
  [/food|apple|bread|chicken|steak|pork|salmon|cod|carrot|potato|mutton|cookie/i,'food'],
  [/server shop|buy item|sell item|buy quantity|sell quantity|shopping/i,'shop'],
  [/market|listing|commodity|browse/i,'market'],
  [/trading|trade|offer|exchange with/i,'trade'],
  [/rank|progress|xp\b/i,'rank'],
  [/wallet|credit|orbit|exchange|balance|price/i,'wallet'],
  [/skill|ability|unlock|learn/i,'skill'],
  [/quest|daily|claim|reward/i,'quest'],
  [/help|command|guide|how to/i,'help'],
  [/give item|item grant|delivery/i,'gift'],
  [/setting|configuration|system/i,'settings'],
  [/previous|back|cancel|return|decline|deny|keep/i,'back'],
  [/next page|continue/i,'next'],
  [/confirm|accept|purchase|buy|sell|activate|allow|add player/i,'confirm'],
  [/remove|delete|clear/i,'delete'],
];

export function skyIcon(label) {
  const t=String(label).replace(/§[0-9a-fk-or]/gi,'');
  for (const [re,name] of ICON_PATTERNS) if (re.test(t)) return ICON_ROOT+name;
  if (/minecraft:[a-z0-9_]+|\s*[×x]\s*\d+|\bLv\d+\b/i.test(t)) return ICON_ROOT+'item';
  return ICON_ROOT+'menu';
}
function clean(s){return String(s).replace(/§[0-9a-fk-or]/gi,'').trim()}
function title(s){
  // Short titles avoid clipping with the Xbox controller UI scale.
  const raw=clean(s).replace(/^SKYGEN CORE\b/i,'Main Menu');
  return '§5§lSKY REALM§r §8| §6'+raw.slice(0,40);
}
function body(s){
  return '§5◆ §6SkyGen Core §8• §7Minecraft Realm\n§8--------------------------§r\n'+String(s||'');
}
function label(s){
  const str=String(s),plain=clean(str);
  if (/^(?:back|cancel|close|previous page|deny|decline)$/i.test(plain)) return '§8< §7'+str;
  if (/^(?:delete|remove all|revoke all|remove|clear)$/i.test(plain))return '§c'+str;
  if (/^(?:confirm|buy|purchase|upgrade|accept|allow)$/i.test(plain))return '§a'+str;
  return str;
}
export function skyAction(){
  const form=new ActionFormData();
  let buttons=0, exitIndex;
  const ui={
    title(s){form.title(title(s));return ui},
    body(s){form.body(body(s));return ui},
    button(s,path){form.button(label(s),path||skyIcon(s));buttons++;return ui},
    show(p){
      if(exitIndex===undefined){exitIndex=buttons;form.button('§cExit',skyIcon('Back'));}
      return form.show(p).then(r=>!r.canceled&&r.selection===exitIndex?{canceled:true}:r);
    }
  };
  return ui;
}
export function skyMessage(){
  // An action form keeps Back, Confirm and Exit separate on controller.
  const form=skyAction();
  const buttons=[];
  let built=false;
  const ui={
    title(s){form.title(s);return ui},
    body(s){form.body(s);return ui},
    button1(s){buttons[0]=s;return ui},
    button2(s){buttons[1]=s;return ui},
    show(p){
      if(!built){form.button(buttons[0]);form.button(buttons[1]);built=true;}
      return form.show(p);
    }
  };
  return ui;
}
export function skyModal(){
  const form=new ModalFormData();
  let built=false;
  const ui={
    title(s){form.title(title(s));return ui},
    textField(...args){form.textField(...args);return ui},
    show(p){
      if(!built){form.toggle('Exit without submitting',{defaultValue:false});built=true;}
      return form.show(p).then(r=>!r.canceled&&r.formValues?.at(-1)===true?{canceled:true}:r);
    }
  };
  return ui;
}
