// v0.10.52: weekly Elite contract SELECTION ONLY.
// No payouts, claims, or player-data writes are enabled until the owner approves
// the precise Credit/Orbit amounts and the transactional journal is integrated.
// Callers must persist the three selected quest IDs and locked rank once per week;
// they must never reselect them after progression or reconnection.
import { NEW_QUESTS } from './quest_expansion.js';

export const WEEKLY_UNLOCK_RANK = 101;
export const WEEKLY_ELITE_LIMIT = 3;

// Return a stable UTC Monday (YYYY-MM-DD), not a timezone-dependent local week.
export function utcWeekStart(value) {
  const date = value instanceof Date ? new Date(value.getTime()) : new Date(value);
  if (!Number.isFinite(date.getTime())) throw Error('Invalid weekly contract date');
  const start = new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate()));
  const day = (start.getUTCDay() + 6) % 7; // Monday -> 0
  start.setUTCDate(start.getUTCDate() - day);
  return start.toISOString().slice(0,10);
}

// Stable deterministic selection (not a security boundary). Exactly three
// eligible Elite contracts when rank>=101, or none before unlocking.
export function selectWeeklyElite(playerId, lockedRank, weekStart) {
  if (!Number.isInteger(lockedRank) || lockedRank < 1 || lockedRank > 1000)
    throw Error('Invalid locked rank');
  if (lockedRank < WEEKLY_UNLOCK_RANK) return [];
  if (typeof playerId !== 'string' || !playerId.trim()) throw Error('Invalid player ID');
  if (typeof weekStart !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(weekStart) ||
      utcWeekStart(weekStart+'T00:00:00Z') !== weekStart)
    throw Error('Week key must be a UTC Monday');
  const choices = NEW_QUESTS.filter(q => q.difficulty === 'elite' && q.rank <= lockedRank);
  if (choices.length < WEEKLY_ELITE_LIMIT) throw Error('Insufficient eligible weekly contracts');
  // FNV-1a order key; sorting is stable because quest ID breaks hash ties.
  const key = value => {
    let hash = 2166136261;
    for (let i=0;i<value.length;i++) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  };
  return choices.map(q=>({q,order:key(playerId+'|'+weekStart+'|'+q.id)}))
    .sort((a,b)=>a.order-b.order || a.q.id-b.q.id)
    .slice(0,WEEKLY_ELITE_LIMIT)
    .map(({q})=>Object.freeze({
      questId:q.id, assignedWeek:weekStart, lockedRank, difficulty:'elite',
      // NO pending numeric rewards can accidentally be paid via this preview.
      pendingEconomy:true
    }));
}
