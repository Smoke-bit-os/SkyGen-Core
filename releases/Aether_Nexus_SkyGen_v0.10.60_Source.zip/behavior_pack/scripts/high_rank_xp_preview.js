// v0.10.52: XP-only frozen PREVIEW for new contracts; no claim or save path.
// Monetary payouts and exact-once settlement remain release-gated.
import { transitionCost, advanceRank, parseProgress, MAX_RANK } from './rank_progression.js';
import { percentageQuestXP, NEW_QUESTS } from './quest_expansion.js';
const QUEST_ID_MAP=new Map(NEW_QUESTS.map(q=>[q.id,q]));
export function quoteAscendedXP(questId,rank,progress){
 const quest=QUEST_ID_MAP.get(questId);
 if(!quest)throw Error('Unknown Ascended quest ID');
 if(!Number.isSafeInteger(rank)||rank<quest.rank||rank>MAX_RANK)throw Error('Quest is locked for this rank');
 const oldProgress=parseProgress(progress).toString();
 if(rank===MAX_RANK)return Object.freeze({questId,lockedRank:rank,lockedProgress:oldProgress,xp:'0',afterRank:rank,afterProgress:oldProgress,previewOnly:true});
 const xp=percentageQuestXP(transitionCost(rank),quest.difficulty);
 const after=advanceRank(rank,oldProgress,xp);
 return Object.freeze({questId,lockedRank:rank,lockedProgress:oldProgress,xp,afterRank:after.rank,afterProgress:after.progress,previewOnly:true});
}
