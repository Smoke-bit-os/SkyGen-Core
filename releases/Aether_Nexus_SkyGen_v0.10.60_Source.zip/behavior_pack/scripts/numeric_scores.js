import {MAX_RANK,transitionCost,parseProgress,cumulativeXP,formattedXP} from './rank_progression.js';
import { world } from '@minecraft/server';
import { ASCENDED_RANK_NAMES } from './rank_titles.js';

// Keep the original objective IDs and rank order for existing holograms and saves.
export const RANK_NAMES=['Rookie','Miner','Builder','Explorer','Crafter','Prospector','Stoneworker','Harvester','Merchant','Apprentice','Scout','Forger','Excavator','Smith','Artisan','Engineer','Trader','Guardian','Specialist','Veteran','Challenger','Pathfinder','Master Miner','Architect','Gem Hunter','Industrialist','Champion','Commander','Warden','Elite','Baron','Overseer','Titan','Virtuoso','Conqueror','Vanguard','Oracle','Paragon','Sovereign','Legend','Ascendant','Celestial','Mythic','Immortal','Eternal','Overlord','Starborn','Cosmic','Infinity','SkyGen Master'];
export function rankLevel(value){
 const n=Number(value);
 return Number.isSafeInteger(n)?Math.min(MAX_RANK,Math.max(1,n)):1;
}
export function rankName(level){const n=rankLevel(level);return n<=50?RANK_NAMES[n-1]:ASCENDED_RANK_NAMES[n-51]}

export const SIDEBAR_PANEL = '';
export const SIDEBAR_OBJECTIVES = [
    ['credits', 'sg_stats_credits', 'SkyGen Credits'],
    ['orbits', 'sg_stats_orbits', 'SkyGen Orbits'],
    ['xp', 'sg_stats_xp', 'SkyGen XP (32-bit display limit)'],
    ['rank', 'sg_stats_rank', 'SkyGen Rank'],
    ['plot', 'sg_stats_plot', 'SkyGen Plot'],
    ['rankXp', 'sg_stats_rank_xp', 'SkyGen XP This Rank'],
    ['xpToNext', 'sg_stats_xp_next', 'SkyGen XP to Next Rank']
];

export function sidebarStats(profile) {
 const rank=rankLevel(profile.rank),p=parseProgress(profile.xpProgress??'0');
 const max=rank===MAX_RANK,cost=max?null:transitionCost(rank),toNext=max?0n:cost>p?cost-p:0n;
 const cap=value=>Number(value>2147483647n?2147483647n:value);
 return {credits:profile.credits,orbits:profile.orbits,xp:cap(cumulativeXP(rank,profile.xpProgress??'0')),rank,
 plot:profile.plot+1,rankXp:cap(p),xpToNext:cap(toNext),rankXpText:formattedXP(p),
 xpToNextText:max?'MAX RANK':formattedXP(toNext),costText:max?'MAX':formattedXP(cost)};
}

function short(value) {
    if (value >= 1e9) return (value / 1e9).toFixed(1) + 'B';
    if (value >= 1e6) return (value / 1e6).toFixed(1) + 'M';
    if (value >= 1e3) return (value / 1e3).toFixed(1) + 'K';
    return String(value);
}

export function sidebarLines(stats, compact = false) {
    const number = value => value.toLocaleString('en-US');
    const balance = compact ? short : number;
    const max = stats.rank === MAX_RANK;
    return [
        '§eCredits: §f' + balance(stats.credits),
        '§dOrbits: §f' + balance(stats.orbits),
        '§dRank: §f' + rankName(stats.rank),
        '§aXP: §f' + (max ? 'MAX' : stats.rankXpText + ' / '+stats.costText),
        '§6To Next: §f' + (max ? 'MAX RANK' : stats.xpToNextText + ' XP'),
        '§bPlot: §f' + (stats.plot > 0 ? '#' + stats.plot : '–')
    ];
}

function ensureObjective(id, name) {
    return world.scoreboard.getObjective(id) ?? world.scoreboard.addObjective(id, name);
}

export function ensureSidebarObjectives() {
    return SIDEBAR_OBJECTIVES.map(([key, id, name]) => [key, ensureObjective(id, name)]);
}

export function updateNumericScores(player, stats) {
    const failures = [];
    for (const [key, id, name] of SIDEBAR_OBJECTIVES) {
        try {
            const objective = ensureObjective(id, name);
            const val=Number(stats[key]);
            const score = Number.isFinite(val)?Math.max(-2147483648,Math.min(2147483647,Math.floor(val))):0;
            let current;
            try {
                if (objective.hasParticipant(player)) current = objective.getScore(player);
            } catch {
                // A score read can fail independently of the write. Try to publish the profile value.
            }
            if (current !== score) objective.setScore(player, score);
        } catch (err) {
            failures.push(id + ': ' + err);
        }
    }
    if (failures.length) throw Error(failures.join(' | '));
}
