import { GameMode, system, world } from '@minecraft/server';
import { SKYSPIRE } from './skyspire_layout.js';
import { formatSkyspireTime } from '../../skyspire_times.js';

const OVERWORLD = 'minecraft:overworld';
const DROP_BLOCK = 'minecraft:cracked_polished_blackstone_bricks';
const CYCLE = 100;
const WARNING_AT = 45;
const DROP_AT = 65;
const RESET_AT = 85;
const BELOW_COURSE = -8;
const MAX_MOVEMENT_PER_TICK = 8;
const TIMER_PULSE = 4;

const { entry, summit, dropFloors } = SKYSPIRE;
const summitCenter = { x: summit[0] + 1, y: summit[1] + 1, z: summit[2] + 1 };
const GROUND_HEIGHT = entry.y + 0.25;

function blockAt(dimension, x, y, z) {
  try { return dimension.getBlock({ x, y, z }); } catch { return undefined; }
}

function insideMat(x, z) {
  return x >= 69 && x < 71 && z >= 8 && z < 10;
}

function onEntryMat(player) {
  const { x, y, z } = player.location;
  return insideMat(x, z) && y >= entry.y && y < entry.y + 0.25 && player.isOnGround &&
    blockAt(player.dimension, Math.floor(x), entry.y, Math.floor(z))?.typeId === 'minecraft:purple_carpet';
}

function onSummit(player, location = player.location) {
  const [x, y, z] = summit;
  if (Math.abs(location.y - (y + 1)) >= 0.23 || Math.abs(location.x - (x + 1)) > 1.5 ||
      Math.abs(location.z - (z + 1)) > 1.5) return false;

  // Bedrock reports actual supporting blocks, including a tile under the player's edge.
  return player.getAllBlocksStandingOn().some(block => {
    const floor = block.location;
    return floor.y === y && floor.x >= x && floor.x < x + 2 && floor.z >= z && floor.z < z + 2 &&
      block.typeId === 'minecraft:gold_block';
  });
}

function eligible(player) {
  const mode = player.getGameMode();
  return mode === GameMode.Survival || mode === GameMode.Adventure;
}

function cycleAt(offset) {
  return (system.currentTick + offset) % CYCLE;
}

function withinTower({ x, y, z }) {
  return x >= 44 && x <= 90 && z >= -18 && z <= 19 && y <= 55;
}

export function createSkyspireTrial({ cityReady, onTime, onClear, returnToSpawn }) {
  const runs = new Map();
  const dropped = new Set();
  let onMat = new Set();
  let notifiedAtSummit = new Set();

  function setFloor(dimension, trap, open) {
    const [x, y, z] = trap;
    const cells = [0, 1].flatMap(dx => [0, 1].map(dz => blockAt(dimension, x + dx, y, z + dz)));
    if (cells.some(block => !block || (!block.isAir && block.typeId !== DROP_BLOCK))) return;
    const material = open ? 'minecraft:air' : DROP_BLOCK;
    for (const block of cells) {
      if (block.typeId !== material) block.setType(material);
    }
    if (open) dropped.add(trap);
    else dropped.delete(trap);
  }

  function start(player) {
    if (!eligible(player) || player.isFlying || player.isGliding) return;
    runs.set(player.id, { player, started: system.currentTick, lastLocation: player.location, leftGround: false });
    player.sendMessage('§aParkour has started! Take any path to the gold blocks at the summit.');
    player.onScreenDisplay.setActionBar('§6Skyspire §f0:00.00');
  }

  function endRun(player, reason) {
    runs.delete(player.id);
    if (!player.isValid) return;
    player.sendMessage(`§cParkour ended. ${reason} Step on the purple mats to try again.`);
    player.onScreenDisplay.setActionBar('§cParkour ended');
  }

  function leave(player) {
    const run = runs.get(player.id);
    if (!run) return player.sendMessage('§eNo active Skyspire run.');
    if (player.dimension.id !== OVERWORLD) return;
    if (run.completed) return finish(run);
    endRun(player, 'You ended the run.');
  }

  function finish(run) {
    const { player } = run;
    if (!run.timeSaved) run.timeSaved = onTime(player, run.elapsedTicks);
    if (!run.settled) run.settled = onClear(player, run.clearedAt);
    if (!run.timeSaved || !run.settled) return;
    returnToSpawn(player, () => {
      if (runs.get(player.id) === run) runs.delete(player.id);
    }, () => runs.get(player.id) === run && player.dimension.id === OVERWORLD && withinTower(player.location));
  }

  function updateRun(run) {
    const { player } = run;
    if (!player.isValid) {
      runs.delete(player.id);
      return;
    }
    const location = player.location;
    if (player.dimension.id !== OVERWORLD || !eligible(player)) {
      return endRun(player, 'Skyspire runs take place in the Overworld in Survival or Adventure.');
    }
    if (!withinTower(location) || location.y < BELOW_COURSE) return endRun(player, 'You left the course.');

    if (run.completed) {
      const { x, y, z } = location;
      if (y >= 43.8 && y < 45.5 && x >= 57 && x < 59 && z >= -9 && z < -6) {
        if (!run.returnNotice) {
          run.returnNotice = true;
          player.sendMessage('§bUse the blue block or Skyspire Trial in the Compass to retry the finish.');
        }
      } else run.returnNotice = false;
      return;
    }

    if (player.isFlying || player.isGliding) return endRun(player, 'Climb or jump to the summit.');
    const previous = run.lastLocation;
    // A direct teleport to the summit must not settle an active run.
    if (Math.hypot(location.x - previous.x, location.y - previous.y, location.z - previous.z) > MAX_MOVEMENT_PER_TICK) {
      return endRun(player, 'You left the course by teleport.');
    }
    run.lastLocation = location;

    // The timer begins at ground level. The initial approach to the first
    // jump is valid. A return to ground level after rising ends the run.
    if (location.y >= GROUND_HEIGHT) run.leftGround = true;
    else if (run.leftGround && (player.getAllBlocksStandingOn().length || player.isInWater || onEntryMat(player))) {
      return endRun(player, 'You hit the ground.');
    }

    const elapsed = system.currentTick - run.started;
    if (onSummit(player, location)) {
      run.completed = true;
      run.clearedAt = Date.now();
      run.elapsedTicks = Math.max(1, elapsed);
      const time = formatSkyspireTime(run.elapsedTicks);
      player.sendMessage(`§6Skyspire cleared in ${time}.`);
      player.onScreenDisplay.setActionBar(`§aSkyspire finished §f${time}`);
      finish(run);
      return;
    }

    let trapWarning = false;
    for (const [x, y, z, offset] of dropFloors) {
      const phase = cycleAt(offset);
      if (phase < WARNING_AT || phase >= DROP_AT) continue;
      if (Math.abs(location.y - y - 1) > 4 || Math.hypot(location.x - x - 1, location.z - z - 1) > 6) continue;
      trapWarning = true;
      if (phase === WARNING_AT) player.playSound('random.click');
    }
    if (elapsed > 0 && elapsed % TIMER_PULSE === 0) {
      player.onScreenDisplay.setActionBar(`§6Skyspire §f${formatSkyspireTime(elapsed)}${trapWarning ? ' §e· Cracked floor opening' : ''}`);
    }
  }

  function tick() {
    if (!cityReady()) return;
    const dimension = world.getDimension(OVERWORLD);
    observeEntry(dimension);
    if (system.currentTick % 10 === 0) notifyAtSummit(dimension);
    if (!runs.size && !dropped.size) return;
    try {
      for (const trap of dropFloors) {
        const phase = cycleAt(trap[3]);
        const open = runs.size > 0 && phase >= DROP_AT && phase < RESET_AT;
        if (open !== dropped.has(trap)) setFloor(dimension, trap, open);
      }
    } catch (error) {
      console.warn('[Skyspire] Trap update: ' + error);
    }
    for (const run of runs.values()) {
      try { updateRun(run); }
      catch (error) {
        runs.delete(run.player.id);
        console.warn('[Skyspire] Course update: ' + error);
      }
    }
  }

  function observeEntry(dimension) {
    const currentMat = new Set();
    for (const player of dimension.getPlayers({ location: entry, maxDistance: 3 })) {
      if (!onEntryMat(player)) continue;
      currentMat.add(player.id);
      if (!onMat.has(player.id) && !runs.has(player.id)) start(player);
    }
    onMat = currentMat;
  }

  function notifyAtSummit(dimension) {
    const onGold = new Set();
    for (const player of dimension.getPlayers({ location: summitCenter, maxDistance: 3 })) {
      if (runs.has(player.id) || !onSummit(player)) continue;
      onGold.add(player.id);
      if (!notifiedAtSummit.has(player.id)) {
        player.sendMessage('§eStep on the purple mats near 70, 1, 9 in the Skill Temple to start in Survival or Adventure.');
      }
    }
    notifiedAtSummit = onGold;
  }

  world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { block, player } = event;
    if (block.dimension.id !== OVERWORLD || event.isFirstEvent === false) return;
    const { x, y, z } = block.location;
    if (block.typeId === 'minecraft:lapis_block' && x === 57 && y === 44 && z === -8 && runs.get(player.id)?.completed) {
      event.cancel = true;
      system.run(() => { if (player.isValid) leave(player); });
    }
  });
  world.afterEvents.playerLeave.subscribe(event => {
    runs.delete(event.playerId);
    onMat.delete(event.playerId);
    notifiedAtSummit.delete(event.playerId);
  });
  world.afterEvents.entityDie.subscribe(({ deadEntity: player }) => {
    if (player.typeId === 'minecraft:player' && runs.has(player.id)) endRun(player, 'You died on the course.');
  });
  system.runInterval(tick, 1);
  return { leave, hasRun: player => runs.has(player.id), isCleared: player => runs.get(player.id)?.completed === true };
}
