import { system, world } from '@minecraft/server';
import { CITY } from './city_layout.js';
import { DISTRICT_ENTRANCE_DISPLAYS } from './district_labels.js';
import { DISTRICT_ORDERS_READY_KEY } from '../../district_order_layout.js';
import { NEXUS_BEACON_READY_KEY } from '../../nexus_beacon_layout.js';
import { COLLECTION_HALL_READY_KEY } from '../../collection_hall_layout.js';
import { RUSH_READY_KEY } from '../../generator_rush_layout.js';

const STATE_KEY = 'sg_phase0_city_capture_v1';
const LEGACY_STATE_KEY = 'sg_skyrealm_builder_v8_state';
const LEGACY_DONE_KEY = 'sg_skyrealm_builder_v8_complete';
export const CAPTURE_READY_KEY = 'sg_phase0_city_ready_v1';
const AREA = 'sg_an_city_stage';
const AIR = 'minecraft:air';
const SCAN_BUDGET = 1800;
const LOAD_LIMIT = 1800;
const FISH_VERIFY_LIMIT = 40;
const CITY_VERSION = '0.10.85';
const OVERWORLD = 'minecraft:overworld';
const DISTRICT_LABEL_EVENT = 'skygen:districtlabels';

const point = ([x, y, z]) => ({ x, y, z });
const dim = () => world.getDimension(OVERWORLD);
const at = ([x, y, z]) => dim().getBlock({ x, y, z });
const readyScore = () => world.scoreboard.getObjective('sg_public_mine')?.getScore('ready') === 1;
const hasLegacyCity = () => readyScore() || world.getDynamicProperty(LEGACY_DONE_KEY) === true ||
  world.getDynamicProperty(LEGACY_STATE_KEY) !== undefined;
const notify = message => world.sendMessage('§b[Aether Nexus Builder] §r' + message);

function span(bounds) {
  return [[0, 1, 2].map(axis => Math.min(...bounds.map(pair => pair[0][axis]))),
    [0, 1, 2].map(axis => Math.max(...bounds.map(pair => pair[1][axis])))];
}

const stages = [
  ...CITY.sections.map(section => {
    const bounds = span(section.tiles.map(tile => tile.bounds));
    const entrances = DISTRICT_ENTRANCE_DISPLAYS.filter(display => contained(display.point.map(Math.floor), bounds));
    return { ...section, bounds, displays: [...section.displays, ...entrances] };
  }),
  { name: 'Garden fish', bounds: CITY.fishBounds, fish: true },
];

let active;
let runtime;
let initialized = false;
let areaSerial = 0;
let placingDistrictLabels = false;

function setScore(objective, participant, value) {
  const board = world.scoreboard.getObjective(objective) ?? world.scoreboard.addObjective(objective);
  board.setScore(participant, value);
  if (board.getScore(participant) !== value) throw Error('Cannot save scoreboard flag ' + objective);
}

function setLock(value) {
  setScore('sg_city_build', 'active', Number(value));
}

function read() {
  const raw = world.getDynamicProperty(STATE_KEY);
  return raw === undefined ? undefined : JSON.parse(raw);
}

function write(state) {
  const encoded = JSON.stringify(state);
  world.setDynamicProperty(STATE_KEY, encoded);
  if (world.getDynamicProperty(STATE_KEY) !== encoded) throw Error('Could not verify saved build progress');
}

function releaseArea(name = runtime?.area) {
  if (!name) return;
  try {
    const manager = world.tickingAreaManager;
    if (manager.hasTickingArea(name)) manager.removeTickingArea(name);
  } catch (error) {
    console.warn('[Aether Nexus Builder] Ticking area cleanup failed: ' + error);
  }
}

function pause(reason) {
  if (!active) return;
  const saved = active;
  active = undefined;
  releaseArea();
  runtime = undefined;
  saved.status = 'paused';
  saved.message = String(reason).slice(0, 250);
  try { write(saved); } catch (error) { console.error('[Aether Nexus Builder] Paused state write failed: ' + error); }
  try { setLock(false); } catch (error) { console.error('[Aether Nexus Builder] Lock release failed: ' + error); }
  notify('§cPAUSED: ' + saved.message + '. Use /scriptevent skyrealm:build status.');
}

function loadStage(stage) {
  const area = AREA + '_' + (++areaSerial);
  const pending = { area, cursor: 0, loaded: false, started: system.currentTick };
  world.tickingAreaManager.createTickingArea(area, {
    dimension: dim(), from: point(stage.bounds[0]), to: point(stage.bounds[1]),
  }).then(() => {
    if (runtime === pending) pending.loaded = true;
    else releaseArea(area);
  }).catch(error => {
    if (runtime === pending) pending.loadError = String(error);
  });
  return pending;
}

function ensureVoid(location, allowOriginPad) {
  const [x, y, z] = location;
  const block = at(location);
  if (block?.isAir) return;
  // Core makes this temporary arrival floor on a blank void world.
  if (y === 0 && Math.abs(x) <= 12 && Math.abs(z) <= 12 && block?.typeId === 'minecraft:stone_bricks') return;
  // Bedrock's Void preset generates a pad under the origin at the minimum Y.
  if (allowOriginPad && (block?.typeId === 'minecraft:stone' ||
      (x === 0 && z === 0 && block?.typeId === 'minecraft:cobblestone'))) return;
  throw Error(`Fresh void check failed at ${x},${y},${z}: ${block?.typeId ?? 'unloaded'}`);
}

function scanTile(tile) {
  const [[x0, y0, z0], [x1, y1, z1]] = tile.bounds;
  const width = x1 - x0 + 1;
  const depth = z1 - z0 + 1;
  const height = y1 - y0 + 1;
  const size = width * height * depth;
  const end = Math.min(size, runtime.cursor + SCAN_BUDGET);
  for (let index = runtime.cursor; index < end; index++) {
    ensureVoid([x0 + Math.floor(index / (depth * height)), y0 + Math.floor(index / depth) % height, z0 + index % depth], tile.originPad);
  }
  runtime.cursor = end;
  return end === size;
}

function contained(location, bounds) {
  return location.slice(0, 3).every((value, i) => value >= bounds[0][i] && value <= bounds[1][i]);
}

function verifyBlocks(rows) {
  for (const [x, y, z, expected] of rows) {
    const actual = at([x, y, z])?.typeId;
    if (actual !== expected) throw Error(`Expected ${expected} at ${x},${y},${z}, found ${actual ?? 'unloaded'}`);
  }
}

function verifyKits(bounds) {
  for (const [x, y, z, slots] of CITY.kits) {
    if (!contained([x, y, z], bounds)) continue;
    const inventory = at([x, y, z])?.getComponent('minecraft:inventory')?.container;
    if (!inventory) throw Error(`Shulker inventory not loaded at ${x},${y},${z}`);
    const expected = new Map(slots.map(([slot, type, amount]) => [slot, [type, amount]]));
    for (let slot = 0; slot < inventory.size; slot++) {
      const item = inventory.getItem(slot);
      const target = expected.get(slot);
      if (item?.typeId !== target?.[0] || item?.amount !== target?.[1]) {
        throw Error(`Shulker contents differ at ${x},${y},${z}, slot ${slot}`);
      }
    }
  }
}

function verifyTile(tile) {
  verifyBlocks(tile.samples);
  verifyBlocks(CITY.mine.filter(position => contained(position, tile.bounds)));
  verifyKits(tile.bounds);
}

function placeTile(tile) {
  world.structureManager.place(tile.structure, dim(), point(tile.bounds[0]), { includeEntities: false });
  verifyTile(tile);
}

function findDisplay(dimension, tag) {
  const matches = dimension.getEntities({ type: 'monkey:floatingtext', tags: [tag] });
  if (matches.length > 1) throw Error('Duplicate saved city display: ' + tag);
  return matches[0];
}

function spawnDisplay(dimension, spec) {
  const display = dimension.spawnEntity('monkey:floatingtext', point(spec.point), {
    spawnEvent: spec.scoreboard ? 'scoreboard' : 'text', initialPersistence: true,
  });
  try {
    for (const tag of spec.tags) display.addTag(tag);
    display.nameTag = spec.text;
    display.setRotation({ x: spec.rotation[1], y: spec.rotation[0] });
    if (spec.scoreboard) display.setDynamicProperty('scoreboardinfo', JSON.stringify(spec.scoreboard));
    if (!display.hasTag(spec.tag)) throw Error('Display tag could not be saved: ' + spec.tag);
  } catch (error) {
    display.remove();
    throw error;
  }
}

function restoreDisplay(spec) {
  const dimension = dim();
  if (spec.scoreboard && !world.scoreboard.getObjective(spec.scoreboard[0])) {
    world.scoreboard.addObjective(spec.scoreboard[0], spec.title);
  }
  if (!findDisplay(dimension, spec.tag)) spawnDisplay(dimension, spec);
}

async function placeDistrictLabels(player) {
  if (placingDistrictLabels) throw Error('District signs are already being placed.');
  const saved = read();
  if (active || (saved && saved.status !== 'completed')) throw Error('Finish the city build before placing district signs.');

  const dimension = dim();
  const area = AREA + '_labels_' + (++areaSerial);
  const [from, to] = span(DISTRICT_ENTRANCE_DISPLAYS.map(({ point: location }) => {
    const [x, y, z] = location.map(Math.floor);
    return [[x, 0, z], [x, y, z]];
  }));
  let placed = 0, updated = 0;
  placingDistrictLabels = true;
  try {
    await world.tickingAreaManager.createTickingArea(area, { dimension, from: point(from), to: point(to) });
    // Check the whole set before writing signs. Keep existing label positions
    // when refreshing their text, including labels moved by a city operator.
    const labels = DISTRICT_ENTRANCE_DISPLAYS.map(spec => {
      const existing = findDisplay(dimension, spec.tag);
      if (!existing) {
        const [x, y, z] = spec.point.map(Math.floor);
        const floor = at([x, 0, z]);
        if (!floor || floor.isAir || floor.isLiquid || !at([x, y, z])?.isAir) {
          throw Error(`District sign landing missing or blocked at ${x}, ${y}, ${z}.`);
        }
      }
      return { spec, existing };
    });
    for (const { spec, existing } of labels) {
      if (!existing) {
        spawnDisplay(dimension, spec);
        placed++;
      } else if (existing.nameTag !== spec.text) {
        existing.nameTag = spec.text;
        updated++;
      }
    }
  } finally {
    releaseArea(area);
    placingDistrictLabels = false;
  }
  if (player.isValid) {
    const total = DISTRICT_ENTRANCE_DISPLAYS.length;
    player.sendMessage(`§aDistrict signs ready (${total}) · ${placed} placed, ${updated} updated, ${total - placed - updated} already current.`);
  }
}

function buildFish(spec) {
  const dimension = dim();
  const matches = dimension.getEntities({ tags: [spec.tag], type: spec.species });
  if (matches.length > 1) throw Error('More than one saved fish has tag ' + spec.tag);
  if (matches.length === 1) {
    runtime.fishPlacedAt = undefined;
    return true;
  }
  if (runtime.fishPlacedAt === undefined) {
    world.structureManager.place(spec.structure, dimension, point(spec.point), { includeBlocks: false, includeEntities: true });
    runtime.fishPlacedAt = system.currentTick;
  } else if (system.currentTick - runtime.fishPlacedAt > FISH_VERIFY_LIMIT) {
    throw Error('Saved fish could not be verified: ' + spec.species + ' ' + spec.tag);
  }
  return false;
}

function advanceStage() {
  active.stage++;
  active.index = 0;
  releaseArea();
  runtime = undefined;
  write(active);
}

function nextIndex() {
  active.index++;
  runtime.cursor = 0;
  write(active);
}

function complete() {
  // The READY property is the gate for Skyspire, and is only published after the mine and city are ready.
  setScore('sg_public_mine', 'ready', 1);
  world.setDynamicProperty(CAPTURE_READY_KEY, true);
  if (world.getDynamicProperty(CAPTURE_READY_KEY) !== true) throw Error('Could not save completion');
  world.setDynamicProperty(NEXUS_BEACON_READY_KEY, true);
  if (world.getDynamicProperty(NEXUS_BEACON_READY_KEY) !== true) throw Error('Could not enable Nexus Beacon');
  world.setDynamicProperty(DISTRICT_ORDERS_READY_KEY, true);
  if (world.getDynamicProperty(DISTRICT_ORDERS_READY_KEY) !== true) throw Error('Could not enable District Orders');
  world.setDynamicProperty(COLLECTION_HALL_READY_KEY, true);
  if (world.getDynamicProperty(COLLECTION_HALL_READY_KEY) !== true) throw Error('Could not enable Collection Hall');
  world.setDynamicProperty(RUSH_READY_KEY, true);
  if (world.getDynamicProperty(RUSH_READY_KEY) !== true) throw Error('Could not enable Generator Rush');
  setLock(false);
  active.status = 'completed';
  write(active);
  active = undefined;
  releaseArea();
  runtime = undefined;
  notify('§aCOMPLETE: Spawn, nine districts, Garden fish and floating displays restored.');
}

function work() {
  if (!active) return;
  try {
    if (active.stage >= stages.length) {
      if (active.pass === 'build') return complete();
      active.pass = 'build';
      active.stage = 0;
      active.index = 0;
      write(active);
      notify('§aFresh-void checks passed. Rebuilding the saved districts.');
      return;
    }
    const stage = stages[active.stage];
    if (active.pass === 'preflight' && stage.fish) return advanceStage();
    runtime ??= loadStage(stage);
    if (runtime.loadError) throw Error('Could not load ' + stage.name + ': ' + runtime.loadError);
    if (!runtime.loaded) {
      if (system.currentTick - runtime.started > LOAD_LIMIT) throw Error('Area did not load: ' + stage.name);
      return;
    }

    if (active.pass === 'preflight') {
      if (active.index >= stage.tiles.length) return advanceStage();
      if (scanTile(stage.tiles[active.index])) nextIndex();
      return;
    }

    if (stage.fish) {
      if (active.index >= CITY.fish.length) return advanceStage();
      if (buildFish(CITY.fish[active.index])) nextIndex();
      return;
    }
    if (active.index >= stage.tiles.length) {
      for (const display of stage.displays) restoreDisplay(display);
      notify('§7Verified ' + stage.name + '.');
      return advanceStage();
    }
    placeTile(stage.tiles[active.index]);
    nextIndex();
  } catch (error) {
    pause(error);
  }
}

function verifyPack() {
  const available = new Set(world.structureManager.getPackStructureIds());
  for (const structure of [
    ...CITY.sections.flatMap(section => section.tiles.map(tile => tile.structure)),
    ...CITY.fish.map(fish => fish.structure),
  ]) {
    if (!available.has(structure)) throw Error('Missing city structure ' + structure);
  }
}

function startFreshCity() {
  if (placingDistrictLabels) throw Error('District signs are already being placed.');
  if (active || read() || hasLegacyCity()) throw Error('A city or build record already exists in this world.');
  verifyPack();
  const state = { layout: CITY_VERSION, status: 'running', pass: 'preflight', stage: 0, index: 0 };
  write(state);
  active = state;
  try {
    setLock(true);
    notify('§aChecking the full city footprint before construction.');
  } catch (error) {
    pause(error);
  }
}

function autoStart() {
  if (!initialized || active || placingDistrictLabels || !world.getAllPlayers().length) return;
  try {
    if (hasLegacyCity() || read()) return;
    for (const [x, z] of [[16, 16], [-16, 16], [16, -16], [-16, -16], [20, 0], [-20, 0], [0, 20], [0, -20]]) {
      if (at([x, 0, z])?.typeId !== AIR) return;
    }
    startFreshCity();
  } catch (error) {
    console.error('[Aether Nexus Builder] Automatic start unavailable: ' + error);
  }
}

function status() {
  const saved = active ?? read();
  if (!saved) return hasLegacyCity() ? 'An earlier city build exists. Use a brand-new void world for this candidate.' :
    'Ready. Use /scriptevent skyrealm:build start in a new void world.';
  if (saved.status === 'completed') return 'Complete. Spawn, nine districts, Garden fish and floating displays restored.';
  const stage = stages[saved.stage]?.name ?? 'Final checks';
  return `${saved.status}: ${saved.pass}, ${stage} (${Math.min(stages.length, saved.stage + 1)}/${stages.length}).` +
    (saved.message ? ' ' + saved.message : '');
}

system.afterEvents.scriptEventReceive.subscribe(event => {
  const districtLabels = event.id === DISTRICT_LABEL_EVENT;
  if (event.id !== 'skyrealm:build' && !districtLabels) return;
  const player = event.sourceEntity;
  if (player?.typeId !== 'minecraft:player') return;
  if (player.isOp?.() !== true && player.playerPermissionLevel !== 2) {
    return player.sendMessage(districtLabels ? '§cOnly a Minecraft Realm operator can place district signs.' :
      '§cOnly a Minecraft Realm operator can control the city builder.');
  }
  if (districtLabels) {
    placeDistrictLabels(player).catch(error => {
      if (player.isValid) player.sendMessage('§cDistrict signs: ' + error.message);
    });
    return;
  }
  const action = String(event.message ?? '').trim().toLowerCase();
  try {
    if (action === 'status') return player.sendMessage(status());
    if (action === 'ping') return player.sendMessage('Aether Nexus Builder ' + CITY_VERSION + ' is active.');
    if (action === 'preview') return player.sendMessage('Saved spawn, nine districts, bridges, Garden pond, Skyspire and floating displays. New void world required.');
    if (action === 'start') {
      if (player.dimension.id !== OVERWORLD) throw Error('Run this from the Overworld.');
      return startFreshCity();
    }
    if (action === 'resume') {
      const saved = read();
      if (active || saved?.status !== 'paused') throw Error('No paused Phase 0 build to resume.');
      if (saved.layout !== CITY_VERSION) throw Error('This paused build belongs to its original pack. Use this pack in a fresh Void world.');
      if (player.dimension.id !== OVERWORLD) throw Error('Run this from the Overworld.');
      verifyPack();
      saved.status = 'running';
      saved.message = '';
      write(saved);
      active = saved;
      runtime = undefined;
      try { setLock(true); } catch (error) { pause(error); }
      return;
    }
    if (action === 'pause' || action === 'abort') {
      if (!active) throw Error('No active build.');
      return pause('Paused by an operator');
    }
    player.sendMessage('Builder actions: ping, preview, start, status, pause, resume.');
  } catch (error) {
    player.sendMessage('§c' + String(error));
  }
});

system.runTimeout(() => {
  try {
    const saved = read();
    if (saved?.status === 'running') {
      saved.status = 'paused';
      saved.message = 'World reloaded. An operator can resume the build.';
      write(saved);
    }
    if (saved?.status !== 'completed' && world.getDynamicProperty(CAPTURE_READY_KEY) !== true && !hasLegacyCity()) {
      setLock(false);
    }
    initialized = true;
  } catch (error) {
    console.error('[Aether Nexus Builder] Initialization failed: ' + error);
  }
}, 20);
system.runInterval(autoStart, 100);
system.runInterval(work, 1);
