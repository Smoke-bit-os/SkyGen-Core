import { ScoreboardIdentityType, system, world } from '@minecraft/server';
import { showMenu } from './ui.js';
import { playerRoster, readSidebarStats } from '../../main.js';
import { rankRoster } from '../../player_roster.js';
import { RUSH_BOARD, RUSH_OBJECTIVE, RUSH_READY_KEY } from '../../generator_rush_layout.js';
import { SKYSPIRE_BEST_TIMES, formatSkyspireTime, isSkyspireTime } from '../../skyspire_times.js';
import { currentRosterPanels, drawRosterPanels, rosterPanelOwner } from './roster_panels.js';
import { SIDEBAR_OBJECTIVES, SIDEBAR_PANEL, sidebarStats, sidebarLines, rankName } from '../../numeric_scores.js';


// Resolve dimensions only when an operator opens the menu or a world-loaded tick runs.
// @minecraft/server 2.x prohibits this world access during early module execution.
export function getDimensions() {
    return [world.getDimension('overworld'), world.getDimension('nether'), world.getDimension('the_end')];
}


// Use a custom item component so the menu activates reliably on current Bedrock.
// Keep the vanilla itemUse listener as a fallback for existing menu items.
// Some engines trigger both; deduplicate openings to avoid a "UI already open" error.
const lastMenuOpen = new Map();
function openFloatingMenu(source) {
    if (!source || source.typeId !== 'minecraft:player') return;
    const isOperator = (() => {
        try { if (typeof source.isOp === 'function' && source.isOp()) return true; } catch {}
        try { return source.playerPermissionLevel === 2; } catch { return false; }
    })();
    if (!isOperator) {
        source.sendMessage('§cOnly Realm operators can use Floating Text & Leaderboards.');
        return;
    }
    const tick = system.currentTick;
    const previous = lastMenuOpen.get(source.id);
    if (previous !== undefined && tick - previous < 10) return;
    lastMenuOpen.set(source.id, tick);
    system.run(() => showMenu(source));
}
system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
    itemComponentRegistry.registerCustomComponent('monkey:open_menu', {
        onUse({ source }) { openFloatingMenu(source); }
    });
});
world.afterEvents.itemUse.subscribe(({ itemStack, source }) => {
    if (itemStack?.typeId === 'monkey:textmenu') openFloatingMenu(source);
});


const rankId = SIDEBAR_OBJECTIVES.find(([key]) => key === 'rank')[1];
const creditsId = SIDEBAR_OBJECTIVES.find(([key]) => key === 'credits')[1];
const isPlayerScore = ({ participant }) => participant.type === ScoreboardIdentityType.Player;

function playerScoreboardId(player) {
    try { return player.scoreboardIdentity?.id; } catch { return undefined; }
}

function resolvePlayer(entity, info, getRows, online) {
    const name = info[7];
    const saved = info[8];
    const target = name.toLowerCase();
    const player = saved?.playerId !== undefined ? online.byId.get(saved.playerId)
        : saved?.scoreboardId !== undefined ? online.byScoreboardId.get(saved.scoreboardId)
        : online.byName.get(target);
    const rosterRecord = saved?.playerId ? online.rosterById.get(saved.playerId) : online.rosterByName.get(target);
    const scoreboardId = (player && playerScoreboardId(player)) ?? rosterRecord?.scoreboardId ?? saved?.scoreboardId;
    let row;
    if (!player && scoreboardId !== undefined && !online.byScoreboardId.has(scoreboardId)) {
        row = getRows().find(entry => isPlayerScore(entry) && entry.participant.id === scoreboardId);
    } else if (!player && !saved) {
        row = getRows().find(entry => isPlayerScore(entry) && entry.participant.displayName.toLowerCase() === target);
    }
    const link = {
        playerId: player?.id ?? rosterRecord?.id ?? saved?.playerId,
        scoreboardId: scoreboardId ?? row?.participant.id
    };
    const displayName = player?.name ?? rosterRecord?.name ?? name;
    if ((player || row) && (link.playerId !== saved?.playerId || link.scoreboardId !== saved?.scoreboardId || displayName !== name)) {
        info[7] = displayName;
        info[8] = link;
        entity.setDynamicProperty('scoreboardinfo', JSON.stringify(info));
    }
    return { player, row, displayName, linked: Boolean(saved || player || row) };
}

function sidebarLabel(target, scoresFor, sidebarFor) {
    const header = '§b§lPERSONAL SIDEBAR§r\n§f' + target.displayName;
    if (target.player) return header + '\n' + sidebarLines(sidebarFor(target.player)).join('\n');
    if (!target.row) return header + '\n§7Player stats unavailable';
    const values = {};
    for (const [key, id] of SIDEBAR_OBJECTIVES) {
        const value = scoresFor(id)?.objective.getScore(target.row.participant);
        if (value !== undefined) values[key] = value;
    }
    if (['credits', 'orbits', 'xp', 'rank', 'plot'].some(key => values[key] === undefined)) {
        return header + '\n§7Waiting for sidebar stats';
    }
    // Historic players may have the original five objectives only.
    const stats = sidebarStats({...values, plot: values.plot - 1});
    return header + '\n' + sidebarLines({...stats, ...values}).join('\n');
}

// Reuse one scoreboard snapshot per objective across all loaded holograms.
// Skip player/profile/scoreboard work entirely when no scoreboard hologram is
// loaded in any dimension. Keep the same 20-tick refresh for active holograms.
function refreshFloatingScoreboards() {
    let dimensions;
    try { dimensions = getDimensions(); }
    catch (err) { console.warn('[MonkeyChan] scoreboard initialization: ' + err); return; }
    const activeDisplays = [];
    for (const dimension of dimensions) {
        try {
            const entities = dimension.getEntities({ type: 'monkey:floatingtext', families: ['scoreboard'] });
            if (entities.length) activeDisplays.push(entities);
        } catch (err) { console.warn('[MonkeyChan] floating-text query: ' + err); }
    }
    if (!activeDisplays.length) return;
    let scoreboard, players;
    try { scoreboard = world.scoreboard; players = world.getAllPlayers(); }
    catch (err) { console.warn('[MonkeyChan] scoreboard initialization: ' + err); return; }
    const online = {byId: new Map(), byName: new Map(), byScoreboardId: new Map()};
    for (const player of players) {
        online.byId.set(player.id, player);
        online.byName.set(player.name.toLowerCase(), player);
        const id = playerScoreboardId(player);
        if (id !== undefined) online.byScoreboardId.set(id, player);
    }
    const cache = new Map();
    // A player can be referenced by several loaded Personal Sidebar holograms.
    // Keep one per-player snapshot for this refresh only; no persistent stale cache.
    const sidebarCache = new Map();
    function sidebarFor(player) {
        if (!sidebarCache.has(player.id)) sidebarCache.set(player.id, readSidebarStats(player));
        return sidebarCache.get(player.id);
    }
    function scoresFor(id) {
        if (!cache.has(id)) {
            const objective = scoreboard.getObjective(id);
            let entries;
            const rows = () => entries ??= objective.getScores()
                .filter(({ participant }) => !participant.displayName.startsWith('#'));
            cache.set(id, objective ? {objective, rows} : null);
        }
        return cache.get(id);
    }
    const roster = playerRoster.records();
    online.rosterById = new Map(roster.map(row => [row.id, row]));
    online.rosterByName = new Map(roster.map(row => [row.name.toLowerCase(), row]));
    for (const entities of activeDisplays) {
        const children = currentRosterPanels(entities);
        for (const entity of entities) {
            try {
                if (!entity.isValid || rosterPanelOwner(entity)) continue;
                let info;
                try { info = JSON.parse(entity.getDynamicProperty('scoreboardinfo') ?? 'null'); }
                catch { continue; }
                if (!Array.isArray(info) || typeof info[0] !== 'string') continue;
                if (info[0] === SIDEBAR_PANEL) {
                    if (typeof info[7] !== 'string' || !info[7]) continue;
                    const target = resolvePlayer(entity, info, () => scoresFor(rankId)?.rows() ?? [], online);
                    const label = sidebarLabel(target, scoresFor, sidebarFor);
                    if (entity.nameTag !== label) entity.nameTag = label;
                    continue;
                }
                const id = info[0];
                const data = scoresFor(id);
                if (!data) continue;
                const metric = id === rankId ? 'rank' : id === creditsId ? 'credits' : id === RUSH_OBJECTIVE ? 'rush' : 'objective';
                const timed = id === SKYSPIRE_BEST_TIMES;
                const order = metric === 'objective' ? !timed && Boolean(info[1]) : true;
                const cacheKey = order ? 'rosterDescending' : 'rosterAscending';
                if (!data[cacheKey]) {
                    const values = metric === 'objective'
                        ? new Map(data.rows().filter(row => isPlayerScore(row) && (!timed || isSkyspireTime(row.score)))
                            .map(({ participant, score }) => [participant.id, score]))
                        : new Map();
                    data[cacheKey] = rankRoster(roster, metric, values, order);
                }
                const rows = data[cacheKey];
                const limit = Math.max(1, Math.min(15, Math.floor(Number(info[6]) || 8)));
                const count = Math.max(1, Math.ceil(rows.length / limit));
                const labels = [];
                const title = metric === 'rank' ? 'SkyGen Rank' : metric === 'credits' ? 'SkyGen Credits' : data.objective.displayName;
                for (let page = 0; page < count; page++) {
                    const start = page * limit;
                    const display = rows.slice(start, start + limit).map((row, index) => {
                        const number = info[2] && (!timed || row.score !== undefined) ? `${info[3]}${start + index + 1}. §r` : '';
                        let score = '—';
                        if (row.score !== undefined) {
                            if (timed) score = formatSkyspireTime(row.score);
                            else if (metric === 'rank') score = `${row.rank} · ${rankName(row.rank)}`;
                            else score = row.score.toLocaleString('en-US');
                        }
                        return `${number}${info[4]}${row.name}§r ${info[5]}${score}§r`;
                    });
                    const header = title + (count > 1 ? ` §7[${page + 1}/${count}]` : '') + '§r';
                    labels.push([header, ...(display.length ? display : ['§7Waiting for the first player.'])].join('\n'));
                }
                drawRosterPanels(entity, labels, limit, children.get(entity.id));
            } catch (err) { console.warn('[MonkeyChan] floating-scoreboard refresh: ' + err); }
        }
    }
}

function createRushBoard() {
    const key = 'sg_rush_board_created_v1';
    if (world.getDynamicProperty(RUSH_READY_KEY) !== true || world.getDynamicProperty(key) === true) return;
    const dimension = world.getDimension('overworld');
    if (!dimension.isChunkLoaded(RUSH_BOARD) || !world.scoreboard.getObjective(RUSH_OBJECTIVE)) return;
    const tag = 'sg_rush_default_board';
    let board = dimension.getEntities({ type: 'monkey:floatingtext', tags: [tag] })[0];
    if (!board) {
        board = dimension.spawnEntity('monkey:floatingtext', RUSH_BOARD, { spawnEvent: 'scoreboard', initialPersistence: true });
        try {
            board.addTag(tag);
            board.setDynamicProperty('scoreboardinfo',JSON.stringify([RUSH_OBJECTIVE,1,true,'§6','§f','§e',8,'']));
        } catch (error) { board.remove(); throw error; }
    }
    world.setDynamicProperty(key, true);
}
world.afterEvents.worldLoad.subscribe(() => {
    console.warn('[MonkeyChan] Floating Text & Scoreboards module initialized.');
    system.runInterval(() => {
        try { createRushBoard(); } catch (error) { console.warn('[Generator Rush] Scoreboard setup: ' + error); }
        refreshFloatingScoreboards();
    }, 20);
});
