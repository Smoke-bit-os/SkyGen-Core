export const PVP_KILLS = 'sg_pvp_kills';
export const PLAYER_DEATHS = 'sg_player_deaths';

export function ensureCombatObjectives(scoreboard) {
    return [
        scoreboard.getObjective(PVP_KILLS) ?? scoreboard.addObjective(PVP_KILLS, 'PvP Kills'),
        scoreboard.getObjective(PLAYER_DEATHS) ?? scoreboard.addObjective(PLAYER_DEATHS, 'Deaths'),
    ];
}

function playerAttacker(source) {
    const direct = source?.damagingEntity;
    if (direct?.typeId === 'minecraft:player') return direct;
    try {
        const owner = source?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
        if (owner?.typeId === 'minecraft:player') return owner;
    } catch {
        // A despawned projectile cannot supply reliable ownership.
    }
}

export function installCombatScores({ world, system, onKill, rememberPlayer }) {
    const voidWindow = 100;
    const lastHits = new Map();
    const handledDeaths = new Set();

    function initialize(player) {
        const identity = player.scoreboardIdentity;
        for (const objective of ensureCombatObjectives(world.scoreboard)) {
            if (!objective.hasParticipant(identity ?? player)) objective.setScore(identity ?? player, 0);
        }
        rememberPlayer(player);
    }

    world.afterEvents.worldLoad.subscribe(() => {
        try { ensureCombatObjectives(world.scoreboard); }
        catch (error) { console.warn('[SkyGen PvP] Scoreboard initialization: ' + error); }
    });
    world.afterEvents.playerSpawn.subscribe(({ player }) => {
        handledDeaths.delete(player.id);
        lastHits.delete(player.id);
        system.run(() => {
            try { if (player.isValid) initialize(player); }
            catch (error) { console.warn('[SkyGen PvP] Player scoreboard setup: ' + error); }
        });
    });
    world.afterEvents.playerLeave.subscribe(({ playerId }) => {
        handledDeaths.delete(playerId);
        lastHits.delete(playerId);
    });
    world.afterEvents.playerDimensionChange.subscribe(({ player }) => lastHits.delete(player.id));

    world.afterEvents.entityHurt.subscribe(({ hurtEntity, damageSource, damage }) => {
        if (hurtEntity.typeId !== 'minecraft:player' || damage <= 0 || damageSource?.cause === 'void') return;
        try {
            const attacker = playerAttacker(damageSource);
            if (!attacker || attacker.id === hurtEntity.id) return;
            const hit = { id: attacker.id, identity: attacker.scoreboardIdentity, dimension: hurtEntity.dimension.id, tick: system.currentTick };
            lastHits.set(hurtEntity.id, hit);
            system.runTimeout(() => {
                if (lastHits.get(hurtEntity.id) === hit) lastHits.delete(hurtEntity.id);
            }, voidWindow + 1);
        } catch (error) { console.warn('[SkyGen PvP] Hit attribution: ' + error); }
    });

    world.afterEvents.entityDie.subscribe(({ deadEntity: victim, damageSource }) => {
        if (victim.typeId !== 'minecraft:player' || handledDeaths.has(victim.id)) return;
        handledDeaths.add(victim.id);
        const hit = lastHits.get(victim.id);
        lastHits.delete(victim.id);
        try {
            const [kills, deaths] = ensureCombatObjectives(world.scoreboard);
            try { deaths.addScore(victim.scoreboardIdentity ?? victim, 1); }
            catch (error) { console.warn('[SkyGen PvP] Could not record death: ' + error); }

            let attacker = damageSource?.cause === 'void' ? undefined : playerAttacker(damageSource);
            let id = attacker?.id;
            let identity = attacker?.scoreboardIdentity;
            if (damageSource?.cause === 'void' && hit && hit.dimension === victim.dimension.id &&
                system.currentTick - hit.tick <= voidWindow) {
                id = hit.id;
                identity = hit.identity;
                attacker = world.getAllPlayers().find(player => player.id === id);
            }
            if (!id || id === victim.id) return;
            try {
                const participant = attacker?.scoreboardIdentity ?? identity ?? attacker;
                if (!participant) throw Error('Killer scoreboard identity unavailable.');
                kills.addScore(participant, 1);
            } catch (error) { console.warn('[SkyGen PvP] Could not record kill: ' + error); }
            onKill({ id, attacker, victim: victim.name });
        } catch (error) { console.warn('[SkyGen PvP] Death handling: ' + error); }
    });
}
