import { GameMode } from '@minecraft/server';
import { centralWeekStart } from './central_week.js';
import { RUSH_LANES, RUSH_PRODUCTS, RUSH_RETURN, RUSH_ALT_RETURNS, insideRushArena, rushLaneContains } from './generator_rush_layout.js';

export const RUSH_WIN_CREDITS = 750;
export const RUSH_PAID_WINS = 3;
export const RUSH_MATCH_SECONDS = 180;
export const RUSH_ORDERS = [
    { name: 'Mason’s Order', need: [4, 2, 0] },
    { name: 'Foundry Order', need: [2, 2, 3] },
    { name: 'Colosseum Supply', need: [4, 3, 3] },
];

export function rushStats(profile) {
    const data = profile.generatorRush ?? { wins: 0, paid: 0, week: '', pending: 0 };
    if (![data.wins, data.paid, data.pending].every(n => Number.isSafeInteger(n) && n >= 0) ||
        data.paid > RUSH_PAID_WINS || data.paid > data.wins || data.pending % RUSH_WIN_CREDITS !== 0 ||
        typeof data.week !== 'string' || (data.week && !/^\d{4}-\d{2}-\d{2}$/.test(data.week))) {
        throw Error('Generator Rush history needs operator review.');
    }
    return data;
}

export function recordRushWin(profile, matchId, now = Date.now()) {
    const prior = rushStats(profile), week = centralWeekStart(now);
    if (prior.lastMatch === matchId) return undefined;
    if (prior.week > week) throw Error('Generator Rush is waiting for its saved week.');
    const paid = prior.week === week ? prior.paid : 0;
    const reward = paid < RUSH_PAID_WINS ? RUSH_WIN_CREDITS : 0;
    const wins = prior.wins + 1, pending = prior.pending + reward;
    if (!Number.isSafeInteger(wins) || !Number.isSafeInteger(pending)) throw Error('Generator Rush history limit.');
    profile.generatorRush = { wins, week, paid: paid + Number(reward > 0), pending, lastMatch: matchId };
    return reward;
}

function sameBlock(a, b) { return a.x === b.x && a.y === b.y && a.z === b.z; }

const OVERWORLD = 'minecraft:overworld';
const RETURN_KEY = 'sg_rush_return_v1';
const MATCH_AREA = 'sg_rush_match';
const COUNTDOWN = 60;
const EXIT_RETRY = 5;
const PRIMARY_EXIT_ATTEMPTS = 3;
const EXIT_BACKOFF = 300;
const EMPTY = 'minecraft:air';

export function createGeneratorRush({ world, system, ready, canPlay, isMenuItem, safeReturn, travel, rescueSpawn, onWin, onStatus, onLabel }) {
    const queue = new Map();
    const returning = new Map();
    let match;
    let loading;
    const dim = () => world.getDimension('overworld');
    const laneLabels = RUSH_LANES.flatMap(lane=>[...lane.generators,lane.orders].map((point,index)=>({
        id:'rush_'+lane.color+'_'+index, point, label:RUSH_PRODUCTS[index]?.name ?? 'Turn In Orders',
        text:{x:point.x+.5,y:point.y+2.1,z:point.z+.5},
    })));
    const startFor = slot => RUSH_LANES[slot.index].start;
    const inArena = player => player.dimension?.id === OVERWORLD && insideRushArena(player.location);
    const isInLane = slot => slot.player.dimension?.id === OVERWORLD &&
        rushLaneContains(RUSH_LANES[slot.index], slot.player.location);

    function activeSlot(player) { return match?.slots.find(slot => slot.player.id === player.id); }
    function occupied(player) { return ready() && Boolean(activeSlot(player) || returning.has(player.id) || inArena(player)); }
    function mayRace(player) {
        return player.isValid && [GameMode.Survival,GameMode.Adventure].includes(player.getGameMode()) &&
            player.dimension.id === OVERWORLD && !player.isFlying && !player.isGliding;
    }
    function show(player, message) { if (player.isValid) player.sendMessage(message); }
    function rememberReturn(player) {
        player.setDynamicProperty(RETURN_KEY, true);
        if (player.getDynamicProperty(RETURN_KEY) !== true) throw Error('Could not save the arena exit.');
    }
    function clearExit(player) {
        player.setDynamicProperty(RETURN_KEY,undefined);
        returning.delete(player.id);
    }

    function sendOut(exit) {
        const {player} = exit;
        const region = dim();
        if (exit.started && !inArena(player) && safeReturn(player.dimension,player.location)) {
            clearExit(player);
            return;
        }
        exit.started = true;
        exit.next = system.currentTick+EXIT_RETRY;
        const candidates = ++exit.attempts < PRIMARY_EXIT_ATTEMPTS ? [RUSH_RETURN] : [RUSH_RETURN,...RUSH_ALT_RETURNS];
        for (const location of candidates) {
            if (region.isChunkLoaded(location) && safeReturn(region,location) && travel(player,location)) {
                clearExit(player);
                return;
            }
        }
        if (exit.attempts >= PRIMARY_EXIT_ATTEMPTS) {
            exit.next = system.currentTick+EXIT_BACKOFF;
            show(player,'§eThe Colosseum exit is blocked. Trying safe spawn.');
            rescueSpawn(player,()=>{
                if (returning.get(player.id) === exit && !inArena(player)) clearExit(player);
            });
        }
    }

    function trackExit(player, retry = false) {
        if (!returning.has(player.id)) {
            returning.set(player.id,{player,attempts:0,next:system.currentTick});
        } else if (retry) {
            const exit = returning.get(player.id);
            exit.next = system.currentTick;
        }
    }

    function releaseArea() {
        try {
            const areas = world.tickingAreaManager;
            if (areas.hasTickingArea(MATCH_AREA)) areas.removeTickingArea(MATCH_AREA);
        } catch (error) { console.warn('[Generator Rush] Ticking area release: ' + error); }
    }
    function outputPosition(slot, index) {
        const core = RUSH_LANES[slot.index].generators[index];
        return { ...core, y: core.y + 1 };
    }
    function updateOutput(slot, index, type) {
        const block = dim().getBlock(outputPosition(slot, index));
        if (!block || (block.typeId !== EMPTY && block.typeId !== RUSH_PRODUCTS[index].output)) {
            throw Error('An arena generator has an unexpected block.');
        }
        if (block.typeId !== type) block.setType(type);
        if (block.typeId !== type) throw Error('An arena output write could not be verified.');
        const core = dim().getBlock(RUSH_LANES[slot.index].generators[index]);
        const station = type === EMPTY ? RUSH_PRODUCTS[index].core : 'minecraft:noteblock';
        if (![RUSH_PRODUCTS[index].core,'minecraft:noteblock'].includes(core?.typeId)) {
            throw Error('An arena generator station has an unexpected block.');
        }
        if (core.typeId !== station) core.setType(station);
        if (core.typeId !== station) throw Error('An arena generator station write could not be verified.');
    }

    function finish(current, winner, text) {
        if (match !== current || current.phase === 'ending') return;
        current.phase = 'ending';
        let result;
        if (winner) {
            try { result = onWin(winner.player, current.id); }
            catch (error) { console.warn('[Generator Rush] Result storage: ' + error); }
        }
        for (const slot of current.slots) {
            if (!slot.player.isValid) continue;
            show(slot.player, text);
            if (winner === slot) show(slot.player, result ?? '§eWin settlement requires operator review.');
            if (slot.returnRequired) trackExit(slot.player);
        }
        try {
            if (current.loaded) for (const slot of current.slots) {
                RUSH_PRODUCTS.forEach((_product, index) => updateOutput(slot, index, EMPTY));
            }
        } catch (error) { console.warn('[Generator Rush] Arena reset: ' + error); }
        match = undefined;
        releaseArea();
    }

    function leave(player) {
        if (queue.delete(player.id)) return show(player,'§eYou left the Generator Rush queue.');
        const slot = activeSlot(player);
        if (slot) finish(match,undefined,'§eGenerator Rush match canceled.');
        else if (occupied(player)) trackExit(player,true);
    }

    async function startPair() {
        if (match || loading || queue.size < 2) return;
        // A pending return outside the arena cannot hold the queue.
        if (world.getAllPlayers().some(player=>inArena(player))) return;
        const pair = [...queue.values()].slice(0, 2);
        pair.forEach(p => queue.delete(p.id));
        const current = {
            id: Date.now()+'-'+system.currentTick+'-'+pair[0].id+'-'+pair[1].id,
            phase: 'loading', loaded: false,
            slots: pair.map((player, index) => ({ player, index, stock: [0,0,0], next: [0,0,0], order: 0 })),
        };
        match = current;
        loading = current;
        try {
            const areas = world.tickingAreaManager;
            if (areas.hasTickingArea(MATCH_AREA)) areas.removeTickingArea(MATCH_AREA);
            await areas.createTickingArea(MATCH_AREA, {
                dimension: dim(), from: { x:-9,y:1,z:54 }, to: { x:9,y:30,z:72 },
            });
            if (match !== current) { releaseArea(); return; }
            current.loaded = true;
            if (!pair.every(p => p.isValid && canPlay(p))) throw Error('A player left the Colosseum lobby.');
            current.phase = 'travel';
            current.travelAt = system.currentTick + 100;
            current.slots.forEach(slot=>{
                slot.lobby = slot.player.location;
                show(slot.player,'§eMatch found. Stand still for 5 seconds to enter Generator Rush.');
            });
        } catch (error) {
            if (match === current) finish(current, undefined, '§cGenerator Rush could not start. '+error.message);
        } finally { loading = undefined; }
    }

    function sendToLanes(current) {
        for (const slot of current.slots) {
            const target = startFor(slot);
            if (!safeReturn(dim(), target)) throw Error('An arena lane has no safe landing.');
            rememberReturn(slot.player);
            slot.returnRequired = true;
            if (!travel(slot.player, target)) throw Error('The arena teleport did not complete.');
            RUSH_PRODUCTS.forEach((product,index)=>updateOutput(slot,index,product.output));
            show(slot.player,'§6Mine the outputs or use the note blocks beneath them. Harvests go straight to your Rush stock.');
        }
        current.phase = 'countdown';
        current.starts = system.currentTick + COUNTDOWN;
        current.ends = current.starts + RUSH_MATCH_SECONDS * 20;
    }

    function join(player) {
        if (!ready() || !canPlay(player) || occupied(player)) return show(player,'§eJoin from the Colosseum in Survival or Adventure.');
        if (queue.has(player.id)) return show(player,'§eYou are already in the Generator Rush queue.');
        queue.set(player.id, player);
        show(player,'§aJoined the 1v1 queue. Stay by the Colosseum station.');
    }

    function harvest(slot, index, pos) {
        const { player } = slot;
        if (match.phase !== 'racing' || system.currentTick >= match.ends || !mayRace(player) || !isInLane(slot)) return;
        if (Math.hypot(player.location.x-pos.x-0.5, player.location.y-pos.y, player.location.z-pos.z-0.5) > 5) return;
        if (slot.next[index] || dim().getBlock(outputPosition(slot,index))?.typeId !== RUSH_PRODUCTS[index].output) return;
        updateOutput(slot,index,EMPTY);
        slot.stock[index]++;
        const tick = system.currentTick;
        slot.next[index] = tick + RUSH_PRODUCTS[index].refill;
        slot.harvestNotice = { index, until: tick + 20 };
        onStatus(player,match,slot);
    }

    function fillOrder(player) {
        const slot = activeSlot(player);
        if (!slot || match.phase !== 'racing' || system.currentTick >= match.ends || !mayRace(player) || !isInLane(slot)) return;
        const pos = RUSH_LANES[slot.index].orders;
        if (Math.hypot(player.location.x-pos.x-0.5, player.location.y-pos.y, player.location.z-pos.z-0.5) > 5) return;
        const order = RUSH_ORDERS[slot.order];
        if (order.need.some((count,index) => slot.stock[index] < count)) {
            return show(player,'§e'+order.name+' needs '+order.need.map((n,i)=>n+' '+RUSH_PRODUCTS[i].name).join(', ')+'.');
        }
        order.need.forEach((count,index) => { slot.stock[index] -= count; });
        slot.order++;
        slot.harvestNotice = undefined;
        show(player,'§a'+order.name+' filled ('+slot.order+'/'+RUSH_ORDERS.length+').');
        if (slot.order === RUSH_ORDERS.length) finish(match,player.isValid?slot:undefined,'§6'+player.name+' wins Generator Rush!');
    }

    function blockAction(event, breaking) {
        const { block, player } = event;
        if (!ready() || block.dimension.id !== OVERWORLD || !insideRushArena(block.location)) return;
        event.cancel = true;
        const slot = activeSlot(player);
        if (!slot || event.isFirstEvent === false) return;
        const pos = block.location;
        const lane = RUSH_LANES[slot.index];
        const isOrder = sameBlock(lane.orders,pos);
        const product = lane.generators.findIndex((core,index) => sameBlock(core,pos) ||
            (breaking && sameBlock(outputPosition(slot,index),pos)));
        if (!isOrder && product < 0) return;
        system.run(() => {
            if (!player.isValid || activeSlot(player) !== slot) return;
            try { if (isOrder) fillOrder(player); else harvest(slot,product,pos); }
            catch (error) { finish(match,undefined,'§cGenerator Rush stopped because the arena could not be updated.');
                console.warn('[Generator Rush] Arena action: '+error); }
        });
    }

    function rejoin(player) {
        if (!ready() || !player.isValid || activeSlot(player)) return false;
        if (inArena(player)) {
            trackExit(player);
            return true;
        }
        if (player.getDynamicProperty(RETURN_KEY) !== true) return false;
        if (safeReturn(player.dimension,player.location)) {
            clearExit(player);
            return false;
        }
        trackExit(player);
        return true;
    }

    function labelStations() {
        const region=dim();
        for (const label of laneLabels) if (region.isChunkLoaded(label.point)) onLabel(region,label);
    }

    system.runTimeout(() => { if (!match) releaseArea(); },20);
    world.beforeEvents.playerInteractWithBlock.subscribe(event=>blockAction(event,false));
    world.beforeEvents.playerBreakBlock.subscribe(event=>blockAction(event,true));
    world.beforeEvents.playerPlaceBlock?.subscribe(event=>{
        if (ready() && event.player.dimension.id === OVERWORLD && insideRushArena(event.block.location)) event.cancel = true;
    });
    world.beforeEvents.itemUse.subscribe(event=>{
        if (ready() && inArena(event.source) && !isMenuItem(event.itemStack)) event.cancel = true;
    });
    world.beforeEvents.entityHurt.subscribe(event => {
        if (ready() && event.hurtEntity.typeId === 'minecraft:player' && inArena(event.hurtEntity)) event.cancel = true;
    });
    world.afterEvents.playerLeave.subscribe(({ playerId }) => {
        queue.delete(playerId);
        returning.delete(playerId);
        if (match?.slots.some(slot => slot.player.id === playerId)) {
            finish(match,undefined,'§eGenerator Rush canceled after a disconnect.');
        }
    });

    system.runInterval(() => {
        for (const [id,exit] of returning) {
            const {player} = exit;
            if (!player.isValid) { returning.delete(id); continue; }
            if (system.currentTick < exit.next && inArena(player)) continue;
            try {
                if (system.currentTick < exit.next) {
                    if (safeReturn(player.dimension,player.location)) clearExit(player);
                } else sendOut(exit);
            } catch (error) {
                exit.next = system.currentTick+EXIT_BACKOFF;
                console.warn('[Generator Rush] Arena exit: '+error);
            }
        }
        for (const [id,player] of queue) {
            if (!player.isValid || !canPlay(player)) {
                queue.delete(id);
                show(player,'§eYou left the Generator Rush queue.');
            }
        }
        if (!match) {
            if (ready() && system.currentTick % 20 < 5) {
                for (const player of world.getAllPlayers()) if (inArena(player) && !returning.has(player.id)) trackExit(player);
            }
            if (queue.size >= 2) void startPair();
            return;
        }
        if (match.phase === 'loading' || match.phase === 'ending') return;
        try {
            const tick = system.currentTick;
            if (tick % 20 < 5) for (const player of world.getAllPlayers()) {
                if (inArena(player) && !activeSlot(player) && !returning.has(player.id)) trackExit(player);
            }
            if (match.phase === 'travel') {
                const still = match.slots.every(({player,lobby})=>player.isValid && canPlay(player) &&
                    Math.hypot(player.location.x-lobby.x,player.location.y-lobby.y,player.location.z-lobby.z)<0.16);
                if (!still) { finish(match,undefined,'§eMatch canceled because a player moved before entry.'); return; }
                if (tick >= match.travelAt) sendToLanes(match);
                return;
            }
            for (const slot of match.slots) {
                if (!mayRace(slot.player)) {
                    finish(match,undefined,'§eGenerator Rush canceled after a player left the arena.');
                    return;
                }
                if (!isInLane(slot) && !slot.player.tryTeleport(startFor(slot),{dimension:dim(),checkForBlocks:true})) {
                    finish(match,undefined,'§eGenerator Rush canceled after an unsafe exit.');
                    return;
                }
            }
            if (match.phase === 'countdown' && tick >= match.starts) {
                match.phase = 'racing';
                match.slots.forEach(slot=>show(slot.player,'§aGo! Fill all three orders before your opponent.'));
            }
            if (match.phase === 'racing' && tick >= match.ends) {
                const [a,b] = match.slots;
                const winner = a.order===b.order ? undefined : a.order>b.order ? a : b;
                finish(match,winner,winner?'§6Time! '+winner.player.name+' wins on completed orders.':'§eTime! Generator Rush ended in a draw.');
                return;
            }
            for (const slot of match.slots) {
                slot.next.forEach((due,index)=>{
                    if (due && due<=tick) { updateOutput(slot,index,RUSH_PRODUCTS[index].output); slot.next[index]=0; }
                });
                if (tick % 20 < 5) onStatus(slot.player,match,slot);
            }
        } catch (error) {
            if (match) finish(match,undefined,'§cGenerator Rush stopped after an arena error.');
            console.warn('[Generator Rush] Tick: '+error);
        }
    },5);

    return { join, leave, occupied, rejoin, labelStations,
        queued: player=>queue.has(player.id), racing: player=>Boolean(activeSlot(player)) };
}
