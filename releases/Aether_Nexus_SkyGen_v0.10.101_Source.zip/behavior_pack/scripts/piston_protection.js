import { StructureSaveMode } from '@minecraft/server';

// A piston can move a chain of 12 blocks. The last block can enter a
// protected column on the 13th step even when that column was empty.
export const PISTON_REACH = 13;
const STEPS = [
    { x:0,y:-1,z:0 }, { x:0,y:1,z:0 }, { x:0,y:0,z:1 },
    { x:0,y:0,z:-1 }, { x:1,y:0,z:0 }, { x:-1,y:0,z:0 },
];
const FACES = ['Down','Up','South','North','East','West'];
const id = position => position.x+','+position.y+','+position.z;
const offset = (loc, delta, multiplier = 1) =>
    ({ x:loc.x+delta.x*multiplier, y:loc.y+delta.y*multiplier, z:loc.z+delta.z*multiplier });

export function pistonType(type) {
    return type === 'minecraft:piston' || type === 'minecraft:sticky_piston';
}

export function inPistonBuffer(x, z, center, radius) {
    const edge = Math.max(Math.abs(x-center.x),Math.abs(z-center.z))-radius;
    return edge >= 1-PISTON_REACH && edge <= PISTON_REACH;
}

export function pistonPlacementBlocked(block, face, nearBoundary) {
    const loc = block.location;
    if (nearBoundary(loc.x,loc.z)) return true;
    const step = STEPS[FACES.indexOf(face)];
    return !!step && nearBoundary(loc.x+step.x,loc.z+step.z);
}

export function installPistonProtection(world, mechanicalArea, boundChest, refundPiston) {
    let serial = 0;

    world.afterEvents.pistonActivate.subscribe(({ piston, isExpanding }) => {
        let block, loc, structures;
        const snapshots = [];
        let retainSnapshots = false;
        try {
            block = piston.block;
            loc = block.location;
            const type = block.typeId;
            if (block.dimension.id !== 'minecraft:overworld' || !pistonType(type)) return;
            const step = STEPS[block.permutation.getState('facing_direction')];
            if (!step) return;
            const region = mechanicalArea(loc.x,loc.z);
            const crosses = point => mechanicalArea(point.x,point.z) !== region || !!boundChest(point);
            const arm = offset(loc,step);
            const moved = piston.getAttachedBlocksLocations().map(from=>({from,to:offset(from,step,isExpanding?1:-1)}));
            if (!crosses(arm) && !moved.some(({from,to})=>crosses(from)||crosses(to))) return;

            // Bedrock has already produced moving blocks. Removing the base settles them
            // synchronously, so we can capture their full permutations and block entities.
            const dimension = block.dimension;
            structures = world.structureManager;
            block.setType('minecraft:air');
            if (!block.isAir) throw Error('Piston could not be disarmed');
            const motion = ++serial;
            for (const {from,to} of moved) {
                const destination = dimension.getBlock(to);
                if (!destination || destination.isAir || destination.typeId === 'minecraft:moving_block') {
                    throw Error('Piston destination did not settle at '+id(to));
                }
                const name = 'skygen:piston_restore_'+motion+'_'+snapshots.length;
                const structure = structures.createFromWorld(name,dimension,to,to,{
                    includeEntities:false, saveMode:StructureSaveMode.Memory,
                });
                snapshots.push({from,to,structure,name,type:destination.typeId});
            }

            const destinations = new Set(snapshots.map(row=>id(row.to)));
            const restored = [];
            try {
                for (const {from} of snapshots) {
                    const source = dimension.getBlock(from);
                    if (!source || (!destinations.has(id(from)) && !source.isAir &&
                        !source.typeId.endsWith('piston_arm_collision'))) throw Error('Unexpected piston source at '+id(from));
                }
                for (const {to} of snapshots) dimension.getBlock(to).setType('minecraft:air');
                for (const row of snapshots) {
                    restored.push(row);
                    structures.place(row.structure,dimension,row.from,{includeEntities:false});
                    if (dimension.getBlock(row.from)?.typeId !== row.type) throw Error('Restored block could not be verified at '+id(row.from));
                }
            } catch (error) {
                // Recover the settled movement from the snapshots if the reverse move fails.
                try {
                    if (restored.length) for (const {from} of restored) dimension.getBlock(from).setType('minecraft:air');
                    for (const row of snapshots) structures.place(row.structure,dimension,row.to,{includeEntities:false});
                } catch (recovery) {
                    retainSnapshots = true;
                    console.error('[SkyGen PISTON] Restore snapshots '+snapshots.map(row=>row.name).join(', ')+' '+recovery);
                }
                throw error;
            } finally {
                refundPiston(dimension,loc,type);
            }
        } catch (error) {
            console.error('[SkyGen PISTON] Boundary movement at '+(loc?id(loc):'unknown')+' requires review. '+error);
        } finally {
            if (!retainSnapshots) for (const {name} of snapshots) structures.delete(name);
        }
    });
}
