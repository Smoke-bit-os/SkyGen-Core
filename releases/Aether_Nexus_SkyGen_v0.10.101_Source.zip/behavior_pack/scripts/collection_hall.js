import { APPROVED_COSMETIC_BUNDLES, grantCosmetic, validateCosmetics } from './cosmetic_entitlements.js';

const legacyCollections = {
    guardian: { bone: 6, rotten_flesh: 6, string: 4, iron_ingot: 8, coal: 16 },
    merchant: { copper_ingot: 8, redstone: 16, emerald: 2, gold_ingot: 8, lapis_lazuli: 16 },
    feast: { baked_potato: 4, pumpkin_pie: 4, cooked_salmon: 4, bread: 4, cooked_chicken: 4 },
};

const premiumItem = (id, label, needed, unitPrice, source, chance, subjects) => Object.freeze({
    item: 'skygen:' + id, label, needed, unitPrice, source, chance, subjects: Object.freeze(subjects),
});

export const COLLECTIONS = Object.freeze([
    {
        id: 'guardian', title: 'Guardian’s Relics', badge: 'sky_guardian_crest', items: [
            premiumItem('skeletal_bone', 'Skeletal Bone', 4, 750_000, 'Defeat skeletons or strays on your plot.', 0.10, ['minecraft:skeleton', 'minecraft:stray']),
            premiumItem('undead_remnant', 'Undead Remnant', 4, 750_000, 'Defeat zombies, husks, or drowned on your plot.', 0.10, ['minecraft:zombie', 'minecraft:husk', 'minecraft:drowned']),
            premiumItem('woven_silk', 'Woven Silk', 4, 1_000_000, 'Defeat spiders or cave spiders on your plot.', 0.10, ['minecraft:spider', 'minecraft:cave_spider']),
            premiumItem('forge_ember', 'Forge Ember', 2, 2_000_000, 'Harvest your Coal generator.', 0.05, ['minecraft:coal_ore']),
            premiumItem('obsidian_ward', 'Obsidian Ward', 2, 3_000_000, 'Harvest your Obsidian generator.', 0.05, ['minecraft:obsidian']),
        ],
    },
    {
        id: 'merchant', title: 'Merchant’s Stockpile', badge: 'merchant_insignia', items: [
            premiumItem('refined_iron', 'Refined Iron', 4, 750_000, 'Harvest your Iron generator.', 0.025, ['minecraft:iron_ore']),
            premiumItem('refined_gold', 'Refined Gold', 4, 750_000, 'Harvest your Gold generator.', 0.025, ['minecraft:gold_ore']),
            premiumItem('charged_redstone', 'Charged Redstone', 4, 1_000_000, 'Harvest your Redstone generator.', 0.025, ['minecraft:redstone_ore']),
            premiumItem('flawless_diamond', 'Flawless Diamond', 2, 2_000_000, 'Harvest your Diamond generator.', 0.025, ['minecraft:diamond_ore']),
            premiumItem('flawless_emerald', 'Flawless Emerald', 2, 3_000_000, 'Harvest your Emerald generator.', 0.025, ['minecraft:emerald_ore']),
        ],
    },
    {
        id: 'feast', title: 'Sky Feast Pantry', badge: 'sky_feast_crest', items: [
            premiumItem('prize_wheat', 'Prize Wheat', 4, 750_000, 'Harvest mature wheat on your plot.', 0.025, ['minecraft:wheat']),
            premiumItem('prize_carrot', 'Prize Carrot', 4, 750_000, 'Harvest mature carrots on your plot.', 0.025, ['minecraft:carrots']),
            premiumItem('prize_potato', 'Prize Potato', 4, 1_000_000, 'Harvest mature potatoes on your plot.', 0.025, ['minecraft:potatoes']),
            premiumItem('garden_cod', 'Garden Prize Cod', 2, 2_000_000, 'Reel in cod at the Garden pond.', 0.12, ['minecraft:cod', 'minecraft:fish']),
            premiumItem('garden_salmon', 'Garden Prize Salmon', 2, 3_000_000, 'Reel in salmon at the Garden pond.', 0.12, ['minecraft:salmon']),
        ],
    },
].map(collection => {
    const total = collection.items.reduce((sum, row) => sum + row.needed * row.unitPrice, 0);
    const price = APPROVED_COSMETIC_BUNDLES.find(bundle => bundle.badge === collection.badge)?.price;
    if (total !== price || new Set(collection.items.map(row => row.item)).size !== 5) {
        throw Error('Collection Hall requirements must match the badge price: ' + collection.id);
    }
    return Object.freeze({ ...collection, items: Object.freeze(collection.items), total });
}));

export function rollCollectionItem(collectionId, subject, random = Math.random) {
    const row = COLLECTIONS.find(collection => collection.id === collectionId)?.items.find(item => item.subjects.includes(subject));
    return row && random() < row.chance ? row : undefined;
}

const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function validateDonations(data, legacy = false) {
    if (!isRecord(data)) throw Error('Collection Hall donation records need staff review.');
    for (const [id, donations] of Object.entries(data)) {
        const definition = legacy ? (Object.hasOwn(legacyCollections, id) ? legacyCollections[id] : undefined)
            : COLLECTIONS.find(entry => entry.id === id);
        if (!definition || !isRecord(donations)) throw Error('Invalid Collection Hall donation record.');
        for (const [item, donated] of Object.entries(donations)) {
            const needed = legacy
                ? item.startsWith('minecraft:') && definition[item.slice('minecraft:'.length)]
                : definition.items.find(row => row.item === item)?.needed;
            if (!Number.isSafeInteger(needed) || !Number.isSafeInteger(donated) || donated < 1 || donated > needed) {
                throw Error('Invalid Collection Hall donation amount.');
            }
        }
    }
}

function collectionState(profile) {
    const state = profile.collectionHall;
    if (state === undefined) return { version: 2, donations: {} };
    if (!isRecord(state)) throw Error('Collection Hall data is invalid. Staff review required.');
    if (state.version === 1) {
        validateDonations(state.donations, true);
        return { version: 2, donations: {}, legacyDonations: state.donations };
    }
    if (state.version !== 2) throw Error('Unknown Collection Hall data version.');
    validateDonations(state.donations);
    if (state.legacyDonations !== undefined) validateDonations(state.legacyDonations, true);
    return state;
}

export function legacyCollectionDonation(profile, collectionId, item) {
    return collectionState(profile).legacyDonations?.[collectionId]?.[item] ?? 0;
}

export function collectionProgress(profile, collectionId) {
    const collection = COLLECTIONS.find(entry => entry.id === collectionId);
    if (!collection) return undefined;
    const state = collectionState(profile);
    const legacyItems = state.legacyDonations?.[collectionId];
    const legacyComplete = !!legacyItems && Object.entries(legacyCollections[collectionId])
        .every(([item, needed]) => legacyItems['minecraft:' + item] === needed);
    const saved = state.donations[collectionId] ?? {};
    const rows = collection.items.map(row => ({ ...row, donated: legacyComplete ? row.needed : saved[row.item] ?? 0 }));
    const completedTypes = rows.filter(row => row.donated === row.needed).length;
    const remainingValue = rows.reduce((sum, row) => sum + (row.needed - row.donated) * row.unitPrice, 0);
    return { ...collection, rows, completedTypes, remainingValue, complete: completedTypes === rows.length };
}

export function collectionQuote(profile, collectionId, item, count) {
    const row = collectionProgress(profile, collectionId)?.rows.find(entry => entry.item === item);
    if (!row || !Number.isSafeInteger(count) || count < 1 || count > row.needed - row.donated) return undefined;
    return { collectionId, item, count, donated: row.donated };
}

export function sameCollectionQuote(quoted, live) {
    return !!quoted && !!live && quoted.collectionId === live.collectionId && quoted.item === live.item &&
        quoted.count === live.count && quoted.donated === live.donated;
}

export function recordCollectionDonation(profile, quote) {
    const { collectionId, item, count, donated } = quote;
    if (!sameCollectionQuote(quote, collectionQuote(profile, collectionId, item, count))) {
        throw Error('Collection Hall donation changed.');
    }
    const progress = collectionProgress(profile, collectionId);
    const completing = progress.rows.every(row => (row.item === item ? donated + count : row.donated) === row.needed);
    const newBadge = completing && !validateCosmetics(profile).owned.includes(progress.badge);
    const state = collectionState(profile);
    if (newBadge) profile.cosmetics = grantCosmetic(profile, progress.badge);
    profile.collectionHall = {
        ...state,
        donations: {
            ...state.donations,
            [collectionId]: { ...state.donations[collectionId], [item]: donated + count },
        },
    };
    return { completing, newBadge, badge: progress.badge };
}
