import { EntitySwingSource, GameMode } from '@minecraft/server';
import { arenaWeaponState, restoreArenaWeapons, stageArenaWeapons } from './arena_weapon_guard.js';
import { playerAttacker } from './combat_scores.js';
import { MINIGAME_QUEUE_SECONDS, MINIGAME_QUEUE_TICKS } from './minigame_queue_movement.js';
import { ARENA_RETURN, OVERWORLD, REMOTE_ARENAS, arenaAt, offset, standing, teamBay } from './remote_arena_layout.js';
import { removeArenaArea } from './remote_arena_builder.js';

export { MINIGAME_QUEUE_SECONDS as ARENA_QUEUE_SECONDS };
export const ARENA_PLAYER_LIMIT = 10;
const ARENA_HEALTH = 20;
const MELEE_DAMAGE = 7;
const MELEE_COOLDOWN = 12;
const FLAG_TAG_DAMAGE = 10;
const KING_TARGET = 60;
const FLAG_TARGET = 3;
const WARMUP = 100;
const COUNTDOWN = 60;
const RETURN_KEY = 'sg_remote_arena_return_v1';
const RETURN_AREA = 'sg_remote_return';
const INSPECTION_AREA_PREFIX = 'sg_remote_inspect_';
const MARKER = 'sg_remote_flag_marker';
const EXTRA_TEAM = 'sg_ctf_extra_team_v1';
const MAX_RANGE = 3;

const between = (value, min, max) => value >= min && value <= max;
const span = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const near = (a, b, radius) => Math.abs(a.y - b.y) < 1.25 && Math.hypot(a.x - b.x, a.z - b.z) <= radius;
const notify = (player, text) => { if (player?.isValid) player.sendMessage(text); };
const members = match => match.slots.filter(slot => !slot.withdrawn);
const meleeWeapon = type => /^minecraft:(?:(?:wooden|stone|copper|golden|iron|diamond|netherite)_(?:sword|axe|spear)|mace|trident)$/.test(type) ||
    /^true_dn:(?:deathnerite|parcanite)_(?:sword|axe|spear)$/.test(type);
const recoveryTicks = match => match.spec.id === 'koth' ? 60 : 80;

export function assignArenaTeams(slots, extra, random = Math.random) {
    const ordered = slots.slice();
    for (let i = ordered.length - 1; i > 0; i--) {
        const index = Math.floor(random() * (i + 1));
        [ordered[i], ordered[index]] = [ordered[index], ordered[i]];
    }
    const redSize = Math.floor(ordered.length / 2) + Number(ordered.length % 2 === 1 && extra === 'red');
    return ordered.map((slot, i) => ({ slot, team: i < redSize ? 'red' : 'blue', pad: i < redSize ? i : i - redSize }));
}

export function createRemoteMinigames({
    world, system, queueMovement, ready, prepare, canJoin, isCompass, heldCompass, safeReturn, travel, rescueSpawn, openMenu, onIdentity, onResult,
    canInspect, canOpenInspection = () => true, isAdminAxe, openAdmin,
}) {
    const games = new Map(REMOTE_ARENAS.map(spec => [spec.id, { spec, queue: new Map() }]));
    const returning = new Map();
    const compassTick = new Map();
    const inspections = new Map();
    const loadingInspections = new Set();
    const dim = () => world.getDimension(OVERWORLD);
    let serial = 0, returningNow = false, initialized = false;
    const physical = player => player.dimension?.id === OVERWORLD && arenaAt(player.location.x, player.location.z);

    function active(player) {
        for (const game of games.values()) {
            const slot = game.match?.slots.find(item => item.id === player.id && !item.withdrawn);
            if (slot) return { game, slot };
        }
    }
    function queued(player) {
        return [...games.values()].find(game => game.queue.has(player.id));
    }
    function occupied(player) {
        return Boolean(active(player) || returning.has(player.id) || physical(player) || player.getDynamicProperty(RETURN_KEY));
    }
    function locked(player) {
        return Boolean(physical(player) || returning.has(player.id) || player.getDynamicProperty(RETURN_KEY) ||
            active(player)?.slot.arrived);
    }
    function involved(player) {
        return occupied(player) || Boolean(queued(player));
    }
    function inspection(player) {
        const spec = inspections.get(player.id);
        if (spec && player.isValid && canInspect(player) && physical(player) === spec &&
            player.location.y >= spec.origin.y + spec.bottom) return spec;
    }
    function canStartInspection(player) {
        return player.isValid && canInspect(player) && canOpenInspection(player) && !queued(player) && !active(player) &&
            !returning.has(player.id) && !player.getDynamicProperty(RETURN_KEY);
    }
    async function inspect(player, id) {
        const spec = games.get(id)?.spec;
        if (!canStartInspection(player)) return notify(player, '§cArena travel is unavailable. Check your admin access and leave any queue or match.');
        if (!spec || !initialized || !ready(spec)) return notify(player, '§eThis arena is still being prepared.');
        if (loadingInspections.has(player.id)) return notify(player, '§eYour arena destination is loading.');
        const target = standing(spec, Math.ceil((spec.min + spec.max) / 2), 6, spec.min);
        loadingInspections.add(player.id);
        try {
            await prepare(spec);
            if (!canStartInspection(player)) throw Error('Your admin access or travel status changed.');
            if (!safeReturn(dim(), target) || !travel(player, target, 0)) throw Error('The arena landing is unavailable.');
            inspections.set(player.id, spec);
            notify(player, '§aVisiting ' + spec.title + '. Open Admin Axe → Arena Teleports to return.');
        } catch (error) {
            notify(player, '§cCould not reach ' + spec.title + '. ' + error.message);
        } finally {
            loadingInspections.delete(player.id);
        }
    }
    function mayPlay(player) {
        return player.isValid && player.dimension.id === OVERWORLD &&
            [GameMode.Survival, GameMode.Adventure].includes(player.getGameMode()) && !player.isFlying && !player.isGliding;
    }
    function matchReady(match) {
        const players = members(match);
        return match.spec.id === 'koth' ? players.length >= 2
            : ['red', 'blue'].every(team => players.some(slot => slot.team === team));
    }
    function announce(match, text) {
        for (const slot of members(match)) notify(slot.player, text);
    }
    function guardedIdentity(player) {
        try { if (player.isValid) onIdentity(player); }
        catch (error) { console.warn('[SkyGen Arenas] Team display: ' + error); }
    }

    function finishReturn(player) {
        if (!player.isValid) return;
        player.extinguishFire(false);
        if ((player.getComponent('minecraft:onfire')?.onFireTicksRemaining ?? 0) > 0) {
            throw Error('Arena fire did not clear.');
        }
        if (player.getDynamicProperty(RETURN_KEY)) restoreArenaWeapons(player);
        player.setDynamicProperty(RETURN_KEY, undefined);
        returning.delete(player.id);
        guardedIdentity(player);
    }
    function trackReturn(player, spec) {
        if (player.isValid && !returning.has(player.id)) {
            returning.set(player.id, { player, spec, next: system.currentTick, landed: false });
        }
    }
    async function returnPlayers() {
        const due = [...returning.values()].filter(entry => system.currentTick >= entry.next);
        if (returningNow || !due.length) return;
        returningNow = true;
        try {
            const region = dim();
            const manager = world.tickingAreaManager;
            if (!region.isChunkLoaded(ARENA_RETURN)) {
                const area = { dimension: region, from: ARENA_RETURN, to: ARENA_RETURN };
                if (manager.hasCapacity(area)) await manager.createTickingArea(RETURN_AREA, area);
            }
            const landings = [ARENA_RETURN, { ...ARENA_RETURN, x: -7.5 }, { ...ARENA_RETURN, z: 62.5 }];
            for (const entry of due) {
                const player = entry.player;
                if (returning.get(player.id) !== entry) continue;
                if (!player.isValid) { returning.delete(player.id); continue; }
                entry.next = system.currentTick + 100;
                try {
                    if (entry.landed) {
                        finishReturn(player);
                        continue;
                    }
                    player.extinguishFire(false);
                    const target = landings.find(location => region.isChunkLoaded(location) && safeReturn(region, location));
                    if (target && travel(player, target)) {
                        entry.landed = true;
                        finishReturn(player);
                    } else rescueSpawn(player, () => {
                        if (returning.get(player.id) !== entry) return;
                        entry.landed = true;
                        try { finishReturn(player); }
                        catch (error) { console.warn('[SkyGen Arenas] Spawn cleanup: ' + error); }
                    });
                } catch (error) { console.warn('[SkyGen Arenas] Exit: ' + error); }
            }
        } catch (error) {
            for (const entry of due) entry.next = system.currentTick + 100;
            console.warn('[SkyGen Arenas] Colosseum return: ' + error);
        } finally {
            try { removeArenaArea(world, RETURN_AREA); }
            finally { returningNow = false; }
        }
    }
    function rejoin(player) {
        if (active(player) || inspection(player)) return false;
        const saved = player.getDynamicProperty(RETURN_KEY);
        const spec = games.get(saved)?.spec ?? physical(player) ?? inspections.get(player.id);
        inspections.delete(player.id);
        if (!spec) return false;
        trackReturn(player, spec);
        return true;
    }

    function dropFlag(match, slot) {
        if (!match.flags) return;
        const held = match.flags.find(flag => flag.carrier === slot.id);
        if (!held) return;
        if (!slot.drop) {
            returnFlag(match, held);
            return;
        }
        held.carrier = undefined;
        held.position = slot.drop;
        held.expires = system.currentTick + 300;
        announce(match, held.side.color + held.side.name + ' flag dropped.');
    }
    function returnFlag(match, flag) {
        flag.carrier = undefined;
        flag.position = undefined;
        flag.expires = undefined;
        announce(match, flag.side.color + flag.side.name + ' flag is home.');
    }
    function end(game, match, result, text) {
        if (game.match !== match || match.phase === 'ending') return;
        match.phase = 'ending';
        for (const { player } of members(match)) queueMovement.unlock(player);
        announce(match, text);
        if (result) {
            try {
                if (onResult(match, result) === false) announce(match, '§eResult pending. It will be saved automatically.');
            }
            catch (error) { announce(match, '§eThe result needs operator review.'); console.warn('[SkyGen Arenas] Result: ' + error); }
        }
        game.match = undefined;
        for (const slot of members(match)) {
            if (!slot.player.isValid) continue;
            if (slot.arrived || slot.player.getDynamicProperty(RETURN_KEY)) trackReturn(slot.player, match.spec);
            else guardedIdentity(slot.player);
        }
        for (const flag of match.flags ?? []) if (flag.visual?.isValid) flag.visual.remove();
    }
    function withdraw(game, slot, disconnected = false) {
        const match = game.match;
        if (!match || slot.withdrawn) return;
        dropFlag(match, slot);
        slot.withdrawn = true;
        queueMovement.unlock(slot.player);
        if (slot.arrived && !disconnected) trackReturn(slot.player, match.spec);
        if (!disconnected) guardedIdentity(slot.player);
        const required = match.phase === 'warmup' ? members(match).length >= 2 : matchReady(match);
        if (required) return;
        const earnedCaptures = match.phase === 'live' && match.spec.id === 'ctf' &&
            match.slots.some(member => member.score > 0);
        end(game, match, earnedCaptures ? {} : undefined, '§e' + game.spec.title + ' canceled because too few players remain.');
    }

    function join(player, id) {
        const game = games.get(id);
        if (!game || !initialized || !ready(game.spec)) return notify(player, '§eThis remote arena is still being prepared.');
        if (!mayPlay(player) || !canJoin(player)) return notify(player, '§eJoin in Survival or Adventure when travel is available.');
        if (involved(player)) return notify(player, '§eLeave your other minigame or queue first.');
        if (game.match) return notify(player, '§eA match is in progress. Join when it ends.');
        const tick = system.currentTick;
        if (game.closes !== undefined && tick >= game.closes && game.queue.size >= 2) {
            return notify(player, '§eThe join window closed. Join the next match.');
        }
        if (game.queue.size >= ARENA_PLAYER_LIMIT) return notify(player, '§eAll ten seats are taken.');
        if (!queueMovement.lock(player)) return notify(player, '§cMovement could not be locked. Try joining again.');
        if (!game.queue.size || (game.closes !== undefined && tick >= game.closes)) game.closes = undefined;
        game.queue.set(player.id, player);
        notify(player, '§aJoined the ' + game.spec.title + ' queue. Use the Compass to leave.');
        if (game.queue.size >= 2 && game.closes === undefined) {
            game.closes = system.currentTick + MINIGAME_QUEUE_TICKS;
            for (const viewer of game.queue.values()) {
                notify(viewer, '§a' + game.spec.title + ' queue closes in ' + MINIGAME_QUEUE_SECONDS + ' seconds.');
            }
        }
    }
    function removeQueued(game, player) {
        game.queue.delete(player.id);
        if (game.queue.size < 2) game.closes = undefined;
        queueMovement.unlock(player);
    }
    function leave(player) {
        const waiting = queued(player);
        if (waiting) {
            removeQueued(waiting, player);
            return notify(player, '§eYou left the queue.');
        }
        const visiting = inspection(player);
        if (visiting) {
            inspections.delete(player.id);
            trackReturn(player, visiting);
            return;
        }
        const entrant = active(player);
        if (entrant) withdraw(entrant.game, entrant.slot);
        else rejoin(player);
    }
    function gameFor(player) {
        return active(player)?.game.spec ?? queued(player)?.spec ?? returning.get(player.id)?.spec ?? physical(player);
    }
    function view(player, id) {
        const game = games.get(id);
        if (!game) return {};
        const current = active(player);
        return {
            queued: game.queue.has(player.id), count: game.queue.size, playing: current?.game === game,
            returning: returning.has(player.id), visiting: inspection(player) === game.spec, busy: Boolean(game.match),
            time: game.closes === undefined ? undefined : Math.max(0, Math.ceil((game.closes - system.currentTick) / 20)),
        };
    }

    function startWarmup(game, tick) {
        if (game.queue.size < 2) return;
        const slots = [...game.queue.values()].map(player => ({
            player, id: player.id, start: { ...player.location }, score: 0, health: ARENA_HEALTH, readyAt: 0, nextAttack: 0,
        }));
        game.queue.clear();
        game.closes = undefined;
        game.match = {
            spec: game.spec, id: Date.now() + '-' + tick + '-' + (++serial),
            phase: 'warmup', warpAt: tick + WARMUP, slots,
        };
        announce(game.match, '§eMatch ready. Entering ' + game.spec.title + ' in 5 seconds.');
    }
    function assignPads(match) {
        const spec = match.spec, slots = members(match);
        if (spec.id === 'koth') {
            slots.forEach((slot, i) => {
                const [x, z] = spec.pads[i];
                slot.pad = standing(spec, x, 0, z);
                slot.yaw = Math.atan2(x, -z) * 180 / Math.PI;
            });
            return;
        }
        const extra = world.getDynamicProperty(EXTRA_TEAM) === 'blue' ? 'blue' : 'red';
        for (const { slot, team, pad } of assignArenaTeams(slots, extra)) {
            slot.team = team;
            slot.pad = standing(spec, spec.sides[team].x, 0, spec.spawnRows[pad]);
            slot.yaw = team === 'red' ? -90 : 90;
        }
        match.nextExtra = slots.length % 2 ? (extra === 'red' ? 'blue' : 'red') : undefined;
        match.points = { red: 0, blue: 0 };
        match.flags = ['red', 'blue'].map(team => {
            const side = spec.sides[team];
            return { team, side, home: standing(spec, side.pedestal[0], 0, side.pedestal[1]) };
        });
    }
    async function stageMatch(game, match) {
        try {
            assignPads(match);
            match.phase = 'staging';
            announce(match, '§eChecking the full arena before travel.');
            await prepare(match.spec);
            if (game.match !== match) return;
            const region = dim();
            for (const slot of members(match)) {
                if (!mayPlay(slot.player) || !safeReturn(region, slot.pad)) throw Error('A starting pad or player is unavailable.');
            }
            for (const slot of members(match)) {
                slot.player.setDynamicProperty(RETURN_KEY, match.spec.id);
                if (slot.player.getDynamicProperty(RETURN_KEY) !== match.spec.id) throw Error('Could not save the return route.');
                slot.arrived = true;
                stageArenaWeapons(slot.player, match.id, item => meleeWeapon(item.typeId) && !isAdminAxe(item));
                if (!travel(slot.player, slot.pad, slot.yaw)) throw Error('Could not reach a starting pad.');
                guardedIdentity(slot.player);
                if (slot.team) notify(slot.player, match.spec.sides[slot.team].color + 'Team ' + match.spec.sides[slot.team].name);
            }
            if (match.nextExtra) world.setDynamicProperty(EXTRA_TEAM, match.nextExtra);
            match.phase = 'countdown';
            match.liveAt = system.currentTick + COUNTDOWN;
        } catch (error) {
            end(game, match, undefined, '§c' + match.spec.title + ' could not start. ' + error.message);
        }
    }

    function respawn(slot, ticks) {
        slot.player.extinguishFire(false);
        if (!travel(slot.player, slot.pad, slot.yaw)) throw Error('Could not reach a recovery pad.');
        slot.player.clearVelocity();
        slot.health = ARENA_HEALTH;
        slot.readyAt = system.currentTick + ticks;
        slot.drop = undefined;
    }
    function available(match, slot, tick) {
        return !slot.withdrawn && slot.arrived && tick >= slot.readyAt &&
            mayPlay(slot.player) && physical(slot.player) === match.spec;
    }

    function aimedOpponent(match, slot, tick) {
        const hit = slot.player.getEntitiesFromViewDirection({
            maxDistance: MAX_RANGE, ignoreBlockCollision: false, type: 'minecraft:player',
        }).sort((a, b) => a.distance - b.distance)[0];
        const target = hit && match.slots.find(member => member.id === hit.entity.id && member !== slot);
        if (!target || !available(match, target, tick) || (slot.team && target.team === slot.team)) return;
        return target;
    }

    function shove(player, target, horizontal, vertical) {
        const direction = player.getViewDirection(), distance = Math.hypot(direction.x, direction.z);
        if (distance > .001) {
            target.applyKnockback({ x: horizontal * direction.x / distance, z: horizontal * direction.z / distance }, vertical);
        }
    }

    function damageFighter(match, target, damage, message) {
        if (target.health > damage) {
            target.health -= damage;
            return false;
        }
        const ticks = recoveryTicks(match);
        dropFlag(match, target);
        respawn(target, ticks);
        notify(target.player, '§e' + message + ' Return to play in ' + ticks / 20 + ' seconds.');
        return true;
    }

    function weaponAttack(player) {
        const entrant = active(player);
        if (!entrant) return;
        const { game, slot } = entrant, match = game.match, tick = system.currentTick;
        if (match.phase !== 'live' || tick >= match.endsAt || tick < slot.nextAttack || !available(match, slot, tick)) return;
        slot.nextAttack = tick + MELEE_COOLDOWN;
        const target = aimedOpponent(match, slot, tick);
        if (!target) return;
        if (damageFighter(match, target, MELEE_DAMAGE, player.name + ' knocked you out.')) {
            notify(player, '§aYou knocked out ' + target.player.name + '.');
        } else shove(player, target.player, .25, .08);
    }

    function compass(player) {
        const tick = system.currentTick;
        if (tick - (compassTick.get(player.id) ?? -100) < 4) return;
        compassTick.set(player.id, tick);
        const entrant = active(player);
        if (!entrant || entrant.game.match.phase !== 'live' || player.isSneaking) {
            const spec = gameFor(player);
            if (spec) openMenu(player, spec.id);
            return;
        }
        const { game, slot } = entrant, match = game.match;
        if (tick >= match.endsAt || tick < slot.nextAttack || !available(match, slot, tick)) return;
        slot.nextAttack = tick + 20;
        const target = aimedOpponent(match, slot, tick);
        if (!target) return;
        if (match.spec.id === 'koth') {
            shove(player, target.player, .85, .24);
            return;
        }
        damageFighter(match, target, FLAG_TAG_DAMAGE, 'Tagged out.');
    }

    function stepKing(game, match, live) {
        const { origin } = match.spec;
        const standingOnHill = live.filter(({ player }) => {
            const point = player.location;
            return player.isOnGround && Math.abs(point.y - origin.y - 5) < .2 &&
                between(Math.floor(point.x) - origin.x, -3, 3) && between(Math.floor(point.z) - origin.z, -3, 3);
        });
        const holder = standingOnHill.length === 1 ? standingOnHill[0] : undefined;
        match.hill = standingOnHill.length > 1 ? 'Contested' : holder?.player.name ?? 'Open';
        if (match.holder !== holder) { match.holder = holder; match.holdTicks = 0; }
        if (holder && ++match.holdTicks >= 20) {
            match.holdTicks = 0;
            if (++holder.score === KING_TARGET) {
                end(game, match, { winner: holder }, '§6' + holder.player.name + ' wins King of the Hill!');
            }
        }
    }

    function pickFlag(match, flag, slot) {
        flag.carrier = slot.id;
        flag.position = undefined;
        flag.expires = undefined;
        announce(match, flag.side.color + flag.side.name + ' flag taken by ' + slot.player.name + '.');
    }
    function stepFlags(game, match, live, tick) {
        for (const flag of match.flags) {
            if (flag.carrier) continue;
            if (flag.position) {
                if (tick >= flag.expires || live.some(slot => slot.team === flag.team && near(slot.player.location, flag.position, 1.5))) {
                    returnFlag(match, flag);
                    continue;
                }
            }
            const point = flag.position ?? flag.home;
            const carrier = live.find(slot => slot.team !== flag.team && near(slot.player.location, point, flag.position ? 1.5 : 2));
            if (carrier) pickFlag(match, flag, carrier);
        }
        for (const flag of match.flags) {
            const runner = live.find(slot => slot.id === flag.carrier);
            if (!runner) continue;
            const home = match.flags.find(candidate => candidate.team === runner.team);
            if (home.carrier || home.position || !near(runner.player.location, home.home, 2)) continue;
            runner.score++;
            match.points[runner.team]++;
            returnFlag(match, flag);
            announce(match, home.side.color + runner.player.name + ' captured the flag. ' +
                match.points.red + ' Red / ' + match.points.blue + ' Blue.');
            if (match.points[runner.team] === FLAG_TARGET) {
                end(game, match, { team: runner.team }, home.side.color + home.side.name + ' wins Capture the Flag!');
                return;
            }
        }
    }
    function timeout(game, match) {
        if (match.spec.id === 'ctf') {
            const { red, blue } = match.points;
            const team = red === blue ? undefined : red > blue ? 'red' : 'blue';
            const side = team && match.spec.sides[team];
            end(game, match, { team }, side ? side.color + 'Time! ' + side.name + ' wins.' : '§eCapture the Flag ended in a draw.');
            return;
        }
        const ranked = members(match).sort((a, b) => b.score - a.score);
        const winner = ranked[0].score === ranked[1].score ? undefined : ranked[0];
        end(game, match, { winner }, winner ? '§6Time! ' + winner.player.name + ' wins King of the Hill.' : '§eKing of the Hill ended in a draw.');
    }
    function baseAccess(match, slot) {
        if (match.spec.id !== 'ctf') return;
        const here = slot.player.location;
        const bay = teamBay(here);
        if (bay && (bay !== slot.team || match.flags.some(flag => flag.carrier === slot.id))) {
            const side = match.spec.sides[bay];
            const target = offset(match.spec, side.exit + .5, .02, Math.min(95.5, Math.max(54.5, here.z - match.spec.origin.z)));
            if (!travel(slot.player, target, slot.yaw)) throw Error('Respawn bay boundary could not be enforced.');
            slot.player.clearVelocity();
        }
        const position = slot.player.location;
        if (!teamBay(position) && Math.abs(position.y - match.spec.origin.y) < .3 && slot.player.isOnGround) {
            slot.drop = { ...position };
        }
    }
    function updateVisuals() {
        const region = dim(), match = games.get('ctf').match;
        const flags = match?.phase === 'live' || match?.phase === 'countdown' ? match.flags : [];
        const owned = new Set(flags.map(flag => flag.visual?.id));
        for (const orphan of region.getEntities({ type: 'monkey:floatingtext', tags: [MARKER] })) {
            if (!owned.has(orphan.id)) orphan.remove();
        }
        for (const flag of flags) {
            const runner = flag.carrier && members(match).find(slot => slot.id === flag.carrier)?.player;
            const position = runner?.isValid ? runner.location : flag.position ?? flag.home;
            const point = { ...position, y: position.y + (runner ? 2.7 : 2.45) };
            if (!region.isChunkLoaded(point)) continue;
            if (!flag.visual?.isValid) {
                flag.visual = region.spawnEntity('monkey:floatingtext', point, { spawnEvent: 'text', initialPersistence: false });
                flag.visual.addTag(MARKER);
            } else flag.visual.teleport(point);
            const text = flag.side.color + flag.side.name + ' Flag' + (runner ? ' §7· §f' + runner.name : flag.position ? ' §7· Dropped' : '');
            if (flag.visual.nameTag !== text) flag.visual.nameTag = text;
        }
    }
    function clock(seconds) {
        return Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
    }
    function hud(match, slot, tick) {
        const screen = slot.player.onScreenDisplay;
        if (match.phase === 'countdown') return screen.setActionBar('§e' + match.spec.short + ' starts in ' +
            Math.max(1, Math.ceil((match.liveAt - tick) / 20)) + 's');
        if (tick < slot.readyAt) return screen.setActionBar('§eRecovering · ' + Math.ceil((slot.readyAt - tick) / 20) + 's');
        const time = clock(Math.max(0, Math.ceil((match.endsAt - tick) / 20)));
        const health = ' · HP ' + slot.health + '/' + ARENA_HEALTH;
        if (match.spec.id === 'koth') {
            screen.setActionBar('§6KOTH §f' + time + ' · You ' + slot.score + '/60 · ' + match.hill + health);
            return;
        }
        const [red, blue] = match.flags.map(flag => flag.carrier ? 'Away' : flag.position ? 'Dropped' : 'Home');
        const color = match.spec.sides[slot.team].color;
        const carrying = match.flags.some(flag => flag.carrier === slot.id);
        const ownFlagHome = (slot.team === 'red' ? red : blue) === 'Home';
        const instruction = carrying ? ownFlagHome ? ' · Your glass stand' : ' · Return your flag to score' : '';
        screen.setActionBar('§cR ' + match.points.red + ' §9B ' + match.points.blue + ' §f' + time +
            ' · R ' + red + ' / B ' + blue + color + health + instruction);
    }

    function tickGame(game, tick) {
        if (!game.match) {
            if (tick % 10 && (game.closes === undefined || tick < game.closes)) return;
            for (const player of game.queue.values()) {
                if (!mayPlay(player) || !canJoin(player) || !queueMovement.atStart(player)) {
                    removeQueued(game, player);
                    notify(player, '§eYou left the ' + game.spec.title + ' queue.');
                }
            }
            if (!game.queue.size) { game.closes = undefined; return; }
            if (game.closes === undefined && game.queue.size >= 2) game.closes = tick + MINIGAME_QUEUE_TICKS;
            if (game.closes !== undefined && tick >= game.closes) {
                if (game.queue.size >= 2) startWarmup(game, tick);
                else game.closes = undefined;
                return;
            }
            if (tick % 20 === 0) for (const player of game.queue.values()) {
                player.onScreenDisplay.setActionBar('§e' + game.spec.short + ' · ' + game.queue.size + '/10 · ' +
                    (game.closes === undefined ? 'Waiting for 2 players' : 'Join window ' + clock(Math.ceil((game.closes - tick) / 20))));
            }
            return;
        }
        const match = game.match;
        if (match.phase === 'warmup') {
            for (const slot of members(match)) {
                if (!mayPlay(slot.player) || !canJoin(slot.player) || span(slot.start, slot.player.location) >= .16) {
                    notify(slot.player, '§eArena warm-up canceled because you moved or became unavailable.');
                    withdraw(game, slot);
                    if (game.match !== match) return;
                }
            }
            if (tick >= match.warpAt) void stageMatch(game, match);
            return;
        }
        if (match.phase === 'staging' || match.phase === 'ending') return;
        for (const slot of members(match)) {
            if (!mayPlay(slot.player)) {
                withdraw(game, slot, !slot.player.isValid);
                if (game.match !== match) return;
                continue;
            }
            const point = slot.player.location, spec = match.spec;
            if (physical(slot.player) !== spec || point.y < spec.origin.y - 2 || point.y > spec.origin.y + 8) {
                dropFlag(match, slot);
                respawn(slot, recoveryTicks(match));
            } else if ((match.phase === 'countdown' || tick < slot.readyAt) && span(slot.pad, point) > .85) {
                if (!travel(slot.player, slot.pad, slot.yaw)) throw Error('Could not secure a starting pad.');
            }
            baseAccess(match, slot);
        }
        if (match.phase === 'countdown' && tick >= match.liveAt) {
            for (const { player } of members(match)) queueMovement.unlock(player);
            match.phase = 'live';
            match.endsAt = tick + (match.spec.id === 'koth' ? 4800 : 9600);
            announce(match, '§aGo! ' + (match.spec.id === 'koth' ? 'Hold the summit alone.' :
                'Take the enemy flag to your glass stand while your flag is home.'));
        }
        if (match.phase === 'live') {
            if (tick >= match.endsAt) return timeout(game, match);
            const live = members(match).filter(slot => available(match, slot, tick));
            if (match.spec.id === 'koth') stepKing(game, match, live);
            else stepFlags(game, match, live, tick);
        }
        if (game.match === match && tick % 10 === 0) for (const slot of members(match)) hud(match, slot, tick);
    }

    function useArenaTool(player, item, allowHeldCompass = false) {
        if (inspection(player) && isAdminAxe(item)) {
            system.run(() => { if (inspection(player)) openAdmin(player); });
        } else if (isCompass(item) || (allowHeldCompass && heldCompass(player))) {
            system.run(() => safeCompass(player));
        }
    }

    world.beforeEvents.itemUse.subscribe(event => {
        const player = event.source;
        if (!locked(player)) return;
        event.cancel = true;
        useArenaTool(player, event.itemStack);
    });
    for (const signal of [world.beforeEvents.playerInteractWithBlock, world.beforeEvents.playerInteractWithEntity]) {
        signal?.subscribe(event => {
            const player = event.player;
            if (!locked(player)) return;
            event.cancel = true;
            if (event.isFirstEvent !== false) useArenaTool(player, event.itemStack, true);
        });
    }
    world.beforeEvents.entityHurt.subscribe(event => {
        const victim = event.hurtEntity;
        const attacker = playerAttacker(event.damageSource);
        const protectedPlayer = victim.typeId === 'minecraft:player' && locked(victim);
        if (protectedPlayer || (attacker && locked(attacker))) {
            event.cancel = true;
            event.damage = 0;
            if (!protectedPlayer || !attacker || !['entityAttack', 'projectile'].includes(event.damageSource.cause)) return;
            system.run(() => {
                if (victim.isValid && locked(victim)) victim.extinguishFire(false);
            });
        }
    });
    world.afterEvents.playerSwingStart.subscribe(({ player, heldItemStack, swingSource }) => {
        if (swingSource !== EntitySwingSource.Attack && swingSource !== EntitySwingSource.None) return;
        if (!meleeWeapon(heldItemStack?.typeId) || isAdminAxe(heldItemStack)) return;
        try { weaponAttack(player); }
        catch (error) { console.warn('[SkyGen Arenas] Weapon attack: ' + error); }
    });
    world.beforeEvents.entityItemPickup?.subscribe(event => {
        const { item, entity } = event;
        if (item.dimension.id !== OVERWORLD || !arenaAt(item.location.x, item.location.z)) return;
        try {
            const state = arenaWeaponState(item.getComponent('minecraft:item')?.itemStack);
            if (state && entity.id !== state.owner) event.cancel = true;
        } catch (error) {
            event.cancel = true;
            console.warn('[SkyGen Arenas] Protected item pickup: ' + error);
        }
    });
    world.afterEvents.playerInventoryItemChange?.subscribe(({ player, itemStack }) => {
        if (!itemStack || !player.isValid) return;
        try {
            const state = arenaWeaponState(itemStack);
            if (!state) return;
            const entrant = active(player);
            const matchId = entrant?.slot.arrived ? entrant.game.match.id : undefined;
            if (state.owner !== player.id || state.matchId !== matchId) restoreArenaWeapons(player, matchId);
        } catch (error) { console.warn('[SkyGen Arenas] Protected item recovery: ' + error); }
    });
    world.afterEvents.entitySpawn.subscribe(({ entity }) => {
        if (entity.isValid && entity.dimension.id === OVERWORLD && arenaAt(entity.location.x, entity.location.z) &&
            entity.matches({ families: ['monster'] })) entity.remove();
    });
    world.afterEvents.entityDie.subscribe(({ deadEntity }) => {
        if (deadEntity.typeId !== 'minecraft:player') return;
        const waiting = queued(deadEntity);
        if (waiting) removeQueued(waiting, deadEntity);
        const entrant = active(deadEntity);
        if (entrant) withdraw(entrant.game, entrant.slot, true);
    });
    world.afterEvents.playerLeave.subscribe(({ playerId }) => {
        compassTick.delete(playerId);
        returning.delete(playerId);
        inspections.delete(playerId);
        for (const game of games.values()) {
            if (game.queue.delete(playerId) && game.queue.size < 2) game.closes = undefined;
            const slot = game.match?.slots.find(item => item.id === playerId);
            if (slot) withdraw(game, slot, true);
        }
    });
    function safeCompass(player) {
        try { if (player.isValid) compass(player); }
        catch (error) { console.warn('[SkyGen Arenas] Compass: ' + error); }
    }

    system.runTimeout(() => {
        for (const area of world.tickingAreaManager.getAllTickingAreas()) {
            const id = area.identifier;
            if (id?.startsWith('sg_remote_match_') || id?.startsWith(INSPECTION_AREA_PREFIX) || id === RETURN_AREA) {
                removeArenaArea(world, id);
            }
        }
        initialized = true;
    }, 20);
    system.runInterval(() => {
        if (!initialized) return;
        const tick = system.currentTick;
        for (const game of games.values()) {
            try { tickGame(game, tick); }
            catch (error) {
                console.warn('[' + game.spec.title + '] ' + error);
                if (game.match) end(game, game.match, undefined, '§cMatch stopped after an arena error.');
            }
        }
        if (tick % 5 === 0) {
            if (returning.size) void returnPlayers();
            try { if (games.get('ctf').match || tick % 100 === 0) updateVisuals(); }
            catch (error) { if (tick % 100 === 0) console.warn('[Capture the Flag] Marker: ' + error); }
        }
        if (tick % 20 === 0) for (const player of world.getAllPlayers()) {
            if (inspections.has(player.id) || physical(player) || player.getDynamicProperty(RETURN_KEY)) rejoin(player);
        }
    }, 1);
    return { join, leave, involved, occupied, locked, rejoin, gameFor, view, inspect, compass: safeCompass,
        isInspecting: player => Boolean(inspection(player)), team: player => active(player)?.slot.team };
}
