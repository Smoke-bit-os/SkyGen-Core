import { centralWeekStart } from './central_week.js';

export const NEXUS_BEACON_GOAL = 120;
export const NEXUS_BEACON_ITEMS = Object.freeze({
    'minecraft:cobblestone': { label: 'Cobblestone', category: 'Mining', points: 1 },
    'minecraft:coal': { label: 'Coal', category: 'Mining', points: 1 },
    'minecraft:wheat': { label: 'Wheat', category: 'Farming', points: 2 },
    'minecraft:carrot': { label: 'Carrots', category: 'Farming', points: 2 },
    'minecraft:potato': { label: 'Potatoes', category: 'Farming', points: 2 },
    'minecraft:cod': { label: 'Raw Cod', category: 'Fishing', points: 5 },
    'minecraft:salmon': { label: 'Raw Salmon', category: 'Fishing', points: 5 },
    'minecraft:tropical_fish': { label: 'Tropical Fish', category: 'Fishing', points: 5 },
    'minecraft:clownfish': { label: 'Tropical Fish', category: 'Fishing', points: 5 },
    'minecraft:pufferfish': { label: 'Pufferfish', category: 'Fishing', points: 5 },
});

const WEEK_KEY = 'sg_nexus_beacon_v1_';
const validWeek = /^\d{4}-\d{2}-\d{2}$/u;

export function beaconQuote(state, item, count) {
    const unit = Object.hasOwn(NEXUS_BEACON_ITEMS, item) ? NEXUS_BEACON_ITEMS[item].points : 0;
    const remaining = NEXUS_BEACON_GOAL - state.total;
    if (!unit || remaining <= 0 || !Number.isSafeInteger(count) || count < 1 ||
        count > Math.ceil(remaining / unit)) return undefined;
    return { week: state.week, item, count, points: Math.min(remaining, count * unit) };
}

export function beaconQuoteForOrder(state, item, count) {
    if (!Object.hasOwn(NEXUS_BEACON_ITEMS, item)) return undefined;
    const remaining = NEXUS_BEACON_GOAL - state.total;
    const eligible = Math.min(count, Math.ceil(remaining / NEXUS_BEACON_ITEMS[item].points));
    return beaconQuote(state, item, eligible);
}

export function sameBeaconQuote(first, second) {
    return Boolean(first && second && first.week === second.week && first.item === second.item &&
        first.count === second.count && first.points === second.points);
}

export function createNexusBeaconStore(storage, clock = Date.now) {
    function readWeek(week) {
        if (!validWeek.test(week)) throw Error('Invalid Nexus Beacon week');
        const raw = storage.getDynamicProperty(WEEK_KEY + week);
        if (raw === undefined) return { week, total: 0, contributors: [] };
        const state = JSON.parse(raw);
        if (state?.version !== 1 || state.week !== week || !Array.isArray(state.contributors) ||
            !Number.isSafeInteger(state.total) || state.total < 0 || state.total > NEXUS_BEACON_GOAL) {
            throw Error('Nexus Beacon saved progress needs operator review.');
        }
        let total = 0;
        const players = new Set();
        for (const entry of state.contributors) {
            if (!Array.isArray(entry) || entry.length !== 4) throw Error('Invalid Beacon contributor');
            const [id, name, points, receipt] = entry;
            if (typeof id !== 'string' || !id || players.has(id) ||
                typeof name !== 'string' || !name || typeof receipt !== 'string' || !receipt ||
                !Number.isSafeInteger(points) || points < 1 || points > NEXUS_BEACON_GOAL) {
                throw Error('Invalid Beacon contribution record');
            }
            players.add(id);
            total += points;
        }
        if (total !== state.total) throw Error('Nexus Beacon total does not match contribution records.');
        return state;
    }

    function current(at = clock()) {
        return readWeek(centralWeekStart(at));
    }

    function hasReceipt(week, playerId, receipt) {
        return readWeek(week).contributors.some(([id, , , latest]) => id === playerId && latest === receipt);
    }

    function applyContribution(before, quote, playerId, name, receipt) {
        const index = before.contributors.findIndex(([id]) => id === playerId);
        const previous = before.contributors[index];
        if (previous?.[3] === receipt) {
            return { state: before, completed: false, repeated: true };
        }
        const live = quote && beaconQuote(before, quote.item, quote.count);
        if (!sameBeaconQuote(quote, live)) throw Error('The Beacon quote changed.');
        const contributors = before.contributors.slice();
        const entry = [playerId, name, (previous?.[2] ?? 0) + live.points, receipt];
        if (index < 0) contributors.push(entry);
        else contributors[index] = entry;
        const state = { version: 1, week: before.week, total: before.total + live.points, contributors };
        const key = WEEK_KEY + state.week;
        const encoded = JSON.stringify(state);
        storage.setDynamicProperty(key, encoded);
        if (storage.getDynamicProperty(key) !== encoded) throw Error('Nexus Beacon write could not be verified.');
        return { state, completed: state.total === NEXUS_BEACON_GOAL, repeated: false };
    }

    function contribute(quote, playerId, name, receipt) {
        const before = current();
        if (quote.week !== before.week) throw Error('The Beacon quote changed.');
        return applyContribution(before, quote, playerId, name, receipt);
    }

    function applyOrderItems(week, item, count, playerId, name, receipt) {
        // The caller has a committed order journal. A retry can arrive after Monday's reset.
        const before = readWeek(week);
        if (before.contributors.some(([id, , , latest]) => id === playerId && latest === receipt)) {
            return { state: before, completed: false, repeated: true };
        }
        const quote = beaconQuoteForOrder(before, item, count);
        return quote ? applyContribution(before, quote, playerId, name, receipt) : undefined;
    }

    return { current, hasReceipt, contribute, applyOrderItems };
}
