import { InputPermissionCategory } from '@minecraft/server';

export const MINIGAME_QUEUE_SECONDS = 45;
export const MINIGAME_QUEUE_TICKS = MINIGAME_QUEUE_SECONDS * 20;

const SAVED_PERMISSIONS = 'sg_minigame_queue_movement_v1';
const CATEGORIES = [
    InputPermissionCategory.LateralMovement,
    InputPermissionCategory.MoveForward,
    InputPermissionCategory.MoveBackward,
    InputPermissionCategory.MoveLeft,
    InputPermissionCategory.MoveRight,
    InputPermissionCategory.Jump,
    InputPermissionCategory.Sneak,
    InputPermissionCategory.Mount,
    InputPermissionCategory.Dismount,
];

function permissionMask(permissions) {
    return CATEGORIES.reduce((mask, category, index) =>
        mask | (permissions.isPermissionCategoryEnabled(category) ? 1 << index : 0), 0);
}

function applyMask(permissions, mask) {
    CATEGORIES.forEach((category, index) => {
        const enabled = Boolean(mask & (1 << index));
        if (permissions.isPermissionCategoryEnabled(category) !== enabled) {
            permissions.setPermissionCategory(category, enabled);
        }
    });
    if (permissionMask(permissions) !== mask) throw Error('Movement permissions could not be verified.');
}

export function createQueueMovement({ world, system }) {
    const positions = new Map();
    const restoring = new Map();

    function restore(player) {
        if (!player.isValid) return false;
        const id = player.id;
        try {
            const mask = player.getDynamicProperty(SAVED_PERMISSIONS);
            if (mask !== undefined) {
                if (!Number.isInteger(mask) || mask < 0 || mask >= (1 << CATEGORIES.length)) {
                    throw Error('Saved movement permissions are invalid.');
                }
                applyMask(player.inputPermissions, mask);
                player.setDynamicProperty(SAVED_PERMISSIONS, undefined);
                if (player.getDynamicProperty(SAVED_PERMISSIONS) !== undefined) throw Error('Could not clear saved movement permissions.');
            }
            restoring.delete(id);
            return true;
        } catch (error) {
            if (!restoring.has(id)) console.warn('[SkyGen Queues] Restoring movement: ' + error);
            restoring.set(id, player);
            return false;
        }
    }

    function lock(player) {
        const id = player.id;
        if (positions.has(id) || !restore(player)) return false;
        try {
            const permissions = player.inputPermissions;
            const mask = permissionMask(permissions);
            // Save the player's controls before changing them so a reload can recover.
            player.setDynamicProperty(SAVED_PERMISSIONS, mask);
            if (player.getDynamicProperty(SAVED_PERMISSIONS) !== mask) throw Error('Could not save movement permissions.');
            applyMask(permissions, 0);
            player.clearVelocity();
            positions.set(id, { dimension: player.dimension.id, ...player.location });
            return true;
        } catch (error) {
            console.warn('[SkyGen Queues] Freezing movement: ' + error);
            restore(player);
            return false;
        }
    }

    function unlock(player) {
        if (positions.delete(player.id)) restore(player);
    }

    function atStart(player) {
        const point = positions.get(player.id);
        if (!point || !player.isValid || player.dimension.id !== point.dimension) return false;
        const { x, y, z } = player.location;
        return Math.hypot(x - point.x, y - point.y, z - point.z) < .16;
    }

    world.afterEvents.playerLeave.subscribe(({ playerId }) => {
        positions.delete(playerId);
        restoring.delete(playerId);
    });
    world.afterEvents.playerSpawn.subscribe(({ player }) => {
        if (!positions.has(player.id)) restore(player);
    });
    world.afterEvents.worldLoad.subscribe(() => {
        for (const player of world.getAllPlayers()) {
            if (!positions.has(player.id)) restore(player);
        }
    });
    system.runInterval(() => {
        for (const [id, player] of restoring) {
            if (player.isValid) restore(player);
            else restoring.delete(id);
        }
    }, 10);

    return { lock, unlock, atStart, has: player => positions.has(player.id) };
}
