export const RUSH_READY_KEY = 'sg_generator_rush_ready_v1';
export const RUSH_OBJECTIVE = 'sg_rush_wins';
export const RUSH_STATION = {
    id: 'generator_rush', x: 8, y: 1, z: 55, block: 'minecraft:noteblock',
    text: { x: 8.5, y: 3, z: 55.5 },
};
export const RUSH_RETURN = { x: 2.5, y: 1.02, z: 59.5 };
export const RUSH_ALT_RETURNS = [
    { x:0.5,y:1.02,z:59.5 }, { x:-1.5,y:1.02,z:61.5 }, { x:4.5,y:1.02,z:62.5 },
];
export const RUSH_BOARD = { x: 4.5, y: 3.2, z: 60.5 };

function lane(firstX, lastX, color) {
    return {
        firstX, lastX, firstZ: 55, lastZ: 72, color,
        start: { x: (firstX + lastX + 1) / 2, y: 27.02, z: 57.5 },
        generators: [-2, 0, 2].map(offset => ({
            x: (firstX + lastX) / 2 + offset, y: 27, z: 62,
        })),
        orders: { x: (firstX + lastX) / 2, y: 27, z: 69 },
    };
}
export const RUSH_LANES = [lane(-9, -3, 'blue'), lane(3, 9, 'red')];
export const RUSH_PRODUCTS = [
    { name: 'Cobblestone', core: 'skygen:cobblestone_generator_core', output: 'minecraft:cobblestone', refill: 32 },
    { name: 'Oak Logs', core: 'skygen:oak_logs_generator_core', output: 'minecraft:oak_log', refill: 40 },
    { name: 'Coal', core: 'skygen:coal_generator_core', output: 'minecraft:coal_ore', refill: 48 },
];

const arena = [];
for (const lane of RUSH_LANES) {
    for (let x = lane.firstX; x <= lane.lastX; x++) {
        for (let z = lane.firstZ; z <= lane.lastZ; z++) {
            const wall = x === lane.firstX || x === lane.lastX || z === lane.firstZ || z === lane.lastZ;
            const lit = x === lane.start.x - 0.5 && (z === 57 || z === 65 || z === 70);
            arena.push([x, 26, z, wall ? 'minecraft:polished_blackstone_bricks' : lit ? 'minecraft:sea_lantern' : 'minecraft:smooth_stone']);
            if (wall) for (const y of [27, 28, 29]) arena.push([x, y, z, 'minecraft:' + lane.color + '_stained_glass']);
        }
    }
    lane.generators.forEach((position, index) => arena.push([position.x, position.y, position.z, RUSH_PRODUCTS[index].core]));
    arena.push([lane.orders.x, lane.orders.y, lane.orders.z, 'minecraft:noteblock']);
}
export const RUSH_BUILDS = [
    { name: 'Colosseum Generator Rush entrance', blocks: [[RUSH_STATION.x, RUSH_STATION.y, RUSH_STATION.z, RUSH_STATION.block]] },
    { name: 'Generator Rush lanes', blocks: arena },
];

export function rushLaneContains(lane, location) {
    return location.x >= lane.firstX + 1 && location.x < lane.lastX && location.z >= lane.firstZ + 1 &&
        location.z < lane.lastZ && location.y >= 26.85 && location.y < 32;
}

export function insideRushArena(location) {
    return location.x >= -10 && location.x < 11 && location.z >= 54 && location.z < 74 &&
        location.y >= 25 && location.y < 36;
}
