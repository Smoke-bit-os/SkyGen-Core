export const NEXUS_BEACON_READY_KEY = 'sg_nexus_beacon_ready_v1';
export const BEACON_DISPLAY_TAG = 'sg_nexus_beacon_display';
export const NEXUS_BEACON_STATIONS = [
    {
        id: 'citadel',
        x: 9, y: 1, z: 7,
        block: 'minecraft:polished_blackstone_bricks',
        text: { x: 9.5, y: 3.05, z: 7.5 },
    },
    {
        id: 'garden',
        x: -58, y: 1, z: 63,
        block: 'minecraft:prismarine_bricks',
        text: { x: -57.5, y: 2.8, z: 63.5 },
    },
];
export const NEXUS_BEACON_CAP = { x: 9, y: 3, z: 9, block: 'minecraft:polished_deepslate' };
const [citadel, garden] = NEXUS_BEACON_STATIONS;
const foundation = [];
for (let x = 8; x <= 10; x++) {
    for (let z = 8; z <= 10; z++) foundation.push([x, 1, z, 'minecraft:iron_block']);
}
export const NEXUS_BEACON_BUILDS = [
    {
        name: 'Citadel Nexus Beacon',
        blocks: [
            ...foundation, [9, 2, 9, 'minecraft:beacon'],
            [NEXUS_BEACON_CAP.x, NEXUS_BEACON_CAP.y, NEXUS_BEACON_CAP.z, NEXUS_BEACON_CAP.block],
            [citadel.x, citadel.y, citadel.z, citadel.block],
        ],
    },
    {
        name: 'Garden fishing turn-in',
        blocks: [[garden.x, garden.y, garden.z, garden.block]],
    },
];

export function nearbyBeaconStation(player) {
    if (player.dimension?.id !== 'minecraft:overworld') return undefined;
    const { x, y, z } = player.location;
    return NEXUS_BEACON_STATIONS.find(station =>
        Math.abs(y - station.y) <= 2 && Math.hypot(x - station.x - 0.5, z - station.z - 0.5) <= 5
    );
}
