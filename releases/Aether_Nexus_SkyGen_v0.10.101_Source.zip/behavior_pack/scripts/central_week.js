const HOUR_MS = 3_600_000;

function sundayOfMonth(year, month, occurrence) {
    const weekday = new Date(Date.UTC(year, month, 1)).getUTCDay();
    return 1 + (7 - weekday) % 7 + 7 * (occurrence - 1);
}

export function centralWeekStart(value = Date.now()) {
    const now = new Date(value);
    if (!Number.isFinite(now.getTime())) throw Error('Invalid Central week date');
    const year = now.getUTCFullYear();
    // US Central switches at 02:00 local: 08:00 UTC in March, 07:00 UTC in November.
    const spring = Date.UTC(year, 2, sundayOfMonth(year, 2, 2), 8);
    const fall = Date.UTC(year, 10, sundayOfMonth(year, 10, 1), 7);
    const centralDate = new Date(now.getTime() - (now >= spring && now < fall ? 5 : 6) * HOUR_MS);
    centralDate.setUTCDate(centralDate.getUTCDate() - (centralDate.getUTCDay() + 6) % 7);
    return centralDate.toISOString().slice(0, 10);
}
