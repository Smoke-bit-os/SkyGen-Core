export const FIRST_GENERATOR_MINE_DROPS = Object.freeze({
    'minecraft:oak_log': 'minecraft:oak_log',
    'minecraft:dirt': 'minecraft:dirt',
    'minecraft:cobblestone': 'minecraft:cobblestone',
    'minecraft:coal_ore': 'minecraft:coal',
});

const dropItems = new Set(Object.values(FIRST_GENERATOR_MINE_DROPS));
const simpleStages = new Set(['mine', 'buy', 'place', 'complete']);
const tokenPattern = /^[1-9][0-9]*$/u;
const positionPattern = /^-?[0-9]+,-?[0-9]+,-?[0-9]+$/u;

export function firstGeneratorState(profile) {
    const saved = profile.firstGeneratorGuide;
    if (saved === undefined) return { stage: 'start' };
    if (saved?.version === 1) {
        if (simpleStages.has(saved.stage)) return saved;
        if (saved.stage === 'sell' && Array.isArray(saved.items) &&
            saved.items.length > 0 && saved.items.length <= dropItems.size &&
            saved.items.every(id => dropItems.has(id))) return saved;
        if (saved.stage === 'harvest' && typeof saved.token === 'string' &&
            tokenPattern.test(saved.token) && typeof saved.generator === 'string' &&
            positionPattern.test(saved.generator)) return saved;
    }
    return { stage: 'unavailable' };
}

export function firstGeneratorPurchaseEligible(profile, price) {
    return Number.isSafeInteger(price) && price > 0 &&
        ['buy', 'place', 'harvest'].includes(firstGeneratorState(profile).stage);
}

export function firstGeneratorPlacementMatches(state, generator, token) {
    return state.stage === 'harvest' && state.generator === generator && state.token === token;
}

export function firstGeneratorProgress(profile, action, detail = {}) {
    const current = firstGeneratorState(profile);
    const stage = current.stage;
    const next = (value, data = {}) => ({ version: 1, stage: value, ...data });

    switch (action) {
    case 'start':
        if (stage === 'start') return next('mine');
        break;
    case 'mine': {
        const drop = FIRST_GENERATOR_MINE_DROPS[detail.block];
        if (!dropItems.has(drop) || (stage !== 'mine' && stage !== 'sell')) break;
        const items = current.items ?? [];
        if (!items.includes(drop)) return next('sell', { items: [...items, drop] });
        break;
    }
    case 'sell':
        if (stage === 'sell' && current.items.includes(detail.item)) return next('buy');
        break;
    case 'purchase':
        if (stage === 'buy' && firstGeneratorPurchaseEligible(profile, detail.price)) return next('place');
        break;
    case 'placement':
    case 'harvest': {
        // The caller supplies these only for a verified token or registry receipt.
        const { generator, token, replace } = detail;
        if (typeof generator !== 'string' || !positionPattern.test(generator) ||
            typeof token !== 'string' || !tokenPattern.test(token)) break;
        const matches = firstGeneratorPlacementMatches(current, generator, token);
        if (stage === 'buy' || stage === 'place' || (stage === 'harvest' && (matches || replace))) {
            if (action === 'harvest') return next('complete');
            if (!matches) return next('harvest', { generator, token });
        }
        break;
    }
    }
    return undefined;
}
