import { CITY } from './sources/worldbuilder/city_layout.js';

export const STARTER_KIT_COOLDOWN = 24 * 60 * 60 * 1000;
const STATIONS = new Map(CITY.kits.filter(([,y])=>y===1)
    .map(([x,y,z,slots])=>[x+','+y+','+z, slots]));

export function starterKitStock(location) {
    return STATIONS.get(location.x+','+location.y+','+location.z);
}

export function nearStarterStock({x,y,z}) {
    return y>=-4 && y<=3 && Math.abs(Math.abs(x)-3)<=2 && Math.abs(Math.abs(z)-8)<=2;
}

export function anchoredStarterStock({x,y,z}) {
    return Math.abs(x)===3 && Math.abs(z)===8 && (y===1 || y===-1 || y===-2);
}

export function shulkerBox(type) {
    return /^minecraft:(?:(?:undyed|white|orange|magenta|light_blue|yellow|lime|pink|gray|light_gray|cyan|purple|blue|brown|green|red|black)_)?shulker_box$/.test(type);
}

export function nextStarterKit(profile) {
    const ready = profile.starterKitNextAt ?? 0;
    if (!Number.isSafeInteger(ready) || ready < 0) throw Error('Starter kit cooldown needs operator review.');
    return ready;
}

export function planStarterKit(source, target, expected) {
    const stacks = [];
    for (const [slot,type,amount] of expected) {
        const item = source.getItem(slot);
        if (item?.typeId !== type || item.amount !== amount) throw Error('Starter kit stock is waiting for its refill.');
        const copy = item.clone();
        let remaining = copy.amount;
        for (const stack of stacks) {
            if (!stack.isStackableWith(copy)) continue;
            const added = Math.min(remaining, stack.maxAmount-stack.amount);
            if (added<=0) continue;
            stack.amount += added;
            remaining -= added;
            if (!remaining) break;
        }
        if (remaining) {
            copy.amount = remaining;
            stacks.push(copy);
        }
    }
    const free = [];
    for (let slot=0;slot<target.size && free.length<stacks.length;slot++) {
        if (!target.getItem(slot)) free.push(slot);
    }
    return {
        needed:stacks.length,
        slots:free.length===stacks.length?stacks.map((item,i)=>[free[i],item]):undefined,
    };
}
