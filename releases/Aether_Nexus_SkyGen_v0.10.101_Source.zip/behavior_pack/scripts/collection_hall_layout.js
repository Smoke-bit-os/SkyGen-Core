import { COLLECTIONS } from './collection_hall.js';

export const COLLECTION_HALL_READY_KEY = 'sg_phase5_collection_hall_ready_v1';
export const COLLECTION_HALL_STATIONS = [
    ['hall', -65, 1, -54],
    ['guardian', -70, 1, -60],
    ['merchant', -65, 1, -68],
    ['feast', -60, 1, -60],
].map(([id, x, y, z]) => {
    const collection = COLLECTIONS.find(entry => entry.id === id);
    return {
        id: 'collection_' + id, collectionId: collection?.id, x, y, z, block: 'minecraft:noteblock',
        title: collection?.title ?? 'Collection Hall', text: { x: x + 0.5, y: y + 2, z: z + 0.5 },
    };
});

export const COLLECTION_HALL_BUILDS = COLLECTION_HALL_STATIONS.map(({ title, x, y, z, block }) => ({
    name: title,
    blocks: [[x, y, z, block]],
}));
