import { world } from '@minecraft/server';

const ROOT = 'sg_roster_board_root';
const INDEX = 'sg_roster_board_page';
const STAMP = 'sg_roster_board_stamp';
const PREFIX = 'sg_roster_board_location_';
const MAX_NEW_PANELS_PER_REFRESH = 6;

export function rosterPanelOwner(entity) {
    return entity.getDynamicProperty(ROOT);
}

export function panelLocations(anchor, pages, rowLimit) {
    const spacingY = 1 + rowLimit * 0.3;
    const direction = anchor.y > 155 ? -1 : 1;
    const height = direction > 0 ? 319 - anchor.y : anchor.y + 63;
    const perColumn = Math.max(1, Math.floor(height / spacingY) + 1);
    return Array.from({ length: pages }, (_, page) => ({
        x: anchor.x + Math.floor(page / perColumn) * 7,
        y: anchor.y + (page % perColumn) * spacingY * direction,
        z: anchor.z,
    }));
}

export function clearRosterPanels(root) {
    world.setDynamicProperty(PREFIX + root.id, undefined);
    for (const child of root.dimension.getEntities({ type: 'monkey:floatingtext', families: ['scoreboard'] })) {
        if (rosterPanelOwner(child) === root.id) child.remove();
    }
}

export function currentRosterPanels(entities) {
    const panels = new Map();
    for (const entity of entities) {
        const owner = rosterPanelOwner(entity);
        if (!owner) continue;
        const page = entity.getDynamicProperty(INDEX);
        const stamp = entity.getDynamicProperty(STAMP);
        if (!Number.isSafeInteger(page) || page < 1 || !stamp ||
            world.getDynamicProperty(PREFIX + owner) !== stamp) {
            entity.remove();
            continue;
        }
        if (!panels.has(owner)) panels.set(owner, new Map());
        const children = panels.get(owner);
        if (children.has(page)) entity.remove();
        else children.set(page, entity);
    }
    return panels;
}

export function drawRosterPanels(root, labels, rowLimit, children = new Map()) {
    const anchor = root.location;
    const positions = panelLocations(anchor, labels.length, rowLimit);
    const stamp = JSON.stringify([anchor.x, anchor.y, anchor.z, rowLimit, labels.length]);
    const key = PREFIX + root.id;
    if (world.getDynamicProperty(key) !== stamp) world.setDynamicProperty(key, stamp);
    if (root.nameTag !== labels[0]) root.nameTag = labels[0];

    for (const [page, child] of children) {
        if (page < labels.length && child.getDynamicProperty(STAMP) === stamp) continue;
        child.remove();
        children.delete(page);
    }
    let spawned = 0;
    for (let page = 1; page < labels.length; page++) {
        let child = children.get(page);
        if (!child) {
            if (spawned >= MAX_NEW_PANELS_PER_REFRESH) continue;
            const position = positions[page];
            if (!root.dimension.isChunkLoaded(position)) continue;
            child = root.dimension.spawnEntity('monkey:floatingtext', position, {
                spawnEvent: 'scoreboard', initialPersistence: true,
            });
            try {
                child.setDynamicProperty(ROOT, root.id);
                child.setDynamicProperty(INDEX, page);
                child.setDynamicProperty(STAMP, stamp);
                child.nameTag = labels[page];
            } catch (error) {
                child.remove();
                throw error;
            }
            spawned++;
        } else if (child.nameTag !== labels[page]) {
            child.nameTag = labels[page];
        }
    }
}
