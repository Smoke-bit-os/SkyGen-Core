import { CommandPermissionLevel, CustomCommandParamType, CustomCommandStatus, EquipmentSlot, system, world } from "@minecraft/server";
import { Component } from "../../libraries/Component.js";
const component = new Component('true_dn:lore', '');
const Slots = Object.values(EquipmentSlot);
system.runJob(SetLore());
function* SetLore() {
    if (!world.getDynamicProperty('stop_lore')) {
        const players = world.getPlayers();
        for (const player of players) {
            if (!player.isValid)
                continue;
            const inv = player.inventory?.container;
            for (let i = 0; i < inv.size; i++) {
                const slot = inv.getSlot(i);
                if (!slot.hasItem())
                    continue;
                const item = slot.getItem();
                const lines = component.getParamsFrom(item);
                if (!lines || !Array.isArray(lines) || !lines.length)
                    continue;
                const old = slot.getRawLore();
                const next = [...old];
                const attributes = item.getComponents().reduce((a, b) => b.customComponentParameters?.params.is_attribute ? { ...a, [b.typeId]: b.customComponentParameters?.params.is_attribute } : a, {});
                // for (const { id, value } of attributes) {
                //     const parsed: RawMessage = { rawtext: [{ text: `§r§9+${value} ` }, { translate: `attribute.name.generic.${id}` }] }
                //     if (next.some(l => JSON.stringify(l) === JSON.stringify(parsed))) continue;
                //     next.push(parsed);
                // }
                for (const line of lines) {
                    const parsed = typeof line === 'string' ? { text: line } :
                        'attribute' in line ? { rawtext: [{ text: `§r§9+${attributes[line.attribute].value} ` }, { translate: `attribute.name.generic.${attributes[line.attribute].id}` }] } : line;
                    if (next.some(l => JSON.stringify(l) === JSON.stringify(parsed)))
                        continue;
                    next.push(parsed);
                }
                slot.setLore(next);
            }
            const { equippable } = player;
            for (const s of Slots) {
                const slot = equippable.getEquipmentSlot(s);
                if (!slot.hasItem())
                    continue;
                const item = slot.getItem();
                const lines = component.getParamsFrom(item);
                if (!lines || !Array.isArray(lines) || !lines.length)
                    continue;
                const old = slot.getRawLore();
                const next = [...old];
                const attributes = item.getComponents().reduce((a, b) => b.customComponentParameters?.params.is_attribute ? { ...a, [b.typeId]: b.customComponentParameters?.params.is_attribute } : a, {});
                // for (const { id, value } of attributes) {
                //     const parsed: RawMessage = { rawtext: [{ text: `§r§9+${value} ` }, { translate: `attribute.name.generic.${id}` }] }
                //     if (next.some(l => JSON.stringify(l) === JSON.stringify(parsed))) continue;
                //     next.push(parsed);
                // }
                for (const line of lines) {
                    const parsed = typeof line === 'string' ? { text: line } :
                        'attribute' in line ? { rawtext: [{ text: `§r§9+${attributes[line.attribute].value} ` }, { translate: `attribute.name.generic.${attributes[line.attribute].id}` }] } : line;
                    if (next.some(l => JSON.stringify(l) === JSON.stringify(parsed)))
                        continue;
                    next.push(parsed);
                }
                slot.setLore(next);
            }
            yield;
        }
    }
    system.runJob(SetLore());
}
system.beforeEvents.startup.subscribe(({ customCommandRegistry: CommandRegistry }) => {
    CommandRegistry.registerEnum('true_dn:state', ['enable', 'disable']);
    CommandRegistry.registerCommand({
        name: 'true_dn:lore',
        description: 'Enable/disable lore for the Deathnerite Add-On',
        permissionLevel: CommandPermissionLevel.Admin,
        cheatsRequired: false,
        optionalParameters: [
            {
                name: 'true_dn:state',
                type: CustomCommandParamType.Enum
            }
        ]
    }, (_origin, argument) => {
        const choice = Array.isArray(argument) ? argument[0] : argument;
        if (choice === undefined) {
            return {
                status: CustomCommandStatus.Success,
                message: `Lore updates are ${world.getDynamicProperty('stop_lore') ? 'disabled' : 'enabled'}.`,
            };
        }
        if (choice !== 'enable' && choice !== 'disable') {
            return { status: CustomCommandStatus.Failure, message: 'Use enable or disable.' };
        }
        const disabled = choice === 'disable';
        system.run(() => world.setDynamicProperty('stop_lore', disabled));
        return {
            status: CustomCommandStatus.Success,
            message: `Setting lore updates to ${disabled ? 'disabled' : 'enabled'}.`,
        };
    });
});
export default component;
