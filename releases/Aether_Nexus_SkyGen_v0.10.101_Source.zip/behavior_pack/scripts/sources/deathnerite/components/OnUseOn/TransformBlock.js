import { GameMode, system } from "@minecraft/server";
import { Component } from "../../libraries/Component.js";
import { beforeEvents } from "../../libraries/utils.js";
import { canTransformBlock } from "../../../../block_transform_permission.js";
const component = new Component('true_dn:transform_block', 'onUseOn', { affect_ids: [], affect_tags: [], damage: 1 });
async function transformBlock(data) {
    const { block, player, itemStack: item } = data;
    if(data.cancel || !canTransformBlock(player, block)) return;
    if (!item)
        return;
    const params = component.getParamsFrom(item);
    if (params === null)
        return;
    if (!params.transform_to && !params.specific_transformations)
        throw new Error(`"${item?.typeId}" did not specify "transform_to" or "specific_transformations" at "${component.id}"`);
    if (!item)
        return;
    const specific = params.specific_transformations?.[block.typeId];
    if (specific === null)
        return;
    const affect_ids = [params.affect_ids].flat();
    const affect_tags = [params.affect_tags].flat();
    if (!specific &&
        affect_ids.length && !affect_ids.includes(block.typeId) &&
        affect_tags.length && !affect_tags.some(t => t && block.permutation.hasTag(t)))
        return;
    // Cancel vanilla interaction once, then re-check the block and player permissions
    // after the deferred tick. Checking data.cancel here would always abort our own transform.
    const originalBlockType = block.typeId;
    const slot = player.selectedSlotIndex;
    const { typeId, amount, lockMode } = item;
    data.cancel = true;
    await system.waitTicks(1);
    if (!player.isValid || !block.isValid || player.dimension.id !== block.dimension.id ||
        block.typeId !== originalBlockType || player.selectedSlotIndex !== slot || !canTransformBlock(player, block)) return;
    const inventory = player.getComponent('minecraft:inventory')?.container;
    const held = inventory?.getItem(slot);
    if (!held || held.typeId !== typeId || held.amount !== amount || held.lockMode !== lockMode) return;
    const next = specific ?? params.transform_to;
    const damagesTool = player.getGameMode() !== GameMode.Creative;
    const result = damagesTool ? held.damage(params.damage) : held;
    const previous = block.permutation;
    block.setType(next);
    if (damagesTool) {
        try { inventory.setItem(slot, result); }
        catch (error) {
            block.setPermutation(previous);
            throw error;
        }
        if (!result) player.dimension.playSound('random.break', player.location);
    }
    if (!params.sfx)
        return;
    const { sound, volume, pitch } = params.sfx;
    if (!sound)
        throw new Error(`"${item.typeId}" did not specify "sound" at "${component.id}/sfx"`);
    const v = Array.isArray(volume) ? volume[Math.floor(Math.random() * volume.length)] : volume;
    const p = Array.isArray(pitch) ? pitch[Math.floor(Math.random() * pitch.length)] : pitch;
    for (const id of [sound].flat()) {
        player.dimension.playSound(id, block.center(), { volume: v, pitch: p });
    }
}
beforeEvents.playerInteractWithBlock.subscribe(transformBlock);
export default component;
