const DISTRICT_LABEL_TAG = 'sg_district_label';

// Each entry marks the district side of a bridge. The coordinates are the
// centers of clear landing blocks in the saved city, with room for its signs.
const districts = [
  { id: 'guild', name: 'Guild Hall', direction: 'Northwest', color: '9', landings: [
    ['bank', -64.5, -42.5],
    ['market', -44.5, -62.5],
    ['citadel', -48.5, -46.5],
  ] },
  { id: 'market', name: 'Market', direction: 'North', color: 'a', landings: [
    ['guild', -19.5, -62.5],
    ['foundry', 20.5, -62.5],
    ['citadel', 0.5, -42.5],
  ] },
  { id: 'foundry', name: 'Foundry', direction: 'Northeast', color: '6', landings: [
    ['market', 45.5, -62.5],
    ['temple', 65.5, -42.5],
    ['citadel', 49.5, -46.5],
  ] },
  { id: 'bank', name: 'Bank', direction: 'West', color: 'e', landings: [
    ['garden', -64.5, 20.5],
    ['guild', -64.5, -19.5],
    ['citadel', -44.5, 0.5],
  ] },
  { id: 'citadel', name: 'Central Citadel', direction: 'Center', color: 'f', landings: [
    ['guild', -15.5, -15.5],
    ['market', 0.5, -19.5],
    ['foundry', 16.5, -15.5],
    // Offset the three landings that already have the owner's waypoint signs.
    ['temple', 20.5, -4.5],
    ['rank', 18.5, 12.5],
    ['colosseum', 0.5, 20.5],
    ['garden', -17.5, 12.5],
    ['bank', -19.5, 0.5],
  ] },
  { id: 'temple', name: 'Skill Temple', direction: 'East', color: 'u', landings: [
    ['foundry', 65.5, -19.5],
    ['rank', 65.5, 20.5],
    ['citadel', 45.5, 0.5],
  ] },
  { id: 'garden', name: 'Garden', direction: 'Southwest', color: 'd', landings: [
    ['colosseum', -44.5, 63.5],
    ['bank', -64.5, 43.5],
    ['citadel', -48.5, 47.5],
  ] },
  { id: 'colosseum', name: 'Colosseum', direction: 'South', color: 'c', landings: [
    ['rank', 20.5, 63.5],
    ['garden', -19.5, 63.5],
    ['citadel', 0.5, 43.5],
  ] },
  { id: 'rank', name: 'Rank Hall', direction: 'Southeast', color: 'b', landings: [
    ['temple', 65.5, 43.5],
    ['colosseum', 45.5, 63.5],
    ['citadel', 49.5, 47.5],
  ] },
];

export const DISTRICT_ENTRANCE_DISPLAYS = districts.flatMap(({ id, name, direction, color, landings }) =>
  landings.map(([destination, x, z]) => {
    const tag = `${DISTRICT_LABEL_TAG}_${id}_${destination}`;
    return { tag, tags: [DISTRICT_LABEL_TAG, tag], point: [x, 4.42, z], rotation: [0, 0],
      text: `§l§${color}${name}§r\n§${color}${direction}` };
  })
);
