export const SKYSPIRE = {
  entry: { x: 70, y: 1, z: 9 },
  summit: [54, 43, -9],
  // The three cracked floors in the captured course keep their original phases.
  dropFloors: [[66, 33, 8, 72], [57, 36, 9, 23], [54, 42, -6, 25]],
};
