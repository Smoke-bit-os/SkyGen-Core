export const TRADING_BONUS_PERCENT = 15;
const MAX_TRACKED_PROCEEDS = 2_000_000_000;

export function hasTradingObjective(quest) {
    return quest.key === 'sold' || quest.secondary?.key === 'sold';
}

export function tradingProceeds(entry) {
    const proceeds = entry.tradeProceeds ?? 0;
    if (!Number.isSafeInteger(proceeds) || proceeds < 0 || proceeds > MAX_TRACKED_PROCEEDS) {
        throw Error('Trading quest proceeds need staff review.');
    }
    return proceeds;
}

export function recordTradingProceeds(entry, quantityAdvanced, quantitySold, saleCredits) {
    if (saleCredits === undefined || quantityAdvanced === 0) return;
    if (!Number.isSafeInteger(saleCredits) || saleCredits < 1 || saleCredits > MAX_TRACKED_PROCEEDS ||
        !Number.isSafeInteger(quantityAdvanced) || quantityAdvanced < 1 || quantityAdvanced > quantitySold) {
        throw Error('Invalid Trading quest sale.');
    }
    // Only the part of a sale that advanced this quest earns a bonus. A sale
    // that advances both objectives is counted once for their overlapping units.
    const qualifyingCredits = Math.floor(saleCredits * quantityAdvanced / quantitySold);
    if (qualifyingCredits) entry.tradeProceeds = Math.min(MAX_TRACKED_PROCEEDS, tradingProceeds(entry) + qualifyingCredits);
}

export function questCreditReward(quest, baseCredits, entry, expeditionPerk = false) {
    const maximum = expeditionPerk ? Math.floor(baseCredits * 120 / 100) : baseCredits;
    if (!hasTradingObjective(quest)) return maximum;
    const percent = expeditionPerk ? TRADING_BONUS_PERCENT * 120 / 100 : TRADING_BONUS_PERCENT;
    return Math.min(maximum, Math.floor(tradingProceeds(entry) * percent / 100));
}
