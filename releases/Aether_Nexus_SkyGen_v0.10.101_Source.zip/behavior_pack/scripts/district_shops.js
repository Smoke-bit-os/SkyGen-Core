const sapling = (label, material, single, bundle) =>
    ({ label, id: 'minecraft:' + material, price: single, bundle });

export const SAPLING_CATALOG = [
    sapling('Oak Sapling', 'oak_sapling', 24, 80),
    sapling('Birch Sapling', 'birch_sapling', 24, 80),
    sapling('Spruce Sapling', 'spruce_sapling', 30, 100),
    sapling('Acacia Sapling', 'acacia_sapling', 30, 100),
    sapling('Jungle Sapling', 'jungle_sapling', 36, 120),
    sapling('Dark Oak Sapling', 'dark_oak_sapling', 36, 120),
    sapling('Azalea', 'azalea', 42, 140),
    sapling('Cherry Sapling', 'cherry_sapling', 48, 160),
    sapling('Poplar Sapling', 'poplar_sapling', 48, 160),
    sapling('Flowering Azalea', 'flowering_azalea', 48, 160),
    sapling('Pale Oak Sapling', 'pale_oak_sapling', 54, 180),
    sapling('Mangrove Propagule', 'mangrove_propagule', 60, 200),
    sapling('Crimson Fungus', 'crimson_fungus', 60, 200),
    sapling('Warped Fungus', 'warped_fungus', 60, 200),
];

const trimPrices = [
    [500, ['Sentry', 'Coast', 'Dune', 'Wild']],
    [850, ['Wayfinder', 'Raiser', 'Shaper', 'Host']],
    [1300, ['Vex', 'Tide', 'Snout', 'Bolt']],
    [2000, ['Eye', 'Rib', 'Ward', 'Spire']],
    [3000, ['Flow']],
    [4000, ['Silence']],
];
export const ARMOR_TRIM_CATALOG = trimPrices.flatMap(([price, names]) => names.map(name => ({
    label: name, id: 'minecraft:' + name.toLowerCase() + '_armor_trim_smithing_template', price,
})));

export const DISTRICT_SHOP_CATALOGS = {
    saplings: { title: 'Garden Nursery', items: SAPLING_CATALOG },
    trims: { title: 'Foundry Armor Trims', items: ARMOR_TRIM_CATALOG },
};

export function districtShopPrice(catalog, item, count) {
    if (!Object.hasOwn(DISTRICT_SHOP_CATALOGS, catalog)) return undefined;
    const entry = DISTRICT_SHOP_CATALOGS[catalog].items.find(row => row.id === item);
    if (!entry) return undefined;
    if (count === 1) return entry.price;
    if (count === 4 && entry.bundle) return entry.bundle;
    return undefined;
}
