let mayTransform = () => false;

export function setBlockTransformPermission(check) {
    mayTransform = check;
}

export function canTransformBlock(player, block) {
    return mayTransform(player, block);
}
