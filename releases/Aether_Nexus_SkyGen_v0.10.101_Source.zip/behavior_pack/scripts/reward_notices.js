const PROPERTY = 'sg_reward_notices_v1';
const DAY = 24_000;
const POPUP = 120;
export const QUEST_PARTIAL_TITLE = '[SGQUEST_PARTIAL]';
export const QUEST_COMPLETE_TITLE = '[SGQUEST_COMPLETE]';
export const QUEST_REMINDER_TITLE = '[SGQUEST_REMINDER]';

export function createRewardNotices({ world, system, questStatus, countPrizes }) {
    const active = new Map();

    function update(player, profile, busy) {
        if (busy) return true;
        const notice = active.get(player.id);
        const showing = notice?.until > system.currentTick;
        if (showing && notice.title !== QUEST_PARTIAL_TITLE) return true;
        if (notice && !showing) {
            active.delete(player.id);
            player.onScreenDisplay.setTitle('', { fadeInDuration: 0, stayDuration: 0, fadeOutDuration: 0, subtitle: '' });
        }

        const now = world.getAbsoluteTime();
        const raw = player.getDynamicProperty(PROPERTY);
        const previous = raw === undefined ? {} : JSON.parse(raw);
        const { ready, assigned, partial } = questStatus(player, profile);
        const seen = (previous.seen ?? []).filter(id => assigned.has(id));
        const fresh = ready.filter(id => !seen.includes(id));
        const partialSeen = (previous.partialSeen ?? []).filter(id => assigned.has(id));
        const freshPartial = partial.filter(id => !partialSeen.includes(id));
        const prizes = countPrizes(player, profile);
        const state = { ...previous, seen };
        const due = last => last === undefined || now < last || now - last >= DAY;
        const prizeDue = prizes > 0 && (prizes > (previous.prizes ?? 0) || due(previous.prizeAt));
        // A newly completed quest can replace the yellow notice on the next refresh.
        if (showing && !prizeDue && !fresh.length) return true;
        let title, subtitle = '';

        if (prizeDue) {
            title = '§6§lYou have prizes to claim!';
            subtitle = '§fOpen Compass → Claim Box';
            state.prizeAt = now;
        } else if (ready.length && (fresh.length || due(previous.questAt))) {
            title = fresh.length ? QUEST_COMPLETE_TITLE : QUEST_REMINDER_TITLE;
            state.questAt = now;
            state.seen.push(...fresh);
        } else if (freshPartial.length) {
            title = QUEST_PARTIAL_TITLE;
            partialSeen.push(...freshPartial);
        }
        if (partialSeen.length || previous.partialSeen) state.partialSeen = partialSeen;
        if (prizes || previous.prizes) state.prizes = prizes;

        if (title) {
            player.onScreenDisplay.setTitle(title, { fadeInDuration: 0, stayDuration: POPUP, fadeOutDuration: 0, subtitle });
            active.set(player.id, { title, until: system.currentTick + POPUP });
        }
        const updated = JSON.stringify(state);
        if (updated !== (raw ?? '{"seen":[]}')) player.setDynamicProperty(PROPERTY, updated);
        return !!title;
    }

    return { update, interrupt: playerId => active.delete(playerId) };
}
