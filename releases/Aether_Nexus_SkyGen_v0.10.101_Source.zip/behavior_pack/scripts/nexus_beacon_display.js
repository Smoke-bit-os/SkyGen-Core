import { world } from '@minecraft/server';
import { NEXUS_BEACON_GOAL } from './nexus_beacon.js';
import { BEACON_DISPLAY_TAG, NEXUS_BEACON_CAP, NEXUS_BEACON_STATIONS } from './nexus_beacon_layout.js';

export function updateDistrictText(dimension, location, familyTag, text) {
    const tag = familyTag + '_' + location.id;
    const displays = dimension.getEntities({
        type: 'monkey:floatingtext', tags: [tag], location: location.text, maxDistance: 2,
    });
    let display = displays[0];
    if (!display) {
        display = dimension.spawnEntity('monkey:floatingtext', location.text, {
            spawnEvent: 'text', initialPersistence: true,
        });
        try {
            display.addTag(familyTag);
            display.addTag(tag);
        } catch (error) {
            display.remove();
            throw error;
        }
    }
    for (const duplicate of displays.slice(1)) duplicate.remove();
    if (display.nameTag !== text) display.nameTag = text;
}

export function refreshNexusBeaconDisplay(state) {
    const dimension = world.getDimension('overworld');
    const complete = state.total >= NEXUS_BEACON_GOAL;
    if (dimension.isChunkLoaded(NEXUS_BEACON_CAP)) {
        const block = dimension.getBlock(NEXUS_BEACON_CAP);
        if (complete && block?.typeId === NEXUS_BEACON_CAP.block) block.setType('minecraft:air');
        if (!complete && block?.isAir) block.setType(NEXUS_BEACON_CAP.block);
    }

    for (const station of NEXUS_BEACON_STATIONS) {
        if (!dimension.isChunkLoaded(station)) continue;
        if (dimension.getBlock(station)?.typeId !== station.block) continue;
        const name = station.id === 'garden' ? '§bGarden Fishing Turn-In' : '§6Restore the Nexus Beacon';
        const count = state.contributors.length;
        const plaque = complete && station.id === 'citadel'
            ? (count <= 3 ? '\n§f' + state.contributors.map(([, name]) => name).join('\n')
                : '\n§f' + count + ' contributors · open the plaque')
            : '';
        const text = name + '\n' + (complete ? '§aBeacon restored' : '§f' + state.total + ' / ' + NEXUS_BEACON_GOAL) + plaque;
        updateDistrictText(dimension, station, BEACON_DISPLAY_TAG, text);
    }
}
