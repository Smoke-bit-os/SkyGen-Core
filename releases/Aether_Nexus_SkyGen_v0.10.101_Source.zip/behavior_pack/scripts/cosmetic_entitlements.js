/** Permanent emblems with player-controlled perks.
 * Callers must authorize payment before saving new ownership. */
import { exactOrbitQuote } from './dual_currency_pricing.js';
export const GUARDIAN_DAMAGE_REDUCTION = 20;
export const MERCHANT_SALE_BONUS = 5;
export const FEAST_BONUS_FISH_CHANCE = 25;
export const COSMETIC_BADGES=Object.freeze({
 sky_guardian_crest:Object.freeze({name:'Sky Guardian Crest',hud:'[SGBG]',perk:`${GUARDIAN_DAMAGE_REDUCTION}% less damage from hostile mobs`}),
 merchant_insignia:Object.freeze({name:'Merchant Insignia',hud:'[SGBM]',perk:`Adds ${MERCHANT_SALE_BONUS}% of the base price to every shop sale`}),
 sky_feast_crest:Object.freeze({name:'Sky Feast Crest',hud:'[SGBF]',perk:`${FEAST_BONUS_FISH_CHANCE}% chance of an extra fish on each successful rod catch`})
});
// Keep historic offer IDs for transaction recovery. Unlocks live on the profile.
export const APPROVED_COSMETIC_BUNDLES=Object.freeze([
 Object.freeze({id:'guardian_totems',name:'Sky Guardian Crest',badge:'sky_guardian_crest',price:20000000,orbitPrice:1,items:Object.freeze([])}),
 Object.freeze({id:'merchant_chest',name:'Merchant Insignia',badge:'merchant_insignia',price:20000000,orbitPrice:1,items:Object.freeze([])}),
 Object.freeze({id:'feast_apples',name:'Sky Feast Crest',badge:'sky_feast_crest',price:20000000,orbitPrice:1,items:Object.freeze([])})
]);
export function validateCosmetics(profile){
 const raw=profile?.cosmetics;
 if(raw===undefined)return {owned:[],equipped:[]};
 if(!raw||typeof raw!=='object'||Array.isArray(raw)||!Array.isArray(raw.owned)||!Array.isArray(raw.equipped))throw Error('Cosmetic profile malformed; staff review required');
 const valid=arr=>arr.length<=64&&arr.every(id=>typeof id==='string'&&id.length>0&&id.length<=80)&&new Set(arr).size===arr.length;
 if(!valid(raw.owned)||!valid(raw.equipped))throw Error('Cosmetic ownership/equipment malformed; staff review required');
 if(raw.equipped.some(id=>!raw.owned.includes(id)))throw Error('Equipped badge without ownership');
 return {owned:[...raw.owned],equipped:[...raw.equipped]};
}
export function emblemEnabled(profile,id){
 const c=profile?.cosmetics;
 return Array.isArray(c?.owned)&&Array.isArray(c?.equipped)&&c.owned.includes(id)&&c.equipped.includes(id);
}
export function grantCosmetic(profile,id){
 if(!COSMETIC_BADGES[id])throw Error('Unknown cosmetic badge');
 const c=validateCosmetics(profile);
 if(c.owned.includes(id))throw Error('Badge already owned');
 return {...c,owned:[...c.owned,id]};
}
export function setCosmeticEquipped(profile,id,equip){
 if(!COSMETIC_BADGES[id]||typeof equip!=='boolean')throw Error('Invalid cosmetic choice');
 const c=validateCosmetics(profile);
 if(!c.owned.includes(id))throw Error('Badge not owned');
 return {...c,equipped:equip?[...new Set([...c.equipped,id])]:c.equipped.filter(s=>s!==id)};
}
export function validateBundle(bundle){
 if(!APPROVED_COSMETIC_BUNDLES.includes(bundle)||!COSMETIC_BADGES[bundle.badge])throw Error('Unapproved cosmetic bundle');
 if(!Number.isSafeInteger(bundle.price)||bundle.price<=0||!Number.isSafeInteger(bundle.orbitPrice)||bundle.orbitPrice<=0)throw Error('Invalid bundle prices');
 exactOrbitQuote(bundle.price,bundle.orbitPrice);
 if(!Array.isArray(bundle.items)||bundle.items.length!==0||('license' in bundle))throw Error('Cosmetic offers must be badge-only');
 return true;
}
