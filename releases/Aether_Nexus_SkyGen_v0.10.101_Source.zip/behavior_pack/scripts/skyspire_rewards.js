import { utcWeekStart } from './weekly_contracts.js';

export const SKYSPIRE_CREDITS = 10_000;
export const SKYSPIRE_KIT = ['minecraft:totem_of_undying', 'minecraft:enchanted_golden_apple'];

export function skyspirePrizes(profile) {
    const { lastClear = '', pending = 0, kits = 0 } = profile.skyspireWeekly ?? {};
    if (typeof lastClear !== 'string' ||
        (lastClear && !/^\d{4}-\d{2}-\d{2}$/.test(lastClear)) ||
        ![pending, kits].every(count => Number.isSafeInteger(count) && count >= 0)) {
        throw Error('Skyspire reward history needs operator review.');
    }
    return { lastClear, pending, kits };
}

export function recordSkyspireClear(profile, clearedAt) {
    const week = utcWeekStart(clearedAt);
    const previous = skyspirePrizes(profile);
    if (week <= previous.lastClear) return false;
    if (previous.kits === Number.MAX_SAFE_INTEGER) throw Error('Skyspire prize limit reached.');
    profile.skyspireWeekly = { ...previous, lastClear: week, kits: previous.kits + 1 };
    return true;
}
