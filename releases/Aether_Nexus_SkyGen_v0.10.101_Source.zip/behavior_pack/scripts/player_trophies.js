import { GameMode, ItemStack } from '@minecraft/server';
import { TROPHY_ID, TROPHY_ITEM, TROPHY_NAME, trophyFromItem, validTrophy } from './claim_box.js';

const DISPLAY = 'skygen:player_head_display';
const DISPLAY_ITEM = 'sg_trophy';
const DISPLAY_OWNER = 'sg_trophy_owner';
const DISPLAY_ANCHOR = 'sg_trophy_anchor';
const SEQUENCE = 'sg_trophy_sequence';
const NEARBY = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1], [0, 0]];
const HAZARDOUS_SUPPORT = new Set(['minecraft:air', 'minecraft:cave_air', 'minecraft:void_air', 'minecraft:magma',
    'minecraft:cactus', 'minecraft:powder_snow', 'minecraft:campfire', 'minecraft:soul_campfire', 'minecraft:sweet_berry_bush',
    'minecraft:pointed_dripstone', 'minecraft:fire', 'minecraft:soul_fire']);

function safeSupport(block) {
    return block && !block.isAir && !block.isLiquid && !HAZARDOUS_SUPPORT.has(block.typeId) &&
        !/(?:_fence(?:_gate)?|_wall|_slab|_stairs|_trapdoor|_door|_carpet|_pressure_plate|_rail|_leaves|_sign|ladder|vine|scaffolding|torch|button|bubble_column|portal)$/u.test(block.typeId);
}

function cell(location) {
    return { x: Math.floor(location.x), y: Math.floor(location.y), z: Math.floor(location.z) };
}

export function createPlayerTrophies({ world, system, inventory, protectedAt, canDropAt, safeStandingLocation, isOperator }) {
    const displays = new Map();

    function itemFor(trophy) {
        if (!validTrophy(trophy)) throw Error('Invalid player head trophy.');
        const item = new ItemStack(TROPHY_ITEM, 1);
        item.nameTag = trophy.victim + "'s Head";
        item.setDynamicProperty(TROPHY_ID, trophy.id);
        item.setDynamicProperty(TROPHY_NAME, trophy.victim);
        return item;
    }

    function issue(victim) {
        const previous = world.getDynamicProperty(SEQUENCE) ?? 0;
        if (!Number.isSafeInteger(previous) || previous < 0 || previous === Number.MAX_SAFE_INTEGER)
            throw Error('Trophy sequence requires operator review.');
        const trophy = { id: 'head_' + (previous + 1).toString(36), victim };
        if (!validTrophy(trophy)) throw Error('Could not verify the victim gamertag.');
        world.setDynamicProperty(SEQUENCE, previous + 1);
        if (world.getDynamicProperty(SEQUENCE) !== previous + 1) throw Error('Trophy sequence was not saved.');
        return trophy;
    }

    function dropBeside(player, trophy) {
        if (!player?.isValid) return false;
        const { dimension, location } = player;
        const x = Math.floor(location.x), y = Math.floor(location.y), z = Math.floor(location.z);
        for (const height of [0, -1, 1]) {
            for (const [dx, dz] of NEARBY) {
                const point = { x: x + dx + 0.5, y: y + height, z: z + dz + 0.5 };
                try {
                    if (!canDropAt(player, point) ||
                        !safeStandingLocation(dimension, point) ||
                        !safeSupport(dimension.getBlock(cell({ ...point, y: point.y - 1 })))) continue;
                } catch { continue; }
                // Once a destination is selected, attempt a single spawn. The
                // caller saves the trophy in the Claim Box if spawning throws.
                dimension.spawnItem(itemFor(trophy), { ...point, y: point.y + 0.2 });
                return true;
            }
        }
        return false;
    }

    function place(player, dimensionId, location, slot, trophy) {
        if (!player.isValid || player.dimension.id !== dimensionId || player.selectedSlotIndex !== slot) return;
        const dim = player.dimension;
        if (Math.hypot(player.location.x - location.x, player.location.y - location.y, player.location.z - location.z) > 8) return;
        const inv = inventory(player), item = inv?.getItem(slot);
        if (trophyFromItem(item)?.id !== trophy.id) return;
        const floor = dim.getBlock(cell({ ...location, y: location.y - 1 }));
        if (protectedAt(player, Math.floor(location.x), Math.floor(location.z)) || !safeSupport(floor) ||
            !dim.getBlock(cell(location))?.isAir || dim.getEntities({ type: DISPLAY, location, maxDistance: 0.55 }).length) {
            player.sendMessage('§ePlace the trophy on a clear block where you can build.');
            return;
        }
        let display;
        try {
            display = dim.spawnEntity(DISPLAY, location, { initialPersistence: true });
            display.nameTag = trophy.victim;
            display.setDynamicProperty(DISPLAY_ITEM, JSON.stringify(trophy));
            display.setDynamicProperty(DISPLAY_OWNER, player.id);
            display.setDynamicProperty(DISPLAY_ANCHOR, location);
            display.setRotation({ x: 0, y: player.getRotation().y + 180 });
            const anchor = display.getDynamicProperty(DISPLAY_ANCHOR);
            if (display.getDynamicProperty(DISPLAY_OWNER) !== player.id || display.nameTag !== trophy.victim ||
                anchor?.x !== location.x || anchor.y !== location.y || anchor.z !== location.z)
                throw Error('Trophy display could not be verified.');
            inv.setItem(slot, undefined);
            if (inv.getItem(slot) !== undefined) throw Error('Trophy item was not used.');
            displays.set(display.id, { display, anchor });
        } catch (error) {
            if (display?.isValid && trophyFromItem(inv.getItem(slot))?.id === trophy.id) display.remove();
            throw error;
        }
    }

    function recover(player, display) {
        if (!player.isValid || !display.isValid || display.dimension.id !== player.dimension.id) return;
        if ([GameMode.Spectator, GameMode.Adventure].includes(player.getGameMode())) return;
        const { x, z } = display.location;
        if (protectedAt(player, Math.floor(x), Math.floor(z)) ||
            (player.id !== display.getDynamicProperty(DISPLAY_OWNER) && !isOperator(player))) {
            player.sendMessage('§eOnly the player who placed this trophy or an operator can pick it up here.');
            return;
        }
        const trophy = JSON.parse(display.getDynamicProperty(DISPLAY_ITEM));
        const inv = inventory(player);
        if (!inv) return;
        const slot = Array.from({ length: inv.size }, (_, i) => i).find(i => !inv.getItem(i));
        if (slot === undefined) return player.sendMessage('§eMake one inventory slot available to pick up this trophy.');
        try {
            inv.setItem(slot, itemFor(trophy));
            if (trophyFromItem(inv.getItem(slot))?.id !== trophy.id) throw Error('Recovery item could not be verified.');
            display.remove();
        }
        catch (error) {
            if (display.isValid && trophyFromItem(inv.getItem(slot))?.id === trophy.id) inv.setItem(slot, undefined);
            throw error;
        }
        player.sendMessage('§aTrophy picked up.');
    }

    function protect(operation, player) {
        system.run(() => {
            try { operation(); }
            catch (error) {
                if (player.isValid) player.sendMessage('§cTrophy action failed.');
                console.warn('[SkyGen Trophy] ' + error);
            }
        });
    }

    function queuePlacement(player, block, face, item) {
        if (face !== 'Up') return;
        const trophy = trophyFromItem(item);
        if (!trophy || [GameMode.Spectator, GameMode.Adventure].includes(player.getGameMode())) return;
        const { x, y, z } = block.location;
        const dimensionId = block.dimension.id, slot = player.selectedSlotIndex;
        protect(() => place(player, dimensionId, { x: x + 0.5, y: y + 1, z: z + 0.5 }, slot, trophy), player);
    }

    system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
        itemComponentRegistry.registerCustomComponent('skygen:place_trophy', {
            onUseOn({ source, block, blockFace, itemStack }) {
                queuePlacement(source, block, blockFace, itemStack);
            },
        });
    });

    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        if (event.cancel || event.isFirstEvent === false || event.blockFace !== 'Up') return;
        const { player, block, itemStack } = event;
        if (itemStack?.typeId === TROPHY_ITEM) {
            event.cancel = true;
            queuePlacement(player, block, event.blockFace, itemStack);
            return;
        }
        if (itemStack || !player.isSneaking) return;
        const { x, y, z } = block.location;
        const [display] = block.dimension.getEntities({
            type: DISPLAY, location: { x: x + 0.5, y: y + 1, z: z + 0.5 }, maxDistance: 0.35,
        });
        if (!display) return;
        event.cancel = true;
        protect(() => recover(player, display), player);
    });
    world.beforeEvents.playerInteractWithEntity.subscribe(event => {
        if (event.target.typeId !== DISPLAY || event.cancel) return;
        event.cancel = true;
        if (!event.player.isSneaking) return;
        const { player, target } = event;
        protect(() => recover(player, target), player);
    });
    world.beforeEvents.entityHurt?.subscribe(event => {
        const source = event.damageSource;
        if (source.damagingEntity?.typeId === DISPLAY || source.damagingProjectile?.typeId === DISPLAY) event.cancel = true;
    });
    world.afterEvents.entityLoad.subscribe(({ entity }) => {
        if (entity.typeId === DISPLAY && entity.getDynamicProperty(DISPLAY_ITEM) !== undefined) {
            displays.set(entity.id, { display: entity, anchor: entity.getDynamicProperty(DISPLAY_ANCHOR) });
        }
    });
    system.runInterval(() => {
        for (const [id, { display, anchor }] of displays) {
            if (!display.isValid) {
                displays.delete(id);
                continue;
            }
            const { x, y, z } = display.location;
            if (anchor && (x !== anchor.x || y !== anchor.y || z !== anchor.z) && display.dimension.isChunkLoaded(anchor)) {
                display.teleport(anchor, { keepVelocity: false });
            }
            // Legacy displays lack an anchor. Stop their drift at their loaded
            // position so that an operator can move them back into reach.
            const velocity = display.getVelocity();
            if (velocity.x || velocity.y || velocity.z) display.clearVelocity();
        }
    }, 2);
    return { issue, itemFor, dropBeside };
}
