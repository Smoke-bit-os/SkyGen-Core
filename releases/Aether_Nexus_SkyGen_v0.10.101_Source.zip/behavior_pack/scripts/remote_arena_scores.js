import { centralWeekStart } from './central_week.js';

export const KING_CREDITS = 750;
export const KING_PAID_WINS = 3;
const FLAG_PREFIX = 'sg_ctf_stats_v1_';
const FLAG_JOURNAL = 'sg_ctf_result_v1';
const nonnegative = val => Number.isSafeInteger(val) && val >= 0;

export function kingStats(profile) {
    const data = profile.kingOfTheHill ?? { wins: 0, week: '', paid: 0, pending: 0 };
    if (![data.wins, data.paid, data.pending].every(nonnegative) || data.paid > KING_PAID_WINS ||
        data.paid > data.wins || data.pending % KING_CREDITS !== 0 ||
        typeof data.week !== 'string' || (data.week && !/^\d{4}-\d{2}-\d{2}$/.test(data.week))) {
        throw Error('King of the Hill history needs operator review.');
    }
    return data;
}

export function recordKingWin(profile, id, now = Date.now()) {
    const prior = kingStats(profile), week = centralWeekStart(now);
    if (prior.lastMatch === id) return undefined;
    if (prior.week > week) throw Error('King of the Hill is waiting for its saved week.');
    const paid = prior.week === week ? prior.paid : 0;
    const reward = paid < KING_PAID_WINS ? KING_CREDITS : 0;
    const wins = prior.wins + 1, pending = prior.pending + reward;
    if (!nonnegative(wins) || !nonnegative(pending)) throw Error('King of the Hill history limit.');
    profile.kingOfTheHill = { wins, week, paid: paid + Number(reward > 0), pending, lastMatch: id };
    return reward;
}

export function flagStats(storage, id) {
    const raw = storage.getDynamicProperty(FLAG_PREFIX + id);
    if (raw === undefined) return { wins: 0, captures: 0 };
    const data = JSON.parse(raw);
    if (!nonnegative(data?.wins) || !nonnegative(data.captures) || typeof data.lastMatch !== 'string') {
        throw Error('Capture the Flag history needs operator review.');
    }
    return data;
}

function write(storage, key, record) {
    const raw = JSON.stringify(record);
    storage.setDynamicProperty(key, raw);
    if (storage.getDynamicProperty(key) !== raw) throw Error('Capture the Flag result did not persist.');
}

export function recoverFlagResult(storage) {
    const raw = storage.getDynamicProperty(FLAG_JOURNAL);
    if (raw === undefined) return;
    const match = JSON.parse(raw);
    if (typeof match?.id !== 'string' || !Array.isArray(match.rows) || match.rows.length > 10 ||
        new Set(match.rows.map(row => row?.id)).size !== match.rows.length ||
        match.rows.some(row => typeof row?.id !== 'string' || !row.id || typeof row.winner !== 'boolean' ||
            !nonnegative(row.captures) || row.captures > 3)) throw Error('Capture the Flag result needs operator review.');
    for (const row of match.rows) {
        const prior = flagStats(storage, row.id);
        if (prior.lastMatch === match.id) continue;
        const wins = prior.wins + Number(row.winner), captures = prior.captures + row.captures;
        if (!nonnegative(wins) || !nonnegative(captures)) throw Error('Capture the Flag history limit.');
        write(storage, FLAG_PREFIX + row.id, { wins, captures, lastMatch: match.id });
    }
    storage.setDynamicProperty(FLAG_JOURNAL, undefined);
    if (storage.getDynamicProperty(FLAG_JOURNAL) !== undefined) throw Error('Capture the Flag journal cleanup did not persist.');
    return match;
}

export function recordFlagResult(storage, id, rows) {
    recoverFlagResult(storage);
    write(storage, FLAG_JOURNAL, { id, rows });
    recoverFlagResult(storage);
}

export function createFlagResultQueue({ world, system, onSettled }) {
    const pending = new Map();
    let nextAttempt = Infinity;
    let retryDelay = 20;

    function publish(result) {
        const notice = pending.get(result.id)?.notice === true;
        pending.delete(result.id);
        try { onSettled(result.rows, notice); }
        catch (error) { console.warn('[Capture the Flag] Scoreboard refresh: ' + error); }
    }

    function flush() {
        if (system.currentTick < nextAttempt) return;
        try {
            const saved = recoverFlagResult(world);
            if (saved) publish(saved);
            const result = pending.values().next().value;
            if (result) {
                recordFlagResult(world, result.id, result.rows);
                publish(result);
            }
            retryDelay = 20;
            nextAttempt = pending.size ? system.currentTick : Infinity;
        } catch (error) {
            if (retryDelay === 20) console.warn('[Capture the Flag] Result will retry: ' + error);
            nextAttempt = system.currentTick + retryDelay;
            retryDelay = Math.min(retryDelay * 2, 200);
        }
    }

    world.afterEvents.worldLoad.subscribe(() => system.run(() => {
        nextAttempt = system.currentTick;
        flush();
    }));
    system.runInterval(flush, 20);

    function submit(id, rows) {
        if (!pending.has(id)) pending.set(id, { id, rows, notice: false });
        if (nextAttempt === Infinity) nextAttempt = system.currentTick;
        flush();
        const entry = pending.get(id);
        if (entry) entry.notice = true;
        return !entry;
    }

    return { submit };
}

export function arenaMetricScores(storage, roster, metric) {
    if (metric !== 'flagWins' && metric !== 'flagCaptures') return new Map();
    return new Map(roster.map(({ id }) => {
        try {
            const score = flagStats(storage, id);
            return [id, metric === 'flagWins' ? score.wins : score.captures];
        } catch { return [id, undefined]; }
    }));
}
