import { TicksPerSecond } from '@minecraft/server';

export const SKYSPIRE_BEST_TIMES = 'sg_skyspire_best';

export function ensureSkyspireTimes(scoreboard) {
    return scoreboard.getObjective(SKYSPIRE_BEST_TIMES) ??
        scoreboard.addObjective(SKYSPIRE_BEST_TIMES, 'Skyspire Best Times');
}

export function isSkyspireTime(ticks) {
    return Number.isInteger(ticks) && ticks > 0 && ticks <= 2147483647;
}

export function formatSkyspireTime(ticks) {
    const hundredths = Math.floor(ticks * 100 / TicksPerSecond);
    const minutes = Math.floor(hundredths / 6000);
    const seconds = String(Math.floor(hundredths / 100) % 60).padStart(2, '0');
    const fraction = String(hundredths % 100).padStart(2, '0');
    return `${minutes}:${seconds}.${fraction}`;
}

export function recordSkyspireTime(scoreboard, player, ticks) {
    if (!isSkyspireTime(ticks)) throw Error('Skyspire elapsed time is outside the scoreboard range.');
    const objective = ensureSkyspireTimes(scoreboard);
    const participant = player.scoreboardIdentity ?? player;
    const saved = objective.getScore(participant);
    if (isSkyspireTime(saved) && saved <= ticks) return { best: saved, improved: false };
    objective.setScore(participant, ticks);
    if (objective.getScore(participant) !== ticks) throw Error('Skyspire best time could not be verified.');
    return { best: ticks, improved: true };
}
