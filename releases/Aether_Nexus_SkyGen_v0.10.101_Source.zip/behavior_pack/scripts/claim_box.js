export const TROPHY_ITEM = 'skygen:player_head_trophy';
export const TROPHY_ID = 'sg_trophy_id';
export const TROPHY_NAME = 'sg_trophy_victim';

const INBOX_PREFIX = 'sg_trophy_inbox_';

export function validTrophy(trophy) {
    return !!trophy && typeof trophy.id === 'string' && /^[a-z0-9_]{3,80}$/.test(trophy.id) &&
        typeof trophy.victim === 'string' && trophy.victim.length > 0 && trophy.victim.length <= 64 &&
        !/[§\x00-\x1f\x7f]/u.test(trophy.victim);
}

export function trophyFromItem(item) {
    if (item?.typeId !== TROPHY_ITEM || item.amount !== 1) return undefined;
    const trophy = { id: item.getDynamicProperty(TROPHY_ID), victim: item.getDynamicProperty(TROPHY_NAME) };
    return validTrophy(trophy) ? trophy : undefined;
}

export function createTrophyInbox(storage) {
    let keysByPlayer;

    function keysFor(playerId) {
        if (!keysByPlayer) {
            keysByPlayer = new Map();
            for (const key of storage.getDynamicPropertyIds()) {
                if (!key.startsWith(INBOX_PREFIX)) continue;
                const separator = key.lastIndexOf('|');
                if (separator < INBOX_PREFIX.length) continue;
                const owner = key.slice(INBOX_PREFIX.length, separator);
                const keys = keysByPlayer.get(owner) ?? new Set();
                keys.add(key);
                keysByPlayer.set(owner, keys);
            }
        }
        return keysByPlayer.get(playerId);
    }

    function keyFor(playerId, id) {
        return INBOX_PREFIX + playerId + '|' + id;
    }

    function read(key) {
        const raw = storage.getDynamicProperty(key);
        if (raw === undefined) return undefined;
        const item = JSON.parse(raw);
        if (!validTrophy(item) || !key.endsWith('|' + item.id)) throw Error('Trophy record needs operator review.');
        return item;
    }

    return {
        add(playerId, trophy) {
            if (!validTrophy(trophy)) throw Error('Invalid player trophy.');
            const key = keyFor(playerId, trophy.id);
            const raw = JSON.stringify(trophy);
            const previous = storage.getDynamicProperty(key);
            if (previous !== undefined && previous !== raw) throw Error('Trophy ID is already in use.');
            if (previous === undefined) storage.setDynamicProperty(key, raw);
            if (storage.getDynamicProperty(key) !== raw) throw Error('Trophy could not be saved.');
            const keys = keysFor(playerId) ?? new Set();
            keys.add(key);
            keysByPlayer.set(playerId, keys);
        },
        get(playerId, id) {
            return read(keyFor(playerId, id));
        },
        count(playerId) {
            return keysFor(playerId)?.size ?? 0;
        },
        list(playerId, start, limit) {
            const keys = keysFor(playerId);
            if (!keys) return [];
            return Array.from(keys).slice(start, start + limit).map(read).filter(Boolean);
        },
        remove(playerId, id) {
            const key = keyFor(playerId, id);
            storage.setDynamicProperty(key, undefined);
            if (storage.getDynamicProperty(key) !== undefined) throw Error('Trophy claim could not be finalized.');
            const keys = keysFor(playerId);
            keys?.delete(key);
            if (!keys?.size) keysByPlayer.delete(playerId);
        },
    };
}

export function planClaimDelivery(inv, stacks, isPlain) {
    if (!inv) return undefined;
    const slots = Array.from({ length: inv.size }, (_, slot) => {
        const before = inv.getItem(slot);
        return { slot, before, after: before };
    });
    for (const stack of stacks) {
        const existing = slots.find(({ after }) => isPlain(after, stack.typeId) &&
            after.isStackableWith(stack) && after.amount + stack.amount <= after.maxAmount);
        if (existing) {
            const copy = existing.after.clone();
            copy.amount += stack.amount;
            existing.after = copy;
        } else {
            const empty = slots.find(({ after }) => !after);
            if (!empty) return undefined;
            empty.after = stack;
        }
    }
    return slots.filter(({ before, after }) => before !== after);
}
