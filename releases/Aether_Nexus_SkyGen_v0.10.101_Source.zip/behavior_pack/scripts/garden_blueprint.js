import { collectionProgress } from './collection_hall.js';

export const GARDEN_FISH_GOAL = 12;
export const BLUEPRINT_GENERATOR = 'Coal';
const HOOK = 'minecraft:fishing_hook';
const ROD = 'minecraft:fishing_rod';
const FISH = new Set(['minecraft:cod', 'minecraft:fish', 'minecraft:salmon', 'minecraft:pufferfish', 'minecraft:tropical_fish', 'minecraft:clownfish']);

export function blueprintState(profile) {
    const state = profile.gardenBlueprint ?? { caught: 0 };
    if (!Number.isInteger(state.caught) || state.caught < 0 || state.caught > GARDEN_FISH_GOAL ||
        (state.token !== undefined && (typeof state.token !== 'string' || !/^[1-9]\d*$/.test(state.token) || state.caught !== GARDEN_FISH_GOAL)) ||
        (state.delivered !== undefined && (state.delivered !== true || state.token === undefined))) {
        throw Error('Garden blueprint history needs operator review.');
    }
    return state;
}

export function hasFinishedSkyFeast(profile) {
    return collectionProgress(profile, 'feast').complete;
}

export function recordGardenFish(profile) {
    const state = blueprintState(profile);
    if (state.caught >= GARDEN_FISH_GOAL || !hasFinishedSkyFeast(profile)) return false;
    profile.gardenBlueprint = { caught: state.caught + 1 };
    return true;
}

function isPondPosition({ x, y, z }) {
    // The captured pond's surface runs from X -70 through -60 and Z 58 through 68.
    return x >= -70 && x < -59 && z >= 58 && z < 69 && y >= -3 && y < 1.25;
}

function isNearPond(player) {
    const { x, y, z } = player.location;
    return player.dimension.id === 'minecraft:overworld' && x >= -75 && x < -54 &&
        z >= 53 && z < 74 && y >= -3 && y < 8;
}

function distance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z); }

export function registerFishingCatches({ world, system, eligible, award }) {
    const hooks = new Map();
    const reels = new Map();

    world.afterEvents.entitySpawn.subscribe(({ entity }) => {
        try {
            if (entity.typeId === HOOK) {
                const owner = entity.getComponent('minecraft:projectile')?.owner;
                if (owner?.typeId === 'minecraft:player') hooks.set(owner.id, entity);
                return;
            }
            if (entity.typeId !== 'minecraft:item' || !reels.size) return;
            const location = entity.location;
            const dimensionId = entity.dimension.id;
            const stack = entity.getComponent('minecraft:item')?.itemStack;
            if (!FISH.has(stack?.typeId) || stack.amount !== 1) return;
            const velocity = entity.getVelocity();
            // Bedrock projects a real catch toward its rod owner from the hook.
            const matching = [...reels.values()].filter(reel => reel.tick === system.currentTick &&
                reel.dimensionId === dimensionId &&
                distance(location, reel.hook) <= 0.15 &&
                Math.hypot(velocity.x - reel.velocity.x, velocity.z - reel.velocity.z) <= 0.055 &&
                Math.abs(velocity.y - reel.velocity.y) <= 0.13);
            if (matching.length === 1) matching[0].fish = stack.typeId;
        } catch (error) { console.warn('[SkyGen fishing] Catch event: ' + error); }
    });

    world.beforeEvents.itemUse.subscribe(({ source, itemStack }) => {
        if (itemStack.typeId !== ROD) return;
        try {
            const hook = hooks.get(source.id);
            if (!hook?.isValid || hook.dimension.id !== source.dimension.id) return;
            const loc = hook.location;
            const garden = isNearPond(source) && isPondPosition(loc);
            if (!eligible(source, garden)) return;
            const player = source.location;
            const vx = (player.x - loc.x) * 0.1, vz = (player.z - loc.z) * 0.1;
            const vy = (player.y - loc.y) * 0.1 + Math.sqrt(distance(player, loc)) * 0.08;
            const reel = { hook: loc, hookId: hook.id, tick: system.currentTick, dimensionId: hook.dimension.id, garden,
                velocity: { x: vx, y: vy, z: vz }, fish: undefined, removed: false };
            reels.set(source.id, reel);
            system.run(() => {
                if (reels.get(source.id) !== reel) return;
                reels.delete(source.id);
                if (!reel.fish || !reel.removed || !source.isValid) return;
                try { award(source, reel.fish, reel.garden); } catch (error) { console.warn('[SkyGen fishing] Catch award: ' + error); }
            });
        } catch (error) { console.warn('[SkyGen fishing] Reel check: ' + error); }
    });

    world.afterEvents.entityRemove.subscribe(({ removedEntityId, typeId }) => {
        if (typeId !== HOOK) return;
        for (const [owner, hook] of hooks) if (hook.id === removedEntityId) hooks.delete(owner);
        for (const reel of reels.values()) if (reel.hookId === removedEntityId) reel.removed = true;
    });
    world.afterEvents.playerLeave.subscribe(({ playerId }) => {
        hooks.delete(playerId);
        reels.delete(playerId);
    });
}
