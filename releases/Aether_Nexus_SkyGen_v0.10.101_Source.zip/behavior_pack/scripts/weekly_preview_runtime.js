// v0.10.52 Checkpoint 5: persisted PREVIEW ONLY, no claims, money or XP.
// The caller saves the returned player profile through the existing verified
// sg_profile persistence path. This module never creates bank transactions.
import {weeklyAssignmentPreview,weeklyProgressPreviewBatch,weeklyReadyPreview} from './weekly_state.js';
import {WEEKLY_UNLOCK_RANK} from './weekly_contracts.js';
import {tradingProceeds} from './trading_quests.js';

function verifyProfile(profile){
 if(!profile||typeof profile!=='object'||Array.isArray(profile))throw Error('Invalid preview profile');
 if(!Number.isSafeInteger(profile.rank)||profile.rank<1||profile.rank>1000)throw Error('Invalid preview rank');
}
export function openWeeklyPreview(profile,playerId,date){
 verifyProfile(profile);
 if(profile.rank<WEEKLY_UNLOCK_RANK)return {state:null,changed:false,locked:true};
 const old=profile.weeklyPreview??null;
 const state=weeklyAssignmentPreview(old,playerId,profile.rank,date);
 const changed=JSON.stringify(old)!==JSON.stringify(state);
 if(changed)profile.weeklyPreview=state;
 return {state,changed,locked:false};
}
export function recordWeeklyPreviewActivity(profile,playerId,keys,subject,amount,date,saleCredits){
 verifyProfile(profile);
 if(profile.rank<WEEKLY_UNLOCK_RANK)return false;
 if(!Number.isSafeInteger(amount)||amount<1||amount>4096)throw Error('Weekly activity out of bounds');
 const {state,changed}=openWeeklyPreview(profile,playerId,date);
 if(!state)return false;
 // Preserve the 4,096-item verified activity limit, but apply the entire
 // saturated counter update in one validation pass instead of up to 64 passes.
 const next=weeklyProgressPreviewBatch(state,keys,subject,amount,saleCredits);
 const modified=JSON.stringify(next)!==JSON.stringify(state);
 if(modified)profile.weeklyPreview=next;
 return changed||modified;
}
export function weeklyPreviewStatus(profile,playerId,date){
 const {state,changed,locked}=openWeeklyPreview(profile,playerId,date);
 if(locked)return {locked:true,changed,week:null,entries:[],previewOnly:true};
 const ready=new Set(weeklyReadyPreview(state));
 return {locked:false,changed,week:state.week,lockedRank:state.lockedRank,
  entries:state.entries.map(e=>({questId:e.questId,primary:e.progress,target:e.target,
   secondary:e.secondaryProgress,secondaryTarget:e.secondaryTarget,tradeProceeds:tradingProceeds(e),ready:ready.has(e.questId)})),
  previewOnly:true};
}
// Deliberate irreversible release gate; no code can call this to claim.
export function claimWeeklyPreview(){throw Error('Weekly Elite payouts remain disabled pending approved monetary terms and transaction journaling');}
