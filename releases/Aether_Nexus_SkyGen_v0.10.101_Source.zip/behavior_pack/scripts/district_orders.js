import { centralWeekStart } from './central_week.js';

const WEEK_MS = 7 * 86400000;
const FIRST_MONDAY = Date.UTC(2026, 0, 5);
const order = (category, material, label, credits, limit, beacon = false) =>
    Object.freeze({ id: category.toLowerCase() + '_' + material, item: 'minecraft:' + material,
        category, label, credits, limit, beacon });

// Rates are below the current shop purchase cost for items the shops stock.
const pools = [
    [
        order('Mining', 'cobblestone', 'Cobblestone', 2, 32, true),
        order('Mining', 'coal', 'Coal', 5, 24, true),
        order('Mining', 'iron_ingot', 'Iron Ingots', 14, 16),
    ],
    [
        order('Farming', 'wheat', 'Wheat', 6, 32, true),
        order('Farming', 'carrot', 'Carrots', 6, 32, true),
        order('Farming', 'potato', 'Potatoes', 5, 32, true),
    ],
    [
        order('Fishing', 'cod', 'Raw Cod', 12, 12, true),
        order('Fishing', 'salmon', 'Raw Salmon', 16, 12, true),
    ],
    [
        order('Building', 'oak_log', 'Oak Logs', 3, 32),
        order('Building', 'sand', 'Sand', 3, 32),
        order('Building', 'stone', 'Stone', 3, 32),
    ],
];
const activeOrderDefinitions = new Map(pools.flat().map(entry => [entry.id, entry]));
const validWeek = /^\d{4}-\d{2}-\d{2}$/u;

export function districtOrdersForWeek(week) {
    if (typeof week !== 'string' || !validWeek.test(week)) throw Error('Invalid District Orders week');
    const cycle = (Date.parse(week + 'T00:00:00Z') - FIRST_MONDAY) / WEEK_MS;
    if (!Number.isSafeInteger(cycle)) throw Error('District Orders week is not a Monday');
    return pools.map((pool, group) => pool[((cycle + group) % pool.length + pool.length) % pool.length]);
}

export function districtOrderUsage(profile, week) {
    const saved = profile.districtOrders;
    if (saved === undefined) return {};
    if (saved?.version !== 1 || typeof saved.week !== 'string' || !validWeek.test(saved.week) ||
        !saved.filled || typeof saved.filled !== 'object' || Array.isArray(saved.filled)) {
        throw Error('District Orders progress needs operator review.');
    }
    if (saved.week > week) throw Error('District Orders is waiting for its saved week.');
    if (saved.week !== week) return {};
    for (const [id, amount] of Object.entries(saved.filled)) {
        const entry = activeOrderDefinitions.get(id);
        if (!entry || !Number.isSafeInteger(amount) || amount < 0 || amount > entry.limit) {
            throw Error('District Orders count needs operator review.');
        }
    }
    return saved.filled;
}

export function districtOrderQuote(profile, orderId, count, now = Date.now()) {
    const week = centralWeekStart(now);
    const entry = districtOrdersForWeek(week).find(item => item.id === orderId);
    if (!entry || !Number.isSafeInteger(count) || count < 1) return undefined;
    const filled = districtOrderUsage(profile, week)[orderId] ?? 0;
    if (count > entry.limit - filled) return undefined;
    return { week, orderId, item: entry.item, count, credits: count * entry.credits, filled, beacon: entry.beacon };
}

export function sameDistrictOrderQuote(a, b) {
    return Boolean(a && b && a.week === b.week && a.orderId === b.orderId &&
        a.item === b.item && a.count === b.count && a.credits === b.credits &&
        a.filled === b.filled && a.beacon === b.beacon);
}

export function recordDistrictOrder(profile, quote, now = Date.now()) {
    const live = districtOrderQuote(profile, quote.orderId, quote.count, now);
    if (!sameDistrictOrderQuote(quote, live)) throw Error('District order changed before settlement.');
    profile.districtOrders = {
        version: 1,
        week: live.week,
        filled: { ...districtOrderUsage(profile, live.week), [live.orderId]: live.filled + live.count },
    };
}
