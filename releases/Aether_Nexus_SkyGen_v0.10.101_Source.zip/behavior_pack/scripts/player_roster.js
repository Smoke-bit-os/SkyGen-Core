// A world-scoped copy of names and profile stats survives player logout.
const PREFIX = 'sg_roster_player_v1_';

function valid(row) {
    return row && typeof row.name === 'string' && row.name.trim() === row.name &&
        row.name.length > 0 && row.name.length <= 64 && !/[§\x00-\x1f\x7f]/u.test(row.name) &&
        !/^commands\.scoreboard\./iu.test(row.name) &&
        Number.isSafeInteger(row.rank) && row.rank >= 1 && row.rank <= 1000 &&
        Number.isSafeInteger(row.credits) && row.credits >= 0 &&
        typeof row.xp === 'string' && /^\d{1,81}$/u.test(row.xp);
}

export function createPlayerRoster(storage) {
    let rows;
    function load() {
        if (rows) return rows;
        const loaded = new Map();
        for (const key of storage.getDynamicPropertyIds()) {
            if (!key.startsWith(PREFIX)) continue;
            try {
                const raw = storage.getDynamicProperty(key);
                const record = JSON.parse(raw);
                if (valid(record)) loaded.set(key.slice(PREFIX.length), { record, raw });
            } catch (error) {
                console.warn('[SkyGen Roster] Invalid record ignored: ' + error);
            }
        }
        rows = loaded;
        return loaded;
    }

    function remember(player, profile) {
        const entries = load();
        const previous = entries.get(player.id);
        let scoreboardId = previous?.record.scoreboardId;
        try {
            const identity = player.scoreboardIdentity?.id;
            if (Number.isSafeInteger(identity)) scoreboardId = identity;
        } catch { /* Identity may become available after the first objective update. */ }
        const wins = profile.generatorRush?.wins;
        const kingWins = profile.kingOfTheHill?.wins;
        const record = { name: player.name, rank: profile.rank, xp: String(profile.xpProgress), credits: profile.credits, scoreboardId,
            rushWins: Number.isSafeInteger(wins) && wins >= 0 ? wins : 0,
            kingWins: Number.isSafeInteger(kingWins) && kingWins >= 0 ? kingWins : 0 };
        if (!valid(record)) return false;
        const raw = JSON.stringify(record);
        if (previous?.raw === raw) return true;
        storage.setDynamicProperty(PREFIX + player.id, raw);
        if (storage.getDynamicProperty(PREFIX + player.id) !== raw) throw Error('Player roster write not verified');
        entries.set(player.id, { record, raw });
        return true;
    }

    return {
        remember,
        records: () => Array.from(load(), ([id, entry]) => ({ id, ...entry.record })),
    };
}

export function rankRoster(records, metric, scores, descending = true) {
    const compareXP = (left, right) => {
        const a = BigInt(left.xp), b = BigInt(right.xp);
        return a < b ? -1 : a > b ? 1 : 0;
    };
    const rows = records.map(row => ({
        ...row,
        score: metric === 'rank' ? row.rank : metric === 'credits' ? row.credits : metric === 'rush' ? row.rushWins ?? 0 :
            metric === 'kingWins' ? row.kingWins ?? 0 :
                metric === 'flagWins' || metric === 'flagCaptures' ? scores.get(row.id) : scores.get(row.scoreboardId),
    }));
    rows.sort((left, right) => {
        if (left.score === undefined && right.score !== undefined) return 1;
        if (right.score === undefined && left.score !== undefined) return -1;
        const value = (left.score ?? 0) - (right.score ?? 0) ||
            (metric === 'rank' ? compareXP(left, right) : 0);
        return value * (descending ? -1 : 1) || left.name.localeCompare(right.name) ||
            left.id.localeCompare(right.id);
    });
    return rows;
}
