import { RUSH_PRODUCTS } from './generator_rush_layout.js';

function draw(pool, random) {
    return pool.splice(Math.floor(random() * pool.length), 1)[0];
}

function twoProductNeed(indices, skip, total, random) {
    const [first, second] = indices.filter(index => index !== skip);
    const need = indices.map(() => 0);
    need[first] = 2 + Math.floor(random() * (total - 3));
    need[second] = total - need[first];
    return need;
}

function nameOrder(products, need, kind) {
    const primary = need.indexOf(Math.max(...need));
    return { name: products[primary].name + ' ' + kind, need };
}

export function createRushContract(catalog, excluded, random = Math.random) {
    const pool = catalog.filter(product => !excluded.has(product.core));
    if (pool.length < RUSH_PRODUCTS.length) throw Error('Too few generators are available for a fresh lineup.');
    const products = RUSH_PRODUCTS.map(({ refill }) => ({ ...draw(pool, random), refill }));
    const indices = products.map((_product, index) => index);
    const firstSkip = draw(indices.slice(), random);
    const secondSkip = draw(indices.filter(index => index !== firstSkip), random);
    const finalNeed = indices.map(() => 2);
    for (let unit = 0; unit < 4; unit++) finalNeed[Math.floor(random() * finalNeed.length)]++;

    // Keep the original 6, 7 and 10-unit order sizes while changing what each order needs.
    return {
        products,
        orders: [
            nameOrder(products, twoProductNeed(indices, firstSkip, 6, random), 'Order'),
            nameOrder(products, twoProductNeed(indices, secondSkip, 7, random), 'Delivery'),
            nameOrder(products, finalNeed, 'Shipment'),
        ],
    };
}

export function formatRushOrder(order, products) {
    return order.need.flatMap((count, index) => count ? [count + ' × ' + products[index].name] : []).join(', ');
}
