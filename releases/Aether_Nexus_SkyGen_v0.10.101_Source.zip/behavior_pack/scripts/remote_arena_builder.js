import { BlockPermutation, BlockVolume } from '@minecraft/server';
import { DISTRICT_DISPLAY_TAG } from './district_order_layout.js';
import { RUSH_STATION } from './generator_rush_layout.js';
import { OVERWORLD, REMOTE_ARENAS, arenaBoxes, offset } from './remote_arena_layout.js';

const AIR = 'minecraft:air';
const STATE_PREFIX = 'sg_remote_arena_build_v1_';
const BUILD_AREA = 'sg_remote_build';
const LOBBY_AREA = 'sg_remote_lobby_build';
const LOADED_AREA_PREFIX = 'sg_remote_loaded_';
const LOBBY_READY_KEY = 'sg_colosseum_entrances_v2';
const SLICE = 32;
const LOAD_CHECK_TICKS = 5;
const LOAD_TIMEOUT_TICKS = 200;

export function waitArenaTicks(system, ticks) {
    return new Promise(resolve => system.runTimeout(resolve, ticks));
}

export function removeArenaArea(world, name) {
    const manager = world.tickingAreaManager;
    if (manager.hasTickingArea(name)) manager.removeTickingArea(name);
}

function tilesFor(spec) {
    const result = [];
    for (let x = spec.min; x <= spec.max; x += SLICE) for (let z = spec.min; z <= spec.max; z += SLICE) {
        result.push({
            from: offset(spec, x, spec.bottom, z),
            to: offset(spec, Math.min(spec.max, x + SLICE - 1), 8, Math.min(spec.max, z + SLICE - 1)),
        });
    }
    return result;
}

function arenaLoadArea(spec) {
    const { min, max, bottom } = spec;
    const from = offset(spec, min, bottom, min);
    const to = offset(spec, max, 8, max);
    const chunks = [];
    for (let x = Math.floor(from.x / 16); x <= Math.floor(to.x / 16); x++) {
        for (let z = Math.floor(from.z / 16); z <= Math.floor(to.z / 16); z++) {
            chunks.push({ x: x * 16 + 8, y: spec.origin.y, z: z * 16 + 8 });
        }
    }
    return { from, to, chunks, name: LOADED_AREA_PREFIX + spec.id };
}

const axes = ['x', 'y', 'z'];
const coordinates = ({ x, y, z }) => [x, y, z].join(', ');
const commandCoordinates = ({ x, y, z }) => [x, y, z].join(' ');
const LOBBY_STATIONS = [RUSH_STATION, ...REMOTE_ARENAS.map(({ id, station }) => ({ id, ...station }))];
const FORMER_STATIONS = {
    generator_rush: { x: 2, y: 1, z: 60 },
    koth: { x: -2, y: 1, z: 60 },
    ctf: { x: -6, y: 1, z: 60 },
};
const lobbyPositions = [...LOBBY_STATIONS, ...Object.values(FORMER_STATIONS)];
const lobbyBounds = { from: {}, to: {} };
for (const axis of axes) {
    const values = lobbyPositions.map(position => position[axis]);
    lobbyBounds.from[axis] = Math.min(...values);
    lobbyBounds.to[axis] = Math.max(...values);
}

function placeEntrance(dimension, station) {
    const block = dimension.getBlock(station);
    if (!block) return 'Entrance could not load at ' + coordinates(station) + '.';
    if (block.typeId !== station.block) {
        if (!block.isAir) return 'Entrance blocked at ' + coordinates(station) + ' by ' + block.typeId + '.';
        const floor = dimension.getBlock({ x: station.x, y: station.y - 1, z: station.z });
        if (!floor || floor.isAir || floor.isLiquid) return 'Entrance needs a floor under ' + coordinates(station) + '.';
        block.setType(station.block);
        if (block.typeId !== station.block) return 'Entrance placement could not be verified at ' + coordinates(station) + '.';
    }

    const former = FORMER_STATIONS[station.id];
    const oldBlock = dimension.getBlock(former);
    if (!oldBlock) return 'Previous entrance could not load at ' + coordinates(former) + '.';
    if (oldBlock.typeId === station.block) oldBlock.setType(AIR);
    for (const display of dimension.getEntities({
        type: 'monkey:floatingtext', tags: [DISTRICT_DISPLAY_TAG + '_' + station.id],
        location: { x: former.x + .5, y: former.y + 2, z: former.z + .5 }, maxDistance: 2,
    })) display.remove();
}

function contains({ from, to }, point) {
    return axes.every(axis => point[axis] >= from[axis] && point[axis] <= to[axis]);
}

function overlap(tile, part) {
    const from = {}, to = {};
    for (const axis of axes) {
        from[axis] = Math.max(tile.from[axis], part.from[axis]);
        to[axis] = Math.min(tile.to[axis], part.to[axis]);
        if (from[axis] > to[axis]) return undefined;
    }
    return { from, to, type: part.type };
}

export function createArenaBuilder({ world, system, cityReady, locationAllowed }) {
    let running = false;
    let lobbyReady = false;
    let lobbyIssue;
    let initialized = false;
    const loadAreas = new Map(REMOTE_ARENAS.map(spec => [spec.id, arenaLoadArea(spec)]));
    const region = () => world.getDimension(OVERWORLD);
    function read(spec) {
        const raw = world.getDynamicProperty(STATE_PREFIX + spec.id);
        if (raw === undefined) return { phase: 'preflight', index: 0 };
        const state = JSON.parse(raw);
        if (!['preflight', 'build', 'ready'].includes(state?.phase) || !Number.isInteger(state.index) ||
            state.index < 0 || state.index > 25) throw Error('Saved arena build progress needs review.');
        return state;
    }

    function save(spec, state) {
        const key = STATE_PREFIX + spec.id, raw = JSON.stringify(state);
        world.setDynamicProperty(key, raw);
        if (world.getDynamicProperty(key) !== raw) throw Error('Arena build progress could not be verified.');
    }

    function ready(spec) {
        try { return cityReady() && read(spec).phase === 'ready'; }
        catch { return false; }
    }

    function loadedChunks(dimension, area) {
        return area.chunks.reduce((count, point) => count + Number(dimension.isChunkLoaded(point)), 0);
    }

    function hasCommandArea(dimension, name) {
        try { return dimension.runCommand('tickingarea preload ' + name).successCount > 0; }
        catch { return false; }
    }

    function keepCommandArea(dimension, { name, from, to }) {
        try {
            if (dimension.runCommand('tickingarea preload ' + name + ' true').successCount > 0) return;
        } catch {}
        const result = dimension.runCommand(
            'tickingarea add ' + commandCoordinates(from) + ' ' + commandCoordinates(to) + ' ' + name + ' true');
        if (!result.successCount) throw Error('Minecraft did not create the saved ticking area.');
    }

    async function keepArenaLoaded(dimension, area) {
        const manager = world.tickingAreaManager;
        if (manager.hasTickingArea(area.name)) area.method = 'script';
        else {
            try {
                keepCommandArea(dimension, area);
                area.method = 'command';
            } catch (commandError) {
                const volume = { dimension, from: area.from, to: area.to };
                if (!manager.hasCapacity(volume)) {
                    throw Error('The full arena needs ' + area.chunks.length + ' ticking chunks. ' + commandError.message);
                }
                await manager.createTickingArea(area.name, volume);
                area.method = 'script';
            }
        }
        for (let waited = 0; waited <= LOAD_TIMEOUT_TICKS; waited += LOAD_CHECK_TICKS) {
            if (loadedChunks(dimension, area) === area.chunks.length) return;
            if (waited < LOAD_TIMEOUT_TICKS) await waitArenaTicks(system, LOAD_CHECK_TICKS);
        }
        throw Error('Minecraft is still loading arena chunks. Try entering again.');
    }

    async function prepare(spec) {
        if (!ready(spec)) throw Error('This arena is still being built.');
        const area = loadAreas.get(spec.id);
        if (area.pending) return area.pending;
        const dimension = region();
        const held = area.method === 'command' ? hasCommandArea(dimension, area.name)
            : area.method === 'script' && world.tickingAreaManager.hasTickingArea(area.name);
        if (held && loadedChunks(dimension, area) === area.chunks.length) {
            area.issue = undefined;
            return;
        }
        area.pending = keepArenaLoaded(dimension, area).then(() => { area.issue = undefined; }, error => {
            const issue = String(error.message ?? error);
            if (area.issue !== issue) console.warn('[' + spec.title + '] Arena loading: ' + issue);
            area.issue = issue;
            throw error;
        }).finally(() => { area.pending = undefined; });
        return area.pending;
    }

    function status(spec) {
        try {
            const state = read(spec);
            if (!cityReady()) return 'The Colosseum opens when the districts finish building.';
            if (state.phase === 'ready') {
                const area = loadAreas.get(spec.id);
                const progress = loadedChunks(region(), area) + '/' + area.chunks.length + ' chunks loaded.';
                return 'Arena built · ' + progress + (area.issue ? ' ' + area.issue : '');
            }
            if (state.issue) return 'Build paused. ' + state.issue;
            return state.phase === 'preflight'
                ? 'Checking the empty remote site (' + state.index + '/25).'
                : 'Building the remote arena (' + state.index + '/25).';
        } catch (error) { return error.message; }
    }

    function lobbyStatus() {
        if (!cityReady()) return 'Waiting for the city to finish building.';
        if (lobbyIssue) return 'Placement paused. ' + lobbyIssue;
        return world.getDynamicProperty(LOBBY_READY_KEY) === true ? 'Entrances ready.' : 'Placing entrances.';
    }

    async function withArea(name, volume, operation) {
        const dimension = region(), manager = world.tickingAreaManager;
        while (!manager.hasCapacity({ dimension, ...volume })) await waitArenaTicks(system, 20);
        await manager.createTickingArea(name, { dimension, ...volume });
        try { operation(dimension); }
        finally { removeArenaArea(world, name); }
        await waitArenaTicks(system, 1);
    }

    async function buildLobby() {
        if (world.getDynamicProperty(LOBBY_READY_KEY) === true) {
            lobbyReady = true;
            return;
        }
        try {
            await withArea(LOBBY_AREA, lobbyBounds, dimension => {
                const issues = [];
                for (const station of LOBBY_STATIONS) {
                    const issue = placeEntrance(dimension, station);
                    if (issue) issues.push(issue);
                }
                if (issues.length) throw Error(issues.join(' '));
                world.setDynamicProperty(LOBBY_READY_KEY, true);
                if (world.getDynamicProperty(LOBBY_READY_KEY) !== true) throw Error('Entrance progress could not be verified.');
            });
            lobbyReady = true;
        } catch (error) {
            lobbyIssue = String(error.message ?? error);
            console.warn('[SkyGen Arenas] Colosseum: ' + lobbyIssue);
        }
    }

    async function work(spec) {
        const state = read(spec);
        if (state.phase === 'ready' || state.issue) return;
        const tiles = tilesFor(spec), parts = arenaBoxes(spec);
        try {
            if (!locationAllowed(spec)) throw Error('The reserved arena site overlaps the current spawn or city.');
            for (const type of new Set(parts.map(part => part.type))) BlockPermutation.resolve(type);
            while (state.phase !== 'ready') {
                if (state.index === tiles.length) {
                    state.phase = state.phase === 'preflight' ? 'build' : 'ready';
                    state.index = 0;
                    save(spec, state);
                    continue;
                }
                const tile = tiles[state.index];
                await withArea(BUILD_AREA, tile, dimension => {
                    if (!locationAllowed(spec)) throw Error('The arena site now overlaps the spawn.');
                    const volume = new BlockVolume(tile.from, tile.to);
                    const existing = dimension.getBlocks(volume, { excludeTypes: [AIR] });
                    if (state.phase === 'preflight') {
                        if (existing.getCapacity()) throw Error('Blocks found in the surveyed footprint near ' +
                            coordinates(tile.from) + '.');
                        return;
                    }
                    const fills = parts.map(part => overlap(tile, part)).filter(Boolean);
                    // A restarted build may already contain some intended layers.
                    for (const point of existing.getBlockLocationIterator()) {
                        const type = dimension.getBlock(point)?.typeId;
                        if (!fills.some(part => part.type === type && contains(part, point))) {
                            throw Error('Unexpected block at ' + coordinates(point) + '.');
                        }
                    }
                    for (const { from, to, type } of fills) dimension.fillBlocks(new BlockVolume(from, to), type);
                });
                state.index++;
                save(spec, state);
            }
            void prepare(spec).then(() => {
                world.sendMessage('§a' + spec.title + ' is ready. Open your Compass or visit the Colosseum.');
            }).catch(() => {});
        } catch (error) {
            state.issue = String(error.message ?? error).slice(0, 160);
            save(spec, state);
            console.warn('[' + spec.title + '] Arena build paused: ' + error);
        }
    }

    async function build() {
        if (!initialized || running || !cityReady()) return;
        running = true;
        try {
            if (!lobbyReady && !lobbyIssue) await buildLobby();
            for (const spec of REMOTE_ARENAS) {
                if (ready(spec)) void prepare(spec).catch(() => {});
                else await work(spec);
            }
        } catch (error) { console.warn('[SkyGen Arenas] Build: ' + error); }
        finally { running = false; }
    }

    function resume() {
        if (running || !cityReady()) return false;
        for (const spec of REMOTE_ARENAS) {
            const state = read(spec);
            if (state.issue) {
                delete state.issue;
                save(spec, state);
            }
        }
        lobbyIssue = undefined;
        void build();
        return true;
    }

    system.runTimeout(() => {
        removeArenaArea(world, BUILD_AREA);
        removeArenaArea(world, LOBBY_AREA);
        initialized = true;
    }, 15);
    system.runInterval(() => {
        if ((!lobbyReady && !lobbyIssue) || REMOTE_ARENAS.some(spec => {
            try { const state = read(spec); return state.phase !== 'ready' && !state.issue; }
            catch { return false; }
        })) void build();
    }, 40);
    system.runInterval(() => {
        if (!initialized || !cityReady()) return;
        for (const spec of REMOTE_ARENAS) {
            if (ready(spec)) void prepare(spec).catch(() => {});
        }
    }, 100);
    return { ready, prepare, status, lobbyStatus, resume };
}
