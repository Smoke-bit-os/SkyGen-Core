import { ItemLockMode } from '@minecraft/server';

const ARENA_WEAPON = 'sg_arena_weapon_v1';

export function arenaWeaponState(item) {
    const raw = item?.getDynamicProperty(ARENA_WEAPON);
    if (raw === undefined) return;
    const state = JSON.parse(raw);
    if (typeof state?.matchId !== 'string' || typeof state.owner !== 'string' ||
        typeof state.unbreakable !== 'boolean' || typeof state.keep !== 'boolean' ||
        ![ItemLockMode.none, ItemLockMode.inventory, ItemLockMode.slot].includes(state.lock)) {
        throw Error('An arena weapon has an invalid recovery record.');
    }
    return state;
}

function inventory(player) {
    const container = player.getComponent('minecraft:inventory')?.container;
    if (!container) throw Error('Arena weapon inventory is unavailable.');
    return container;
}

export function stageArenaWeapons(player, matchId, eligible) {
    const container = inventory(player);
    for (let slot = 0; slot < container.size; slot++) {
        const item = container.getItem(slot);
        if (!item || !eligible(item)) continue;
        if (item.getDynamicProperty(ARENA_WEAPON) !== undefined) throw Error('An arena weapon still needs restoration.');
        const durability = item.getComponent('minecraft:durability');
        if (!durability || durability.unbreakable) continue;
        const state = JSON.stringify({
            matchId, owner: player.id, unbreakable: durability.unbreakable,
            lock: item.lockMode, keep: item.keepOnDeath,
        });
        item.setDynamicProperty(ARENA_WEAPON, state);
        durability.unbreakable = true;
        // Preserve the marked stack even if a command kills the player during a match.
        item.lockMode = ItemLockMode.slot;
        item.keepOnDeath = true;
        container.setItem(slot, item);
        const written = container.getItem(slot);
        if (written?.getDynamicProperty(ARENA_WEAPON) !== state ||
            !written.getComponent('minecraft:durability')?.unbreakable ||
            written.lockMode !== ItemLockMode.slot || !written.keepOnDeath) {
            throw Error('Could not protect an arena weapon.');
        }
    }
}

export function restoreArenaWeapons(player, activeMatchId) {
    const container = inventory(player);
    for (let slot = 0; slot < container.size; slot++) {
        const item = container.getItem(slot);
        const state = arenaWeaponState(item);
        if (!state || (state.owner === player.id && state.matchId === activeMatchId)) continue;
        const durability = item.getComponent('minecraft:durability');
        if (!durability) throw Error('An arena weapon cannot restore its durability.');
        durability.unbreakable = state.unbreakable;
        item.lockMode = state.lock;
        item.keepOnDeath = state.keep;
        item.setDynamicProperty(ARENA_WEAPON, undefined);
        container.setItem(slot, item);
        const written = container.getItem(slot);
        if (written?.typeId !== item.typeId || written.getDynamicProperty(ARENA_WEAPON) !== undefined ||
            written.getComponent('minecraft:durability')?.unbreakable !== state.unbreakable ||
            written.lockMode !== state.lock || written.keepOnDeath !== state.keep) {
            throw Error('Could not restore an arena weapon.');
        }
    }
}
