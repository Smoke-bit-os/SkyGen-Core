import {world,system,ItemStack,ItemLockMode,ItemTypes,BlockTypes,GameMode,GameRule} from '@minecraft/server';
import {STARTER_KIT_COOLDOWN,starterKitStock,nearStarterStock,anchoredStarterStock,shulkerBox,nextStarterKit,planStarterKit} from './starter_kits.js';
import {PISTON_REACH,pistonType,inPistonBuffer,pistonPlacementBlocked,installPistonProtection} from './piston_protection.js';
import {SKYSPIRE_CREDITS,SKYSPIRE_KIT,recordSkyspireClear,skyspirePrizes} from './skyspire_rewards.js';
import {ensureSkyspireTimes,formatSkyspireTime,recordSkyspireTime} from './skyspire_times.js';
import {createTrophyInbox,planClaimDelivery,trophyFromItem} from './claim_box.js';
import {createPlayerTrophies} from './player_trophies.js';
import {installCombatScores} from './combat_scores.js';
import {createRewardNotices} from './reward_notices.js';
import {createPlayerRoster,rankRoster} from './player_roster.js';
import {NEXUS_BEACON_GOAL,NEXUS_BEACON_ITEMS,beaconQuote,beaconQuoteForOrder,createNexusBeaconStore,sameBeaconQuote} from './nexus_beacon.js';
import {centralWeekStart} from './central_week.js';
import {utcWeekStart} from './weekly_contracts.js';
import {districtOrderQuote,districtOrderUsage,districtOrdersForWeek,recordDistrictOrder,sameDistrictOrderQuote} from './district_orders.js';
import {DISTRICT_DISPLAY_TAG,DISTRICT_ORDERS_READY_KEY,DISTRICT_STATIONS,isNearDistrictStation} from './district_order_layout.js';
import {DISTRICT_SHOP_CATALOGS,districtShopPrice} from './district_shops.js';
import {COLLECTIONS,collectionProgress,collectionQuote,legacyCollectionDonation,recordCollectionDonation,rollCollectionItem,sameCollectionQuote} from './collection_hall.js';
import {COLLECTION_HALL_READY_KEY,COLLECTION_HALL_STATIONS} from './collection_hall_layout.js';
import {BLUEPRINT_GENERATOR,GARDEN_FISH_GOAL,blueprintState,hasFinishedSkyFeast,recordGardenFish,registerFishingCatches} from './garden_blueprint.js';
import {createGeneratorRush,recordRushWin,rushStats,RUSH_PAID_WINS,RUSH_WIN_CREDITS,RUSH_MATCH_SECONDS} from './generator_rush.js';
import {createQueueMovement,MINIGAME_QUEUE_SECONDS} from './minigame_queue_movement.js';
import {setBlockTransformPermission} from './block_transform_permission.js';
import {RUSH_OBJECTIVE,RUSH_READY_KEY,RUSH_STATION} from './generator_rush_layout.js';
import {ARENA_BOARDS,REMOTE_ARENAS,arenaAt} from './remote_arena_layout.js';
import {createArenaBuilder} from './remote_arena_builder.js';
import {ARENA_QUEUE_SECONDS,createRemoteMinigames} from './remote_minigames.js';
import {KING_CREDITS,KING_PAID_WINS,arenaMetricScores,createFlagResultQueue,flagStats,kingStats,recordKingWin} from './remote_arena_scores.js';
import {NEXUS_BEACON_READY_KEY,nearbyBeaconStation} from './nexus_beacon_layout.js';
import {refreshNexusBeaconDisplay,updateDistrictText} from './nexus_beacon_display.js';
import {firstGeneratorPlacementMatches,firstGeneratorProgress,firstGeneratorPurchaseEligible,firstGeneratorState} from './first_generator.js';
import {createSkyspireTrial} from './sources/worldbuilder/skyspire.js';
import {QUESTS,questDefinition,questState,recordQuestProgress,completeQuest} from './quests.js';
import {hasTradingObjective,questCreditReward} from './trading_quests.js';
import {openWeeklyPreview,recordWeeklyPreviewActivity,weeklyPreviewStatus} from './weekly_preview_runtime.js';
import {openAscendedDailyPreview,recordAscendedDailyPreviewActivity,ascendedDailyStatus} from './ascended_daily_preview.js';
import {RANK_NAMES,rankLevel,rankName,sidebarStats,sidebarLines,updateNumericScores} from './numeric_scores.js';
import {equippedBadgeMarkers} from './cosmetic_badge_hud.js';
import {hudProgressMarkers} from './hud_xp_progress.js';
import {COSMETIC_BADGES,APPROVED_COSMETIC_BUNDLES,GUARDIAN_DAMAGE_REDUCTION,MERCHANT_SALE_BONUS,FEAST_BONUS_FISH_CHANCE,emblemEnabled,validateCosmetics,grantCosmetic,setCosmeticEquipped,validateBundle} from './cosmetic_entitlements.js';
import {DEATHNERITE_SHOP} from './deathnerite_shop.js';
import {createFarmingCatalog} from './farming_shop.js';
import {PRO_SHOP,enchantProItem,hasProEnchantments} from './pro_shop.js';
import {CREDIT_PER_ORBIT,exactOrbitQuote} from './dual_currency_pricing.js';
import {approvedContractQuote} from './approved_economy_policy.js';
import {cumulativeXP,MAX_RANK,transitionCost,parseProgress,legacyProgress,mirrorXP,advanceRank,formattedXP} from './rank_progression.js';
import {allocateOrRecoverPlot} from './plot_claim_registry.js';
import {HELP_TOPICS,RULEBOOK_TOPIC} from './help_pages.js';
import {skyAction,skyModal,skyMessage} from './skyrealm_ui.js';
import {CREDIT_CAP,createBank,creditPayout,destinationName,payoutDestination} from './bank.js';
const C={spawn:{x:0,y:1,z:0},base:{x:512,y:106,z:512},spacing:128,columns:8,radius:24,warmup:100,cooldown:100,exchange:Number(CREDIT_PER_ORBIT)};
const TOOLS=[{slot:6,type:'minecraft:compass',name:'§bSkyGen Menu'},{slot:7,type:'minecraft:goat_horn',name:'§6Go to Spawn'},{slot:8,type:'minecraft:goat_horn',name:'§aGo to Plot'}];
const GENS=[{"name":"Oak Logs","block":"minecraft:oak_log","cost":1800,"period":240,"category":"Starter","unlock":1},{"name":"Coal","block":"minecraft:coal_ore","cost":2500,"period":300,"category":"Starter","unlock":1},{"name":"Cobblestone","block":"minecraft:cobblestone","cost":500,"period":200,"category":"Starter","unlock":1},{"name":"Dirt","block":"minecraft:dirt","cost":500,"period":180,"category":"Starter","unlock":1},{"name":"Iron","block":"minecraft:iron_ore","cost":10000,"period":400,"category":"Mining","unlock":1},{"name":"Gold","block":"minecraft:gold_ore","cost":40000,"period":500,"category":"Mining","unlock":1},{"name":"Diamond","block":"minecraft:diamond_ore","cost":200000,"period":600,"category":"Mining","unlock":1},{"name":"Emerald","block":"minecraft:emerald_ore","cost":500000,"period":800,"category":"Mining","unlock":1},{"name":"Stone","block":"minecraft:stone","cost":700,"period":220,"category":"Mining","unlock":2},{"name":"Deepslate","block":"minecraft:deepslate","cost":1100,"period":220,"category":"Mining","unlock":3},{"name":"Gravel","block":"minecraft:gravel","cost":900,"period":220,"category":"Mining","unlock":3},{"name":"Sand","block":"minecraft:sand","cost":950,"period":220,"category":"Mining","unlock":3},{"name":"Clay","block":"minecraft:clay","cost":1200,"period":260,"category":"Mining","unlock":4},{"name":"Spruce Logs","block":"minecraft:spruce_log","cost":2200,"period":260,"category":"Nature","unlock":5},{"name":"Birch Logs","block":"minecraft:birch_log","cost":2200,"period":260,"category":"Nature","unlock":5},{"name":"Cherry Logs","block":"minecraft:cherry_log","cost":4500,"period":280,"category":"Nature","unlock":8},{"name":"Mangrove Logs","block":"minecraft:mangrove_log","cost":5200,"period":300,"category":"Nature","unlock":10},{"name":"Copper","block":"minecraft:copper_ore","cost":7500,"period":320,"category":"Mining","unlock":8},{"name":"Redstone","block":"minecraft:redstone_ore","cost":18000,"period":380,"category":"Mining","unlock":12},{"name":"Lapis Lazuli","block":"minecraft:lapis_ore","cost":24000,"period":440,"category":"Mining","unlock":16},{"name":"Nether Quartz","block":"minecraft:quartz_ore","cost":30000,"period":500,"category":"Mining","unlock":18},{"name":"Nether Gold","block":"minecraft:nether_gold_ore","cost":60000,"period":560,"category":"Mining","unlock":20},{"name":"Moss","block":"minecraft:moss_block","cost":15000,"period":300,"category":"Nature","unlock":15},{"name":"Netherrack","block":"minecraft:netherrack","cost":17500,"period":300,"category":"Nature","unlock":16},{"name":"Soul Sand","block":"minecraft:soul_sand","cost":21000,"period":360,"category":"Nature","unlock":18},{"name":"Basalt","block":"minecraft:basalt","cost":26000,"period":380,"category":"Nature","unlock":20},{"name":"Blackstone","block":"minecraft:blackstone","cost":32000,"period":400,"category":"Nature","unlock":22},{"name":"Glowstone","block":"minecraft:glowstone","cost":55000,"period":480,"category":"Nature","unlock":25},{"name":"Magma","block":"minecraft:magma","cost":65000,"period":500,"category":"Nature","unlock":27},{"name":"Calcite","block":"minecraft:calcite","cost":72000,"period":520,"category":"Nature","unlock":30},{"name":"Tuff","block":"minecraft:tuff","cost":76000,"period":520,"category":"Nature","unlock":30},{"name":"Amethyst Block","block":"minecraft:amethyst_block","cost":100000,"period":560,"category":"Nature","unlock":35},{"name":"Obsidian","block":"minecraft:obsidian","cost":150000,"period":650,"category":"Endgame","unlock":30},{"name":"Prismarine","block":"minecraft:prismarine","cost":165000,"period":660,"category":"Endgame","unlock":32},{"name":"Sea Lantern","block":"minecraft:sea_lantern","cost":190000,"period":700,"category":"Endgame","unlock":34},{"name":"End Stone","block":"minecraft:end_stone","cost":220000,"period":720,"category":"Endgame","unlock":36},{"name":"Purpur Block","block":"minecraft:purpur_block","cost":260000,"period":740,"category":"Endgame","unlock":38},{"name":"Sculk","block":"minecraft:sculk","cost":330000,"period":760,"category":"Endgame","unlock":40},{"name":"Crying Obsidian","block":"minecraft:crying_obsidian","cost":420000,"period":800,"category":"Endgame","unlock":42},{"name":"Gilded Blackstone","block":"minecraft:gilded_blackstone","cost":520000,"period":840,"category":"Endgame","unlock":44},{"name":"Shroomlight","block":"minecraft:shroomlight","cost":620000,"period":880,"category":"Endgame","unlock":46},{"name":"Ancient Debris","block":"minecraft:ancient_debris","cost":1900000,"period":1600,"category":"Endgame","unlock":48}];
for(const spec of GENS)spec.period=Math.max(20,Math.round(spec.period*0.85));
const GENERATOR_MAX_LEVEL=10;

// Stable namespaced item IDs. Keep these unchanged across future versions so
// previously purchased unused custom tokens remain valid.
const GENERATOR_ITEM_BY_NAME=new Map(GENS.map(g=>[g.name,'skygen:generator_'+g.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')]));
const GENERATOR_ITEM_TYPE_IDS=new Set(GENERATOR_ITEM_BY_NAME.values());
function generatorItemId(g){return GENERATOR_ITEM_BY_NAME.get(g.name)}
// BlockTypes.get is part of the stable Script API. A missing registry entry
// fails closed BEFORE purchase or token debit, not after the player is charged.
function validGeneratorOutput(g){
 try{return !!g&&!!BlockTypes.get(g.block)}catch(err){genError('Block registry unavailable: '+err,'catalog');return false}
}
function checkGeneratorCatalog(){
 const bad=GENS.filter(g=>!validGeneratorOutput(g));
 if(bad.length)console.warn('[SkyGen GENERATORS] UNAVAILABLE: '+bad.map(g=>g.name+'='+g.block).join('; '));
 else console.warn('[SkyGen GENERATORS] all '+GENS.length+' output blocks found in registry');
}
system.runTimeout(checkGeneratorCatalog,20);
// Names of the 42 registered in-world cores are stable; changing IDs would
// orphan already-placed custom blocks in saved Realm chunks.
const GENERATOR_CORE_BY_NAME=new Map(GENS.map(g=>[g.name,'skygen:'+g.name.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')+'_generator_core']));

// PUBLIC SKY REALM STARTER MINE: display blocks are at Y=2; their top face is Y=3.
// Ten mineable resources in each of five rows, with one empty column between slots.
// Core never creates these blocks before Builder has finished its last construction stage.
// Shared Minecraft scoreboard objectives, because pack dynamic properties are UUID-scoped.
const PUBLIC_MINE_SCOREBOARD='sg_public_mine',CITY_BUILD_SCOREBOARD='sg_city_build';
const PUBLIC_LEVEL_SCOREBOARD='sg_pub_gen_lv';
const PUBLIC_MINE_LEVEL_IDS=['wood','coal','cobblestone','dirt'];
function publicGeneratorLevel(block){
 const id=block==='minecraft:oak_log'?'wood':block==='minecraft:coal_ore'?'coal':block==='minecraft:cobblestone'?'cobblestone':'dirt';
 try{const raw=world.scoreboard.getObjective(PUBLIC_LEVEL_SCOREBOARD)?.getScore(id);return Math.min(10,Math.max(1,Number.isInteger(raw)?raw:1));}
 catch{return 1}
}
function publicGeneratorDelay(g){
 const lvl=publicGeneratorLevel(g.block);
 return lvl>=GENERATOR_MAX_LEVEL?1:Math.max(10,Math.round(g.delay*Math.pow(0.85,lvl-1)));
}
function publicMineAdminMenu(p){
 if(!isOperator(p)||!canUseAdminMenu(p))return p.sendMessage('§cUse the Admin Axe as a Realm operator.');
 const types=PUBLIC_STARTER_TYPES;
 form(p,'§bPUBLIC MINE LEVELS',`50 community generators • Level 1–10.
Set shared upgrades for each resource. Level 10 refills in about one tick after harvesting.`,
  [...types.map(t=>`${t.block.split(':')[1]} Lv${publicGeneratorLevel(t.block)}/10`),'Back to Admin'],i=>{
  if(i===types.length)return adminMenu(p);
  if(i>=0&&i<types.length)publicMineLevelMenu(p,types[i]);
 });
}
function publicMineLevelMenu(p,type){
 if(!isOperator(p)||!canUseAdminMenu(p))return p.sendMessage('§cUse the Admin Axe as a Realm operator.');
 const name=type.block.split(':')[1];
 form(p,'§bPUBLIC MINE: '+name,`Current level: ${publicGeneratorLevel(type.block)} / 10.
Higher levels reduce the community recharge timer.`,
  [...Array.from({length:10},(_,i)=>`Set Level ${i+1}`),'Back'],i=>{
    if(i===10)return publicMineAdminMenu(p);
    if(!isOperator(p)||!canUseAdminMenu(p)||i<0||i>9)return;
    try{
      let obj=world.scoreboard.getObjective(PUBLIC_LEVEL_SCOREBOARD);
      if(!obj)obj=world.scoreboard.addObjective(PUBLIC_LEVEL_SCOREBOARD,'SkyGen Community Mine Levels');
      const id=type.block==='minecraft:oak_log'?'wood':type.block==='minecraft:coal_ore'?'coal':type.block==='minecraft:cobblestone'?'cobblestone':'dirt';
      obj.setScore(id,i+1);
      if(publicGeneratorLevel(type.block)!==i+1)throw Error('Scoreboard did not save level');
      for(const g of PUBLIC_STARTER_GENERATORS)if(g.block===type.block)publicStarterDue.delete(`${g.x},${g.y},${g.z}`);
      p.sendMessage('§aPublic '+name+' generators now Level '+(i+1)+'.');
    }catch(err){p.sendMessage('§cCannot change public mine level: '+err)}
    menuAgain(p,()=>publicMineLevelMenu(p,type));
  });
}

const PUBLIC_STARTER_TYPES=[
 {block:'minecraft:oak_log',delay:60},
 {block:'minecraft:coal_ore',delay:130},
 {block:'minecraft:cobblestone',delay:100},
 {block:'minecraft:dirt',delay:80}
];
const PUBLIC_STARTER_GENERATORS=[57,61,65,69,73].flatMap(x=>
 Array.from({length:10},(_,slot)=>({x,y:2,z:72-2*slot,...PUBLIC_STARTER_TYPES[slot%4]}))
);
const PUBLIC_STARTER_MAP=new Map(PUBLIC_STARTER_GENERATORS.map(g=>[`${g.x},${g.y},${g.z}`,g]));
// Due ticks remain local to loaded chunks. On world restart, empty blocks wait a
// full delay before restoration, instead of immediately overwriting adjacent builds.
const publicStarterDue=new Map(),publicStarterBlockedWarnings=new Set();
function publicStarterAt(x,y,z){return PUBLIC_STARTER_MAP.get(`${x},${y},${z}`)}
function publicStarterEnabled(){try{return world.scoreboard.getObjective(PUBLIC_MINE_SCOREBOARD)?.getScore('ready')===1}catch{return false}}
function publicCityBuildRunning(){try{return world.scoreboard.getObjective(CITY_BUILD_SCOREBOARD)?.getScore('active')===1}catch{return false}}
function generatorCoreType(g){return GENERATOR_CORE_BY_NAME.get(g.type||g.name)||''}
function isGeneratorBase(g,base){return !!base&&(base.typeId===generatorCoreType(g)||base.typeId==='minecraft:bedrock')}
// Only migrate a bedrock block directly backed by an authenticated registry
// record; no chunk force-loading, scanning, or replacement of player builds.
function migrateGeneratorCore(g,base){
 const expected=generatorCoreType(g);
 if(!expected||!base)return false;
 if(base.typeId===expected)return true;
 if(base.typeId!=='minecraft:bedrock')return false;
 base.setType(expected);
 if(world.getDimension('overworld').getBlock({x:g.x,y:g.y,z:g.z})?.typeId!==expected)throw Error('Generator core migration not verified at '+g.x+','+g.y+','+g.z);
 return true;
}
function validTokenItemType(type,name){return type==='minecraft:goat_horn'||type===GENERATOR_ITEM_BY_NAME.get(name)}
const GEN_BY_NAME=new Map(GENS.map(g=>[g.name,g]));
const SHOP=[{name:'Cobblestone × 16',id:'minecraft:cobblestone',count:16,buy:80,sell:16},{name:'Oak Logs × 16',id:'minecraft:oak_log',count:16,buy:160,sell:32},{name:'Iron Ingots × 8',id:'minecraft:iron_ingot',count:8,buy:400,sell:80},{name:'Diamond × 1',id:'minecraft:diamond',count:1,buy:500,sell:100},{"name":"Stone","id":"minecraft:stone","count":16,"buy":128,"sell":32,"category":"Starter"},{"name":"Dirt","id":"minecraft:dirt","count":16,"buy":64,"sell":16,"category":"Starter"},{"name":"Gravel","id":"minecraft:gravel","count":16,"buy":128,"sell":32,"category":"Starter"},{"name":"Sand","id":"minecraft:sand","count":16,"buy":128,"sell":32,"category":"Starter"},{"name":"Clay","id":"minecraft:clay_ball","count":16,"buy":160,"sell":32,"category":"Starter"},{"name":"Spruce Logs","id":"minecraft:spruce_log","count":16,"buy":192,"sell":48,"category":"Starter"},{"name":"Birch Logs","id":"minecraft:birch_log","count":16,"buy":192,"sell":48,"category":"Starter"},{"name":"Cherry Logs","id":"minecraft:cherry_log","count":16,"buy":320,"sell":80,"category":"Starter"},{"name":"Copper Ingots","id":"minecraft:copper_ingot","count":8,"buy":280,"sell":64,"category":"Ores"},{"name":"Coal","id":"minecraft:coal","count":16,"buy":240,"sell":48,"category":"Ores"},{"name":"Gold Ingots","id":"minecraft:gold_ingot","count":8,"buy":800,"sell":160,"category":"Ores"},{"name":"Redstone Dust","id":"minecraft:redstone","count":16,"buy":240,"sell":64,"category":"Ores"},{"name":"Lapis Lazuli","id":"minecraft:lapis_lazuli","count":16,"buy":288,"sell":64,"category":"Ores"},{"name":"Emerald","id":"minecraft:emerald","count":1,"buy":1500,"sell":300,"category":"Ores"},{"name":"Nether Quartz","id":"minecraft:quartz","count":16,"buy":320,"sell":64,"category":"Nether"},{"name":"Netherrack","id":"minecraft:netherrack","count":16,"buy":128,"sell":32,"category":"Nether"},{"name":"Soul Sand","id":"minecraft:soul_sand","count":8,"buy":160,"sell":40,"category":"Nether"},{"name":"Blackstone","id":"minecraft:blackstone","count":16,"buy":480,"sell":128,"category":"Nether"},{"name":"Glowstone Dust","id":"minecraft:glowstone_dust","count":16,"buy":640,"sell":160,"category":"Nether"},{"name":"Magma Cream","id":"minecraft:magma_cream","count":8,"buy":800,"sell":200,"category":"Nether"},{"name":"Obsidian","id":"minecraft:obsidian","count":4,"buy":1200,"sell":320,"category":"Endgame"},{"name":"Prismarine","id":"minecraft:prismarine","count":8,"buy":1600,"sell":400,"category":"Endgame"},{"name":"End Stone","id":"minecraft:end_stone","count":8,"buy":1600,"sell":400,"category":"Endgame"},{"name":"Sculk","id":"minecraft:sculk","count":8,"buy":2400,"sell":640,"category":"Endgame"}];
// Simple vanilla food, no special NBT/dynamic properties: reuse the Server Shop transaction safeguards.
const FOOD_SHOP=[{"name":"Apple","id":"minecraft:apple","count":1,"buy":30,"sell":8,"category":"Basics"},{"name":"Bread","id":"minecraft:bread","count":1,"buy":40,"sell":10,"category":"Basics"},{"name":"Baked Potato","id":"minecraft:baked_potato","count":1,"buy":40,"sell":10,"category":"Basics"},{"name":"Carrot","id":"minecraft:carrot","count":1,"buy":18,"sell":4,"category":"Basics"},{"name":"Potato","id":"minecraft:potato","count":1,"buy":15,"sell":3,"category":"Basics"},{"name":"Beetroot","id":"minecraft:beetroot","count":1,"buy":18,"sell":4,"category":"Basics"},{"name":"Steak","id":"minecraft:cooked_beef","count":1,"buy":95,"sell":24,"category":"Cooked Meats"},{"name":"Porkchop","id":"minecraft:cooked_porkchop","count":1,"buy":85,"sell":20,"category":"Cooked Meats"},{"name":"Chicken","id":"minecraft:cooked_chicken","count":1,"buy":75,"sell":18,"category":"Cooked Meats"},{"name":"Mutton","id":"minecraft:cooked_mutton","count":1,"buy":75,"sell":18,"category":"Cooked Meats"},{"name":"Rabbit","id":"minecraft:cooked_rabbit","count":1,"buy":95,"sell":23,"category":"Cooked Meats"},{"name":"Cooked Cod","id":"minecraft:cooked_cod","count":1,"buy":65,"sell":15,"category":"Seafood"},{"name":"Cooked Salmon","id":"minecraft:cooked_salmon","count":1,"buy":85,"sell":20,"category":"Seafood"},{"name":"Dried Kelp","id":"minecraft:dried_kelp","count":1,"buy":15,"sell":3,"category":"Seafood"},{"name":"Melon Slice","id":"minecraft:melon_slice","count":1,"buy":20,"sell":4,"category":"Snacks"},{"name":"Sweet Berries","id":"minecraft:sweet_berries","count":1,"buy":20,"sell":4,"category":"Snacks"},{"name":"Glow Berries","id":"minecraft:glow_berries","count":1,"buy":28,"sell":6,"category":"Snacks"},{"name":"Cookie","id":"minecraft:cookie","count":1,"buy":24,"sell":5,"category":"Snacks"},{"name":"Pumpkin Pie","id":"minecraft:pumpkin_pie","count":1,"buy":70,"sell":15,"category":"Snacks"},{"name":"Golden Carrot","id":"minecraft:golden_carrot","count":1,"buy":180,"sell":45,"category":"Premium"},{"name":"Golden Apple","id":"minecraft:golden_apple","count":1,"buy":1400,"sell":350,"category":"Premium"},{"name":"Honey Bottle","id":"minecraft:honey_bottle","count":1,"buy":85,"sell":20,"category":"Premium"},{"name":"Mushroom Stew","id":"minecraft:mushroom_stew","count":1,"buy":90,"sell":20,"category":"Premium"},{"name":"Rabbit Stew","id":"minecraft:rabbit_stew","count":1,"buy":140,"sell":35,"category":"Premium"},{"name":"Beetroot Soup","id":"minecraft:beetroot_soup","count":1,"buy":75,"sell":18,"category":"Premium"}];
const FOOD_CATEGORIES=['Basics','Cooked Meats','Seafood','Snacks','Premium'];
const FARMING_SHOP=createFarmingCatalog([...SHOP,...FOOD_SHOP]);

const pending=new Map(),cooldowns=new Map(),generators=new Map(),trades=new Map(),visitRequests=new Map();
const genEmptySeconds=new Map();
const genDueByKey=new Map(),genDueBuckets=new Map();
let genCursor;
// Limit player-initiated commands before scheduling forms or mutating state.
const playerCommandLastTick=new Map(),PLAYER_COMMAND_MIN_TICKS=10;
let genWatchdogRuns=0, genLastTick=-1, genLastError="none", genStartupTick=system.currentTick;
const genErrors=[];
// Register commands early so a later optional event subscription cannot disable them.
try{
 system.afterEvents.scriptEventReceive.subscribe(e=>{
  if(!['skygen:menu','skygen:help','skygen:adminaxe','skygen:admin','skygen:debug','skygen:marketreview','skygen:security','skygen:tokenrestore','skygen:creativeclear','skygen:tokenstatus','skygen:txnreview','skygen:txnclear','skygen:spawn','skygen:rankchat','skygen:raidstatus','skygen:purgestatus'].includes(e.id))return;
  const actor=e.sourceEntity;
  console.warn('[SkyGen CMD] received '+e.id+' source='+e.sourceType+' player='+(actor?.name||'none'));
  if(!actor||actor.typeId!=='minecraft:player'){console.warn('[SkyGen CMD] no player source; use command from player chat');return;}
  const last=playerCommandLastTick.get(actor.id),now=system.currentTick;
  if(last!==undefined&&now-last<PLAYER_COMMAND_MIN_TICKS)return;
  playerCommandLastTick.set(actor.id,now);
  try{actor.sendMessage('§7SkyGen received '+e.id);}catch{}
  system.run(()=>{
   try{
    if(e.id==='skygen:debug'&&!isOperator(actor))actor.sendMessage('§cRealm operator required.');
    else if(e.id==='skygen:help')helpCommand(actor,e.message);
    else if(e.id==='skygen:menu')menu(actor);
    else if(e.id==='skygen:adminaxe')issueAdminAxe(actor);
    else if(e.id==='skygen:admin')adminCommand(actor,e.message);
    else if(e.id==='skygen:marketreview')marketReviewCommand(actor);
    else if(e.id==='skygen:security')securityReviewCommand(actor);
    else if(e.id==='skygen:tokenrestore')adminTokenRestore(actor,e.message);
    else if(e.id==='skygen:tokenstatus')adminTokenStatus(actor,e.message);
    else if(e.id==='skygen:creativeclear')adminCreativeClear(actor,e.message);
    else if(e.id==='skygen:txnreview')economicTxnReviewCommand(actor,e.message);
    else if(e.id==='skygen:txnclear')economicTxnClearCommand(actor,e.message);
    else if(e.id==='skygen:spawn')spawnCommand(actor,e.message);
    else if(e.id==='skygen:rankchat')rankChatCommand(actor,e.message);
    else if(e.id==='skygen:purgestatus'||e.id==='skygen:raidstatus')purgeStatusCommand(actor);
    else actor.sendMessage('§aSkyGen command handler active. OP='+isOperator(actor)+' Admin='+isAdmin(actor)+' PermissionLevel='+String(actor.playerPermissionLevel)+' isOpAPI='+String(typeof actor.isOp));
   }catch(err){console.warn('[SkyGen CMD] '+err);try{actor.sendMessage('§cSkyGen command error: '+err)}catch{}}
  });
 });
 console.warn('[SkyGen CMD] command listener registered');
}catch(err){console.warn('[SkyGen CMD] LISTENER REGISTRATION FAILED '+err)}

const GEN_REGISTRY_LIMIT=1200, GEN_REGISTRY_BYTES=12000, GEN_REGISTRY_SHARDS=24;
const GEN_STORAGE_META='sg_generators_v2_commit', GEN_STORAGE_LEGACY='sg_generators';
const GEN_BASE_SLOTS=20;
const genErrorTick=new Map();
function genError(message,key='general'){
 genLastError=String(message);
 const now=system.currentTick,last=genErrorTick.get(key)??-99999;
 if(now-last<1200)return;
 genErrorTick.set(key,now);
 genErrors.push(`${now}: ${genLastError}`);
 if(genErrors.length>20)genErrors.shift();
 console.warn('SkyGen generator: '+genLastError);
}
// Register the generator heartbeat BEFORE optional UI/event subscriptions.
// A later unsupported event must not prevent generator processing.
// Schedule independently with runTimeout; this path is independent of other intervals.
function generatorHeartbeat(){
 try{genWatchdog()}catch(e){genError('heartbeat '+e)}
 finally{system.runTimeout(generatorHeartbeat,4)}
}
system.runTimeout(generatorHeartbeat,4);
// Independent public mine loop: no dependency on a player-owned generator existing.
system.runTimeout(publicStarterHeartbeat,5);
system.runTimeout(()=>{try{genLoad()}catch(e){console.warn('SkyGen generator loading: '+e)}},40);
const MAX_LISTINGS=80, MARKET_KEY='sg_market_v1';
const keyForPlot=id=>'sg_plot_'+id;
function ownerId(id){return String(world.getDynamicProperty(keyForPlot(id))||'')}
function trusted(id){try{const a=JSON.parse(String(world.getDynamicProperty('sg_trust_'+id)||'[]'));return Array.isArray(a)?a.filter(x=>typeof x==='string'):[]}catch{return []}}
function canBuild(p,id){return id>=0&&(ownerId(id)===p.id||trusted(id).includes(p.id))}
function visitors(id){try{const a=JSON.parse(String(world.getDynamicProperty('sg_visitors_'+id)||'[]'));return Array.isArray(a)?a.filter(x=>typeof x==='string'):[]}catch{return []}}
let interactionGuardAvailable=false;
function canVisit(p,id){
 if(id<0)return false;
 if(ownerId(id)===p.id)return true;
 // Do not admit visitors when the stable container-interaction guard is missing.
 return interactionGuardAvailable&&(visitors(id).includes(p.id)||trusted(id).includes(p.id));
}
function setVisit(id,ids){world.setDynamicProperty('sg_visitors_'+id,JSON.stringify([...new Set(ids)]))}

function cityProtectionActive(){return publicStarterEnabled()||publicCityBuildRunning()}
function inBuiltSkyRealm(x,z){return cityProtectionActive()&&insideSquare({x,z},C.spawn,spawnLimit())}
const personalSpawnBuild=new Set();
function protectedAt(p,x,z,building=true){
 if(p.dimension?.id!=='minecraft:overworld')return false;
 if(arenaAt(x,z))return true;
 if(inSpawn(x,z)){
  const id=plotAt(x,z);
  if(id>=0&&ownerId(id))return true;
  return !isOperator(p)||(building&&!personalSpawnBuild.has(p.id));
 }
 if(inBuiltSkyRealm(x,z))return !isOperator(p);
 const id=plotAt(x,z);
 return id>=0&&!canBuild(p,id);
}
const CITY_WORKSTATIONS=new Set([
 'minecraft:crafting_table','minecraft:cartography_table','minecraft:smithing_table',
 'minecraft:furnace','minecraft:lit_furnace','minecraft:blast_furnace','minecraft:lit_blast_furnace',
 'minecraft:smoker','minecraft:lit_smoker','minecraft:brewing_stand','minecraft:barrel',
 'minecraft:anvil','minecraft:chipped_anvil','minecraft:damaged_anvil','minecraft:grindstone',
 'minecraft:loom','minecraft:stonecutter_block','minecraft:enchanting_table','minecraft:ender_chest',
]);
function canUseCityWorkstation({player,block,itemStack}){
 const {x,z}=block.location;
 if(block.dimension.id!=='minecraft:overworld'||!inBuiltSkyRealm(x,z)||publicCityBuildRunning())return false;
 if(player.isSneaking&&itemStack)return false;
 const type=block.typeId;
 if(type==='minecraft:beehive'||type==='minecraft:bee_nest'){
  return !itemStack||itemStack.typeId==='minecraft:shears'||itemStack.typeId==='minecraft:glass_bottle';
 }
 if(type==='minecraft:fletching_table')return !itemStack;
 return CITY_WORKSTATIONS.has(type);
}
function protectedPlotFoundation(p,{x,y,z},id){
 if(id<0)return false;
 const center=coords(id);
 return Math.abs(x-center.x)<=8&&Math.abs(z-center.z)<=8&&y>=center.y-3&&y<=center.y-1&&
  !(y===center.y-1&&ownerId(id)===p.id);
}
setBlockTransformPermission((p,block)=>{
 if(block.dimension.id!=='minecraft:overworld')return true;
 const {x,y,z}=block.location;
 if(protectedAt(p,x,z)||anchoredStarterStock({x,y,z})||boundSaleChestOwner({x,y,z})||
    (publicStarterEnabled()&&publicStarterAt(x,y,z))||generators.has(`${x},${y},${z}`)||
    generators.has(`${x},${y-1},${z}`))return false;
 const id=plotAt(x,z);
 if(protectedPlotFoundation(p,block.location,id))return false;
 if(isOperator(p))return true;
 if(insideSquare({x,z},C.spawn,spawnLimit()))return false;
 const plannedPlot=plotAt(x,z,true);
 return plannedPlot<0||(plannedPlot===id&&canBuild(p,id));
});
function marketRead(){
 const raw=world.getDynamicProperty(MARKET_KEY);
 if(raw===undefined||raw===null)return [];
 let records;
 try{records=JSON.parse(String(raw))}catch{throw Error('Market data corrupt: preserving original data. Operator recovery required.')}
 if(!Array.isArray(records))throw Error('Market data has invalid structure; refusing overwrite.');
 return records;
}
function marketSave(v){
 const json=JSON.stringify(v);
 if(json.length>30000)throw Error('Marketplace persistence capacity exhausted');
 world.setDynamicProperty(MARKET_KEY,json);
 if(world.getDynamicProperty(MARKET_KEY)!==json)throw Error('Marketplace write verification failed');
 return true;
}
function inventory(p){return p.getComponent('minecraft:inventory')?.container}
function itemChoices(p){const inv=inventory(p),a=[];if(!inv)return a;for(let slot=0;slot<inv.size;slot++){const it=inv.getItem(slot);if(it&&!isTool(it)&&it.lockMode===ItemLockMode.none&&it.typeId!=='minecraft:air'&&!it.nameTag?.startsWith('§bSkyGen '))a.push({slot,it})}return a}
function fit(p,it){const inv=inventory(p);if(!inv)return false;for(let i=0;i<inv.size;i++){const q=inv.getItem(i);if(!q)return true;if(q.typeId===it.typeId&&!q.nameTag&&!it.nameTag&&q.amount+it.amount<=q.maxAmount)return true}return false}
function give(p,it){return !inventory(p)?.addItem(it)}
function removeExact(p,slot,id,count){const inv=inventory(p),it=inv?.getItem(slot);if(!it||it.typeId!==id||it.amount<count||isTool(it)||it.lockMode!==ItemLockMode.none)return false;if(it.amount===count)inv.setItem(slot,undefined);else{it.amount-=count;inv.setItem(slot,it)}return true}
function buildGenerator(g){
 const dim=world.getDimension('overworld');
 const base=dim.getBlock({x:g.x,y:g.y,z:g.z});
 const output=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
 if(!base||!output)return false;
 // New placements may NEVER overwrite player blocks or preexisting bedrock.
 // Registered legacy bedrock is migrated only in the watchdog below.
 if(!base.isAir||!output.isAir)return false;
 const core=generatorCoreType(g);
 if(!core)throw Error('Unknown generator core for '+g.type);
 try{
  base.setType(core);
  if(dim.getBlock({x:g.x,y:g.y,z:g.z})?.typeId!==core)throw Error('Generator base placement not verified');
  output.setType(g.block);
  if(dim.getBlock({x:g.x,y:g.y+1,z:g.z})?.typeId!==g.block)throw Error('Generator output placement not verified');
  return true;
 }catch(err){
  // Scope rollback to blocks this invocation created, never unrelated blocks.
  try{if(dim.getBlock({x:g.x,y:g.y+1,z:g.z})?.typeId===g.block)output.setType('minecraft:air')}catch{}
  try{if(dim.getBlock({x:g.x,y:g.y,z:g.z})?.typeId===core)base.setType('minecraft:air')}catch{}
  throw err;
 }
}
// Delete only the registered core and its expected output. On a failed block
// write, restore the previous state before the management UI restores registry.
function eraseGeneratorWorldBlocks(dim,g){
 const loc={x:g.x,y:g.y,z:g.z},above={x:g.x,y:g.y+1,z:g.z};
 const base=dim.getBlock(loc),output=dim.getBlock(above);
 if(!base||!output||!isGeneratorBase(g,base))throw Error('Registered generator base unavailable/mismatched');
 const oldBase=base.typeId,oldOutput=output.typeId;
 try{
  if(oldOutput===g.block){
   output.setType('minecraft:air');
   if(dim.getBlock(above)?.typeId!=='minecraft:air')throw Error('Output erase not verified');
  }
  base.setType('minecraft:air');
  if(dim.getBlock(loc)?.typeId!=='minecraft:air')throw Error('Core erase not verified');
 }catch(err){
  // Restore only if the current block is air; never overwrite player changes.
  try{if(dim.getBlock(loc)?.typeId==='minecraft:air')base.setType(oldBase)}catch(e){genError('CRITICAL core delete rollback '+e,'rollback')}
  try{if(oldOutput===g.block&&dim.getBlock(above)?.typeId==='minecraft:air')output.setType(oldOutput)}catch(e){genError('CRITICAL output delete rollback '+e,'rollback')}
  throw err;
 }
}
// Two-bank / multi-key registry. Never truncate records or overwrite the
// legacy sg_generators backup. The commit marker is the final atomic write.
let generatorRegistryLoaded=false;
function generatorChecksum(raw){
 let h=2166136261;for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}
 return (h>>>0).toString(16);
}
function generatorChunks(raw){
 const chunks=[];for(let i=0;i<raw.length;i+=GEN_REGISTRY_BYTES)chunks.push(raw.slice(i,i+GEN_REGISTRY_BYTES));
 return chunks.length?chunks:['[]'];
}
function generatorRead(){
 const metaRaw=world.getDynamicProperty(GEN_STORAGE_META);
 if(metaRaw===undefined||metaRaw===null){
  const legacy=world.getDynamicProperty(GEN_STORAGE_LEGACY);
  return legacy===undefined||legacy===null?[]:JSON.parse(String(legacy));
 }
 const meta=JSON.parse(String(metaRaw));
 if(!meta||meta.v!==2||![0,1].includes(meta.bank)||!Number.isSafeInteger(meta.chunks)||meta.chunks<1||meta.chunks>GEN_REGISTRY_SHARDS||typeof meta.checksum!=='string')throw Error('Invalid generator v2 manifest');
 let raw='';for(let i=0;i<meta.chunks;i++){
  const part=world.getDynamicProperty('sg_g2_'+meta.bank+'_'+i);
  if(typeof part!=='string')throw Error('Missing generator data shard '+i);
  raw+=part;
 }
 if(generatorChecksum(raw)!==meta.checksum)throw Error('Generator registry checksum failed; backup preserved');
 const records=JSON.parse(raw);
 if(!Array.isArray(records)||records.length!==meta.records)throw Error('Generator registry record count invalid');
 return records;
}
function genSave(){
 try{
  if(!generatorRegistryLoaded)throw Error('Generator registry has not loaded safely');
  if(generators.size>GEN_REGISTRY_LIMIT)throw Error('Generator registry limit reached');
  const raw=JSON.stringify([...generators]);
  const chunks=generatorChunks(raw);
  if(chunks.length>GEN_REGISTRY_SHARDS)throw Error('Generator registry storage full; no records discarded');
  const previous=world.getDynamicProperty(GEN_STORAGE_META);
  const previousMeta=previous===undefined||previous===null?null:JSON.parse(String(previous));
  const bank=previousMeta?.bank===0?1:0;
  for(let i=0;i<chunks.length;i++){
   const key='sg_g2_'+bank+'_'+i;
   world.setDynamicProperty(key,chunks[i]);
   if(world.getDynamicProperty(key)!==chunks[i])throw Error('Generator shard write not verified '+i);
  }
  const meta=JSON.stringify({v:2,bank,chunks:chunks.length,records:generators.size,checksum:generatorChecksum(raw)});
  world.setDynamicProperty(GEN_STORAGE_META,meta);
  if(world.getDynamicProperty(GEN_STORAGE_META)!==meta)throw Error('Generator commit marker write failed');
  return true;
 }catch(e){genError('save '+e,'save');return false}
}
function genLoad(){
 try{
  const records=generatorRead();
  if(!Array.isArray(records))throw Error('Invalid generator registry');
  const incoming=new Map();
  for(const entry of records){
   if(!Array.isArray(entry)||entry.length!==2)throw Error('Invalid generator entry');
   const [k,v]=entry;
   if(typeof k!=='string'||!v||!GENS.some(g=>g.name===v.type)||!Number.isFinite(v.x)||!Number.isFinite(v.y)||!Number.isFinite(v.z))throw Error('Invalid generator '+k);
   if(incoming.has(k))throw Error('Duplicate generator '+k);
   incoming.set(k,v);
  }
  if(incoming.size>GEN_REGISTRY_LIMIT)throw Error('Generator registry exceeds maximum; data preserved');
  // Change only the expected output field for authenticated old Quartz records;
  // NEVER replace any existing physical block during this data migration.
  let quartzMigrated=0;
  for(const [,v] of incoming)if(v.type==='Nether Quartz'&&v.block==='minecraft:nether_quartz_ore'){
   v.block='minecraft:quartz_ore';quartzMigrated++;
  }
  generators.clear();for(const [k,v] of incoming)generators.set(k,v);
  genCursor=undefined;genEmptySeconds.clear();genDueByKey.clear();genDueBuckets.clear();
  generatorRegistryLoaded=true;
  if(quartzMigrated){
   if(!genSave())throw Error('Quartz registry migration did not commit; generator editing disabled');
   console.warn('[SkyGen GENERATORS] migrated '+quartzMigrated+' Quartz registry output ID(s), without touching world blocks');
  }
 }catch(e){generatorRegistryLoaded=false;genError('CRITICAL registry load failed; persistence disabled: '+e,'load')}
}
function playerByName(name){return world.getAllPlayers().find(q=>q.name.toLowerCase()===String(name).toLowerCase())}

const SPAWN_PAD_RADIUS=12;
const forcefieldTickets=new Map();
const PLOT_TIERS=[{radius:24,cost:0,name:'Starter 49×49'},{radius:40,cost:250000,name:'Expanded 81×81'},{radius:56,cost:1000000,name:'Estate 113×113'}];
function plotRadius(id){const n=Number(world.getDynamicProperty('sg_plot_radius_'+id)??24);return [24,40,56].includes(n)?n:24}

// Independent from plot-owned generator registry. It runs even when no player
// has purchased a private generator, and it does not touch any other spawn block.
// Event-driven immediate refill for public Level 10 mine blocks.
function refillPublicInstant(g){
 try{
  if(!publicStarterEnabled()||publicGeneratorLevel(g.block)<GENERATOR_MAX_LEVEL)return;
  const key=`${g.x},${g.y},${g.z}`,dim=world.getDimension('overworld');
  const block=loadedPlotBlock(dim,g.x,g.y,g.z);
  if(!block||!block.isAir)return;
  block.setType(g.block);
  if(block.typeId!==g.block)throw Error('Public instant refill verification failed');
  publicStarterDue.delete(key);
 }catch(err){console.warn('[SkyGen PUBLIC MINE] fast refill failed '+err)}
}
function publicStarterHeartbeat(){
 try{
  if(!publicStarterEnabled()){publicStarterDue.clear();return}
  const dim=world.getDimension('overworld');
  for(const gen of PUBLIC_STARTER_GENERATORS){
   const key=`${gen.x},${gen.y},${gen.z}`;
   const block=loadedPlotBlock(dim,gen.x,gen.y,gen.z);
   if(!block)continue; // chunk unavailable; do not treat unloaded as an empty block
   if(block.typeId===gen.block){publicStarterDue.delete(key);publicStarterBlockedWarnings.delete(key);continue}
   if(!block.isAir){
    publicStarterDue.delete(key);
    if(!publicStarterBlockedWarnings.has(key)){
     publicStarterBlockedWarnings.add(key);
     console.warn('[SkyGen PUBLIC MINE] Non-air block at '+key+' ('+block.typeId+'); will not overwrite it.');
    }
    continue;
   }
   if(!publicStarterDue.has(key)){publicStarterDue.set(key,system.currentTick+publicGeneratorDelay(gen));continue}
   if(system.currentTick<publicStarterDue.get(key))continue;
   try{
    block.setType(gen.block);
    if(block.typeId!==gen.block)throw Error('Output type verification failed');
    publicStarterDue.delete(key);
   }catch(err){console.warn('[SkyGen PUBLIC MINE] Cannot regenerate '+key+': '+err)}
  }
 }catch(err){console.warn('[SkyGen PUBLIC MINE] heartbeat '+err)}
 finally{system.runTimeout(publicStarterHeartbeat,5)}
}

// Fixed original SkyGen spawn. Ignore older v0.9.7 movable-spawn settings;
// leave those legacy properties untouched for safe backup/rollback.
// Versioned, operator-verified arrival anchor. Previous movable-spawn keys are
// deliberately ignored; an OP must explicitly confirm the actual platform.
const SPAWN_ANCHOR_KEY='sg_spawn_anchor_v0103';
function spawnPosition(){
 try{
  const raw=world.getDynamicProperty(SPAWN_ANCHOR_KEY);
  if(typeof raw!=='string')return C.spawn;
  const c=JSON.parse(raw);
  if(c&&['x','y','z'].every(k=>Number.isSafeInteger(c[k]))&&Math.abs(c.x)<=29000000&&Math.abs(c.z)<=29000000&&c.y>=-63&&c.y<=317)return {x:c.x,y:c.y,z:c.z};
 }catch(e){console.warn('[SkyGen SPAWN] invalid anchor; using original '+e)}
 return C.spawn;
}
function spawnIsOriginal(){const s=spawnPosition();return s.x===C.spawn.x&&s.y===C.spawn.y&&s.z===C.spawn.z}
function spawnLimit(){return 116}
function plotUpgradeMenu(p){
 const d=profile(p),id=d.plot;
 if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cPlot owner required.');
 const radius=plotRadius(id);
 const summary=PLOT_TIERS.map(t=>(t.radius===radius?'§aCURRENT  ':t.radius<radius?'§8OWNED  ':'§dLOCKED  ')+t.name+'  §6'+(t.cost?t.cost.toLocaleString()+' Credits':'Free')).join('\n');
 const next=PLOT_TIERS.find(t=>t.radius>radius);
 form(p,'Plot Expansion','§6Royal Land Registry\n'+summary+'\n\n§eWallet: '+Number(d.credits).toLocaleString()+' Credits\n§7Upgrades increase the protected boundary without moving your plot.',
 [next?'Review Next Upgrade':'Maximum Tier Reached','Back to My Plot'],i=>{
  if(i===1)return plotMenu(p);
  if(i===0&&next)return plotUpgradeConfirmMenu(p);
  return plotMenu(p);
 });
}
function plotUpgradeConfirmMenu(p){const d=profile(p),id=d.plot;if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cPlot owner required.');const r=plotRadius(id);const next=PLOT_TIERS.find(t=>t.radius>r);if(!next)return p.sendMessage('§aMaximum plot size purchased.');
 try{recoverEconomicTxn(p);if(readEconomicTxn(p))return p.sendMessage('§cEconomic transaction pending operator review.')}catch(e){return p.sendMessage('§cEconomic recovery failed: '+e)}
 showUI(p,skyMessage().title('§aEXPAND YOUR PLOT').body(`Current: ${2*r+1}×${2*r+1}\nNext: ${next.name}\nUpgrade price: ${next.cost.toLocaleString()} Credits\nBalance: ${d.credits.toLocaleString()} Credits\nThe boundary expands without resetting your existing structures.`).button1('Cancel').button2('Buy Upgrade')).then(res=>{if(res.canceled)return;if(res.selection!==1)return menuAgain(p,()=>plotUpgradeMenu(p));try{const fresh=profile(p);if(fresh.plot!==id||ownerId(id)!==p.id||plotRadius(id)!==r)return p.sendMessage('§cPlot state changed. Retry.');if(fresh.credits<next.cost)return p.sendMessage('§cInsufficient Credits.');
 // Commit a pending world journal BEFORE changing the profile. Profile debit and
 // transaction ID are a single player dynamic-property write.
 if(plotOverlapsProtection(id,next.radius))return p.sendMessage('§cThis expansion would overlap protected spawn or city land. No Credits charged.');
 const tx=beginEconomicTxn(p,'plot',{plot:id,oldRadius:r,newRadius:next.radius,cost:next.cost});
 try{
  const balance=profile(p);if(balance.credits<next.cost)throw Error('Credits changed before payment');
  balance.credits-=next.cost;balance.sg_last_econ_txn=tx.id;save(p,balance);
  world.setDynamicProperty('sg_plot_radius_'+id,next.radius);
  if(plotRadius(id)!==next.radius)throw Error('Plot entitlement could not be verified');
  endEconomicTxn(p,tx,true);
 }catch(err){economicTxnReview(p,tx,'Upgrade interrupted: '+err);throw err}
 p.sendMessage(`§aPlot upgraded to ${next.name}! Credits charged: ${next.cost.toLocaleString()}.`);
 }catch(err){p.sendMessage('§cPlot upgrade failed: '+err)}finally{menuAgain(p,()=>plotUpgradeMenu(p))}}).catch(e=>p.sendMessage('§cUpgrade menu error: '+e));
}
const showTeleportText=(p,text)=>{rewardNotices.interrupt(p.id);purgeAnnouncementUntil=Math.max(purgeAnnouncementUntil,system.currentTick+35);try{p.onScreenDisplay.setTitle(text,{fadeInDuration:0,stayDuration:20,fadeOutDuration:0})}catch{}try{p.onScreenDisplay.setActionBar(text)}catch{}};
// Damage sanctuary is limited to the central citadel island, NOT its bridges.
// Citadel blueprint occupies x/z -48..48; use a conservative circular footprint
// so the four connecting paths are outside the no-kill boundary.
function isCentralIslandSanctuary(x,z){
 // Exact octagon footprint from the Sky Realm Builder citadel Y=0 floor.
 // Bridges begin beyond |x| or |z|=23; protect ALL elevations above/below floor.
 const dx=Math.abs(Math.floor(x)-C.spawn.x),dz=Math.abs(Math.floor(z)-C.spawn.z);
 return dx<=23&&dz<=23&&(dx+dz)<=37;
}
function insideSquare(point,center,radius){
 return Math.abs(point.x-center.x)<=radius&&Math.abs(point.z-center.z)<=radius;
}
function inSpawn(x,z){return insideSquare({x,z},spawnPosition(),spawnLimit())}
function blastProtected(x,z){
 return Boolean(arenaAt(x,z))||inSpawn(x,z)||inBuiltSkyRealm(x,z)||plotAt(x,z)>=0;
}
function pistonArea(x,z){
 return (arenaAt(x,z)?.id??'')+'|'+(inSpawn(x,z)?'spawn':'')+'|'+(inBuiltSkyRealm(x,z)?'city':'')+'|'+plotAt(x,z);
}
function nearPistonBoundary(x,z){
 if(inPistonBuffer(x,z,spawnPosition(),spawnLimit())||
    (cityProtectionActive()&&inPistonBuffer(x,z,C.spawn,spawnLimit())))return true;
 const reach=PLOT_TIERS.at(-1).radius+PISTON_REACH;
 const firstCol=Math.max(0,Math.ceil((x-C.base.x-reach)/C.spacing));
 const lastCol=Math.min(C.columns-1,Math.floor((x-C.base.x+reach)/C.spacing));
 const firstRow=Math.max(0,Math.ceil((z-C.base.z-reach)/C.spacing));
 const lastRow=Math.min(Math.floor(64000/C.columns),Math.floor((z-C.base.z+reach)/C.spacing));
 for(let row=firstRow;row<=lastRow;row++)for(let col=firstCol;col<=lastCol;col++){
  const id=row*C.columns+col;
  if(id<=64000&&inPistonBuffer(x,z,coords(id),plotRadius(id)))return true;
 }
 return false;
}
function dropProtectedPiston(dimension,loc,type){
 dimension.spawnItem(new ItemStack(type,1),{x:loc.x+.5,y:loc.y+.25,z:loc.z+.5});
}
function plotOverlapsProtection(id,radius,anchor=spawnPosition()){
 const center=coords(id);
 return insideSquare(center,anchor,spawnLimit()+radius)||
  (cityProtectionActive()&&insideSquare(center,C.spawn,spawnLimit()+radius));
}
function overlappingPlots(anchor,radius,ownedOnly=false){
 const reach=spawnLimit()+radius;
 const firstCol=Math.max(0,Math.ceil((anchor.x-reach-C.base.x)/C.spacing));
 const lastCol=Math.min(C.columns-1,Math.floor((anchor.x+reach-C.base.x)/C.spacing));
 const firstRow=Math.max(0,Math.ceil((anchor.z-reach-C.base.z)/C.spacing));
 const lastRow=Math.min(Math.floor(64000/C.columns),Math.floor((anchor.z+reach-C.base.z)/C.spacing));
 const ids=[];
 for(let row=firstRow;row<=lastRow;row++)for(let col=firstCol;col<=lastCol;col++){
  const id=row*C.columns+col;
  if(id<=64000&&(!ownedOnly||(ownerId(id)&&insideSquare(coords(id),anchor,spawnLimit()+plotRadius(id)))))ids.push(id);
 }
 return ids;
}
function spawnFloorBlock(dim,x,y,z){return loadedPlotBlock(dim,x,y,z)}
function orderedLandingOffsets(radius){
 const points=[];
 for(let dx=-radius;dx<=radius;dx++)for(let dz=-radius;dz<=radius;dz++)points.push([dx,dz]);
 return points.sort((a,b)=>a[0]**2+a[1]**2-b[0]**2-b[1]**2);
}
const SPAWN_LANDING_OFFSETS=orderedLandingOffsets(SPAWN_PAD_RADIUS);
const PLOT_LANDING_OFFSETS=orderedLandingOffsets(8);
const UNSAFE_LANDING_FLOORS=new Set(['minecraft:water','minecraft:flowing_water','minecraft:lava',
 'minecraft:flowing_lava','minecraft:magma','minecraft:fire','minecraft:soul_fire','minecraft:cactus',
 'minecraft:powder_snow','minecraft:campfire','minecraft:soul_campfire','minecraft:sweet_berry_bush']);
// Stable runtimes may omit Block.isSolid. Use common full blocks as the conservative fallback.
const KNOWN_LANDING_FLOORS=new Set(['stone','cobblestone','stonebrick','stone_bricks','dirt','grass_block',
 'coarse_dirt','deepslate','cobbled_deepslate','polished_deepslate','blackstone','polished_blackstone','polished_blackstone_bricks',
 'bedrock','obsidian','crying_obsidian','glass','bricks','brick_block','netherrack','end_stone','smooth_stone',
 'quartz_block','purpur_block','prismarine','sea_lantern','terracotta','hardened_clay','sandstone','red_sandstone',
 'polished_andesite','polished_diorite','polished_granite','andesite','diorite','granite','grass']);
function safeLandingFloor(block){
 try{
  if(!block||block.isAir||block.isLiquid||block.isWaterlogged||UNSAFE_LANDING_FLOORS.has(block.typeId))return false;
  if(typeof block.isSolid==='boolean')return block.isSolid;
  if(!block.typeId.startsWith('minecraft:'))return false;
  const id=block.typeId.slice(10);
  return KNOWN_LANDING_FLOORS.has(id)||/_(planks|concrete|terracotta|wool|stained_glass|log|stem)$/.test(id);
 }catch{return false}
}
function findSafeLanding(center,offsets,floorLevels,isAllowed,arrivalOffset){
 const dim=world.getDimension('overworld');
 for(const [dx,dz] of offsets){
  const x=center.x+dx,z=center.z+dz;
  if(!isAllowed(x,z))continue;
  for(const floor of floorLevels){
   if(!safeLandingFloor(loadedPlotBlock(dim,x,floor,z)))continue;
   if([1,2,3].every(dy=>loadedPlotBlock(dim,x,floor+dy,z)?.isAir))
    return {x:x+0.5,y:floor+arrivalOffset,z:z+0.5};
  }
 }
 return undefined;
}
function spawnLanding(){
 const s=spawnPosition();
 return findSafeLanding(s,SPAWN_LANDING_OFFSETS,[s.y-1],(x,z)=>{
  const id=plotAt(x,z);
  return inSpawn(x,z)&&(id<0||!ownerId(id));
 },1);
}
function spawnDiagnostics(){
 const s=spawnPosition(),dim=world.getDimension('overworld');
 const floor=spawnFloorBlock(dim,s.x,s.y-1,s.z),feet=spawnFloorBlock(dim,s.x,s.y,s.z);
 return {anchor:s,chunkLoaded:!!floor&&!!feet,centerFloor:!!floor&&!floor.isAir,centerHeadroom:!!feet&&[0,1,2].every(dy=>spawnFloorBlock(dim,s.x,s.y+dy,s.z)?.isAir),landing:spawnLanding()};
}
// Create the original spawn platform once per world (air-only: no player builds overwritten).
// All protected spawn coordinates are fixed to x/z -12..12, with a floor at Y=0.
// This is designed for the SkyGen void-world origin. Natural terrain that blocks
// the landing is NOT cleared, and the script never silently moves spawn.
const FIXED_SPAWN_FLOOR_KEY='sg_fixed_spawn_floor_v098';
let fixedSpawnDefaultApplied=false,spawnAreaChanging=false;
function createSpawn(){
 try{
  const dim=world.getDimension('overworld'),s=spawnPosition();
  // Avoid issuing commands against an unloaded destination.
  if(!spawnFloorBlock(dim,s.x,s.y-1,s.z))return false;
  try{dim.runCommand(`fill ${s.x-SPAWN_PAD_RADIUS} ${s.y-1} ${s.z-SPAWN_PAD_RADIUS} ${s.x+SPAWN_PAD_RADIUS} ${s.y-1} ${s.z+SPAWN_PAD_RADIUS} stone_bricks keep`)}
  catch(err){console.warn('[SkyGen] air-only spawn platform fill: '+err)}
  if(!spawnLanding())return false;
  world.setDynamicProperty(FIXED_SPAWN_FLOOR_KEY,true);
  return true;
 }catch(err){console.warn('[SkyGen] fixed spawn platform setup failed: '+err);return false}
}
function syncFixedDefaultSpawn(){
 if(fixedSpawnDefaultApplied)return true;
 const s=spawnPosition(),dim=world.getDimension('overworld');
 try{dim.runCommand(`setworldspawn ${s.x} ${s.y} ${s.z}`);fixedSpawnDefaultApplied=true;return true}
 catch(err){
  try{world.setDefaultSpawnLocation({...s});fixedSpawnDefaultApplied=true;return true}
  catch(fallback){console.warn('[SkyGen] fixed worldspawn failed '+err+' / '+fallback);return false}
 }
}
function ensureSpawn(){
 // Migrate worlds from v0.9.7 even if its stale sg_spawn_ready flag is true.
 if(spawnIsOriginal()&&world.getDynamicProperty(FIXED_SPAWN_FLOOR_KEY)!==true)createSpawn();
 const target=spawnLanding();
 if(!target)return undefined; // Never teleport into a blocked or absent platform.
 syncFixedDefaultSpawn();
 if(world.getDynamicProperty('sg_spawn_ready')!==true)world.setDynamicProperty('sg_spawn_ready',true);
 return target;
}
// Keep the verified spawn area loaded for arrivals from remote plots.
function preloadSpawnArea(dim){
 try{return dim.runCommand('tickingarea preload sg_spawn_safe true')?.successCount>0}
 catch{return false}
}
function stageFixedSpawnAreaAt(s){
 const dim=world.getDimension('overworld');
 try{
  if(preloadSpawnArea(dim))return true;
  dim.runCommand(`tickingarea add circle ${s.x} ${s.y} ${s.z} 1 sg_spawn_safe true`);
  if(!preloadSpawnArea(dim))throw Error('Minecraft could not verify the spawn ticking area');
  return true;
 }catch(err){
  console.warn('[SkyGen SPAWN] unable to stage area at '+s.x+','+s.y+','+s.z+': '+err);
  return false;
 }
}
function stageFixedSpawnArea(){return !spawnAreaChanging&&stageFixedSpawnAreaAt(spawnPosition())}
async function replaceFixedSpawnArea(s){
 const dim=world.getDimension('overworld');
 if(preloadSpawnArea(dim)){
  dim.runCommand('tickingarea remove sg_spawn_safe');
  // Bedrock releases a removed name on a later tick. Reusing it too early can
  // appear successful while the new chunks were never registered.
  for(let i=0;i<5&&preloadSpawnArea(dim);i++)await new Promise(resolve=>system.runTimeout(resolve,2));
  if(preloadSpawnArea(dim))throw Error('Previous spawn ticking area could not be removed');
 }
 if(!stageFixedSpawnAreaAt(s))throw Error('Could not keep destination chunks loaded; check tickingarea limit');
}
const spawnStages=new Map();
function safeSpawnTravel(p,immediate=false,onArrival,canArrive){
 if(!p?.isValid)return;
 const begin=system.currentTick,id=p.id;
 if(spawnStages.has(id))return;
 if(!immediate&&pending.has(id))return p.sendMessage('§eTeleport already counting down.');
 if(!immediate&&system.currentTick<(cooldowns.get(id)||0))return p.sendMessage('§cTeleport cooldown is active.');
 const state={finished:false},dim=world.getDimension('overworld');
 spawnStages.set(id,state);
 function release(){
  if(state.finished)return;
  state.finished=true;
  if(spawnStages.get(id)===state)spawnStages.delete(id);
 }
 state.release=release;
 function check(){
  if(state.finished)return;
  if(!p.isValid||(canArrive&&!canArrive())){release();return}
  // Force loaded spawn before validating landing; retry while a stale plot
  // ticking area is being cleaned up. Never consume the warm-up on failure.
  if(!stageFixedSpawnArea()){
   if(system.currentTick-begin>240){
    p.sendMessage('§cSpawn ticking area could not be prepared. Operator: /tickingarea list all-dimensions');
    release();return;
   }
   system.runTimeout(check,10);return;
  }
  let target;
  try{target=ensureSpawn()}catch(e){console.warn('[SkyGen] fixed spawn verification '+e)}
  if(target){
   if(immediate){
    try{
     forcefieldTickets.set(id,{...target,expires:system.currentTick+5});
     if(typeof p.tryTeleport==='function'){if(!p.tryTeleport(target,{dimension:dim,checkForBlocks:false}))throw Error('Spawn chunk not ready')}
     else p.teleport(target,{dimension:dim,checkForBlocks:false});
     cooldowns.set(id,system.currentTick+teleportCooldown(p));
     p.sendMessage('§aSafe SkyGen spawn reached.');
     if(onArrival)onArrival();
    }catch(e){forcefieldTickets.delete(id);p.sendMessage('§cSpawn rescue unavailable; verify origin chunks: '+e)}
    release();
   }else{
    if(!tpRequest(p,target,'spawn',undefined,release,true))release();
   }
   return;
  }
  if(system.currentTick-begin>240){const s=spawnPosition();p.sendMessage('§cSpawn unavailable at '+s.x+', '+s.y+', '+s.z+'. Realm operator: /scriptevent skygen:spawn status');release();return}
  system.runTimeout(check,10);
 }
 system.runTimeout(check,immediate?1:10);
}
function bootFixedSpawn(attempt=0){
 const staged=stageFixedSpawnArea();
 try{if(staged&&ensureSpawn())return}catch(err){console.warn('[SkyGen] boot spawn check '+err)}
 if(attempt<39)system.runTimeout(()=>bootFixedSpawn(attempt+1),10);
 else console.warn('[SkyGen] spawn at '+JSON.stringify(spawnPosition())+' is blocked/unloaded. Operator can check /scriptevent skygen:spawn status.');
}
export const playerRoster=createPlayerRoster(world);
function rememberLeaderboardPlayer(p,d){
 try{playerRoster.remember(p,d)}
 catch(error){console.warn('[SkyGen Roster] '+error)}
}
function profile(p){
 const defaults={credits:1000,orbits:0,rank:1,xp:0,xpProgress:'0',plot:-1};
 const raw=p.getDynamicProperty('sg_profile');
 if(raw===undefined||raw===null)return defaults;
 if(typeof raw!=='string')throw Error('SkyGen profile storage is invalid; refusing to reset player data');
 let data;try{data=JSON.parse(raw)}catch{throw Error('SkyGen player profile is corrupt. Operator recovery required; data not overwritten.')}
 if(!data||typeof data!=='object'||Array.isArray(data))throw Error('SkyGen profile has invalid structure');
 for(const name of ['credits','orbits','rank','xp','plot']){
  const v=data[name];if(v!==undefined&&(!Number.isSafeInteger(v)||v< (name==='plot'?-1:0)))throw Error('SkyGen profile has invalid '+name+'; data not overwritten');
 }
 if(data.rank!==undefined&&(data.rank<1||data.rank>MAX_RANK))throw Error('Invalid rank; profile unchanged');
 const level=data.rank||1;
 const xpProgress=data.xpProgress===undefined?legacyProgress(Math.min(level,50),data.xp??0):data.xpProgress;
 parseProgress(xpProgress);
 // Numeric XP is a compatibility mirror, not the 1,000-rank source of truth.
 const xp=data.xpProgress===undefined?mirrorXP(level,xpProgress):(data.xp??mirrorXP(level,xpProgress));
 return {...defaults,...data,xp,xpProgress};
}
function save(p,d){
 // A review lock blocks unrelated credit changes, including rank rewards,
 // conversions and purchases, until an operator reconciles the journal.
 const journal=readEconomicTxn(p);
 if(journal&&journal.state!=='complete'&&!activeEconomicTxns.has(p.id)&&!economicReconcileBypass.has(p.id)){
  const before=profile(p);
  if(d.credits!==before.credits||JSON.stringify(d.bank)!==JSON.stringify(before.bank)||
     JSON.stringify(d.bankTransferReceipt)!==JSON.stringify(before.bankTransferReceipt))
   throw Error('Credits locked by pending economic review '+journal.id);
 }
 if(d.xpProgress===undefined)d.xpProgress=legacyProgress(Math.min(d.rank,50),d.xp||0);
 parseProgress(d.xpProgress);
 const json=JSON.stringify(d);
 p.setDynamicProperty('sg_profile',json);
 if(p.getDynamicProperty('sg_profile')!==json)throw Error('Player profile did not persist');
 rememberLeaderboardPlayer(p,d);
}
// v0.9.10 durable, fail-closed economic transaction journal. An ambiguous
// crash never triggers an automatic item or Credits refund; staff reconcile.
// One record per player and one in-flight mutation per tick/callback.
const activeEconomicTxns=new Set();
const economicReconcileBypass=new Set();
let economicTxnSequence=0;
function economicTxnKey(p){return 'sg_econ_journal_'+p.id}
function readEconomicTxn(p){
 const raw=world.getDynamicProperty(economicTxnKey(p));
 if(raw===undefined||raw===null)return null;
 const tx=JSON.parse(String(raw));
 if(!tx||tx.v!==1||typeof tx.id!=='string'||!['plot','buy','sell','gen','quest_fish','contract','beacon','district_order','collection','starter_kit','claim_box'].includes(tx.kind)||typeof tx.state!=='string')throw Error('Economic journal damaged; staff review needed');
 return tx;
}
function assertBankUnlocked(p){
 const journal=readEconomicTxn(p);
 if(journal&&journal.state!=='complete')throw Error('Economy locked by pending review '+journal.id);
}
function writeEconomicTxn(p,tx){
 const raw=tx===null?undefined:JSON.stringify(tx);
 world.setDynamicProperty(economicTxnKey(p),raw);
 if(world.getDynamicProperty(economicTxnKey(p))!==raw)throw Error('Economic journal write not verified');
}
function beginEconomicTxn(p,kind,details){
 if(activeEconomicTxns.has(p.id))throw Error('Another transaction is active');
 recoverEconomicTxn(p);
 if(readEconomicTxn(p))throw Error('Transaction awaiting operator reconciliation: /scriptevent skygen:txnreview');
 activeEconomicTxns.add(p.id);
 try{
  const tx={v:1,id:'t'+Date.now()+'_'+system.currentTick+'_'+(++economicTxnSequence)+'_'+p.id,kind,state:'prepared',before:profile(p).credits,...details};
  writeEconomicTxn(p,tx);
  return tx;
 }catch(e){activeEconomicTxns.delete(p.id);throw e}
}
function advanceEconomicTxn(p,tx,state){
 const current=readEconomicTxn(p);
 if(!current||current.id!==tx.id)throw Error('Economic journal changed during transaction');
 writeEconomicTxn(p,{...current,state});
}
function endEconomicTxn(p,tx,complete){
 try{
  if(complete){advanceEconomicTxn(p,tx,'complete');writeEconomicTxn(p,null)}
 }finally{activeEconomicTxns.delete(p.id)}
}
function economicTxnReview(p,tx,reason){
 try{const current=readEconomicTxn(p);if(current?.id===tx.id)writeEconomicTxn(p,{...current,state:'review',reason:String(reason).slice(0,140)})}
 catch(e){console.warn('[SkyGen SECURITY] journal review write failed '+p.id+' '+e)}
 activeEconomicTxns.delete(p.id);
 console.warn('[SkyGen ECON] LOCKED '+p.id+' tx='+tx.id+' '+reason);
 try{p.sendMessage('§cEconomic transaction '+tx.id+' requires operator reconciliation. Do not retry the transaction.')}catch{}
}
function plannedDebitIntact(p,tx){
 const inv=inventory(p);
 return tx.state==='prepared'&&inv&&Array.isArray(tx.slots)&&tx.slots.length&&tx.slots.every(([slot,id,amount])=>{
  const item=inv.getItem(slot);
  return eligibleShopItem(item,id)&&item.amount===amount;
 });
}
function recoverEconomicTxn(p){
 const tx=readEconomicTxn(p);
 if(!tx)return;
 if(tx.state==='complete'){writeEconomicTxn(p,null);return}
 if(tx.kind==='beacon'){
  try{
   if(nexusBeacon.hasReceipt(tx.week,p.id,tx.id)){endEconomicTxn(p,tx,true);return}
   if(plannedDebitIntact(p,tx)){writeEconomicTxn(p,null);return}
  }catch(error){console.warn('[Nexus Beacon] Donation recovery needs review: '+error)}
 }
 const d=profile(p),paid=d.sg_last_econ_txn===tx.id;
 if(tx.kind==='claim_box'){
  try{
   if(paid){finishClaimDelivery(p,tx);return}
   if(tx.state==='prepared'){writeEconomicTxn(p,null);return}
   if(tx.state==='delivering'&&claimSlotsDelivered(inventory(p),tx)){
    commitClaimDelivery(p,tx,d);return;
   }
   if(tx.state==='delivering'){
    restoreClaimSlots(inventory(p),tx);
    endEconomicTxn(p,tx,true);return;
   }
  }catch(error){console.warn('[SkyGen Claim Box] Recovery: '+error)}
  if(tx.state!=='review')economicTxnReview(p,tx,'Interrupted prize delivery; verify the marked inventory slots before reissuing.');
  return;
 }
 if(tx.kind==='starter_kit'){
  if(paid&&nextStarterKit(d)===tx.nextAt){endEconomicTxn(p,tx,true);return}
  if(!paid&&tx.state==='prepared'){writeEconomicTxn(p,null);return}
 }
 if(tx.kind==='collection'){
  try{
   const progress=collectionProgress(d,tx.collectionId);
   const row=progress?.rows.find(entry=>entry.item===tx.item);
   const donated=row?.donated??legacyCollectionDonation(d,tx.collectionId,tx.item);
   if(paid&&donated===tx.donated+tx.count&&
     (!progress.complete||validateCosmetics(d).owned.includes(progress.badge))){
    endEconomicTxn(p,tx,true);return;
   }
   if(!paid&&donated===tx.donated&&plannedDebitIntact(p,tx)){
    writeEconomicTxn(p,null);return;
   }
  }catch(error){console.warn('[Collection Hall] Donation recovery needs review: '+error)}
 }
 if(tx.kind==='district_order'){
  try{
   const filled=districtOrderUsage(d,tx.week)[tx.orderId]??0;
   const balance=destinationCredits(d,tx.destination);
   if(paid&&filled===tx.filled+tx.count&&balance===tx.destinationBefore+tx.credits){
    settleDistrictOrderBeacon(p,tx);
    endEconomicTxn(p,tx,true);return;
   }
   if(!paid&&filled===tx.filled&&balance===tx.destinationBefore&&plannedDebitIntact(p,tx)){
    writeEconomicTxn(p,null);return;
   }
  }catch(error){console.warn('[District Orders] Payout recovery needs review: '+error)}
 }
 if(tx.kind==='plot'&&tx.state==='prepared'){
  const current=plotRadius(tx.plot);
  if(paid&&d.credits===tx.before-tx.cost&&[tx.oldRadius,tx.newRadius].includes(current)){
   // The debit and nonce are in ONE profile write. Never debit a second time.
   if(current===tx.oldRadius){
    if(plotOverlapsProtection(tx.plot,tx.newRadius)){economicTxnReview(p,tx,'Pending paid upgrade overlaps spawn or city; resolve before applying.');return}
    world.setDynamicProperty('sg_plot_radius_'+tx.plot,tx.newRadius);
   }
   if(plotRadius(tx.plot)!==tx.newRadius)throw Error('Plot entitlement recovery failed');
   advanceEconomicTxn(p,tx,'complete');writeEconomicTxn(p,null);return;
  }
  if(!paid&&d.credits===tx.before&&current===tx.oldRadius){writeEconomicTxn(p,null);return}
 }
 if(tx.kind==='contract'&&tx.state==='prepared'){
  try{
   const field=contractClaimField(tx.kindContract),record=d[field];
   const claimed=record?.period===tx.period&&Array.isArray(record.ids)&&record.ids.includes(tx.quest);
   const balance=tx.destination==='wallet'?d.credits:d.bank?.accounts?.find(a=>a.id===tx.destination)?.credits;
   if(paid&&claimed&&balance===tx.destinationBefore+tx.total&&d.orbits===tx.beforeOrbits+tx.orbits){
    advanceEconomicTxn(p,tx,'complete');writeEconomicTxn(p,null);return;
   }
   if(!paid&&!claimed&&d.credits===tx.before&&d.orbits===tx.beforeOrbits&&balance===tx.destinationBefore){
    writeEconomicTxn(p,null);return;
   }
  }catch(err){console.warn('[SkyGen CONTRACT] Recovery needs review '+err)}
 }
 if((tx.kind==='buy'||tx.kind==='gen')&&tx.state==='prepared'&&!paid&&d.credits===tx.before){writeEconomicTxn(p,null);return}
 // A seller may have already had inventory removed; NEVER auto-restore.
 // A buyer may have received items; NEVER auto-refund or redeliver.
 if(tx.state!=='review')economicTxnReview(p,tx,'Interrupted transaction; inspect inventory and wallet before manually clearing');
}
function economicTxnClearCommand(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cRealm operator required.');
 const m=/^\s*(\S+)\s*\|\s*(\S+)\s*$/.exec(String(message||''));
 if(!m)return actor.sendMessage('§eUsage: /scriptevent skygen:txnclear PlayerName | ExactTransactionID (after manually reconciling)');
 const target=playerByName(m[1]);if(!target)return actor.sendMessage('§cTarget must be online.');
 const tx=readEconomicTxn(target);if(!tx||tx.id!==m[2])return actor.sendMessage('§cNo matching pending transaction.');
 if(tx.state!=='review')return actor.sendMessage('§cOnly review-state transactions can be cleared.');
 writeEconomicTxn(target,null);activeEconomicTxns.delete(target.id);
 adminAudit(actor,'CLEAR ECON REVIEW',target,tx.id+' '+tx.kind+' '+tx.reason);
 actor.sendMessage('§eReview lock cleared for '+target.name+'; settlement must already be completed manually.');
 target.sendMessage('§eYour SkyGen economic review lock has been cleared by an operator.');
}
function economicTxnReviewCommand(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cRealm operator required.');
 const name=String(message||'').trim();
 const targets=name?[playerByName(name)].filter(Boolean):world.getAllPlayers();
 if(!targets.length)return actor.sendMessage('§cPlayer must be online.');
 let found=0;
 for(const p of targets){let tx;try{tx=readEconomicTxn(p)}catch(e){actor.sendMessage('§c'+p.name+': corrupted journal '+e);continue}
  if(tx){found++;actor.sendMessage('§e'+p.name+' '+tx.kind+' '+tx.id+' ['+tx.state+'] before='+tx.before+' amount='+(tx.cost??tx.total??'n/a')+' reason='+(tx.reason||''));
   if(tx.kind==='quest_fish')actor.sendMessage('§7Quest '+(tx.quest+1)+' assigned '+tx.assigned+' · fish slots [slot, item, original, debit]: '+JSON.stringify(tx.slots));
  }}
 if(!found)actor.sendMessage('§aNo outstanding economic reviews for selected online players.');
}
const SKILL_BRANCHES=["Mining", "Mobility", "Survival", "Exploration", "Economy", "Engineering"];
const SKILLS=[{"id":"miner_haste_1","name":"Quick Hands I","desc":"Haste I on your plot","cost":1,"rank":2,"branch":"Mining","prev":null},{"id":"miner_haste_2","name":"Quick Hands II","desc":"Haste II on your plot","cost":2,"rank":10,"branch":"Mining","prev":"miner_haste_1"},{"id":"miner_xp_1","name":"Prospector I","desc":"+10% generator mining XP","cost":1,"rank":12,"branch":"Mining","prev":"miner_haste_2"},{"id":"miner_xp_2","name":"Prospector II","desc":"+25% generator mining XP","cost":2,"rank":20,"branch":"Mining","prev":"miner_xp_1"},{"id":"miner_luck_1","name":"Lucky Strikes I","desc":"2% chance of a bonus material","cost":2,"rank":25,"branch":"Mining","prev":"miner_xp_2"},{"id":"miner_luck_2","name":"Lucky Strikes II","desc":"4% chance of a bonus material","cost":3,"rank":35,"branch":"Mining","prev":"miner_luck_1"},{"id":"miner_master","name":"Master Miner","desc":"+50% generator mining XP total","cost":4,"rank":45,"branch":"Mining","prev":"miner_luck_2"},{"id":"move_speed_1","name":"Swift Steps I","desc":"Speed I on your plot","cost":1,"rank":2,"branch":"Mobility","prev":null},{"id":"move_speed_2","name":"Swift Steps II","desc":"Speed II on your plot","cost":2,"rank":12,"branch":"Mobility","prev":"move_speed_1"},{"id":"move_jump_1","name":"High Jumper I","desc":"Jump Boost I, toggleable","cost":1,"rank":8,"branch":"Mobility","prev":"move_speed_2"},{"id":"move_jump_2","name":"High Jumper II","desc":"Jump Boost II, toggleable","cost":2,"rank":18,"branch":"Mobility","prev":"move_jump_1"},{"id":"move_fall","name":"Feather Foot","desc":"Slow Falling, toggleable","cost":2,"rank":25,"branch":"Mobility","prev":"move_jump_2"},{"id":"move_tp_1","name":"Fast Traveler","desc":"Teleport cooldown 20% shorter","cost":3,"rank":35,"branch":"Mobility","prev":"move_fall"},{"id":"move_tp_2","name":"Wayfinder","desc":"Teleport cooldown 40% shorter","cost":4,"rank":45,"branch":"Mobility","prev":"move_tp_1"},{"id":"surv_resist","name":"Stone Skin","desc":"Resistance I on your plot","cost":1,"rank":5,"branch":"Survival","prev":null},{"id":"surv_regen","name":"Vitality","desc":"Regeneration I on your plot","cost":2,"rank":15,"branch":"Survival","prev":"surv_resist"},{"id":"surv_health","name":"Fortified","desc":"Health Boost I on your plot","cost":2,"rank":20,"branch":"Survival","prev":"surv_regen"},{"id":"surv_fire","name":"Flameproof","desc":"Fire Resistance on your plot","cost":2,"rank":25,"branch":"Survival","prev":"surv_health"},{"id":"surv_absorb","name":"Second Wind","desc":"Active Absorption, 2-minute cooldown","cost":2,"rank":30,"branch":"Survival","prev":"surv_fire"},{"id":"surv_regen2","name":"Greater Vitality","desc":"Regeneration II on your plot","cost":3,"rank":40,"branch":"Survival","prev":"surv_absorb"},{"id":"surv_saturate","name":"Survival Feast","desc":"Active Saturation, 5-minute cooldown","cost":4,"rank":48,"branch":"Survival","prev":"surv_regen2"},{"id":"explore_night","name":"Night Owl","desc":"Night Vision on your plot","cost":1,"rank":2,"branch":"Exploration","prev":null},{"id":"explore_water","name":"Deep Diver","desc":"Water Breathing on your plot","cost":1,"rank":10,"branch":"Exploration","prev":"explore_night"},{"id":"explore_conduit","name":"Tidal Power","desc":"Conduit Power while underwater","cost":2,"rank":18,"branch":"Exploration","prev":"explore_water"},{"id":"explore_dolphin","name":"Ocean Runner","desc":"Speed I while underwater","cost":2,"rank":25,"branch":"Exploration","prev":"explore_conduit"},{"id":"explore_invisible","name":"Shadow Step","desc":"Active invisibility, 4-minute cooldown","cost":2,"rank":30,"branch":"Exploration","prev":"explore_dolphin"},{"id":"explore_reward","name":"Expedition Rewards","desc":"+20% Daily Quest Credits","cost":2,"rank":35,"branch":"Exploration","prev":"explore_invisible"},{"id":"explore_master","name":"Expedition Master","desc":"All exploration passives work across your plot, even on land","cost":4,"rank":45,"branch":"Exploration","prev":"explore_reward"},{"id":"econ_sell_1","name":"Merchant I","desc":"+2% ordinary shop sale price","cost":1,"rank":2,"branch":"Economy","prev":null},{"id":"econ_buy_1","name":"Bargain Hunter I","desc":"2% off ordinary shop purchases","cost":1,"rank":8,"branch":"Economy","prev":"econ_sell_1"},{"id":"econ_sell_2","name":"Merchant II","desc":"+5% ordinary shop sale price","cost":2,"rank":15,"branch":"Economy","prev":"econ_buy_1"},{"id":"econ_buy_2","name":"Bargain Hunter II","desc":"5% off ordinary shop purchases","cost":2,"rank":22,"branch":"Economy","prev":"econ_sell_2"},{"id":"econ_rank","name":"Rank Rewards","desc":"+10% future rank Credits","cost":2,"rank":28,"branch":"Economy","prev":"econ_buy_2"},{"id":"econ_sell_3","name":"Master Merchant","desc":"+10% shop sale prices","cost":3,"rank":36,"branch":"Economy","prev":"econ_rank"},{"id":"econ_buy_3","name":"Master Negotiator","desc":"10% off shop purchases","cost":4,"rank":45,"branch":"Economy","prev":"econ_sell_3"},{"id":"eng_speed_1","name":"Tuned Pistons I","desc":"5% quicker generator recovery","cost":1,"rank":3,"branch":"Engineering","prev":null},{"id":"eng_speed_2","name":"Tuned Pistons II","desc":"10% quicker generator recovery","cost":2,"rank":12,"branch":"Engineering","prev":"eng_speed_1"},{"id":"eng_slots_1","name":"Builder Permit I","desc":"5 additional generator slots","cost":1,"rank":15,"branch":"Engineering","prev":"eng_speed_2"},{"id":"eng_speed_3","name":"Tuned Pistons III","desc":"15% quicker generator recovery","cost":2,"rank":25,"branch":"Engineering","prev":"eng_slots_1"},{"id":"eng_slots_2","name":"Builder Permit II","desc":"10 additional generator slots","cost":2,"rank":30,"branch":"Engineering","prev":"eng_speed_3"},{"id":"eng_price_1","name":"Factory Contracts I","desc":"5% off generator purchases and upgrades","cost":3,"rank":38,"branch":"Engineering","prev":"eng_slots_2"},{"id":"eng_price_2","name":"Factory Contracts II","desc":"10% off generator purchases and upgrades","cost":4,"rank":47,"branch":"Engineering","prev":"eng_price_1"}];

// v0.9.0: skill point entitlement derives from rank: old players automatically
// receive points without a one-time grant that could duplicate on reinstall.
function teleportCooldown(p){
 try{const d=profile(p);return Math.max(40,Math.floor(C.cooldown*(hasSkill(d,'move_tp_2')?0.6:hasSkill(d,'move_tp_1')?0.8:1)))}
 catch{return C.cooldown}
}
// Preserve 59 points at Rank 50; grant up to 31 more to finish the 90-point tree.
function skillEntitlement(rank){const n=Math.max(1,Math.min(MAX_RANK,rank));return Math.min(90,Math.max(0,Math.min(50,n)-1)+2*Math.floor(Math.min(50,n)/10)+Math.max(0,n-50))}
function purchasedSkills(d){return Array.isArray(d.skills)?d.skills:[]}
function hasSkill(d,id){return purchasedSkills(d).includes(id)}
function skillSpent(d){return purchasedSkills(d).reduce((sum,id)=>sum+(SKILLS.find(s=>s.id===id)?.cost||0),0)}
function skillAvailable(d){return Math.max(0,skillEntitlement(d.rank)-skillSpent(d))}
function perkValue(d,kind){
 const values={
  sell:[['econ_sell_3',10],['econ_sell_2',5],['econ_sell_1',2]],
  buy:[['econ_buy_3',10],['econ_buy_2',5],['econ_buy_1',2]],
  generatorPrice:[['eng_price_2',10],['eng_price_1',5]],
  generatorSpeed:[['eng_speed_3',15],['eng_speed_2',10],['eng_speed_1',5]],
  miningXp:[['miner_master',50],['miner_xp_2',25],['miner_xp_1',10]],
  luck:[['miner_luck_2',4],['miner_luck_1',2]]
 };
 return values[kind]?.find(([id])=>hasSkill(d,id))?.[1]||0;
}
function discountedPrice(price,percent){return Math.max(1,Math.floor(price*(100-percent)/100))}
function generatorSlots(p){const d=profile(p);return GEN_BASE_SLOTS+(hasSkill(d,'eng_slots_2')?10:hasSkill(d,'eng_slots_1')?5:0)}
function generatorOwnerCount(p){let count=0;for(const g of generators.values())if(g.owner===p.id)count++;return count}
function effectivePeriod(g, heartbeat=null){
 // The heartbeat caches owner profiles only for its current tick; purchases, skill
 // changes and disconnects therefore cannot leave persistent stale bonuses.
 let bonus=0;
 try{
  if(heartbeat){
   if(!heartbeat.speedBonuses.has(g.owner)){
    const owner=heartbeat.players.get(g.owner);
    heartbeat.speedBonuses.set(g.owner,owner?perkValue(profile(owner),'generatorSpeed'):0);
   }
   bonus=heartbeat.speedBonuses.get(g.owner)||0;
  }else{
   const owner=world.getAllPlayers().find(p=>p.id===g.owner);
   if(owner)bonus=perkValue(profile(owner),'generatorSpeed');
  }
 }catch{}
 return (g.level||1)>=GENERATOR_MAX_LEVEL?1:Math.max(10,Math.floor((Number(g.period)||200)*(100-bonus)/100));
}
function affordableSkill(d,s){
 return !hasSkill(d,s.id)&&d.rank>=s.rank&&(!s.prev||hasSkill(d,s.prev))&&skillAvailable(d)>=s.cost;
}
function skillTree(p){
 const d=profile(p),spent=skillSpent(d),total=skillEntitlement(d.rank);
 form(p,'§dSKILL TREE',`Rank ${d.rank}/1000  §ePoints: ${total-spent}/${total}\n§7Permanent on-plot buffs, toggles and abilities. Combat buffs are restricted to your own plot.`,
 [...SKILL_BRANCHES.map(b=>b+' — '+purchasedSkills(d).filter(id=>SKILLS.some(s=>s.id===id&&s.branch===b)).length+'/7'),'Active Abilities / Toggles','Reset Skills','Back'],i=>{
  if(i<SKILL_BRANCHES.length)return skillBranchMenu(p,SKILL_BRANCHES[i]);
  if(i===SKILL_BRANCHES.length)return skillAbilities(p);
  if(i===SKILL_BRANCHES.length+1)return skillReset(p);
  skyMenuRanksSkills(p);
 });
}
function skillBranchMenu(p,branch){
 const d=profile(p),nodes=SKILLS.filter(s=>s.branch===branch);
 const status=s=>hasSkill(d,s.id)?'§aOWNED':affordableSkill(d,s)?'§eBUY':'§8LOCKED';
 form(p,'§d'+branch+' Skills',`Available points: ${skillAvailable(d)}\nUnlock skills in order. Rank and point requirements apply.`,
 [...nodes.map(s=>`${status(s)} §f${s.name} (${s.cost} SP, R${s.rank})`),'Back'],i=>{
  if(i>=nodes.length)return skillTree(p);
  const skill=nodes[i],current=profile(p);
  if(!affordableSkill(current,skill)){p.sendMessage('§cSkill locked: need prerequisite, rank and available Skill Points.');return menuAgain(p,()=>skillBranchMenu(p,branch));}
  showUI(p,skyMessage().title('§dLEARN '+skill.name).body(`${skill.desc}\nCost: ${skill.cost} Skill Point(s)\nRemaining: ${skillAvailable(current)-skill.cost}`).button1('Cancel').button2('Learn Skill')).then(r=>{
   if(r.canceled)return;
   if(r.selection!==1)return menuAgain(p,()=>skillBranchMenu(p,branch));
   try{
    const latest=profile(p);if(!affordableSkill(latest,skill))return p.sendMessage('§cSkill requirements have changed.');
    latest.skills=[...purchasedSkills(latest),skill.id];save(p,latest);
    p.sendMessage(`§aUnlocked ${skill.name}. ${skillAvailable(latest)} Skill Points remain.`);
   }catch(e){p.sendMessage('§cSkill could not save: '+String(e).slice(0,100))}
   finally{menuAgain(p,()=>skillBranchMenu(p,branch))}
  }).catch(e=>p.sendMessage('§cSkill menu error '+e));
 });
}
function skillReset(p){
 const d=profile(p);if(skillSpent(d)===0)return p.sendMessage('§eNo purchased skills to reset.');
 const cost=10000+d.rank*200;
 showUI(p,skyMessage().title('§cRESET ALL SKILLS').body(`Refund all spent Skill Points for ${cost} Credits? Rank and earned points are retained.\nCurrent Skill Points spent: ${skillSpent(d)}`).button1('Keep Skills').button2('Reset')).then(r=>{
  if(r.canceled)return;
  if(r.selection!==1)return menuAgain(p,()=>skillTree(p));
  try{const fresh=profile(p);if(fresh.credits<cost)return p.sendMessage('§cNot enough Credits.');
   fresh.credits-=cost;fresh.skills=[];save(p,fresh);p.sendMessage('§aSkill points refunded. Your rank stays unchanged.');
  }catch(e){p.sendMessage('§cReset could not save: '+e)}finally{menuAgain(p,()=>skillTree(p))}
 });
}
const skillCooldowns=new Map(),skillLastEffects=new Map(),skillActiveEffects=new Map();
function skillToggles(d){return d.skillToggles&&typeof d.skillToggles==='object'&&!Array.isArray(d.skillToggles)?d.skillToggles:{}}
function onOwnPlot(p){try{return p.dimension?.id==='minecraft:overworld'&&belongs(p,p.location.x,p.location.z)}catch{return false}}
function inCityAbilityArea(p){
 // Use the city's horizontal bounds so bridges, gaps and airspace share one rule.
 return p.dimension?.id==='minecraft:overworld'&&insideSquare(p.location,C.spawn,spawnLimit());
}
function activeAbilityAllowed(p){return onOwnPlot(p)||inCityAbilityArea(p)}
function useAbility(p,id,effect,duration,cooldown){
 const d=profile(p);if(!hasSkill(d,id))return p.sendMessage('§cUnlock this ability in the skill tree first.');
 if(!activeAbilityAllowed(p))return p.sendMessage('§cUse active skills on your plot or within the nine-island city.');
 const key=p.id+':'+id,now=system.currentTick,until=skillCooldowns.get(key)||0;
 const timestamp=Date.now(),persistent=Number(d.skillCooldownUntil?.[id])||0;
 if(now<until||timestamp<persistent)return p.sendMessage('§eAbility cooldown: '+Math.ceil(Math.max((until-now)/20,(persistent-timestamp)/1000))+' seconds.');
 try{
  p.addEffect(effect,duration,{amplifier:0,showParticles:false});
  d.skillCooldownUntil={...(d.skillCooldownUntil||{}),[id]:timestamp+cooldown*50};
  save(p,d);
  if(!skillActiveEffects.has(p.id))skillActiveEffects.set(p.id,new Set());
  skillActiveEffects.get(p.id).add(effect);skillCooldowns.set(key,now+cooldown);
  p.sendMessage('§aAbility activated!');
 }catch(e){try{p.removeEffect?.(effect)}catch{}p.sendMessage('§cAbility could not activate or save: '+String(e).slice(0,90))}
}
function skillAbilities(p){
 const d=profile(p),toggles=skillToggles(d);
 const list=[['move_jump_1','Jump Boost',true],['move_fall','Slow Falling',true],['explore_night','Exploration Effects',true],['surv_absorb','Second Wind',false],['surv_saturate','Survival Feast',false],['explore_invisible','Shadow Step',false]];
 form(p,'§bSKILL ABILITIES','Use active skills on your plot and throughout the nine-island city, including the airspace between islands.',
 [...list.map(([id,label,toggle])=>`${hasSkill(d,id)?'§a':'§8'}${label}${toggle?' ['+(toggles[id]===false?'OFF':'ON')+']':' [ACTIVATE]'}`),'Back'],i=>{
  if(i>=list.length)return skillTree(p);
  const [id,label,toggle]=list[i];if(!hasSkill(profile(p),id)){p.sendMessage('§cSkill not unlocked.');return menuAgain(p,()=>skillAbilities(p));}
  if(toggle){try{const fresh=profile(p);fresh.skillToggles={...skillToggles(fresh),[id]:skillToggles(fresh)[id]===false};save(p,fresh);p.sendMessage('§a'+label+' toggled '+(fresh.skillToggles[id]?'ON':'OFF'))}catch(e){p.sendMessage('§cToggle save failed '+e)}return menuAgain(p,()=>skillAbilities(p));}
  if(id==='surv_absorb')useAbility(p,id,'minecraft:absorption',200,2400);
  if(id==='surv_saturate')useAbility(p,id,'minecraft:saturation',100,6000);
  if(id==='explore_invisible')useAbility(p,id,'minecraft:invisibility',200,4800);
  menuAgain(p,()=>skillAbilities(p));
 });
}
const PASSIVE_SKILLS=[
 ['miner_haste_1','minecraft:haste',0,'miner_haste_2'],
 ['move_speed_1','minecraft:speed',0,'move_speed_2'],
 ['move_jump_1','minecraft:jump_boost',0,'move_jump_2'],
 ['move_fall','minecraft:slow_falling',0],
 ['surv_resist','minecraft:resistance',0],
 ['surv_regen','minecraft:regeneration',0,'surv_regen2'],
 ['surv_health','minecraft:health_boost',0],
 ['surv_fire','minecraft:fire_resistance',0],
 ['explore_night','minecraft:night_vision',0],
 ['explore_water','minecraft:water_breathing',0],
 ['explore_conduit','minecraft:conduit_power',0],
 ['explore_dolphin','minecraft:speed',0]
];
// Short 0.5-second polling is NOT the effect duration. For actual infinite
// effects use Bedrock's /effect infinite, with the stable Script API's maximum
// duration as a fallback if commands are unavailable in a particular Realm.
const PLOT_PASSIVE_LEDGER='sg_plot_passives_v1';
const PLOT_PASSIVE_MAX_TICKS=20000000; // 20 ticks/sec; API upper bound
const PLOT_PASSIVE_RENEW_BELOW=19000000; // renew fallback before it expires
const PLOT_PASSIVE_PULSE_TICKS=5; // check plot boundaries at most 0.25 sec apart
const KNOWN_PASSIVE_EFFECTS=new Set(PASSIVE_SKILLS.map(s=>s[1]));
function readPlotPassiveLedger(p){
 const raw=p.getDynamicProperty(PLOT_PASSIVE_LEDGER);
 if(raw===undefined||raw===null||raw==='')return new Map();
 let saved;
 try{saved=JSON.parse(String(raw))}catch(e){throw Error('Damaged passive effect ledger: '+e)}
 if(!Array.isArray(saved))throw Error('Invalid passive effect ledger');
 const result=new Map();
 for(const entry of saved){
  if(!Array.isArray(entry)||entry.length!==2||!KNOWN_PASSIVE_EFFECTS.has(entry[0])||![0,1].includes(entry[1]))throw Error('Invalid passive effect ledger entry');
  result.set(entry[0],entry[1]);
 }
 return result;
}
function savePlotPassiveLedger(p,ledger){
 const raw=ledger.size?JSON.stringify([...ledger]):undefined;
 p.setDynamicProperty(PLOT_PASSIVE_LEDGER,raw);
 if(p.getDynamicProperty(PLOT_PASSIVE_LEDGER)!==raw)throw Error('Plot effect ledger write was not verified');
}
function grantInfinitePlotPassive(p,effect,amplifier){
 // Bedrock's native infinite form shows Infinity in the status UI.
 // The command can be unavailable under some Realm/Script API contexts.
 let commandWorked=false;
 if(typeof p.runCommand==='function'){
  try{const result=p.runCommand('effect @s '+effect.replace(/^minecraft:/,'')+' infinite '+amplifier+' true');commandWorked=!!result&&result.successCount>0}catch{}
 }
 if(!commandWorked)p.addEffect(effect,PLOT_PASSIVE_MAX_TICKS,{amplifier,showParticles:false});
}
function removeOwnedPlotPassive(p,effect,ownedAmp){
 const current=p.getEffect?.(effect);
 if(!current)return true;
 // A stronger external potion is not owned by SkyGen. Same-strength effects
 // cannot be distinguished by the API; prioritize plot-boundary enforcement.
 if(current.amplifier>ownedAmp)return true;
 p.removeEffect(effect);
 return !p.getEffect?.(effect);
}
function skillPulsePlayer(p){
 const own=onOwnPlot(p),allowed=own||inCityAbilityArea(p),d=profile(p),toggles=skillToggles(d);
 // Only explicitly toggleable active effects may persist in the public city.
 const districtToggles=new Set(['move_jump_1','move_fall','explore_night','explore_water','explore_conduit','explore_dolphin']);
 const owned=readPlotPassiveLedger(p),desired=new Map();
 if(allowed){
  for(const [skill,effect,amp,upgraded] of PASSIVE_SKILLS){
   if(!own&&!districtToggles.has(skill))continue;
   if(!hasSkill(d,skill))continue;
   if(skill==='move_jump_1'&&toggles.move_jump_1===false)continue;
   if(skill==='move_fall'&&(toggles.move_fall===false||skyspireTrial.isTiming(p)))continue;
   if(skill.startsWith('explore_')&&toggles.explore_night===false&&!hasSkill(d,'explore_master'))continue;
   if((skill==='explore_conduit'||skill==='explore_dolphin')&&!p.isInWater&&!hasSkill(d,'explore_master'))continue;
   const strength=upgraded&&hasSkill(d,upgraded)?1:amp;
   desired.set(effect,Math.max(desired.get(effect)??-1,strength));
  }
 }
 // Revoke plot buffs immediately upon the next boundary check (also on skill
 // reset/toggle). The persistent ledger survives script reloads and reconnects.
 for(const [effect,amp] of [...owned]){
  if(desired.get(effect)===amp)continue;
  if(removeOwnedPlotPassive(p,effect,amp)){
   owned.delete(effect);
   savePlotPassiveLedger(p,owned);
  }
 }
 if(allowed){
  for(const [effect,amp] of desired){
   try{
    const current=p.getEffect?.(effect);
    // Respect stronger effects from other sources, even on a plot.
    if(current&&current.amplifier>amp)continue;
    const tracked=owned.has(effect)&&owned.get(effect)===amp;
    const sufficientlyLong=current&&(!Number.isFinite(current.duration)||current.duration<=0||current.duration>=PLOT_PASSIVE_RENEW_BELOW);
    if(tracked&&current&&current.amplifier===amp&&sufficientlyLong)continue;
    if(!tracked&&current&&current.amplifier===amp&&sufficientlyLong)continue;
    // Record ownership before creating an infinite effect; crash/rejoin will
    // then know what to remove outside the player's own plot.
    owned.set(effect,amp);
    savePlotPassiveLedger(p,owned);
    grantInfinitePlotPassive(p,effect,amp);
   }catch(e){
    if(!skillEffectWarnings.has(effect)){
     skillEffectWarnings.add(effect);console.warn('[SkyGen SKILLS] Infinite plot passive '+effect+' failed: '+e)
    }
   }
  }
 }
 if(!allowed&&skillActiveEffects.has(p.id)){
  for(const effect of skillActiveEffects.get(p.id))try{p.removeEffect?.(effect)}catch{}
  skillActiveEffects.delete(p.id);
 }
 skillLastEffects.set(p.id,new Set(owned.keys()));
}
function skillPulse(){
 for(const p of world.getAllPlayers()){
  try{skillPulsePlayer(p)}catch(e){console.warn('[SkyGen SKILLS] plot effect pulse '+e)}
 }
 system.runTimeout(skillPulse,PLOT_PASSIVE_PULSE_TICKS);
}
const skillEffectWarnings=new Set();
system.runTimeout(skillPulse,PLOT_PASSIVE_PULSE_TICKS);
function dailyDate(){return new Date().toISOString().slice(0,10)}
function recordDaily(p,d,keys,amount=1,subject=undefined,saleCredits=undefined){
 if(p.getGameMode()===GameMode.Creative)return false;
 const dailyChanged=recordQuestProgress(questState(d,p.id,dailyDate(),publicStarterEnabled()),keys,amount,false,subject,saleCredits);
 let weeklyChanged=false,ascendedChanged=false;
 try{weeklyChanged=recordWeeklyPreviewActivity(d,p.id,keys,subject,amount,new Date(),saleCredits)}
 catch(err){console.warn('[SkyGen WEEKLY PREVIEW] activity ignored: '+err)}
 try{ascendedChanged=recordAscendedDailyPreviewActivity(d,p.id,keys,subject,amount,new Date(),saleCredits)}
 catch(err){console.warn('[SkyGen ASCENDED PREVIEW] activity ignored: '+err)}
 return dailyChanged||weeklyChanged||ascendedChanged;
}
function recordQuestActivity(p,key,subject=undefined){
 try{
  const d=profile(p);
  if(recordDaily(p,d,[key],1,subject))save(p,d);
 }catch(e){console.warn('[SkyGen QUEST] '+key+': '+e)}
}
const QUEST_FISH=new Set(['minecraft:cod','minecraft:salmon','minecraft:tropical_fish','minecraft:pufferfish','minecraft:clownfish']);
function eligibleQuestFish(item){
 return QUEST_FISH.has(item?.typeId)&&eligibleShopItem(item,item.typeId);
}
function fishHeld(p){
 const inv=inventory(p);
 if(!inv||creativeEconomyBlocked(p))return 0;
 let total=0;
 for(let i=0;i<inv.size;i++){
  const item=inv.getItem(i);
  if(eligibleQuestFish(item))total+=item.amount;
 }
 return total;
}
function rewardQuestStatus(p,data){
 const assigned=new Set(),ready=[],partial=[];
 if(p.getGameMode()===GameMode.Creative)return {assigned,ready,partial};
 const day=dailyDate(),mineReady=publicStarterEnabled();
 // Evaluate on the disposable profile snapshot used by the HUD. The quest
 // menus and activity handlers still own the persisted assignment and payouts.
 const board=questState(data,p.id,day,mineReady);
 let fish;
 for(const entry of board.active){
  const quest=questDefinition(entry.id);
  if(quest.pendingEconomy)continue;
  const id='daily:'+entry.assigned+':'+entry.id;
  assigned.add(id);
  const progress=quest.key==='fish'?(fish??=fishHeld(p)):entry.progress;
  const primaryComplete=progress>=quest.need;
  const secondaryComplete=quest.secondary&&(entry.secondaryProgress??0)>=quest.secondary.need;
  if(primaryComplete&&(!quest.secondary||secondaryComplete))ready.push(id);
  else if(quest.secondary&&(primaryComplete||secondaryComplete))partial.push(id);
 }
 const contracts=[['daily',day,data.ascendedDailyPreview],['weekly',utcWeekStart(day+'T00:00:00Z'),data.weeklyPreview]];
 for(const [kind,period,state] of contracts){
  if((kind==='daily'?state?.day:state?.week)!==period||!Array.isArray(state.entries))continue;
  const claimed=new Set(contractClaims(data,kind,period));
  for(const entry of state.entries){
   if(claimed.has(entry.questId))continue;
   const id=kind+'-contract:'+period+':'+entry.questId;
   assigned.add(id);
   const primaryComplete=entry.progress===entry.target;
   const secondaryComplete=entry.secondaryProgress===entry.secondaryTarget;
   if(primaryComplete&&secondaryComplete)ready.push(id);
   else if(primaryComplete||secondaryComplete)partial.push(id);
  }
 }
 return {assigned,ready,partial};
}
function planQuestClaim(p,selected){
 const fresh=profile(p),mineReady=publicStarterEnabled();
 const today=questState(fresh,p.id,dailyDate(),mineReady);
 const q=questDefinition(selected.id);
 if(q.pendingEconomy)throw Error('This Ascended Contract is a catalog preview; payouts are not activated.');
 const entry=today.active.find(item=>item.id===selected.id&&item.assigned===selected.assigned);
 if(!entry)throw Error('Quest expired or already claimed.');
 let slots;
 if(q.key==='fish'){
  if(creativeEconomyBlocked(p))throw Error('Fishing turn-ins require operator clearance after Creative use.');
  slots=planInventoryDebit(inventory(p),q.need,eligibleQuestFish);
  if(!slots)throw Error('Not enough eligible fish. Check your inventory.');
  // This is a temporary readiness flag on the copy that will be committed.
  entry.progress=q.need;
 }
 if(!completeQuest(today,selected,fresh.rank,mineReady))throw Error('Quest is incomplete, expired, or already claimed.');
 const reward=questCreditReward(q,q.credits,entry,hasSkill(fresh,'explore_reward'));
 assertBankUnlocked(p);
 fresh.xp+=q.xp;
 const {oldRank,bonus,orbits}=rankRewards(fresh);
 const credits=reward+bonus,destination=credits?payoutDestination(fresh,credits):'wallet';
 if(destination===undefined)throw Error(noPayoutRoom(fresh,credits)+' Your quest remains claimable.');
 if(orbits&&orbits>CREDIT_CAP-fresh.orbits)throw Error('Free room for '+orbits+' milestone Orbits. Your quest remains claimable.');
 if(credits)creditPayout(fresh,destination,credits);
 fresh.orbits+=orbits;
 return {fresh,oldRank,slots,credits,orbits,xp:q.xp,destination};
}
function claimQuest(p,selected,quote){
 const plan=planQuestClaim(p,selected);
 if(quote&&['credits','orbits','xp','destination'].some(key=>quote[key]!==plan[key]))throw Error('Your reward changed. Open a new quote.');
 if(plan.slots){
  const info={quest:selected.id,assigned:selected.assigned,total:plan.credits,count:selected.quest.need,destination:plan.destination};
  const committed=commitInventoryDebit(p,plan.slots,'quest_fish',info,(latest,tx)=>{
   if(latest.credits!==tx.before)throw Error('Wallet changed');
   plan.fresh.sg_last_econ_txn=tx.id;
   save(p,plan.fresh);
  });
  if(!committed)return;
 }else save(p,plan.fresh);
 announceRank(p,plan.fresh,plan.oldRank);
 const credits=plan.credits?`${plan.credits.toLocaleString()} Credits to ${destinationName(plan.fresh,plan.destination)} + `:'';
 p.sendMessage(`§aQuest reward · ${credits}${plan.xp} XP${plan.orbits?' + '+plan.orbits+' Orbits':''}.`);
}
const lastExplorationDistrict=new Map();
function explorationDistrict({x,z}){
 const bx=Math.floor(x),bz=Math.floor(z);
 const column=Math.round(bx/65),row=Math.round(bz/63);
 if(Math.abs(column)>1||Math.abs(row)>1)return;
 // Match the octagon of each island's deck at the bridge landings.
 const dx=Math.abs(bx-column*65),dz=Math.abs(bz-row*63);
 if(dx<=23&&dz<=23&&dx+dz<=37)return column+','+row;
}
function recordExplorationVisit(p,district){
 const d=profile(p),now=new Date();
 const state=questState(d,p.id,now.toISOString().slice(0,10),true);
 const hasDailyVisit=state.active.some(entry=>{const q=questDefinition(entry.id);return q.key==='visits'||q.secondary?.key==='visits'});
 let hasWeeklyVisit=false,hasAscendedVisit=false;
 try{
  const draft=openWeeklyPreview(d,p.id,now).state;
  hasWeeklyVisit=!!draft?.entries?.some(e=>e.primaryKey==='visits'||e.secondaryKey==='visits');
 }catch(err){console.warn('[SkyGen WEEKLY PREVIEW] district state requires review: '+err)}
 try{
  const draft=openAscendedDailyPreview(d,p.id,now).state;
  hasAscendedVisit=!!draft?.entries?.some(e=>e.primaryKey==='visits'||e.secondaryKey==='visits');
 }catch(err){console.warn('[SkyGen ASCENDED PREVIEW] district state requires review: '+err)}
 if(!hasDailyVisit&&!hasWeeklyVisit&&!hasAscendedVisit)return;
 const dailyChanged=hasDailyVisit&&recordQuestProgress(state,['visits'],1,false,district);
 let weeklyChanged=false,ascendedChanged=false;
 try{if(hasWeeklyVisit)weeklyChanged=recordWeeklyPreviewActivity(d,p.id,['visits'],district,1,now)}
 catch(err){console.warn('[SkyGen WEEKLY PREVIEW] district update ignored: '+err)}
 try{if(hasAscendedVisit)ascendedChanged=recordAscendedDailyPreviewActivity(d,p.id,['visits'],district,1,now)}
 catch(err){console.warn('[SkyGen ASCENDED PREVIEW] district update ignored: '+err)}
 if(dailyChanged||weeklyChanged||ascendedChanged)save(p,d);
}
function updateExplorationQuest(p){
 const id=p.id;
 if(loginPending.has(id)||p.dimension?.id!=='minecraft:overworld'||p.getGameMode()===GameMode.Creative){
  lastExplorationDistrict.delete(id);
  return;
 }
 const district=explorationDistrict(p.location),previous=lastExplorationDistrict.get(id);
 if(previous===undefined){
  lastExplorationDistrict.set(id,district??null);
  return;
 }
 // A bridge keeps the last district as the origin. Entering a new district
 // updates that origin even when none of the active objectives use the visit.
 if(district===undefined||district===previous)return;
 recordExplorationVisit(p,district);
 lastExplorationDistrict.set(id,district);
}
function questCreditLabel(quest,base,entry,expeditionPerk){
 const amount=questCreditReward(quest,base,entry,expeditionPerk).toLocaleString();
 return amount+' Credits'+(hasTradingObjective(quest)?' from qualifying sales':'');
}
function twoPartQuestLabel(ready,anyComplete,readyLabel='2/2 complete'){
 if(ready)return '§a'+readyLabel;
 return anyComplete?'§61/2 complete':'§70/2 complete';
}
function dailyQuests(p,back=menu){
 const d=profile(p),day=dailyDate(),state=questState(d,p.id,day,publicStarterEnabled());
 const fish=fishHeld(p);
 save(p,d);
 const active=state.active.map(entry=>{
  const quest=questDefinition(entry.id);
  const progress=quest.key==='fish'?Math.min(fish,quest.need):entry.progress;
  const secondaryProgress=entry.secondaryProgress??0;
  const primaryComplete=progress>=quest.need;
  const secondaryComplete=quest.secondary&&secondaryProgress>=quest.secondary.need;
  const ready=primaryComplete&&(!quest.secondary||secondaryComplete);
  return {...entry,quest,progress,secondaryProgress,ready,anyComplete:primaryComplete||secondaryComplete};
 });
 const number=quest=>quest.id<0?'Legacy '+(-quest.id):'#'+(quest.id+1);
 const buttons=active.map(({quest,progress,ready,anyComplete})=>quest.secondary
  ?`${twoPartQuestLabel(ready,anyComplete,'CLAIM')} · ${quest.group} ${number(quest)}`
  :`${ready?'§aCLAIM':'§e'} ${quest.group} ${number(quest)}: ${progress}/${quest.need}`);
 const details=active.map(entry=>{
  const {quest}=entry;
  const reward=`${questCreditLabel(quest,quest.credits,entry,hasSkill(d,'explore_reward'))} + ${quest.xp} XP`;
  if(!quest.secondary)return `§e${number(quest)} §r${quest.label} ×${quest.need} · ${reward}`;
  const status=twoPartQuestLabel(entry.ready,entry.anyComplete);
  return `§f${number(quest)} · ${status}§r\n${quest.label}\n`+
   `First ${entry.progress}/${quest.need} · Second ${entry.secondaryProgress}/${quest.secondary.need}\n${reward}`;
 }).join('\n');
 form(p,'§eDAILY QUESTS',`UTC rotation: ${day} · 00:00 UTC\nCompleted quests stay until claimed.\n${details||'All available quests claimed for this rotation.'}`,
  [...buttons,'Browse Quest Catalog','Ascended Contracts','Weekly Elite','Back'],i=>{
  if(i===active.length)return questCatalog(p);
  if(i===active.length+1)return ascendedDailyPreviewMenu(p);
  if(i===active.length+2)return weeklyElitePreview(p);
  if(i===active.length+3)return back(p);
  const selected=active[i];
  if(!selected)return;
  const reopen=()=>menuAgain(p,()=>dailyQuests(p,back));
  if(selected.quest.key==='fish'){
   try{
    const quote=planQuestClaim(p,selected);
    const confirm=skyMessage().title('Confirm Fishing Turn-in')
     .body(`Turn in ${selected.quest.need} eligible fish for ${quote.credits.toLocaleString()} Credits and ${quote.xp} XP${quote.orbits?' plus '+quote.orbits+' Orbits':''}? Credits go to ${destinationName(quote.fresh,quote.destination)}.`)
     .button1('Cancel').button2('Turn In');
    showUI(p,confirm).then(r=>{
     if(r.canceled)return;
     try{if(r.selection===1)claimQuest(p,selected,quote)}
     catch(e){p.sendMessage('§cCould not claim quest: '+e.message)}
     finally{reopen()}
    }).catch(e=>p.sendMessage('§cFishing turn-in menu failed: '+e));
   }catch(e){p.sendMessage('§cCould not claim quest: '+e.message);reopen()}
   return;
  }
  try{claimQuest(p,selected)}
  catch(e){p.sendMessage('§cCould not claim quest: '+e.message)}
  finally{reopen()}
 });
}
// v0.10.52 approved contracts: atomic monetary/rank/claim updates. The quest
// objective state remains independently validated by the existing preview
// modules; a separate period claim marker is written in the SAME sg_profile
// mutation as balances and XP. One in-flight economic journal per player.
function contractClaimField(kind){return kind==='daily'?'ascendedClaimed':'weeklyEliteClaimed'}
function contractPeriod(kind,status){return kind==='daily'?status.day:status.week}
function contractClaims(d,kind,period){
 const record=d[contractClaimField(kind)];
 if(record!==undefined){
  if(!record||typeof record!=='object'||Array.isArray(record)||typeof record.period!=='string'||
     !/^\d{4}-\d\d-\d\d$/.test(record.period)||!Array.isArray(record.ids)||record.ids.length>3||
     record.ids.some(x=>!Number.isSafeInteger(x)||x<500||x>=1000)||new Set(record.ids).size!==record.ids.length)
   throw Error('Contract claim ledger requires operator review');
  if(record.period>period)throw Error('Contract claim ledger is ahead of UTC calendar');
  if(record.period===period)return record.ids;
 }
 return [];
}
function planNewContractClaim(p,kind,questId){
 if(!['daily','weekly'].includes(kind))throw Error('Invalid contract claim kind');
 if(p.getGameMode()===GameMode.Creative||creativeEconomyBlocked(p))throw Error('Contract claims require survival gameplay');
 const d=profile(p),now=new Date();
 const status=kind==='daily'?ascendedDailyStatus(d,p.id,now):weeklyPreviewStatus(d,p.id,now);
 if(status.locked)throw Error('This contract board has not unlocked');
 const period=contractPeriod(kind,status),entryIndex=status.entries.findIndex(e=>e.questId===questId);
 if(entryIndex<0)throw Error('Contract not assigned to this player');
 const entry=status.entries[entryIndex];
 if(!entry.ready)throw Error('Complete both objectives before claiming');
 const claims=contractClaims(d,kind,period);
 if(claims.includes(questId))throw Error('Contract already claimed this period');
 const q=questDefinition(questId),quote=approvedContractQuote(q,status.lockedRank,kind,entryIndex);
 const multiplier=hasSkill(d,'econ_rank')?110:100;
 const oldRank=d.rank;
 const change=advanceRank(oldRank,d.xpProgress,quote.xp);
 let rankCredits=0,rankOrbits=0;
 for(let level=oldRank+1;level<=change.rank;level++){
  rankCredits+=level*multiplier;
  if(level%10===0)rankOrbits++;
 }
 const questCredits=questCreditReward(q,quote.credits,entry,kind==='daily'&&hasSkill(d,'explore_reward'));
 const totalCredits=questCredits+rankCredits;
 const totalOrbits=quote.orbits+rankOrbits;
 if(!Number.isSafeInteger(totalCredits)||totalCredits<0||totalCredits>CREDIT_CAP)throw Error('Unsafe Credit reward');
 if(!Number.isSafeInteger(totalOrbits)||totalOrbits<0||totalOrbits>CREDIT_CAP-d.orbits)throw Error('Not enough Orbit wallet capacity; reward remains claimable');
 const destination=totalCredits?payoutDestination(d,totalCredits):'wallet';
 if(destination===undefined)throw Error('No wallet/bank capacity for '+totalCredits+' Credits; reward remains claimable');
 return {kind,questId,entryIndex,period,lockedRank:status.lockedRank,oldRank,quote,destination,
   totalCredits,totalOrbits,rankCredits,rankOrbits,questCredits,rankChange:change,claims,profile:d};
}
function claimNewContract(p,kind,questId){
 const initial=planNewContractClaim(p,kind,questId); // no write before readiness and payout checks
 assertBankUnlocked(p);
 let tx;
 try{
  tx=beginEconomicTxn(p,'contract',{kindContract:kind,quest:questId,period:initial.period,
   total:initial.totalCredits,orbits:initial.totalOrbits,destination:initial.destination,
   destinationBefore:initial.destination==='wallet'?initial.profile.credits:
     initial.profile.bank?.accounts?.find(a=>a.id===initial.destination)?.credits,
   beforeOrbits:initial.profile.orbits,oldRank:initial.oldRank});
  const latest=planNewContractClaim(p,kind,questId); // recalc against authoritative saved profile
  if(latest.period!==initial.period||latest.lockedRank!==initial.lockedRank||
     latest.destination!==tx.destination||latest.totalCredits!==tx.total||
     latest.totalOrbits!==tx.orbits||latest.quote.xp!==initial.quote.xp)
   throw Error('Contract quote changed during confirmation');
  const d=latest.profile;
  if(d.credits!==tx.before||d.orbits!==tx.beforeOrbits)throw Error('Balances changed');
  const balance=tx.destination==='wallet'?d.credits:d.bank?.accounts?.find(a=>a.id===tx.destination)?.credits;
  if(balance!==tx.destinationBefore)throw Error('Payout destination changed');
  if(tx.total)creditPayout(d,tx.destination,tx.total);
  d.orbits+=tx.orbits;
  d.rank=latest.rankChange.rank;d.xpProgress=latest.rankChange.progress;d.xp=mirrorXP(d.rank,d.xpProgress);
  d[contractClaimField(kind)]={period:latest.period,ids:[...latest.claims,questId]};
  d.sg_last_econ_txn=tx.id;
  save(p,d); // exact-once profile write: Credits, Orbits, XP and claim marker
  endEconomicTxn(p,tx,true);
  announceRank(p,d,latest.oldRank);
  const credits=tx.total?tx.total.toLocaleString()+' Credits to '+destinationName(d,tx.destination)+' + ':'';
  p.sendMessage('§a'+(kind==='weekly'?'Weekly Elite':'Ascended')+' contract #'+(questId+1)+
   ' claimed · '+credits+
   formattedXP(latest.quote.xp)+' XP'+(tx.orbits?' + '+tx.orbits+' Orbits':'')+'.');
  return true;
 }catch(err){
  if(tx){
   try{
    const d=profile(p),hasClaim=contractClaims(d,kind,initial.period).includes(questId);
    if(!hasClaim&&d.sg_last_econ_txn!==tx.id&&d.credits===tx.before&&d.orbits===tx.beforeOrbits){
     const balance=tx.destination==='wallet'?d.credits:d.bank?.accounts?.find(a=>a.id===tx.destination)?.credits;
     if(balance===tx.destinationBefore){endEconomicTxn(p,tx,true);throw Error('Contract not paid; please retry');}
    }
   }catch(cleanupError){
    if(String(cleanupError).includes('Contract not paid; please retry'))throw cleanupError;
   }
   economicTxnReview(p,tx,'Contract settlement uncertain: '+err);
  }
  throw err;
 }
}
function contractQuestStatus(entry,claimed,readyLabel='READY'){
 if(claimed)return '§aCLAIMED';
 const anyComplete=entry.primary>=entry.target||entry.secondary>=entry.secondaryTarget;
 return twoPartQuestLabel(entry.ready,anyComplete,readyLabel);
}
function ascendedDailyPreviewMenu(p){
 try{
  const d=profile(p),status=ascendedDailyStatus(d,p.id,new Date());
  if(status.changed)save(p,d);
  if(status.locked)return form(p,'§bASCENDED CONTRACTS','Ascended contracts unlock at Rank 51.',['Back to Quests'],()=>dailyQuests(p));
  const claimed=new Set(contractClaims(d,'daily',status.day));
  const details=status.entries.map((entry,i)=>{
   const q=questDefinition(entry.questId);
   const quote=approvedContractQuote(q,status.lockedRank,'daily');
   return `§e${i+1}. #${entry.questId+1} — ${contractQuestStatus(entry,claimed.has(entry.questId))}\n`+
    `${q.label}\nPrimary ${entry.primary}/${entry.target} · Secondary ${entry.secondary}/${entry.secondaryTarget}\n`+
    `${formattedXP(quote.xp)} XP + ${questCreditLabel(q,quote.credits,entry,hasSkill(d,'explore_reward'))} (${q.difficulty})`;
  }).join('\n\n');
  const buttons=[...status.entries.map(entry=>`${contractQuestStatus(entry,claimed.has(entry.questId),'Claim')} #${entry.questId+1}`),'Back to Quests'];
  form(p,'§bASCENDED CONTRACTS',`UTC day: ${status.day} · Locked rank: ${status.lockedRank}\n`+
   'Trading Credit rewards grow with qualifying sales.\n\n'+details,buttons,i=>{
    if(i===status.entries.length)return dailyQuests(p);
    const entry=status.entries[i];if(!entry)return;
    if(!entry.ready||claimed.has(entry.questId))return ascendedDailyPreviewMenu(p);
    showUI(p,skyMessage().title('Claim Ascended Contract').body('Claim #'+(entry.questId+1)+'? Credits may go to your default bank when the wallet is full.').button1('Cancel').button2('Claim')).then(r=>{
     if(!r.canceled&&r.selection===1)try{claimNewContract(p,'daily',entry.questId)}catch(err){p.sendMessage('§cClaim unavailable: '+String(err).slice(0,130))}
     menuAgain(p,()=>ascendedDailyPreviewMenu(p));
    }).catch(err=>p.sendMessage('§cContract claim menu failed: '+err));
  });
 }catch(err){console.warn('[SkyGen ASCENDED] board failed: '+err);p.sendMessage('§cAscended contracts require operator review: '+String(err).slice(0,100))}
}
function weeklyElitePreview(p){
 try{
  const d=profile(p),status=weeklyPreviewStatus(d,p.id,new Date());
  if(status.changed)save(p,d);
  if(status.locked)return form(p,'§dWEEKLY ELITE','Weekly Elite contracts unlock at Rank 101.',['Back to Quests'],()=>dailyQuests(p));
  const claimed=new Set(contractClaims(d,'weekly',status.week));
  const details=status.entries.map((entry,i)=>{
   const q=questDefinition(entry.questId);
   const quote=approvedContractQuote(q,status.lockedRank,'weekly',i);
   return `§e${i+1}. #${entry.questId+1} — ${contractQuestStatus(entry,claimed.has(entry.questId))}\n`+
    `${q.label}\nPrimary ${entry.primary}/${entry.target} · Secondary ${entry.secondary}/${entry.secondaryTarget}\n`+
    `${formattedXP(quote.xp)} XP + ${questCreditLabel(q,quote.credits,entry,false)} + ${quote.orbits} Orbits`;
  }).join('\n\n');
  form(p,'§dWEEKLY ELITE',`UTC week: ${status.week} · Locked rank: ${status.lockedRank}\n`+
   'Three weekly Elite rewards; each can be claimed once per week.\n\n'+details,
   [...status.entries.map(entry=>`${contractQuestStatus(entry,claimed.has(entry.questId),'Claim')} #${entry.questId+1}`),'Back to Quests'],i=>{
    if(i===status.entries.length)return dailyQuests(p);
    const entry=status.entries[i];if(!entry)return;
    if(!entry.ready||claimed.has(entry.questId))return weeklyElitePreview(p);
    showUI(p,skyMessage().title('Claim Weekly Elite Contract').body('Claim #'+(entry.questId+1)+'? Orbit and Credit capacity will be rechecked.').button1('Cancel').button2('Claim')).then(r=>{
     if(!r.canceled&&r.selection===1)try{claimNewContract(p,'weekly',entry.questId)}catch(err){p.sendMessage('§cClaim unavailable: '+String(err).slice(0,130))}
     menuAgain(p,()=>weeklyElitePreview(p));
    }).catch(err=>p.sendMessage('§cWeekly claim menu failed: '+err));
  });
 }catch(err){console.warn('[SkyGen WEEKLY] board failed: '+err);p.sendMessage('§cWeekly contracts require operator review: '+String(err).slice(0,100))}
}

function questCatalog(p,group=null,page=0){
 const groups=[...new Set(QUESTS.map(q=>q.group))];
 if(!group)return form(p,'QUEST CATALOG',`${QUESTS.length} definitions · 500 legacy quests and 500 Ascended/Weekly contracts.`,[...groups,'Back'],i=>{
  if(i===groups.length)return dailyQuests(p);
  questCatalog(p,groups[i]);
 });
 const results=QUESTS.filter(q=>q.group===group);
 const rows=results.slice(page*6,page*6+6);
 const level=rankLevel(profile(p).rank);
 const actions=[];
 if(page>0)actions.push(['Previous Page',()=>questCatalog(p,group,page-1)]);
 if((page+1)*6<results.length)actions.push(['Next Page',()=>questCatalog(p,group,page+1)]);
 actions.push(['Back',()=>questCatalog(p)]);
 form(p,group,`Page ${page+1}/${Math.ceil(results.length/6)}\n`+rows.map(q=>
  `#${q.id+1} · Rank ${q.rank}${q.id>=500?' (Ascended/Weekly)':q.rank>level?' (Locked)':''} · ${q.label} ×${q.need}${q.secondary?' + '+q.secondary.label+' ×'+q.secondary.need:''}`).join('\n'),
  actions.map(([label])=>label),i=>actions[i]?.[1]());
}
function coords(id){return {x:C.base.x+(id%C.columns)*C.spacing,y:C.base.y,z:C.base.z+Math.floor(id/C.columns)*C.spacing}}
function belongs(p,x,z){if(p.dimension?.id!=='minecraft:overworld')return false;const d=profile(p);if(d.plot<0)return false;const c=coords(d.plot);return Math.abs(x-c.x)<=plotRadius(d.plot)&&Math.abs(z-c.z)<=plotRadius(d.plot)}
function plotAt(x,z,maximum=false){
 const dx=x-C.base.x,dz=z-C.base.z,maxRadius=PLOT_TIERS.at(-1).radius;
 if(dx < -maxRadius||dz < -maxRadius)return -1;
 const col=Math.round(dx/C.spacing),row=Math.round(dz/C.spacing);
 if(col<0||col>=C.columns||row<0)return -1;
 const id=row*C.columns+col,c=coords(id),radius=maximum?maxRadius:plotRadius(id);
 return Math.abs(x-c.x)<=radius&&Math.abs(z-c.z)<=radius?id:-1;
}
// v0.9.10 VISIBLE FORCEFIELDS. These are script-enforced particle walls, not
// placed glass: installing the add-on never overwrites player structures.
// All enforcement is server-side. Spawn is fixed; claim boundaries follow paid tiers.
// Only operators can walk across spawn AND plot perimeters. Plot owners,
// trusted players and invited visitors ENTER via normal permissioned teleports.
// Realm-wide OP walk-bypass settings. Missing values preserve legacy ON defaults.
const OP_SPAWN_BYPASS_KEY='sg_op_spawn_walk_bypass';
const OP_PLOT_BYPASS_KEY='sg_op_plot_walk_bypass';
function operatorBoundaryBypass(kind){
 const value=world.getDynamicProperty(kind==='spawn'?OP_SPAWN_BYPASS_KEY:OP_PLOT_BYPASS_KEY);
 return value!==false;
}
function operatorMayCrossField(p,field){
 return isOperator(p)&&operatorBoundaryBypass(field?.kind==='spawn'?'spawn':'plot');
}
const forcefieldPrevious=new Map(),forcefieldNotices=new Map();
const FORCEFIELD_STEP_LIMIT=8; // distinguish walking/flying from long-distance teleports
function fieldAt(x,z){
 const bx=Math.floor(x),bz=Math.floor(z);
 if(inSpawn(bx,bz))return {kind:'spawn',id:-1};
 const id=plotAt(bx,bz);
 return id>=0?{kind:'plot',id}:null;
}
function sameField(a,b){return a?.kind===b?.kind&&a?.id===b?.id}
function fieldAccess(p,field){
 if(!field||isOperator(p))return true;
 if(field.kind==='spawn')return false; // Spawn horn is allowed; walking across is not.
 return canVisit(p,field.id); // visit access, NOT permission to build
}
function forcefieldWarn(p,message){
 const tick=system.currentTick,last=forcefieldNotices.get(p.id)??-9999;
 if(tick-last<40)return;
 forcefieldNotices.set(p.id,tick);
 try{p.onScreenDisplay.setActionBar('§c'+message)}catch{}
 try{p.sendMessage('§c'+message)}catch{}
}
function forcefieldReturn(p,previous){
 try{
  const at={x:previous.x,y:previous.y,z:previous.z};
  if(typeof p.tryTeleport==='function'){
   if(p.tryTeleport(at,{dimension:p.dimension,checkForBlocks:false}))return true;
  }else{p.teleport(at,{dimension:p.dimension,checkForBlocks:false});return true;}
 }catch(e){console.warn('[SkyGen] forcefield return failed: '+e)}
 return false;
}
function enforceForcefield(p){
 const loc=p.location,id=p.id,dimension=p.dimension.id;
 if(dimension!=='minecraft:overworld'){forcefieldPrevious.delete(id);return}
 const prev=forcefieldPrevious.get(id),nowField=fieldAt(loc.x,loc.z);
 // Fresh join or dimension transfer: uninvited players inside a private plot
 // are evacuated. Legitimate spawn/plot horn arrivals remain permitted.
 if(!prev||prev.dim!==dimension){
  if(nowField?.kind==='plot'&&!fieldAccess(p,nowField)){
   forcefieldWarn(p,'Private plot: access denied. Returning to spawn.');
   safeSpawnTravel(p,true);
  }
  forcefieldPrevious.set(id,{x:loc.x,y:loc.y,z:loc.z,dim:dimension});
  return;
 }
 const prevField=fieldAt(prev.x,prev.z);
 const delta=Math.hypot(loc.x-prev.x,loc.y-prev.y,loc.z-prev.z);
 let denied=false,reason='';
 // Every edge physically contains non-operators, including plot owners.
 // Our scripted teleport system issues a short-lived one-use travel ticket.
 const ticket=forcefieldTickets.get(id);
 const validTicket=!!ticket&&ticket.expires>=system.currentTick&&
  Math.hypot(loc.x-ticket.x,loc.y-ticket.y,loc.z-ticket.z)<2;
 if(validTicket)forcefieldTickets.delete(id);
 else if(ticket&&ticket.expires<system.currentTick)forcefieldTickets.delete(id);
 if(!validTicket&&!sameField(prevField,nowField)&&
     !(isOperator(p)&&(!prevField||operatorMayCrossField(p,prevField))&&(!nowField||operatorMayCrossField(p,nowField)))&&
     (prevField||nowField)) {
  denied=true;reason='Forcefield: use your teleport horn to travel.';
 }
 // Unauthorized plot occupancy is always denied, even on spawn/relogin,
 // after permission revocation, or following an external /tp command.
 if(nowField?.kind==='plot'&&!fieldAccess(p,nowField)){
  denied=true;reason='Private plot forcefield: access denied.';
 }
 if(denied){
  // Never return to a position already inside a private plot from which
  // permissions have been revoked, and never bounce across a huge distance.
  const safePrevious=delta<=FORCEFIELD_STEP_LIMIT&&
    !(prevField?.kind==='plot'&&!fieldAccess(p,prevField));
  if(safePrevious&&forcefieldReturn(p,prev)){
   forcefieldPrevious.set(id,{...prev});
  }else{
   // No safe walking-side to return to (teleport exploit, revoked visit, login).
   // Use the established, validated original-spawn rescue routine.
   safeSpawnTravel(p,true);
   const updated=p.location;
   forcefieldPrevious.set(id,{x:updated.x,y:updated.y,z:updated.z,dim:dimension});
  }
  forcefieldWarn(p,reason);
  return;
 }
 forcefieldPrevious.set(id,{x:loc.x,y:loc.y,z:loc.z,dim:dimension});
}
// v0.9.12: render a visible nearby SEGMENT of each perimeter instead of
// requiring the player to stand within nine blocks of one plot edge.
// Protection/movement rules are intentionally unchanged.
const FORCEFIELD_VISUAL_RANGE=32;
function nearestForcefield(loc){
 const x=loc.x,z=loc.z,candidates=[{kind:'spawn',id:-1,c:spawnPosition(),radius:spawnLimit()}];
 const col=Math.round((x-C.base.x)/C.spacing),row=Math.round((z-C.base.z)/C.spacing);
 if(col>=0&&col<C.columns&&row>=0){
  const id=row*C.columns+col;
  candidates.push({kind:'plot',id,c:coords(id),radius:plotRadius(id)});
 }
 let best;
 for(const field of candidates){
  const dx=x-field.c.x,dz=z-field.c.z,r=field.radius;
  const sides=[
   {side:'x',sign:1,score:Math.hypot(x-(field.c.x+r+0.5),Math.max(0,Math.abs(dz)-r))},
   {side:'x',sign:-1,score:Math.hypot(x-(field.c.x-r-0.5),Math.max(0,Math.abs(dz)-r))},
   {side:'z',sign:1,score:Math.hypot(z-(field.c.z+r+0.5),Math.max(0,Math.abs(dx)-r))},
   {side:'z',sign:-1,score:Math.hypot(z-(field.c.z-r-0.5),Math.max(0,Math.abs(dx)-r))}
  ];
  for(const candidate of sides){
   if(candidate.score>FORCEFIELD_VISUAL_RANGE||best&&best.score<=candidate.score)continue;
   best={...field,...candidate};
  }
 }
 return best;
}
function renderForcefield(p){
 const loc=p.location,field=nearestForcefield(loc);
 if(!field)return false;
 const {c,radius:r,side,sign,kind,id}=field;
 const visibleType=kind==='spawn'?'minecraft:basic_flame_particle':'minecraft:blue_flame_particle';
 // Render the original dense wall close to the boundary, but a sparser
 // wall at greater distance. Movement/permissions are still checked every tick.
 // This reduces visual work without affecting forcefield collision or access.
 const near=field.score<=12;
 const step=near?2:4;
 const levels=near?5:3;
 for(let offset=-17;offset<=17;offset+=step){
  for(let height=0;height<levels;height++){
   const pos=side==='x'
    ?{x:c.x+(sign>0?r+1:-r),y:loc.y+0.3+height*0.85,z:Math.max(c.z-r,Math.min(c.z+r,loc.z+offset))}
    :{x:Math.max(c.x-r,Math.min(c.x+r,loc.x+offset)),y:loc.y+0.3+height*0.85,z:c.z+(sign>0?r+1:-r)};
   try{p.dimension.spawnParticle(visibleType,pos)}catch{}
  }
 }
 const access=fieldAccess(p,field);
 const plotMode=isOperator(p)?(operatorBoundaryBypass('plot')?'§aOP WALK ACCESS':'§cOP BYPASS OFF'):access?'§bTELEPORT ONLY':'§cLOCKED';
 try{p.onScreenDisplay.setActionBar(kind==='spawn'
  ?'§6SPAWN FORCEFIELD §7(233×233) §f| '+(isOperator(p)&&operatorBoundaryBypass('spawn')?'§aOP WALK ACCESS':'§cNO WALK-THROUGH')
  :`§bPLOT #${id+1} FORCEFIELD §7(${r*2+1}×${r*2+1}) §f| ${plotMode}`)}catch{}
 return true;
}
// Even at the center of a maximum-size plot, show which boundary is closest.
function plotBoundaryDistanceBar(p){
 if(p.dimension?.id!=='minecraft:overworld')return;
 const d=profile(p);if(d.plot<0)return;
 const c=coords(d.plot),r=plotRadius(d.plot),x=p.location.x-c.x,z=p.location.z-c.z;
 if(Math.abs(x)>r+.5||Math.abs(z)>r+.5)return;
 const dist=Math.max(0,Math.floor(Math.min(r+.5-Math.abs(x),r+.5-Math.abs(z))));
 try{p.onScreenDisplay.setActionBar(`§bPLOT BOUNDARY §7(${2*r+1}×${2*r+1}) §f| nearest edge §e${dist} blocks`)}catch{}
}
// Movement check every tick, wall particles twice per second. Does not
// place/remove blocks, interfere with horn cooldown, or alter world spawn.
system.runInterval(()=>{
 const online=new Set();
 for(const p of world.getAllPlayers()){
  online.add(p.id);
  try{enforceForcefield(p)}catch(err){console.warn('[SkyGen] forcefield enforcement error: '+err)}
  if(system.currentTick%10===0&&p.dimension?.id==='minecraft:overworld'){
   try{if(!renderForcefield(p))plotBoundaryDistanceBar(p)}catch(err){console.warn('[SkyGen] forcefield display error: '+err)}
  }
 }
 for(const id of forcefieldPrevious.keys())if(!online.has(id)){forcefieldPrevious.delete(id);forcefieldNotices.delete(id)}
},1);
// v0.8.1: Load the destination, generate/verify its floor, and KEEP that
// chunk loaded until the teleport completes (or the request is cancelled).
// In v0.8.0 the ticking area was removed before the Plot Horn teleport,
// making previously created islands appear to be missing while unloaded.
const plotBuilds=new Map(),plotRepairNotice=new Map();
const ACTIVE_PLOT_AREAS='sg_active_plot_areas_v1',MAX_PLOT_STAGES=6;
let plotStartupSweepDone=false;
function areaRegistry(){
 try{const a=JSON.parse(String(world.getDynamicProperty(ACTIVE_PLOT_AREAS)||'[]'));return Array.isArray(a)?a.filter(x=>/^sg_p\d+$/.test(x)):[]}catch{return []}
}
function trackArea(name,active){
 const names=new Set(areaRegistry());if(active)names.add(name);else names.delete(name);
 world.setDynamicProperty(ACTIVE_PLOT_AREAS,JSON.stringify([...names].slice(0,100)));
}
function sweepSkyGenAreas(){
 const dim=world.getDimension('overworld');
 const names=new Set(areaRegistry());
 // Also find legacy v0.8.1 leftovers where no registry existed.
 try{const result=dim.runCommand('tickingarea list');const txt=String(result?.statusMessage||'');
  for(const match of txt.matchAll(/sg_p\d+/g))names.add(match[0]);
 }catch(e){console.warn('[SkyGen] tickingarea enumeration unavailable '+e)}
 for(const name of names){
  if([...plotBuilds.values()].some(x=>x.areaName===name))continue;
  try{dim.runCommand('tickingarea remove '+name)}catch(e){console.warn('[SkyGen] stale plot area '+name+' '+e)}
 }
 try{world.setDynamicProperty(ACTIVE_PLOT_AREAS,JSON.stringify([...plotBuilds.values()].map(x=>x.areaName).filter(Boolean)))}catch(e){console.warn('[SkyGen] tickingarea registry '+e)}
 plotStartupSweepDone=true;
}
system.runTimeout(sweepSkyGenAreas,20);
const PLOT_RETRY_TICKS=10,PLOT_MAX_TRIES=40;
function plotNotice(p,msg){
 const last=plotRepairNotice.get(p.id)??-99999;
 if(system.currentTick-last>200){plotRepairNotice.set(p.id,system.currentTick);p.sendMessage(msg)}
}
function loadedPlotBlock(dim,x,y,z){
 try{return dim.getBlock({x,y,z})}catch{return undefined}
}
function solidPlotFloor(b){return !!b&&!b.isAir&&!['minecraft:water','minecraft:lava'].includes(b.typeId)}
function plotFloorReady(id){
 const c=coords(id),dim=world.getDimension('overworld');
 // Verify the permanent support layer. The surface can be mined by the owner.
 for(let dx=-8;dx<=8;dx++)for(let dz=-8;dz<=8;dz++){
  if(!solidPlotFloor(loadedPlotBlock(dim,c.x+dx,c.y-2,c.z+dz)))return false;
 }
 return true;
}
function findPlotLanding(id){
 const c=coords(id);
 return findSafeLanding(c,PLOT_LANDING_OFFSETS,[c.y-1,c.y-2],
  (x,z)=>plotAt(x,z)===id&&!inSpawn(x,z)&&!inBuiltSkyRealm(x,z),2);
}
function buildPlotInLoadedChunk(id){
 const c=coords(id),dim=world.getDimension('overworld');
 // Do not run fill against chunks that have not loaded yet.
 if(!loadedPlotBlock(dim,c.x,c.y-1,c.z))return false;
 if(plotFloorReady(id))return true;
 // 'keep' fills AIR ONLY. Existing buildings / chests / custom plot flooring
 // are not overwritten. A no-blocks-filled command may fail harmlessly.
 for(const [offset,block] of [[-1,'minecraft:grass_block'],[-3,'minecraft:dirt'],[-2,'minecraft:dirt']]){
  const y=c.y+offset;
  try{dim.runCommand(`fill ${c.x-8} ${y} ${c.z-8} ${c.x+8} ${y} ${c.z+8} ${block} keep`)}
  catch(e){if(!plotFloorReady(id))console.warn('[SkyGen] plot '+id+' floor layer '+offset+': '+e)}
 }
 return plotFloorReady(id);
}
function stageAndBuildPlot(p,id,teleportAfter=true){
 if(!p?.isValid)return;
 if(!canVisit(p,id))return p.sendMessage('§cYou do not have permission to use this plot.');
 if(teleportAfter){
  const now=system.currentTick,until=cooldowns.get(p.id)||0;
  if(now<until)return p.sendMessage('§cTeleport cooldown: '+Math.ceil((until-now)/20)+'s');
  if(pending.has(p.id))return p.sendMessage('§eTeleport already counting down.');
 }
 if(!plotStartupSweepDone){system.runTimeout(()=>{if(p.isValid)stageAndBuildPlot(p,id,teleportAfter)},25);return}
 const active=plotBuilds.get(id);
 if(active){
  // Claim-time pre-generation can be upgraded into a Plot Horn teleport.
  if(active.playerId===p.id&&teleportAfter){active.teleportAfter=true;p.sendMessage('§eSkyGen: Your plot is loading. Teleport will start when ready.');}
  else if(teleportAfter)plotNotice(p,'§eSkyGen: That plot is currently loading. Try again shortly.');
  return;
 }
 if(plotBuilds.size>=MAX_PLOT_STAGES){
  plotNotice(p,'§eSkyGen: Too many islands loading. Please retry the Plot Horn shortly.');return;
 }
 const dim=world.getDimension('overworld'),c=coords(id),name='sg_p'+id;
 const session={playerId:p.id,teleportAfter,finished:false,areaName:name};
 plotBuilds.set(id,session);
 let areaActive=false,tries=0,lastError='Plot chunk not loaded';
 function cleanup(){
  if(session.finished)return;
  session.finished=true;
  if(plotBuilds.get(id)===session)plotBuilds.delete(id);
  if(areaActive){try{dim.runCommand(`tickingarea remove ${name}`)}catch(e){console.warn('[SkyGen] plot tickingarea cleanup '+id+': '+e)}}
  try{trackArea(name,false)}catch(e){console.warn('[SkyGen] area registry cleanup '+e)}
 }
 session.cancel=cleanup;
 try{
  // Track the area BEFORE creating it, so startup can reclaim a crash orphan.
  trackArea(name,true);
  // Clear only a stale area from a previous interrupted SkyGen run.
  try{dim.runCommand(`tickingarea remove ${name}`)}catch{}
  // A radius of 1 chunk is enough for the 17x17 starter island.
  // false avoids permanent preload overhead on Realm restarts.
  const added=dim.runCommand(`tickingarea add circle ${c.x} ${c.y} ${c.z} 1 ${name} false`);
  if(added?.successCount===0)throw Error('Plot ticking area rejected or limit reached');
  areaActive=true;
  if(teleportAfter)p.sendMessage('§eSkyGen: Preparing plot #'+(id+1)+' safely. Stay where you are.');
 }catch(e){
  lastError=String(e);cleanup();
  console.warn('[SkyGen] cannot load plot '+id+': '+lastError);
  p.sendMessage('§cSkyGen cannot load plot chunks. Check that cheats are enabled and there is a free ticking-area slot. '+lastError.slice(0,120));
  return;
 }
 function check(){
  if(session.finished)return;
  if(!p.isValid){cleanup();return}
  if(!canVisit(p,id)){cleanup();p.sendMessage('§cPlot access was revoked.');return}
  try{
   if(buildPlotInLoadedChunk(id)){
    const target=findPlotLanding(id);
    if(!target){cleanup();p.sendMessage('§cPlot floor is present, but the landing area is blocked. Clear some space at the plot center.');return}
    if(!session.teleportAfter){cleanup();p.sendMessage('§aSkyGen: Plot #'+(id+1)+' is ready. Use the Plot Horn to teleport.');return}
    // IMPORTANT: keep the ticking area alive throughout the 5-second
    // countdown. tpRequest releases it on success, failure or cancellation.
    if(!tpRequest(p,target,id===profile(p).plot?'your plot':'plot #'+(id+1),id,cleanup))cleanup();
    return;
   }
  }catch(e){lastError=String(e);if(tries===0||tries===PLOT_MAX_TRIES-1)console.warn('[SkyGen] plot '+id+' build error: '+lastError)}
  tries++;
  if(tries>=PLOT_MAX_TRIES){
   cleanup();p.sendMessage('§cSkyGen: Plot chunks could not be prepared. No teleport attempted. '+lastError.slice(0,120));return;
  }
  system.runTimeout(check,PLOT_RETRY_TICKS);
 }
 system.runTimeout(check,10);
}
function claim(p){
 const d=profile(p);
 if(d.plot>=0){
  const owner=ownerId(d.plot);
  if(owner&&owner!==p.id)throw Error('Plot owner mismatch; assignment locked for operator review');
  if(!owner)world.setDynamicProperty(keyForPlot(d.plot),p.id);
  return d;
 }
 // A single recoverable global intent prevents a failed write from stalling
 // onboarding or assigning one plot to two players. Existing owners are kept.
 const id=allocateOrRecoverPlot({
  get:key=>world.getDynamicProperty(key),
  set:(key,value)=>world.setDynamicProperty(key,value),
  owner:ownerId,
  ownerKey:keyForPlot,
  overlaps:id=>plotOverlapsProtection(id,PLOT_TIERS.at(-1).radius)
 },p.id);
 d.plot=id;save(p,d);
 p.sendMessage('§aSkyGen: Plot #'+(id+1)+' assigned. Building starter island...');
 system.runTimeout(()=>{if(p.isValid&&!plotBuilds.has(id))stageAndBuildPlot(p,id,false)},10);
 return d;
}
function toolmatch(i,t){return i?.typeId===t.type&&i?.nameTag===t.name}
function isTool(i){return !!i&&TOOLS.some(t=>toolmatch(i,t))}
function syncSkyGenPlotPermission(p){
 try{
  const d=profile(p),id=d.plot;
  const desired=Number.isInteger(id)&&id>=0&&ownerId(id)===p.id?'sg_owner_'+id+'_'+plotRadius(id):'';
  for(const tag of p.getTags())if(tag.startsWith('sg_owner_')&&tag!==desired)p.removeTag(tag);
  if(desired&&!p.hasTag(desired))p.addTag(desired);
 }catch(err){console.warn('[SkyGen SECURITY] plot permission tags: '+err)}
}
function ensure(p){try{syncSkyGenPlotPermission(p);const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return;for(const t of TOOLS){const old=inv.getItem(t.slot);if(toolmatch(old,t)&&old.lockMode===ItemLockMode.slot&&old.keepOnDeath)continue;if(old&&!isTool(old)){let free=-1;for(let i=9;i<inv.size;i++)if(!inv.getItem(i)){free=i;break}if(free<0)for(let i=0;i<6;i++)if(!inv.getItem(i)){free=i;break}if(free<0)continue;inv.setItem(free,old)}const item=new ItemStack(t.type,1);item.nameTag=t.name;item.lockMode=ItemLockMode.slot;item.keepOnDeath=true;inv.setItem(t.slot,item)}for(let i=0;i<inv.size;i++)if((i<6||i>8)&&isTool(inv.getItem(i)))inv.setItem(i,undefined)}catch(e){console.warn('SkyGen tools: '+e)}}
function finishPendingTeleport(t,success=false){
 if(!t||t.finished)return;
 t.finished=true;
 if(typeof t.onFinish==='function'){
  // After success keep the destination loaded briefly for client chunk handoff.
  if(success)system.runTimeout(()=>{try{t.onFinish()}catch(e){console.warn('[SkyGen] plot release '+e)}},40);
  else try{t.onFinish()}catch(e){console.warn('[SkyGen] plot release '+e)}
 }
}
function teleportWatchdog(p,id,token){
 const t=pending.get(id);
 if(!t||t.token!==token)return;
 try{
  if(!p.isValid){pending.delete(id);finishPendingTeleport(t);return}
  const now=system.currentTick,loc=p.location;
  if(p.dimension.id!==t.dim||Math.abs(loc.x-t.start.x)>0.15||Math.abs(loc.y-t.start.y)>0.15||Math.abs(loc.z-t.start.z)>0.15){
   pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cTELEPORT CANCELLED');p.sendMessage('§cTeleport cancelled: you moved.');return;
  }
  if(now-t.created>C.warmup+120){pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cTELEPORT TIMED OUT');p.sendMessage('§cDestination chunks did not become ready; try again later. Operator: /tickingarea list all-dimensions');return;}
  if(now<t.end){
   const n=Math.max(1,Math.ceil((t.end-now)/20));
   try{p.onScreenDisplay.setTitle('§e'+n,{fadeInDuration:0,stayDuration:5,fadeOutDuration:0})}catch{}
   try{p.onScreenDisplay.setActionBar('§eTeleport in '+n+' seconds — stand still')}catch{}
   if(t.lastShown!==n){t.lastShown=n;p.sendMessage('§e'+n+'...')}
   system.runTimeout(()=>teleportWatchdog(p,id,token),1);return;
  }
  if(t.nextTeleportTry&&now<t.nextTeleportTry){system.runTimeout(()=>teleportWatchdog(p,id,token),Math.max(1,t.nextTeleportTry-now));return;}
  if(t.visitPlot!==undefined&&!canVisit(p,t.visitPlot)){
   pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cACCESS REVOKED');p.sendMessage('§cPlot access was revoked.');return;
  }
  if(t.safeSpawn){
   const safe=ensureSpawn();
   if(!safe){pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cSPAWN NOT READY');p.sendMessage('§cSpawn is not verified. Teleport canceled.');return}
   t.target=safe;
  }
  if(t.visitPlot!==undefined){
   // Re-select a landing just before teleport. Someone could have built in
   // the original arrival spot while the countdown was running.
   const safe=findPlotLanding(t.visitPlot);
   if(!safe){pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cPLOT NOT READY');p.sendMessage('§cPlot landing is not safe; teleport cancelled. Try the Plot Horn again.');return;}
   t.target=safe;
  }
  try{
   const destination=world.getDimension('overworld');
   // tryTeleport reports false if Bedrock still cannot load the destination.
   // NEVER fall back to a blind /tp into a void chunk.
   forcefieldTickets.set(id,{...t.target,expires:system.currentTick+5});
   if(typeof p.tryTeleport==='function'){
    if(!p.tryTeleport(t.target,{dimension:destination,checkForBlocks:false}))throw new Error('Destination chunk is not ready');
   }else p.teleport(t.target,{dimension:destination,checkForBlocks:false});
   pending.delete(id);cooldowns.set(id,system.currentTick+teleportCooldown(p));
   finishPendingTeleport(t,true);
   try{t.onArrive?.()}catch(e){console.warn('[SkyGen] Arrival callback: '+e)}
   showTeleportText(p,'§aTELEPORTED!');p.sendMessage('§aTeleport successful.');
  }catch(err){
   forcefieldTickets.delete(id);
   // Keep the source-side movement guard and the destination ticking area
   // active for a bounded retry window after the 5-second countdown.
   if(system.currentTick-t.end<100){
    if(!t.waitingNotice){t.waitingNotice=true;p.sendMessage('§eDestination is still loading. Stand still; retrying safely.');}
    t.nextTeleportTry=system.currentTick+10;
    system.runTimeout(()=>teleportWatchdog(p,id,token),10);
   }else{
    pending.delete(id);finishPendingTeleport(t);showTeleportText(p,'§cTELEPORT FAILED');
    p.sendMessage('§cTeleport failed safely: '+String(err).slice(0,120));
   }
  }
 }catch(err){pending.delete(id);finishPendingTeleport(t);try{p.sendMessage('§cTeleport timer error: '+String(err))}catch{};console.warn('SkyGen watchdog '+err)}
}
function tpRequest(p,target,label,visitPlot,onFinish,safeSpawn=false,onArrive){
 if(queueMovement.has(p)){p.sendMessage('§eLeave the minigame queue before traveling.');return false}
 if(remoteGames.occupied(p)){p.sendMessage('§eLeave the minigame before traveling.');return false}
 const now=system.currentTick,id=p.id,until=cooldowns.get(id)||0;
 if(now<until){p.sendMessage('§cTeleport cooldown: '+Math.ceil((until-now)/20)+'s');return false}
 if(pending.has(id)){p.sendMessage('§eTeleport already counting down.');return false}
 const start={x:p.location.x,y:p.location.y,z:p.location.z};
 const token=now+'-'+id;
 pending.set(id,{start,dim:p.dimension.id,target,label,visitPlot,onFinish,safeSpawn,onArrive,created:now,end:now+C.warmup,token,lastShown:5});
 p.sendMessage('§eTeleport to '+label+' in 5 seconds. Stand still!');
 showTeleportText(p,'§e5');
 system.runTimeout(()=>teleportWatchdog(p,id,token),1);
 return true;
}
function tpPlot(p){
 let d=profile(p);
 // The Horn can recover a first-join plot assignment without forcing a rejoin.
 if(d.plot<0){try{d=claim(p)}catch(e){return p.sendMessage('§cPlot assignment needs operator review: '+String(e).slice(0,120))}}
 stageAndBuildPlot(p,d.plot,true);
}
// The original 50 ordered SkyGen ranks remain unchanged; 51-1000 extend them.
// The original 50 ordered SkyGen ranks are authoritative. Never trust player
// chat, nametags, or user-set tags to assign a title or player permissions.
const rankNativeUnsupported=new Set();
function rankColor(level){const n=rankLevel(level);return n>=50?'§5':n>=41?'§6':n>=31?'§d':n>=21?'§b':n>=11?'§a':'§7'}
function rankBadge(level){return rankColor(level)+'['+rankName(level)+']§r'}
function nativeRankPrefixAvailable(p){return !!p&&'chatNamePrefix' in p}
function applyRankIdentity(p,level){
 const badge=rankBadge(level),team=remoteGames.team(p);
 const head=(team==='red'?'§c[Red] §r':team==='blue'?'§9[Blue] §r':'')+badge+' '+p.name;
 // Bedrock Entity.nameTag is the visible overhead label, not a permission.
 if(p.nameTag!==head)p.nameTag=head;
 // Native chat prefix preserves normal player chat delivery and moderation.
 // This is a pre-release API, so do not assume it exists on Xbox/Realms.
 if(nativeRankPrefixAvailable(p)){
  try{if(p.chatNamePrefix!==badge+' ')p.chatNamePrefix=badge+' ';rankNativeUnsupported.delete(p.id);return}
  catch(err){if(!rankNativeUnsupported.has(p.id))console.warn('[SkyGen RANK] native chat prefix not usable: '+String(err).slice(0,120));rankNativeUnsupported.add(p.id)}
 }
}
function rankChatCommand(actor){
 const d=profile(actor);
 const mode=nativeRankPrefixAvailable(actor)&&!rankNativeUnsupported.has(actor.id)?'native rank prefix':'normal Bedrock chat';
 actor.sendMessage('§dSkyGen rank: §r'+rankName(d.rank)+' §7('+rankLevel(d.rank)+'/1000).');
 actor.sendMessage('§7Overhead rank tag active. Chat mode: §e'+mode+'.');
}
function noPayoutRoom(d,amount){
 const shortage=amount-Math.max(0,CREDIT_CAP-d.credits);
 return 'Free '+shortage.toLocaleString()+' Credits of wallet space or make room in your default bank account.';
}
function rankRewards(d){
 const oldRank=d.rank||1;
 const progress=d.xpProgress===undefined?legacyProgress(Math.min(oldRank,50),d.xp||0):d.xpProgress;
 const mirror=mirrorXP(oldRank,progress);
 const delta=Math.max(0,d.xp-mirror);
 if(!Number.isSafeInteger(delta))throw Error('Unsafe incoming XP; profile must be reviewed');
 const change=advanceRank(oldRank,progress,delta);
 d.rank=change.rank;d.xpProgress=change.progress;d.xp=mirrorXP(d.rank,d.xpProgress);
 const multiplier=hasSkill(d,'econ_rank')?110:100;
 let bonus=0,orbits=0;
 for(let n=oldRank+1;n<=d.rank;n++){
  bonus+=n*multiplier;
  if(n%10===0)orbits++;
 }
 return {oldRank,bonus,orbits};
}
function announceRank(p,d,old){
 if(d.rank>old)p.sendMessage(`§dRank up! ${old} → ${d.rank}. §e+${skillEntitlement(d.rank)-skillEntitlement(old)} Skill Points!`);
 applyRankIdentity(p,d.rank);
}
function rank(p,d){
 const {oldRank,bonus,orbits}=rankRewards(d);
 const journal=readEconomicTxn(p);
 const unlocked=!journal||journal.state==='complete';
 const destination=bonus&&unlocked?payoutDestination(d,bonus):undefined;
 const paidOrbits=unlocked&&orbits<=CREDIT_CAP-d.orbits?orbits:0;
 if(destination!==undefined)creditPayout(d,destination,bonus);
 else if(bonus)d.pendingRankCredits=(d.pendingRankCredits??0)+bonus;
 if(paidOrbits)d.orbits+=paidOrbits;
 else if(orbits)d.pendingRankOrbits=(d.pendingRankOrbits??0)+orbits;
 save(p,d);
 announceRank(p,d,oldRank);
 if(bonus)p.sendMessage(destination===undefined?'§eRank Credits are pending in Compass → Bank.':
  '§aRank reward: '+bonus+' Credits to '+destinationName(d,destination)+'.');
 if(orbits)p.sendMessage(paidOrbits?'§aRank milestone: +'+paidOrbits+' Orbits.':'§eMilestone Orbits are pending in Compass → Bank.');
}
function collectBankPayouts(p){
 assertBankUnlocked(p);
 const d=profile(p);
 const credits=d.pendingRankCredits??0,orbits=d.pendingRankOrbits??0;
 if(!Number.isSafeInteger(credits)||credits<0||!Number.isSafeInteger(orbits)||orbits<0)
  throw Error('Pending rank rewards require operator review.');
 const destination=credits?payoutDestination(d,credits):undefined;
 const claimOrbits=orbits>0&&orbits<=CREDIT_CAP-d.orbits;
 if(destination!==undefined){
  creditPayout(d,destination,credits);
  delete d.pendingRankCredits;
 }
 if(claimOrbits){
  d.orbits+=orbits;
  delete d.pendingRankOrbits;
 }
 if(destination!==undefined||claimOrbits)save(p,d);
 if(credits)p.sendMessage(destination===undefined?'§e'+noPayoutRoom(d,credits):
  '§aCollected '+credits+' rank Credits in '+destinationName(d,destination)+'.');
 if(orbits)p.sendMessage(claimOrbits?'§aCollected '+orbits+' milestone Orbits.':'§eFree room for '+orbits+' milestone Orbits.');
 const marketPaid=settleSellerProceeds(p,d);
 if(!credits&&!orbits&&!marketPaid)p.sendMessage('§7No sale or rank payouts collected.');
}

function showUI(p,ui,attempt=0){
 return new Promise((resolve,reject)=>{
  system.runTimeout(()=>{
   if(p?.isValid===false)return resolve({canceled:true});
   try{ui.show(p).then(r=>{
    if(r.canceled&&/UserBusy/i.test(String(r.cancelationReason||''))&&attempt<5){showUI(p,ui,attempt+1).then(resolve,reject);return}
    resolve(r);
   }).catch(e=>{
    if(attempt<5&&/busy/i.test(String(e)))showUI(p,ui,attempt+1).then(resolve,reject);
    else reject(e);
   })}catch(e){reject(e)}
  },attempt?20*(attempt+1):8);
 });
}
// Keep the player in their current shopping/upgrade workflow after a completed
// action. Respect manual UserClosed/Esc cancellation; only action handlers call
// this helper, and no transaction is ever retried automatically.
function menuAgain(p,open){
 system.runTimeout(()=>{
  if(p?.isValid===false)return;
  try{open()}catch(err){console.warn('[SkyGen MENU] return navigation '+err)}
 },12);
}
function form(p,title,body,buttons,cb,onClose){
 let f=skyAction().title(title).body(body);
 for(const b of buttons)f=f.button(b);
 showUI(p,f).then(r=>{if(!r.canceled&&Number.isInteger(r.selection))cb(r.selection);else onClose?.()}).catch(e=>{onClose?.();console.warn('SkyGen UI '+e)});
}
// Admin privileges require both a server-issued axe and a persistent grant.
// Operator bootstrap: /scriptevent skygen:adminaxe
const ADMIN_AXE='§4§lSkyGen Admin Manager';
function isOperator(p){try{if(typeof p.isOp==="function"&&p.isOp()===true)return true}catch{}try{return p.playerPermissionLevel===2}catch{return false}}
function isAdmin(p){return isOperator(p)||world.getDynamicProperty('sg_admin_'+p.id)===true}
function adminAxe(i){return i?.typeId==='minecraft:wooden_axe'&&i.nameTag===ADMIN_AXE&&i.getLore()?.includes('§8SkyGen issued admin tool')}
function holdingAdminAxe(p){return adminAxe(inventory(p)?.getItem(p.selectedSlotIndex))}
function canUseAdminMenu(p){return p.isValid&&isAdmin(p)&&holdingAdminAxe(p)}
function issueAdminAxe(p,attempt=0){
 try{
  if(!p)return;
  if(!isAdmin(p))return p.sendMessage('§cSkyGen Admin permission not active. Ask an operator to grant access.');
  const inv=inventory(p);
  if(!inv){if(attempt<3)return system.runTimeout(()=>issueAdminAxe(p,attempt+1),20);return p.sendMessage('§cAdmin axe: inventory unavailable.');}
  let existing=-1;
  for(let i=0;i<inv.size;i++){if(adminAxe(inv.getItem(i))){existing=i;break;}}
  if(existing>=0&&existing<6)return p.sendMessage('§aAdmin axe is in hotbar slot '+(existing+1)+'.');
  let slot=-1;
  for(let i=0;i<Math.min(6,inv.size);i++){if(!inv.getItem(i)){slot=i;break;}}
  if(existing>=0){
   if(slot>=0){const axe=inv.getItem(existing);inv.setItem(slot,axe);inv.setItem(existing,undefined);return p.sendMessage('§aAdmin axe moved to hotbar slot '+(slot+1)+'.');}
   return p.sendMessage('§eAdmin axe is in inventory slot '+(existing+1)+'. Free a hotbar slot 1–6 to move it.');
  }
  if(slot<0)return p.sendMessage('§cFree one of hotbar slots 1–6, then run /scriptevent skygen:adminaxe again.');
  const axe=new ItemStack('minecraft:wooden_axe',1);
  axe.nameTag=ADMIN_AXE;axe.setLore(['§8SkyGen issued admin tool','§cAdmin access required']);
  axe.lockMode=ItemLockMode.inventory;
  inv.setItem(slot,axe);
  const actual=inv.getItem(slot);
  if(!adminAxe(actual))throw Error('Item verification failed after insertion');
  p.sendMessage('§aSkyGen Admin axe delivered to hotbar slot '+(slot+1)+'.');
 }catch(err){
  console.warn('[SkyGen ADMIN] axe delivery: '+err);
  if(attempt<3)system.runTimeout(()=>issueAdminAxe(p,attempt+1),20);
  else try{p.sendMessage('§cAdmin axe delivery failed: '+err)}catch{}
 }
}
function adminAudit(actor,action,target,detail){console.warn('[SkyGen ADMIN] '+actor.name+' '+action+' '+target.name+' '+detail)}
// All admin UI transitions are deferred: Bedrock rejects forms opened in the same tick
// as the previous form's completion (often returning UserBusy).
function adminLater(fn){system.runTimeout(()=>{try{fn()}catch(e){console.warn('[SkyGen ADMIN UI] '+e);}},12)}
function adminShow(p,ui,step,attempt=0,requireAxe=true){
 return new Promise((resolve,reject)=>{
  system.runTimeout(()=>{
   if(requireAxe&&!canUseAdminMenu(p))return resolve({canceled:true});
   ui.show(p).then(r=>{
    if(requireAxe&&!canUseAdminMenu(p))return resolve({canceled:true});
    if(r.canceled&&String(r.cancelationReason||'').includes('UserBusy')&&attempt<5){
     adminNotice(p,'§eAdmin menu busy; retrying '+step+'...');
     adminShow(p,ui,step,attempt+1,requireAxe).then(resolve,reject);return;
    }
    if(r.canceled)adminNotice(p,'§7Admin '+step+' closed ('+String(r.cancelationReason||'cancelled')+').');
    else adminNotice(p,'§7Admin '+step+' selection received.');
    resolve(r);
   }).catch(e=>{
    if(attempt<3&&/busy/i.test(String(e)))return adminShow(p,ui,step,attempt+1,requireAxe).then(resolve,reject);
    adminNotice(p,'§cAdmin '+step+' failed: '+e);reject(e);
   });
  },attempt?20*(attempt+1):8);
 });
}
function adminNotice(p,msg){try{p.sendMessage(msg)}catch(e){console.warn('[SkyGen ADMIN NOTICE] '+e)}}
function adminOnline(target){return world.getAllPlayers().some(x=>x.id===target.id)}
function adminFormError(p,where,e){console.warn('[SkyGen ADMIN '+where+'] '+e);adminNotice(p,'§cAdmin '+where+' error: '+e)}
function adminAction(p,title,body,buttons,cb){
 if(!canUseAdminMenu(p))return adminNotice(p,'§cHold your Admin Axe to open this menu.');
 let ui=skyAction().title(title).body(body);
 for(const label of buttons)ui=ui.button(label);
 adminShow(p,ui,title).then(r=>{if(!r.canceled)adminLater(()=>{
  if(canUseAdminMenu(p))cb(r.selection);
 })}).catch(e=>adminFormError(p,title,e));
}
function adminBoundaryMenu(p){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators can change boundary bypass settings.');
 const spawn=operatorBoundaryBypass('spawn'),plots=operatorBoundaryBypass('plot');
 adminAction(p,'§6BOUNDARY CONTROLS',
  '§7Walk bypass settings apply to all operators.\n§eAdmin Build Mode is personal, spawn-only, and resets on logout.',
  ['Spawn OP Bypass: '+(spawn?'§aON':'§cOFF'),
   'Plot OP Bypass: '+(plots?'§aON':'§cOFF'),'Admin Build Mode: '+(personalSpawnBuild.has(p.id)?'§aON':'§cOFF'),'Back to Admin Manager'],
  i=>{
   if(!isOperator(p))return adminNotice(p,'§cRealm operator permission required.');
   if(i===3)return adminMenu(p);
   if(i===2){if(personalSpawnBuild.has(p.id))personalSpawnBuild.delete(p.id);else personalSpawnBuild.add(p.id);adminNotice(p,'§ePersonal spawn placing/breaking '+(personalSpawnBuild.has(p.id)?'ENABLED':'DISABLED')+'.');return adminBoundaryMenu(p)}
   if(i!==0&&i!==1)return;
   const kind=i===0?'spawn':'plot',key=kind==='spawn'?OP_SPAWN_BYPASS_KEY:OP_PLOT_BYPASS_KEY;
   const newValue=!operatorBoundaryBypass(kind);
   try{
    world.setDynamicProperty(key,newValue);
    if(world.getDynamicProperty(key)!==newValue)throw Error('Setting did not persist');
   }catch(err){adminNotice(p,'§cCould not save boundary setting: '+err);return adminBoundaryMenu(p)}
   // Invalidate prior walking sample so operators already outside a wall
   // are not automatically bounced during a permission change.
   for(const op of world.getAllPlayers())if(isOperator(op))forcefieldPrevious.delete(op.id);
   adminNotice(p,'§a'+kind.toUpperCase()+' operator walk bypass '+(newValue?'ENABLED':'DISABLED')+'.');
   adminBoundaryMenu(p);
  });
}
// OP-only recovery: register the actual lobby instead of blindly teleporting
// everyone to obsolete fixed-Y coordinates. Changes do not alter builds or player data.
function spawnCandidateSafe(pos){
 const arena=REMOTE_ARENAS.find(spec=>arenaOverlapsLobby(spec,pos,spawnLimit()));
 if(arena)return 'Spawn protection would overlap '+arena.title;
 if(!pos||!['x','y','z'].every(k=>Number.isSafeInteger(pos[k])))return 'Invalid coordinates';
 if(Math.abs(pos.x)>29000000||Math.abs(pos.z)>29000000||pos.y<-63||pos.y>317)return 'Outside safe world boundaries';
 const overlaps=overlappingPlots(pos,PLOT_TIERS.at(-1).radius);
 if(overlaps.length)return 'Spawn protection would overlap reserved plot #'+(overlaps[0]+1);
 const dim=world.getDimension('overworld'),floor=spawnFloorBlock(dim,pos.x,pos.y-1,pos.z);
 if(!floor)return 'Destination chunk is not loaded';
 if(!safeLandingFloor(floor))return 'No safe solid floor immediately beneath your feet';
 if(![0,1,2].every(dy=>spawnFloorBlock(dim,pos.x,pos.y+dy,pos.z)?.isAir))return 'Three air blocks of headroom are required';
 return '';
}
async function updateSpawnAnchor(p,pos,requireAxe=false){
 if(publicCityBuildRunning())return adminNotice(p,'§cSpawn changes are disabled while Sky Realm city construction is active.');
 if(!isOperator(p)||(requireAxe&&!canUseAdminMenu(p)))return adminNotice(p,'§cOnly Realm operators can change spawn.');
 if(spawnAreaChanging)return adminNotice(p,'§eA spawn change is already in progress.');
 const err=spawnCandidateSafe(pos);if(err)return adminNotice(p,'§cSpawn not changed: '+err);
 const old=spawnPosition(),oldRaw=world.getDynamicProperty(SPAWN_ANCHOR_KEY);
 spawnAreaChanging=true;
 try{
  await replaceFixedSpawnArea(pos);
  if(!isOperator(p)||(requireAxe&&!canUseAdminMenu(p)))throw Error('Realm operator or Admin Axe access changed');
  world.setDynamicProperty(SPAWN_ANCHOR_KEY,JSON.stringify(pos));
  const now=spawnPosition();if(now.x!==pos.x||now.y!==pos.y||now.z!==pos.z)throw Error('Spawn settings could not be verified');
  if(!spawnLanding())throw Error('Spawn landing could not be verified after save');
  fixedSpawnDefaultApplied=false;
  if(!syncFixedDefaultSpawn())throw Error('World spawn could not be updated');
  for(const op of world.getAllPlayers())forcefieldPrevious.delete(op.id);
  adminAudit(p,'SET SPAWN',p,`${old.x},${old.y},${old.z} -> ${pos.x},${pos.y},${pos.z}`);
  adminNotice(p,`§aSkyGen spawn verified: ${pos.x}, ${pos.y}, ${pos.z}. Protected spawn area follows this location.`);
  return true;
 }catch(e){
  console.warn('[SkyGen SPAWN] anchor change rolled back: '+e);
  try{world.setDynamicProperty(SPAWN_ANCHOR_KEY,oldRaw)}catch(rollback){console.warn('[SkyGen SPAWN] rollback failed '+rollback)}
  try{await replaceFixedSpawnArea(old)}catch(rollback){console.warn('[SkyGen SPAWN] ticking area rollback failed '+rollback)}
  fixedSpawnDefaultApplied=false;syncFixedDefaultSpawn();
  adminNotice(p,'§cSpawn change canceled and previous settings restored: '+e);
  return false;
 }finally{spawnAreaChanging=false}
}
function spawnStatus(p){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may inspect spawn settings.');
 const d=spawnDiagnostics(),s=d.anchor,areaVerified=stageFixedSpawnArea();
 const overlaps=new Set(overlappingPlots(s,PLOT_TIERS.at(-1).radius,true));
 if(cityProtectionActive())for(const id of overlappingPlots(C.spawn,PLOT_TIERS.at(-1).radius,true))overlaps.add(id);
 if(overlaps.size)p.sendMessage('§cProtected land overlaps owned plots: '+[...overlaps].map(id=>'#'+(id+1)).join(', '));
 p.sendMessage(`§6SkyGen SPAWN STATUS §7X:${s.x} Y:${s.y} Z:${s.z} (${spawnIsOriginal()?'original':'operator-set'})`);
 p.sendMessage(`§7Chunk: ${d.chunkLoaded?'§aloaded':'§cunloaded'} §7Center floor: ${d.centerFloor?'§aexists':'§cmissing'} §7Headroom: ${d.centerHeadroom?'§aclear':'§cblocked/unloaded'}`);
 p.sendMessage('§7Verified landing: '+(d.landing?'§a'+d.landing.x+', '+d.landing.y+', '+d.landing.z:'§cNONE'));
 p.sendMessage('§7Spawn ticking area staged: '+(areaVerified?'§ayes':'§cno')+'. If blocked, stand at your real lobby and run /scriptevent skygen:spawn set');
}
function spawnAtOperator(p,requireAxe=true){
 if(!isOperator(p)||p.dimension?.id!=='minecraft:overworld')return adminNotice(p,'§cRealm operator must stand at the spawn platform in the Overworld.');
 const pos={x:Math.floor(p.location.x),y:Math.floor(p.location.y),z:Math.floor(p.location.z)},problem=spawnCandidateSafe(pos);
 if(problem)return adminNotice(p,'§cCannot set spawn here: '+problem);
 const old=spawnPosition();
 const confirm=skyMessage().title('§6CONFIRM SPAWN LOCATION')
  .body(`§eNew location: ${pos.x}, ${pos.y}, ${pos.z}\n§7Current location: ${old.x}, ${old.y}, ${old.z}\n\nThis changes the protected 233×233 spawn center for all players. Existing blocks will not be deleted. Confirm only while standing on your finished lobby.`)
  .button1('Cancel').button2('Set Spawn Here');
 adminShow(p,confirm,'spawn location confirmation',0,requireAxe).then(r=>{
  if(r.canceled||r.selection!==1)return;
  adminLater(()=>updateSpawnAnchor(p,pos,requireAxe).catch(e=>adminFormError(p,'spawn location',e)));
 }).catch(e=>adminFormError(p,'spawn location',e));
}
function spawnControls(p){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may manage spawn.');
 const s=spawnPosition();
 adminAction(p,'§6SPAWN CONTROLS',`§7Active spawn: §e${s.x}, ${s.y}, ${s.z}\n§7Must have solid floor and 3 blocks of air above. All teleport horns and menus use the verified destination.`,
 ['Set Spawn at My Location','Check Spawn Status','Restore Original Spawn (0, 1, 0)','Back to Admin Manager'],i=>{
  if(i===0)return spawnAtOperator(p);
  if(i===1){spawnStatus(p);return spawnControls(p)}
  if(i===2){
   const confirm=skyMessage().title('§cRESTORE ORIGINAL SPAWN').body('Restore 0, 1, 0 as the protected spawn center? The old area must load and have a safe landing.').button1('Cancel').button2('Restore');
   adminShow(p,confirm,'restore spawn confirmation').then(r=>{if(!r.canceled&&r.selection===1)adminLater(()=>updateSpawnAnchor(p,{...C.spawn},true).catch(e=>adminFormError(p,'restore spawn',e)))}).catch(e=>adminFormError(p,'restore spawn',e));
   return;
  }
  if(i===3)return adminMenu(p);
 });
}
function spawnCommand(p,message){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may manage spawn.');
 const action=String(message||'').trim().toLowerCase();
 if(action==='status'||action==='check')return spawnStatus(p);
 if(action==='set')return spawnAtOperator(p,false);
 if(action==='reset')return adminNotice(p,'§eFor safety, use Admin Axe → Spawn Controls → Restore Original Spawn.');
 p.sendMessage('§eUse /scriptevent skygen:spawn status OR /scriptevent skygen:spawn set (at your lobby).');
}
function adminArenaTeleports(p){
 if(!canUseAdminMenu(p))return adminNotice(p,'§cUse your Admin Axe for arena travel.');
 const arenas=REMOTE_ARENAS;
 const canReturn=remoteGames.isInspecting(p);
 const options=[...arenas.map(spec=>spec.title),...(canReturn?['Return to Colosseum']:[]),'Back'];
 adminAction(p,'§6ARENA TELEPORTS','Choose a remote arena to visit.',options,i=>{
  if(!canUseAdminMenu(p))return adminNotice(p,'§cAdmin Axe access expired.');
  if(i===options.length-1)return adminMenu(p);
  if(canReturn&&i===arenas.length&&remoteGames.isInspecting(p))return remoteGames.leave(p);
  if(arenas[i])return remoteGames.inspect(p,arenas[i].id);
 });
}
function adminMenu(p){
 if(!canUseAdminMenu(p))return adminNotice(p,'§cHold your Admin Axe to open this menu.');
 const operator=isOperator(p);
 adminAction(p,'§4SKYGEN ADMIN MANAGER','Select an action. Changes are logged.',
 [operator?'Manage Player Wallet':'Wallet (operator only)',operator?'Give Player Items':'Items (operator only)',operator?'Grant/Revoke Admin Access':'Admin Access (operator only)','Get My Admin Axe','Boundary Controls (operator only)','Spawn Controls (operator only)','Public Mine Levels (operator only)','Arena Teleports',...(operator?['Generator Controls']:[]),'Close'],
 i=>adminLater(()=>{
  if(!canUseAdminMenu(p))return adminNotice(p,'§cAdmin Axe access expired.');
  if(i===0)return isOperator(p)?adminChoosePlayer(p,'wallet'):adminNotice(p,'§cRealm operator required.');
  if(i===1)return isOperator(p)?adminChoosePlayer(p,'items'):adminNotice(p,'§cRealm operator required.');
  if(i===2)return isOperator(p)?adminChoosePlayer(p,'access'):adminNotice(p,'§cOnly Realm operators can manage admin access.');
  if(i===3)return issueAdminAxe(p);
  if(i===4)return isOperator(p)?adminBoundaryMenu(p):adminNotice(p,'§cRealm operator required.');
  if(i===5)return isOperator(p)?spawnControls(p):adminNotice(p,'§cRealm operator required.');
  if(i===6)return isOperator(p)?publicMineAdminMenu(p):adminNotice(p,'§cRealm operator required.');
  if(i===7)return adminArenaTeleports(p);
  if(i===8&&operator&&isOperator(p))return adminGeneratorControls(p);
 }));
}
function adminGeneratorControls(p,page=0){
 if(!isOperator(p)||!canUseAdminMenu(p))return adminNotice(p,'§cUse the Admin Axe as a Realm operator.');
 const owned=[...generators].filter(([,g])=>g.owner===p.id);
 const size=8,last=Math.max(0,Math.ceil(owned.length/size)-1);
 const current=Math.max(0,Math.min(last,page)),rows=owned.slice(current*size,current*size+size);
 const labels=rows.map(([,g])=>`Force output · ${g.type} @ ${g.x},${g.y},${g.z}`);
 const actions=rows.map(([key,g])=>()=>forceGeneratorOutput(p,key,g));
 if(current>0){labels.push('Previous Page');actions.push(()=>adminGeneratorControls(p,current-1));}
 if(current<last){labels.push('Next Page');actions.push(()=>adminGeneratorControls(p,current+1));}
 labels.push('Back');actions.push(()=>adminMenu(p));
 adminAction(p,'§6GENERATOR CONTROLS','Force output on one of your registered generators. The output cell must be air.',labels,i=>actions[i]?.());
}
function forceGeneratorOutput(p,key,g){
 if(!isOperator(p)||!canUseAdminMenu(p))return adminNotice(p,'§cAdmin Axe access expired.');
 if(!generatorRegistryLoaded||generators.get(key)!==g||g.owner!==p.id)return adminNotice(p,'§cThat generator is no longer available.');
 try{
  const dim=world.getDimension('overworld'),base=dim.getBlock({x:g.x,y:g.y,z:g.z}),out=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
  const expected=GEN_BY_NAME.get(g.type)?.block||g.block;
  if(!expected||!isGeneratorBase(g,base)||!out?.isAir)return adminNotice(p,'§cForce test requires a registered base and an empty output cell.');
  out.setType(expected);
  clearGeneratorRefill(key);
  adminAudit(p,'FORCED GENERATOR OUTPUT',p,key+' '+expected);
  adminNotice(p,'§aGenerator output test succeeded.');
 }catch(error){genError('force test '+error);adminNotice(p,'§cForce test failed: '+error)}
}
function adminChoosePlayer(p,mode){
 if(!isAdmin(p))return adminNotice(p,'§cAdmin access denied.');
 const online=world.getAllPlayers();
 adminAction(p,'§4SELECT PLAYER','Choose an online player.',[...online.map(x=>x.name),'Back'],i=>adminLater(()=>{
  if(i===online.length)return adminMenu(p);
  const target=online[i];if(!target||!adminOnline(target))return adminNotice(p,'§cPlayer is no longer online.');
  if(mode==='wallet')return adminWallet(p,target);
  if(mode==='items')return adminGive(p,target);
  return adminAccess(p,target);
 }));
}
function adminWallet(p,target){
 if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access denied or player offline.');
 const d=profile(target);
 adminAction(p,'§6PLAYER WALLET',target.name+'\\nCredits: '+d.credits+'\\nOrbits: '+d.orbits,
 ['Add Credits','Remove Credits','Add Orbits','Remove Orbits','Back'],i=>{
  if(i===4)return adminChoosePlayer(p,'wallet');
  if(i<0||i>3)return;
  const key=i<2?'credits':'orbits',sign=i%2===0?1:-1;
  const operation=(sign>0?'Add ':'Remove ')+(key==='credits'?'Credits':'Orbits');
  const ui=skyModal().title(operation).textField('Amount (whole number)','Enter amount',{defaultValue:'1000'});
  adminShow(p,ui,'wallet amount').then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();
   const amount=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   if(!Number.isSafeInteger(amount)||amount>2000000000)return adminNotice(p,'§cEnter 1 to 2,000,000,000.');
   if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access lost or player offline.');
   const current=profile(target),balance=Number(current[key])||0,next=balance+sign*amount;
   if(!Number.isSafeInteger(next)||next<0||next>2000000000)return adminNotice(p,'§cInsufficient balance or limit exceeded.');
   const confirm=skyMessage().title('Confirm '+operation)
    .body(target.name+'\\nAmount: '+amount+'\\nBefore: '+balance+'\\nAfter: '+next)
    .button1('Cancel').button2('Confirm');
   adminShow(p,confirm,'wallet confirmation').then(c=>{
    if(c.canceled||c.selection!==1)return adminNotice(p,'§7Wallet change canceled.');
    try{
     if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAccess lost or player disconnected.');
     const fresh=profile(target),now=Number(fresh[key])||0,updated=now+sign*amount;
     if(!Number.isSafeInteger(updated)||updated<0||updated>2000000000)return adminNotice(p,'§cBalance limit exceeded.');
     fresh[key]=updated;
     economicReconcileBypass.add(target.id);
     try{save(target,fresh)}finally{economicReconcileBypass.delete(target.id)}
     const verified=profile(target);
     if(Number(verified[key])!==updated)throw Error('Balance verification failed');
     adminAudit(p,sign>0?'ADD':'REMOVE',target,amount+' '+key);
     adminNotice(p,'§aSUCCESS: '+target.name+' '+key+' '+now+' → '+updated);
     adminNotice(target,'§aAdmin '+(sign>0?'added ':'removed ')+amount+' '+key+'. New balance: '+updated);
    }catch(e){adminFormError(p,'wallet save',e)}
   }).catch(e=>adminFormError(p,'wallet confirmation',e));
  }).catch(e=>adminFormError(p,'wallet amount',e));
 });
}
function adminGive(p,target){
 if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access denied or player offline.');
 const ui=skyModal().title('Give Item to '+target.name)
  .textField('Minecraft item ID','minecraft:diamond',{defaultValue:'minecraft:diamond'})
  .textField('Quantity (1–64)','1',{defaultValue:'1'});
 adminShow(p,ui,'give item').then(r=>{
  if(r.canceled)return;
  const id=String(r.formValues?.[0]??'').trim().toLowerCase();
  const raw=String(r.formValues?.[1]??'').trim();
  const qty=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
  if(!/^[a-z0-9_]+:[a-z0-9_]+$/.test(id)||!Number.isSafeInteger(qty)||qty>64)
   return adminNotice(p,'§cInvalid item ID or quantity.');
  let stack;
  try{stack=new ItemStack(id,qty)}catch(e){return adminFormError(p,'item creation',e)}
  const confirm=skyMessage().title('Confirm Item Delivery')
   .body('Player: '+target.name+'\\nItem: '+id+'\\nQuantity: '+qty)
   .button1('Cancel').button2('Give Items');
  adminShow(p,confirm,'give item confirmation').then(c=>{
   if(c.canceled||c.selection!==1)return adminNotice(p,'§7Item delivery canceled.');
   if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cAdmin access lost or player offline.');
   try{
    const inv=inventory(target);
    if(!inv)return adminNotice(p,'§cTarget inventory unavailable.');
    if(!inventoryCapacity(target,stack))return adminNotice(p,'§cNot enough room in target inventory. No items delivered.');
    const leftover=inv.addItem(stack);
    if(leftover)return adminNotice(p,'§cInventory changed; some items could not be delivered.');
    adminAudit(p,'GIVE',target,qty+' '+id);
    adminNotice(p,'§aSUCCESS: Gave '+qty+' '+id+' to '+target.name);
    adminNotice(target,'§aSkyGen Admin gave you '+qty+' '+id);
   }catch(e){adminFormError(p,'item delivery',e)}
  }).catch(e=>adminFormError(p,'item confirmation',e));
 }).catch(e=>adminFormError(p,'give item form',e));
}
function adminAccess(p,target){
 if(!isOperator(p))return adminNotice(p,'§cOnly Realm operators may manage admin access.');
 const granted=world.getDynamicProperty('sg_admin_'+target.id)===true;
 adminAction(p,'§4ADMIN ACCESS',target.name+'\\nAccess: '+(granted?'Granted':'Not granted'),
 [granted?'Revoke Admin':'Grant Admin','Back'],i=>{
  if(i===1)return adminMenu(p);
  if(i!==0)return;
  if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cOperator access required; player must be online.');
  const next=!granted;
  const confirm=skyMessage().title('Confirm Admin Access')
   .body((next?'Grant':'Revoke')+' SkyGen Admin for '+target.name+'?')
   .button1('Cancel').button2('Confirm');
  adminShow(p,confirm,'admin permission confirmation').then(c=>{
   if(c.canceled||c.selection!==1)return adminNotice(p,'§7Admin change canceled.');
   if(!isOperator(p)||!adminOnline(target))return adminNotice(p,'§cOperator access required; player offline.');
   try{
    world.setDynamicProperty('sg_admin_'+target.id,next);
    if(world.getDynamicProperty('sg_admin_'+target.id)!==next)throw Error('Permission verification failed');
    adminAudit(p,next?'GRANT ADMIN':'REVOKE ADMIN',target,'');
    adminNotice(target,next?'§aSkyGen Admin access granted.':'§cSkyGen Admin access revoked.');
    if(next)system.runTimeout(()=>issueAdminAxe(target),30);
    adminNotice(p,'§aSUCCESS: Admin access '+(next?'granted to ':'revoked from ')+target.name+'.');
   }catch(e){adminFormError(p,'access update',e)}
  }).catch(e=>adminFormError(p,'admin permission confirmation',e));
 });
}
function back(p){menu(p)}
const bank=createBank({world,system,profile,save,assertUnlocked:assertBankUnlocked,collectPayouts:collectBankPayouts,
 form,showUI,skyModal,skyMessage,back:skyMenuBankWallet});
function bankMenu(p){bank.open(p)}
// v0.10.55: Xbox-first, owner-approved player navigation. The form action list
// and callback table share ONE source of truth, avoiding hard-coded index drift.
// The older purchase, rank, quest and permissions engines are not changed here.
function navForm(p,title,body,entries,onBack){
 const actions=[...entries,['Back',onBack]];
 form(p,title,body,actions.map(([name])=>name),i=>{
  if(!Number.isInteger(i)||i<0||i>=actions.length)return;
  // Permissions are enforced again in the destination, never by button hiding alone.
  actions[i][1](p);
 });
}
function skyMenuRanksSkills(p){
 const d=profile(p);
 navForm(p,'§dRANKS & SKILLS',`Rank: ${d.rank}/1000 — ${rankName(d.rank)}\nAvailable Skill Points: ${skillAvailable(d)}\nXP toward next: ${formattedXP(d.xpProgress)}`,
  [['Rank Codex · 1,000 Ranks',ranks],['Skill Tree',skillTree],['Active Abilities',skillAbilities]],menu);
}
const trophyInbox=createTrophyInbox(world);
const trophies=createPlayerTrophies({world,system,inventory,protectedAt,safeStandingLocation,isOperator,
 canDropAt:(player,{x,z})=>{
  if(player.dimension.id!=='minecraft:overworld')return true;
  const id=plotAt(x,z);
  return id<0||fieldAccess(player,{kind:'plot',id});
 }});
const SKYSPIRE_KIT_LABEL='1 Totem of Undying + 1 Enchanted Golden Apple';

function saveSkyspireTime(p,ticks){
 try{
  const {best,improved}=recordSkyspireTime(world.scoreboard,p,ticks);
  rememberLeaderboardPlayer(p,profile(p));
  p.sendMessage((improved?'§aNew Skyspire personal best · ':'§7Skyspire personal best · ')+formatSkyspireTime(best));
  return true;
 }catch(error){
  p.sendMessage('§cSkyspire time could not be saved. Use Skyspire Trial in the Compass to retry.');
  console.warn('[Skyspire time] '+error);
  return false;
 }
}
world.afterEvents.worldLoad.subscribe(()=>{
 try{ensureSkyspireTimes(world.scoreboard)}
 catch(error){console.warn('[Skyspire time] Scoreboard initialization: '+error)}
});
function skyspireReward(p,clearedAt){
 let earned;
 try{
  const data=profile(p);
  earned=recordSkyspireClear(data,clearedAt);
  if(earned)save(p,data);
 }catch(error){
  p.sendMessage('§cSkyspire prize was not saved. Use Skyspire Trial in the Compass to retry.');
  console.warn('[Skyspire reward] '+error);
  return false;
 }
 if(!earned)p.sendMessage('§eYou already earned this week’s Skyspire prize.');
 else{
  try{
   if(deliverClaimBoxItems(p,'kit'))p.sendMessage('§aSkyspire prize delivered: '+SKYSPIRE_KIT_LABEL+'.');
   else p.sendMessage('§eSkyspire prize saved. Open Compass → Claim Box.');
  }catch(error){
   p.sendMessage('§eSkyspire prize saved. Open Compass → Claim Box.');
   console.warn('[Skyspire reward] Delivery deferred: '+error);
  }
 }
 return true;
}
function returnSkyspireToSpawn(p,onArrival,canArrive){
 const prior=pending.get(p.id);
 pending.delete(p.id);
 finishPendingTeleport(prior);
 spawnStages.get(p.id)?.release();
 safeSpawnTravel(p,true,onArrival,canArrive);
}
const skyspireTrial=createSkyspireTrial({
 cityReady:()=>world.getDynamicProperty('sg_phase0_city_ready_v1')===true,
 onStart:p=>{
  try{skillPulsePlayer(p)}catch(error){console.warn('[Skyspire] Start effects: '+error)}
 },
 onTime:saveSkyspireTime,
 onClear:skyspireReward,
 returnToSpawn:returnSkyspireToSpawn
});
function skyspireMenu(p){
 const running=skyspireTrial.hasRun(p);
 const cleared=skyspireTrial.isCleared(p);
 const actions=[];
 if(running)actions.push([cleared?'Retry Finish':'End Run',skyspireTrial.leave]);
 actions.push(['Open Claim Box',claimBoxMenu]);
 navForm(p,'§dSKYSPIRE TRIAL',
  cleared?'Finish reached. Retry saving the clear and returning to spawn.':running?
   'Take any path to the four gold tiles for an instant return to spawn. Touching the ground ends the run.':
   'Step on the purple mats near 70, 1, 9 in the Skill Temple to start your timer. The weekly clear prize is '+SKYSPIRE_KIT_LABEL+'.',
  actions,skyMenuTravelVisitors);
}
function skyMenuTravelVisitors(p){
 navForm(p,'§bTRAVEL & VISITORS','Teleports retain their five-second stand-still warm-up and cooldown.',
  [['Teleport to Spawn / Plot',teleports],['Skyspire Trial · Skill Temple',skyspireMenu],['Visit Other Plots',visitMenu],['My Visitor Permissions',visitorOwnerMenu],['My Plot & Trust',plotMenu]],menu);
}

// These transactions only mark the delivery in inventory. They do not debit a
// balance. The prize receipt and its weekly count commit in one profile write.
const CLAIM_DELIVERY_MARKER='sg_claim_delivery';
const CLAIM_DELIVERY_LORE='§8SkyGen delivery ';
function claimDeliveryLore(tx){return CLAIM_DELIVERY_LORE+tx.id.slice(0,32);}
function claimSlotDelivered(item,tx,row){
 const [, ,type,amount,trophyId]=row;
 const marked=item?.maxAmount===1?item.getDynamicProperty(CLAIM_DELIVERY_MARKER)===tx.id:
  item?.getLore().includes(claimDeliveryLore(tx));
 return item?.typeId===type&&item.amount===amount&&marked&&
  (!trophyId||trophyFromItem(item)?.id===trophyId);
}
function claimSlotsDelivered(inv,tx){
 return !!inv&&Array.isArray(tx.slots)&&tx.slots.length>0&&
  tx.slots.every(row=>claimSlotDelivered(inv.getItem(row[0]),tx,row));
}
function restoreClaimSlots(inv,tx){
 if(!inv||!Array.isArray(tx.slots)||!tx.slots.length)throw Error('Prize delivery slots are unavailable.');
 const sameBefore=(item,before,type)=>before?eligibleShopItem(item,type)&&item.amount===before:item===undefined;
 for(const row of tx.slots){
  const [slot,before,type]=row,current=inv.getItem(slot);
  if(claimSlotDelivered(current,tx,row)){
   inv.setItem(slot,before?new ItemStack(type,before):undefined);
  }
  if(!sameBefore(inv.getItem(slot),before,type))
   throw Error('Could not restore the pre-delivery inventory.');
 }
}
function finishClaimDelivery(p,tx){
 if(tx.prize==='trophy')trophyInbox.remove(p.id,tx.trophyId);
 const inv=inventory(p);
 for(const row of tx.slots){
  try{
   const [slot]=row;
   const item=inv?.getItem(slot);
   if(!claimSlotDelivered(item,tx,row))continue;
   if(item.maxAmount===1)item.setDynamicProperty(CLAIM_DELIVERY_MARKER,undefined);
   else item.setLore();
   inv.setItem(slot,item);
  }catch(error){console.warn('[SkyGen Claim Box] Delivery marker cleanup: '+error)}
 }
 endEconomicTxn(p,tx,true);
}
function commitClaimDelivery(p,tx,data){
 if(tx.prize==='kit'){
  const prior=skyspirePrizes(data);
  if(prior.kits<1)throw Error('Skyspire kit is no longer claimable.');
  data.skyspireWeekly={...prior,kits:prior.kits-1};
 }else if(tx.prize!=='trophy'||!trophyInbox.get(p.id,tx.trophyId))throw Error('Trophy is no longer claimable.');
 data.sg_last_econ_txn=tx.id;
 save(p,data);
 finishClaimDelivery(p,tx);
}
function deliverClaimBoxItems(p,prize,trophyId){
 recoverEconomicTxn(p);
 assertBankUnlocked(p);
 const inv=inventory(p),data=profile(p);
 const entry=prize==='trophy'?trophyInbox.get(p.id,trophyId):undefined;
 if(prize==='kit'?!skyspirePrizes(data).kits:!entry)return false;
 const stacks=entry?[trophies.itemFor(entry)]:SKYSPIRE_KIT.map(type=>new ItemStack(type,1));
 const plan=planClaimDelivery(inv,stacks,eligibleShopItem);
 if(!plan)return false;
 const tx=beginEconomicTxn(p,'claim_box',{prize,trophyId,slots:plan.map(({slot,before,after})=>
  [slot,before?.amount??0,after.typeId,after.amount,trophyId??null])});
 try{
  advanceEconomicTxn(p,tx,'delivering');
  for(const {slot,after} of plan){
   if(after.maxAmount===1)after.setDynamicProperty(CLAIM_DELIVERY_MARKER,tx.id);
   else after.setLore([claimDeliveryLore(tx)]);
   inv.setItem(slot,after);
  }
  if(!claimSlotsDelivered(inv,tx))throw Error('Could not verify the delivered items.');
  commitClaimDelivery(p,tx,profile(p));
  return true;
 }catch(error){
  try{
   // A verified profile receipt means the prize was granted. Recovery only
   // finalizes its record and never issues the item again.
   if(profile(p).sg_last_econ_txn===tx.id){finishClaimDelivery(p,tx);return true;}
   restoreClaimSlots(inv,tx);
   endEconomicTxn(p,tx,true);
  }catch(failure){economicTxnReview(p,tx,error+' · '+failure);}
  throw error;
 }
}
function claimLegacySkyspireCredits(p){
 recoverEconomicTxn(p);assertBankUnlocked(p);
 const d=profile(p),prizes=skyspirePrizes(d);
 if(!prizes.pending)return '§eNo earlier Skyspire Credits are pending.';
 if(d.credits>CREDIT_CAP-SKYSPIRE_CREDITS)return '§eMake room for 10,000 Credits in your wallet.';
 d.credits+=SKYSPIRE_CREDITS;
 d.skyspireWeekly={...prizes,pending:prizes.pending-1};
 save(p,d);
 return '§aClaimed 10,000 Credits from an earlier Skyspire clear.';
}
function claimBoxCounts(p,d){
 const skyspire=skyspirePrizes(d),rush=rushStats(d).pending/RUSH_WIN_CREDITS,heads=trophyInbox.count(p.id);
 const king=kingStats(d).pending/KING_CREDITS;
 return {skyspire,rush,heads,king,total:skyspire.kits+skyspire.pending+rush+heads+king};
}
const rewardNotices=createRewardNotices({world,system,questStatus:rewardQuestStatus,countPrizes:(p,d)=>claimBoxCounts(p,d).total});

installCombatScores({world,system,ignorePlayer:p=>remoteGames.locked(p),rememberPlayer:p=>rememberLeaderboardPlayer(p,profile(p)),onKill:({id,attacker,victim})=>{
 const trophy=trophies.issue(victim);
 try{if(trophies.dropBeside(attacker,trophy))return;}
 catch(error){console.warn('[SkyGen Trophy] Drop deferred: '+error);}
 trophyInbox.add(id,trophy);
 if(attacker?.isValid)attacker.sendMessage('§6'+victim+'\'s head is waiting in Compass → Claim Box.');
}});

function disablePhantomInsomnia(){
 try{
  if(world.gameRules.doInsomnia!==false)world.gameRules.doInsomnia=false;
  if(world.gameRules.doInsomnia!==false)throw Error('doInsomnia did not update');
 }catch(error){console.warn('[SkyGen] Could not disable natural phantom spawning: '+error);}
}
world.afterEvents.worldLoad.subscribe(disablePhantomInsomnia);
world.afterEvents.gameRuleChange.subscribe(({rule,value})=>{
 if(rule===GameRule.DoInsomnia&&value===true)disablePhantomInsomnia();
});
function claimBoxAction(p,act,open=claimBoxMenu){
 try{p.sendMessage(act());}
 catch(error){p.sendMessage('§cClaim unavailable: '+error.message);}
 menuAgain(p,()=>open(p));
}
function claimBoxBankPayouts(p){
 navForm(p,'§6PENDING BANK PAYOUTS','Collect pending Marketplace proceeds, rank Credits and milestone Orbits through the Bank.',[
  ['Collect Pending Payouts',viewer=>{
   try{collectBankPayouts(viewer);}
   catch(error){viewer.sendMessage('§cPayout unavailable: '+error.message);}
   menuAgain(viewer,()=>claimBoxBankPayouts(viewer));
  }],
  ['Open Bank',bankMenu]
 ],claimBoxMenu);
}
function claimBoxMenu(p){
 try{
  const data=profile(p),{skyspire,rush,heads,king,total}=claimBoxCounts(p,data);
  const rows=[];
  if(skyspire.kits)rows.push(['Claim Skyspire Kit · '+skyspire.kits,viewer=>claimBoxAction(viewer,()=>
   deliverClaimBoxItems(viewer,'kit')?'§aClaimed '+SKYSPIRE_KIT_LABEL+'.':'§eThe kit is still waiting. Make room for both rewards and try again.')]);
  if(skyspire.pending)rows.push(['Claim Earlier Skyspire Credits · '+skyspire.pending,viewer=>claimBoxAction(viewer,()=>claimLegacySkyspireCredits(viewer))]);
  if(rush)rows.push(['Claim Generator Rush Prize · '+rush,viewer=>claimBoxAction(viewer,()=>claimPendingRushReward(viewer))]);
  if(king)rows.push(['Claim King of the Hill Prize · '+king,viewer=>claimBoxAction(viewer,()=>claimPendingKingReward(viewer))]);
  if(heads)rows.push(['Claim Trophy Heads · '+heads,viewer=>claimTrophyPage(viewer,0)]);
  const questCount=rewardQuestStatus(p,data).ready.length;
  rows.push(['Bank → Pending Payouts',claimBoxBankPayouts],
   [questCount?'Quests → Completed Rewards · '+questCount:'Quests → Completed Rewards',viewer=>dailyQuests(viewer,claimBoxMenu)]);
  navForm(p,'§6CLAIM BOX',total?'Prizes waiting: '+total:'No prizes waiting.',rows,menu);
 }catch(error){p.sendMessage('§cClaim Box unavailable: '+error.message);}
}
function claimTrophyPage(p,requested){
 try{
  const size=8,count=trophyInbox.count(p.id);
  if(!count)return claimBoxMenu(p);
  const last=Math.ceil(count/size)-1,page=Math.min(requested,last);
  const rows=trophyInbox.list(p.id,page*size,size).map(({id,victim})=>[victim+'\'s Head',viewer=>
   claimBoxAction(viewer,()=>deliverClaimBoxItems(viewer,'trophy',id)?'§aTrophy claimed.':'§eMake room in your inventory to claim this trophy.',player=>claimTrophyPage(player,page))]);
  if(page>0)rows.push(['Previous Page',viewer=>claimTrophyPage(viewer,page-1)]);
  if(page<last)rows.push(['Next Page',viewer=>claimTrophyPage(viewer,page+1)]);
  navForm(p,'§6CLAIM TROPHY HEADS',`Page ${page+1} / ${last+1}`,rows,claimBoxMenu);
 }catch(error){p.sendMessage('§cTrophy claims unavailable: '+error.message);}
}
function skyMenuBankWallet(p){
 const d=profile(p);
 navForm(p,'§eBANK & WALLET',`Credits: ${d.credits.toLocaleString()}\nOrbits: ${d.orbits.toLocaleString()}\n1 Orbit = ${C.exchange.toLocaleString()} Credits`,
  [['View Bank / Accounts / Transfers',bankMenu],['Exchange Credits for Orbits',wallet],['Collect Pending Rank Rewards',p=>{
   try{collectBankPayouts(p)}catch(err){p.sendMessage('§cPending rewards require review: '+String(err).slice(0,90))}
   menuAgain(p,()=>skyMenuBankWallet(p));
  }]],menu);
}
function skyMenuProfileCosmetics(p){
 let badges='';
 try{const c=validateCosmetics(profile(p));badges=Object.entries(COSMETIC_BADGES).map(([id,v])=>
  v.name+' · '+(c.equipped.includes(id)?'On':c.owned.includes(id)?'Off':'Locked')).join('\n');}
 catch{badges='Cosmetics require review.'}
 navForm(p,'§bPROFILE & COSMETICS',badges,
  [['My Cosmetics · Emblem Perks',myCosmetics],['Personal Sidebar · Show / Hide',sidebarMenu],['View My Rank',ranks]],menu);
}
function skyMenuHelpRulebook(p){
 navForm(p,'§bHELP & RULEBOOK','Guides, rules, and operator-only commands where permitted.',
  [['Getting Started / Help & Commands',helpMenu],['Player Rulebook',rulebookMenu]],menu);
}
function skyMenuShops(p){
 navForm(p,'§6SHOPS & TRADING','Choose a shop or player-commerce feature. Purchases retain balance and ownership checks.',
  [['Pro Shop · Premium & Cosmetics',proShop],['Server Shop',shop],['Food Shop',foodShop],
   ['Farming Shop',farmingShop],['Deathnerite Shop',deathneriteShop],
   ['Player Marketplace',market],['Player Trading',trade]],menu);
}
function firstGeneratorMineLabel(id){
 const names={'minecraft:oak_log':'Oak Logs','minecraft:dirt':'Dirt','minecraft:cobblestone':'Cobblestone','minecraft:coal':'Coal'};
 return names[id]??id;
}
function markFirstGenerator(d,action,details){
 const previous=firstGeneratorState(d).stage,next=firstGeneratorProgress(d,action,details);
 if(!next)return undefined;
 d.firstGeneratorGuide=next;
 return next.stage!==previous?next.stage:undefined;
}
function announceFirstGenerator(p,stage){
 const next={
  sell:'Mine step complete. Pick up your drops, then sell one of the materials you mined at the Server Shop.',
  buy:'Sale recorded. Open First Generator in your compass to buy a generator token.',
  place:'Token purchased. Use your Plot Horn, then use the token while aiming at a plot floor block.',
  harvest:'Generator placed. Mine the output block directly above its core.',
  complete:'Tutorial complete. Open Compass → Generators → My Generators / Upgrade.'
 }[stage];
 if(next)p.sendMessage('§aFirst Generator: §r'+next);
}
function recordFirstGeneratorPurchase(p,price){
 try{
  const d=profile(p),stage=markFirstGenerator(d,'purchase',{price});
  if(!stage)return;
  save(p,d);announceFirstGenerator(p,stage);
 }catch(error){console.warn('[SkyGen First Generator] Purchase guide progress: '+error)}
}
function trackedFirstGenerator(p,state){
 const generator=generators.get(state.generator);
 return generator?.owner===p.id&&firstGeneratorPlacementMatches(state,state.generator,generator.firstGeneratorToken)?generator:undefined;
}
function recordFirstGeneratorPlacement(d,p,action,generator,key){
 if(!generator.firstGeneratorToken||generator.owner!==p.id)return undefined;
 const state=firstGeneratorState(d);
 return markFirstGenerator(d,action,{
  generator:key,token:generator.firstGeneratorToken,
  replace:state.stage==='harvest'&&!trackedFirstGenerator(p,state)
 });
}
function firstGeneratorMenu(p){
 const d=profile(p);
 let state=firstGeneratorState(d);
 if(state.stage==='complete')return menu(p);
 // A committed registry entry can survive a disconnect during the guide's profile write.
 if(generatorRegistryLoaded&&['buy','place','harvest'].includes(state.stage)&&!trackedFirstGenerator(p,state)){
  const placed=[...generators].find(([,g])=>g.owner===p.id&&g.firstGeneratorToken);
  if(placed&&recordFirstGeneratorPlacement(d,p,'placement',placed[1],placed[0])){
   save(p,d);state=firstGeneratorState(d);
  }
 }
 const starter=GEN_BY_NAME.get('Cobblestone');
 const cost=discountedPrice(starter.cost,perkValue(d,'generatorPrice'));
 const steps={
  start:()=>['Mine at the public starter mine, sell the haul, then buy, place and use a generator on your plot.',[
   ['Start Tutorial',viewer=>{
    const current=profile(viewer);
    if(markFirstGenerator(current,'start'))save(viewer,current);
    firstGeneratorMenu(viewer);
   }]
  ]],
  mine:()=>['§e1 / 5 · Mine at the Rank Hall§r\n'+
   (publicStarterEnabled()
    ?'From the Citadel, cross the southeast bridge to the public mine (65, 2, 63). Break and collect an oak log or dirt by hand, or use a pickaxe for cobblestone or coal. Use the Spawn Horn if you need to return to the Citadel.'
    :'The public mine opens when the city build is complete. You can reopen this guide from your compass.'),[]],
  sell:()=>['§e2 / 5 · Sell your haul§r\nSell at least one of these materials at the Server Shop: '+state.items.map(firstGeneratorMineLabel).join(', ')+'. You can return to the public mine for more.',[
   ['Open Server Shop Sell Menu',viewer=>shopCatalog(viewer,false)]
  ]],
  buy:()=>['§e3 / 5 · Buy a generator token§r\nA Cobblestone Generator costs '+cost.toLocaleString('en-US')+' Credits at your current shop price. Buy it or another generator you have unlocked.',[
   ['Open Starter Generators',viewer=>buyGen(viewer,'Starter')]
  ]],
  place:()=>['§e4 / 5 · Place your generator§r\nUse the Plot Horn to go to your own plot. Hold your purchased token, aim at a floor block with two open spaces above it, and use the token.',[
   ['Open Starter Generators',viewer=>buyGen(viewer,'Starter')]
  ]],
  harvest:()=>{
   const g=trackedFirstGenerator(p,state);
   if(!g)return ['§e5 / 5 · Mine your generator§r\nYour tutorial generator is missing. Place another token purchased during the tutorial on your own plot.',[
    ['Open Starter Generators',viewer=>buyGen(viewer,'Starter')]
   ]];
   return ['§e5 / 5 · Mine your generator§r\nBreak the output above your '+g.type+' core at '+g.x+', '+(g.y+1)+', '+g.z+
    '. Use the right tool for that block. If the output is empty, wait for it to refill.',[]];
  },
  unavailable:()=>['Tutorial progress could not be read. Contact a Realm operator.',[]]
 };
 const [body,entries]=steps[state.stage]();
 navForm(p,'§aFIRST GENERATOR',body,entries,menu);
}
const nexusBeacon = createNexusBeaconStore(world);
function nexusBeaconReady(){return world.getDynamicProperty(NEXUS_BEACON_READY_KEY)===true}
function updateBeaconDisplay(){
 if(!nexusBeaconReady())return;
 try{refreshNexusBeaconDisplay(nexusBeacon.current())}
 catch(error){console.warn('[Nexus Beacon] Display refresh: '+error)}
}
system.runInterval(updateBeaconDisplay,40);

function beaconStationAllows(p,item){
 const station=nearbyBeaconStation(p);
 const category=Object.hasOwn(NEXUS_BEACON_ITEMS,item)?NEXUS_BEACON_ITEMS[item].category:undefined;
 return station?.id==='garden'?category==='Fishing':station?.id==='citadel'&&(category==='Mining'||category==='Farming');
}
function donateNexusBeacon(p,quote){
 if(!p.isValid||!nexusBeaconReady()||!beaconStationAllows(p,quote.item)){
  p.sendMessage('§cReturn to the correct Beacon turn-in to donate.');return false;
 }
 const mode=p.getGameMode();
 if((mode!==GameMode.Survival&&mode!==GameMode.Adventure)||creativeEconomyBlocked(p)){
  p.sendMessage('§cBeacon donations require eligible Survival items.');return false;
 }
 const live=beaconQuote(nexusBeacon.current(),quote.item,quote.count);
 if(!sameBeaconQuote(quote,live)){
  p.sendMessage('§eBeacon progress changed. Open a new donation quote.');return false;
 }
 const slots=planInventoryDebit(inventory(p),live.count,item=>eligibleShopItem(item,live.item));
 if(!slots){
  p.sendMessage('§cThose donation items are no longer in your inventory.');return false;
 }
 let result;
 const committed=commitInventoryDebit(p,slots,'beacon',{
  week:live.week,item:live.item,count:live.count,points:live.points
 },(_profile,tx)=>{result=nexusBeacon.contribute(live,p.id,p.name,tx.id)},
 tx=>nexusBeacon.hasReceipt(tx.week,p.id,tx.id));
 if(!committed)return false;
 p.sendMessage('§aDonated '+live.count+' × '+NEXUS_BEACON_ITEMS[live.item].label+' for '+live.points+' Beacon points.');
 if(result.completed)world.sendMessage('§6The Realm restored the Nexus Beacon! Visit the Citadel plaque to see the contributors.');
 updateBeaconDisplay();
 return true;
}
function beaconDonationAmounts(p,id){
 const state=nexusBeacon.current(),entry=NEXUS_BEACON_ITEMS[id];
 const count=Math.min(countShopInventory(p,id),Math.ceil((NEXUS_BEACON_GOAL-state.total)/entry.points));
 if(count<1||!beaconStationAllows(p,id))return nexusBeaconMenu(p);
 const quotes=[...new Set([1,Math.min(8,count),count])].map(amount=>beaconQuote(state,id,amount));
 navForm(p,'§6BEACON DONATION',entry.label+' · '+entry.points+' point(s) each',
  quotes.map(quote=>[
   'Donate '+quote.count+' · +'+quote.points+' points',viewer=>{
    const confirm=skyMessage().title('Confirm Beacon Donation')
     .body('Turn in '+quote.count+' × '+entry.label+' for '+quote.points+' points toward the Realm goal?')
     .button1('Back').button2('Donate');
    showUI(viewer,confirm).then(answer=>{
     if(answer.canceled)return;
     if(answer.selection===1)donateNexusBeacon(viewer,quote);
     menuAgain(viewer,()=>nexusBeaconMenu(viewer));
    }).catch(error=>viewer.sendMessage('§cBeacon donation could not be completed: '+error));
   }
  ]),nexusBeaconMenu);
}
function beaconContributors(p,page=0){
 const state=nexusBeacon.current(),size=8;
 const names=new Map(playerRoster.records().map(row=>[row.id,row.name]));
 const namesAndPoints=state.contributors.map(([id,name,points])=>[names.get(id)??name,points])
  .sort(([first],[second])=>first.localeCompare(second));
 const pages=Math.max(1,Math.ceil(namesAndPoints.length/size)),current=Math.max(0,Math.min(page,pages-1));
 const list=namesAndPoints.slice(current*size,current*size+size).map(([name,points])=>name+' · '+points+' points');
 const entries=[];
 if(current>0)entries.push(['Previous Page',viewer=>beaconContributors(viewer,current-1)]);
 if(current+1<pages)entries.push(['Next Page',viewer=>beaconContributors(viewer,current+1)]);
 navForm(p,'§6BEACON CONTRIBUTORS',list.length?list.join('\n'):'No donations yet this week.',entries,nexusBeaconMenu);
}
function nexusBeaconMenu(p){
 if(!nexusBeaconReady()){
  return navForm(p,'§6NEXUS BEACON','The Beacon opens when the new city build finishes.',[],menu);
 }
 const state=nexusBeacon.current(),complete=state.total>=NEXUS_BEACON_GOAL;
 const station=nearbyBeaconStation(p);
 const status=complete?'§aRestored for this week.§r':state.total+' / '+NEXUS_BEACON_GOAL+' Realm points';
 const detail=station?.id==='garden'?'Donate raw fish here.':station?.id==='citadel'?
  'Donate Cobblestone or Coal (1 point each), or Wheat, Carrots or Potatoes (2 each).':
  'Mining and crops: Citadel plaque at 9, 1, 7. Raw fish (5 each): Garden pond at -58, 1, 63.';
 const entries=[];
 if(!complete){
  for(const [id,entry] of Object.entries(NEXUS_BEACON_ITEMS)){
   if(beaconStationAllows(p,id)&&countShopInventory(p,id)>0){
    entries.push(['Donate '+entry.label,viewer=>beaconDonationAmounts(viewer,id)]);
   }
  }
 }
 entries.push(['View Contributor Plaque',beaconContributors]);
 navForm(p,'§6NEXUS BEACON',status+'\n'+detail+'\nResets Monday at midnight Central.',entries,menu);
}
const marketOrdersStation=DISTRICT_STATIONS.find(station=>station.id==='market');
function districtOrdersReady(){return world.getDynamicProperty(DISTRICT_ORDERS_READY_KEY)===true}
function destinationCredits(d,id){
 return id==='wallet'?d.credits:d.bank?.accounts?.find(account=>account.id===id)?.credits;
}
function settleDistrictOrderBeacon(p,tx){
 return tx.beacon?nexusBeacon.applyOrderItems(tx.week,tx.item,tx.count,p.id,p.name,tx.id):undefined;
}
function fillDistrictOrder(p,quote){
 if(!p.isValid||!districtOrdersReady()||!isNearDistrictStation(p,marketOrdersStation)){
  p.sendMessage('§cVisit the Market order board at 8, 1, -54 to fill an order.');return false;
 }
 const mode=p.getGameMode();
 if((mode!==GameMode.Survival&&mode!==GameMode.Adventure)||creativeEconomyBlocked(p)){
  p.sendMessage('§cDistrict Orders require eligible Survival items.');return false;
 }
 const d=profile(p),live=districtOrderQuote(d,quote.orderId,quote.count);
 if(!sameDistrictOrderQuote(quote,live)){
  p.sendMessage('§eYour order quote expired. Open the Market board again.');return false;
 }
 const slots=planInventoryDebit(inventory(p),live.count,item=>eligibleShopItem(item,live.item));
 if(!slots){p.sendMessage('§cThose order items are no longer in your inventory.');return false}
 const destination=payoutDestination(d,live.credits);
 if(destination===undefined){p.sendMessage('§cOrder could not be paid. '+noPayoutRoom(d,live.credits));return false}
 let beaconResult,beaconPoints=0;
 const committed=commitInventoryDebit(p,slots,'district_order',{
  ...live,total:live.credits,destination,destinationBefore:destinationCredits(d,destination),
 },(latest,tx)=>{
  if(latest.credits!==tx.before||destinationCredits(latest,tx.destination)!==tx.destinationBefore)
   throw Error('Credit destination changed');
  recordDistrictOrder(latest,live);
  creditPayout(latest,destination,live.credits);
  latest.sg_last_econ_txn=tx.id;
  save(p,latest);
  const before=tx.beacon?nexusBeacon.current():undefined;
  beaconResult=settleDistrictOrderBeacon(p,tx);
  if(beaconResult&&before?.week===beaconResult.state.week)beaconPoints=beaconResult.state.total-before.total;
 });
 if(!committed)return false;
 p.sendMessage('§aOrder filled: '+live.credits.toLocaleString('en-US')+' Credits to '+destinationName(d,destination)+
  (beaconPoints>0?' and '+beaconPoints+' Beacon points.':'.'));
 if(beaconResult?.completed&&nexusBeacon.current().week===live.week)
  world.sendMessage('§6The Realm restored the Nexus Beacon! Visit the Citadel plaque to see the contributors.');
 if(beaconResult)updateBeaconDisplay();
 return true;
}
function districtOrderDetails(p,orderId){
 const now=Date.now(),week=centralWeekStart(now),d=profile(p);
 const order=districtOrdersForWeek(week).find(entry=>entry.id===orderId);
 if(!order)return districtOrdersMenu(p);
 const used=districtOrderUsage(d,week)[order.id]??0,remaining=order.limit-used;
 const held=countShopInventory(p,order.item),max=Math.min(held,remaining);
 const atBoard=isNearDistrictStation(p,marketOrdersStation);
 const beaconState=order.beacon?nexusBeacon.current(now):undefined;
 const beaconLine=!beaconState?'':beaconState.total>=NEXUS_BEACON_GOAL?'\nNexus Beacon is restored for this week.':
  '\nThis order also helps restore the Nexus Beacon.';
 const entries=[];
 if(atBoard&&max>0)for(const count of new Set([1,Math.min(8,max),max])){
  const quote=districtOrderQuote(d,orderId,count,now);
  if(!quote)continue;
  const forecast=beaconState&&beaconQuoteForOrder(beaconState,order.item,count);
  entries.push(['Turn in '+count+' · '+quote.credits+' Credits',viewer=>{
   const confirm=skyMessage().title('Confirm District Order')
    .body(count+' × '+order.label+' for '+quote.credits+' Credits.'+
     (forecast?' Up to '+forecast.points+' Beacon points.':'')).button1('Back').button2('Confirm');
   showUI(viewer,confirm).then(answer=>{
    if(answer.canceled)return;
    if(answer.selection===1)fillDistrictOrder(viewer,quote);
    menuAgain(viewer,()=>districtOrdersMenu(viewer));
   }).catch(error=>viewer.sendMessage('§cDistrict Order could not be completed: '+error));
  }]);
 }
 navForm(p,'§6'+order.label+' ORDER',order.credits+' Credits each · '+remaining+'/'+order.limit+
  ' left for you this week.\nEligible inventory: '+held+'.'+beaconLine+
  (atBoard?'':'\nTurn in items at the Market board, 8, 1, -54.'),entries,districtOrdersMenu);
}
function districtOrdersMenu(p){
 if(!districtOrdersReady())return navForm(p,'§6DISTRICT ORDERS','The Market order board opens after the city finishes building.',[],menu);
 const week=centralWeekStart(),usage=districtOrderUsage(profile(p),week);
 navForm(p,'§6DISTRICT ORDERS','Market · 8, 1, -54\nEach player has their own limit. Orders rotate Monday at midnight Central.',
  districtOrdersForWeek(week).map(entry=>[
   entry.category+' · '+entry.label+' · '+entry.credits+' Cr each · '+(entry.limit-(usage[entry.id]??0))+' left'+(entry.beacon?' · Beacon':''),
   viewer=>districtOrderDetails(viewer,entry.id)
  ]),menu);
}
const hallEntrance=COLLECTION_HALL_STATIONS[0];
const hallDirections='Guild Hall · '+[hallEntrance.x,hallEntrance.y,hallEntrance.z].join(', ');
function collectionHallReady(){return world.getDynamicProperty(COLLECTION_HALL_READY_KEY)===true}
function atCollectionHall(p){return COLLECTION_HALL_STATIONS.some(station=>isNearDistrictStation(p,station))}
function collectionActivityAllowed(p){
 return collectionHallReady()&&p.getGameMode()===GameMode.Survival&&
  !generatorRush.occupied(p)&&!creativeEconomyBlocked(p);
}
function awardCollectionItem(p,collectionId,subject){
 if(!collectionActivityAllowed(p))return;
 const row=rollCollectionItem(collectionId,subject);
 if(!row)return;
 try{
  const item=new ItemStack(row.item,1),inv=inventory(p);
  const remaining=inv?inv.addItem(item):item;
  if(remaining)p.dimension.spawnItem(remaining,p.location);
  p.sendMessage('§dCollection item found · '+row.label);
 }catch(error){console.warn('[Collection Hall] Could not deliver '+row.item+': '+error)}
}
function donateCollectionItems(p,quote){
 if(!p.isValid)return false;
 if(!collectionHallReady()||!atCollectionHall(p)){
  p.sendMessage('§cVisit the Collection Hall to donate. '+hallDirections);return false;
 }
 const mode=p.getGameMode();
 if((mode!==GameMode.Survival&&mode!==GameMode.Adventure)||generatorRush.occupied(p)||creativeEconomyBlocked(p)){
  p.sendMessage('§cThe Collection Hall accepts eligible Survival items.');return false;
 }
 const live=collectionQuote(profile(p),quote.collectionId,quote.item,quote.count);
 if(!sameCollectionQuote(quote,live)){
  p.sendMessage('§eYour donation quote expired. Open the collection again.');return false;
 }
 const slots=planInventoryDebit(inventory(p),live.count,item=>eligibleShopItem(item,live.item));
 if(!slots){p.sendMessage('§cThose items are no longer in your inventory.');return false}
 let result;
 const committed=commitInventoryDebit(p,slots,'collection',live,(latest,tx)=>{
  result=recordCollectionDonation(latest,live);
  latest.sg_last_econ_txn=tx.id;
  save(p,latest);
 });
 if(!committed)return false;
 const badgeName=COSMETIC_BADGES[result.badge].name;
 p.sendMessage(result.newBadge?'§aCollection complete! You earned '+badgeName+'. Equip it in My Cosmetics.':
  result.completing?'§aCollection complete! Your '+badgeName+' is already owned.':'§aDonation saved.');
 return true;
}
function collectionHallMenu(p){
 if(!collectionHallReady())return navForm(p,'§6COLLECTION HALL','The Collection Hall opens when the city finishes building.',[],menu);
 const d=profile(p);
 const entries=COLLECTIONS.map(collection=>{
  const progress=collectionProgress(d,collection.id);
  return [collection.title+' · '+(progress.complete?'Complete':progress.completedTypes+' / '+progress.rows.length+' types'),
   viewer=>collectionDetails(viewer,collection.id)];
 });
 entries.push(['Garden Fishing Blueprint',gardenBlueprintMenu]);
 navForm(p,'§6COLLECTION HALL',hallDirections+'\nEarn or buy five item types for each badge. Each full collection costs 20,000,000 Credits at its listed prices.',entries,menu);
}
function gardenBlueprintMenu(p){
 const d=profile(p),state=blueprintState(d);
 const status=!hasFinishedSkyFeast(d)?'Complete Sky Feast Pantry to start tracking your catches.':
  state.delivered?'Coal Generator claimed. Use its token on your plot.':
  state.caught===GARDEN_FISH_GOAL?'Blueprint ready. Claim one Coal Generator token.':
  state.caught+' / '+GARDEN_FISH_GOAL+' Garden fish caught.';
 const choices=state.caught===GARDEN_FISH_GOAL&&!state.delivered?[['Claim Coal Generator',viewer=>{
  try{claimGardenBlueprint(viewer)}catch(error){
   viewer.sendMessage('§cBlueprint claim could not finish. Reopen this menu to check the saved claim.');
   console.warn('[Garden blueprint] '+error);
  }
  menuAgain(viewer,()=>gardenBlueprintMenu(viewer));
 }]]:[];
 navForm(p,'Garden Fishing Blueprint',status+'\nCatch any 12 fish yourself with a rod at the Garden pond, near -65, 1, 63.\nOne Coal Generator per player.',choices,collectionHallMenu);
}
function fishingRewardsAllowed(p){
 return [GameMode.Survival,GameMode.Adventure].includes(p.getGameMode())&&!creativeEconomyBlocked(p)&&!generatorRush.occupied(p);
}
registerFishingCatches({world,system,eligible:(p,garden)=>{
 if(!fishingRewardsAllowed(p))return false;
 const d=profile(p);
 return emblemEnabled(d,'sky_feast_crest')||(garden&&collectionHallReady()&&
  (p.getGameMode()===GameMode.Survival||blueprintState(d).caught<GARDEN_FISH_GOAL&&hasFinishedSkyFeast(d)));
},award:(p,fish,garden)=>{
 if(!fishingRewardsAllowed(p))return;
 const d=profile(p);
 if(emblemEnabled(d,'sky_feast_crest')&&Math.random()*100<FEAST_BONUS_FISH_CHANCE){
  try{
   const item=new ItemStack(fish,1),inv=inventory(p);
   const extra=inv?inv.addItem(item):item;
   if(extra)p.dimension.spawnItem(extra,p.location);
   p.sendMessage('§aSky Feast Crest · Extra fish caught.');
  }catch(err){console.warn('[SkyGen fishing] Extra fish delivery: '+err)}
 }
 if(garden&&collectionHallReady()){
  awardCollectionItem(p,'feast',fish);
  if(!recordGardenFish(d))return;
  save(p,d);
  const count=blueprintState(d).caught;
  p.sendMessage(count===GARDEN_FISH_GOAL?'§aGarden blueprint earned! Claim your Coal Generator in Compass → Collection Hall.':
   '§aGarden blueprint · '+count+' / '+GARDEN_FISH_GOAL+' fish caught.');
 }
}});
function collectionDetails(p,collectionId){
 if(!collectionHallReady())return collectionHallMenu(p);
 const d=profile(p),progress=collectionProgress(d,collectionId);
 const badgeName=COSMETIC_BADGES[progress.badge].name;
 const owned=validateCosmetics(d).owned.includes(progress.badge);
 const status=progress.complete?'Collection complete. Equip your badge in My Cosmetics.':
  owned?'Badge owned. You can still complete this display.':'Badge reward · '+badgeName;
 const location=atCollectionHall(p)?'Select an item to donate.':'Visit the Guild Hall to donate. '+hallDirections;
 const entries=progress.rows.map(row=>[row.label+' · '+row.donated+' / '+row.needed,
  viewer=>collectionItemMenu(viewer,collectionId,row.item)]);
 const cost=progress.remainingValue.toLocaleString()+' Credits for the remaining items';
 navForm(p,'§6'+progress.title,status+(progress.complete?'':'\n'+cost+' at listed prices.\n'+location),entries,collectionHallMenu);
}
function buyCollectionItem(p,collectionId,item,count){
 if(!p.isValid||!collectionHallReady()||!atCollectionHall(p)||generatorRush.occupied(p)||creativeEconomyBlocked(p)||
    ![GameMode.Survival,GameMode.Adventure].includes(p.getGameMode()))return false;
 const row=collectionProgress(profile(p),collectionId)?.rows.find(entry=>entry.item===item);
 if(!row||!Number.isSafeInteger(count)||count<1||count>row.needed-row.donated-countShopInventory(p,item)){
  p.sendMessage('§eThe number of items you need has changed. Open the collection again.');return false;
 }
 if(buyShopItems(p,[{id:item,count}],row.unitPrice*count)){
  p.sendMessage('§aPurchased '+count+' × '+row.label+'. Donate them at the Collection Hall.');
  return true;
 }
 return false;
}
function collectionItemMenu(p,collectionId,item){
 if(!collectionHallReady())return collectionHallMenu(p);
 const d=profile(p),row=collectionProgress(d,collectionId).rows.find(entry=>entry.item===item);
 const held=countShopInventory(p,item),remaining=row.needed-row.donated;
 const atHall=atCollectionHall(p),max=Math.min(held,remaining);
 const entries=[];
 if(atHall&&max>0)for(const count of new Set([1,max])){
  const quote=collectionQuote(d,collectionId,item,count);
  entries.push(['Donate '+count,viewer=>{
   const confirm=skyMessage().title('Confirm Collection Donation')
    .body('Donate '+count+' × '+row.label+'? Donated items are consumed.').button1('Back').button2('Donate');
   showUI(viewer,confirm).then(answer=>{
    if(answer.canceled)return;
    if(answer.selection===1&&donateCollectionItems(viewer,quote))menuAgain(viewer,()=>collectionDetails(viewer,collectionId));
    else menuAgain(viewer,()=>collectionItemMenu(viewer,collectionId,item));
   }).catch(error=>viewer.sendMessage('§cDonation could not be completed: '+error));
  }]);
 }
 const toBuy=remaining-held;
 if(atHall&&toBuy>0)for(const count of new Set([1,toBuy])){
  const price=(row.unitPrice*count).toLocaleString();
  entries.push(['Buy '+count+' · '+price+' Credits',viewer=>{
   const confirm=skyMessage().title('Buy Collection Item')
    .body('Buy '+count+' × '+row.label+' for '+price+' Credits?').button1('Back').button2('Buy');
   showUI(viewer,confirm).then(answer=>{
    if(answer.canceled)return;
    if(answer.selection===1)buyCollectionItem(viewer,collectionId,item,count);
    menuAgain(viewer,()=>collectionItemMenu(viewer,collectionId,item));
   }).catch(error=>viewer.sendMessage('§cCollection purchase could not be completed: '+error));
  }]);
 }
 navForm(p,'§6'+row.label,row.donated+' / '+row.needed+' donated · '+held+' eligible in inventory\n'+row.source+
  '\nCollection Hall price · '+row.unitPrice.toLocaleString()+' Credits each.'+
  (atHall||!remaining?'':'\nDonate at the Collection Hall. '+hallDirections),entries,viewer=>collectionDetails(viewer,collectionId));
}
function buyDistrictShopOffer(p,catalog,id,count,quoted){
 if(!districtOrdersReady())return false;
 const price=districtShopPrice(catalog,id,count);
 if(price===undefined||price!==quoted||!ItemTypes.get(id)){
  p.sendMessage('§cThe shop quote changed. Open the catalog again.');return false;
 }
 return buyShopItems(p,[{id,count}],price);
}
function rushReady(){return world.getDynamicProperty(RUSH_READY_KEY)===true}
function rushScoreboard(){return world.scoreboard.getObjective(RUSH_OBJECTIVE)??world.scoreboard.addObjective(RUSH_OBJECTIVE,'Generator Rush Wins')}
function claimPendingRushReward(p){
 recoverEconomicTxn(p);assertBankUnlocked(p);
 const d=profile(p),state=rushStats(d);
 if(!state.pending)return '§eNo Generator Rush reward is pending.';
 const destination=payoutDestination(d,RUSH_WIN_CREDITS);
 if(destination===undefined)return '§e750 Credits are pending. '+noPayoutRoom(d,RUSH_WIN_CREDITS);
 creditPayout(d,destination,RUSH_WIN_CREDITS);
 d.generatorRush={...state,pending:state.pending-RUSH_WIN_CREDITS};
 save(p,d);
 return '§aGenerator Rush · 750 Credits to '+destinationName(d,destination)+'.';
}
function settleRushWin(p,id){
 const d=profile(p),reward=recordRushWin(d,id);
 if(reward===undefined)return '§aThis win is already recorded.';
 save(p,d);
 try{rushScoreboard().setScore(p,Math.min(2147483647,rushStats(d).wins))}
 catch(error){console.warn('[Generator Rush] Score mirror: '+error)}
 if(!reward)return '§aWin recorded. This week’s three Credit prizes are earned.';
 try{return claimPendingRushReward(p)}catch(error){
  console.warn('[Generator Rush] Prize is pending: '+error);
  return '§eWin recorded. Your 750 Credits are pending in the Generator Rush menu.';
 }
}
function rushTravel(p,target,yaw){
 forcefieldTickets.set(p.id,{...target,expires:system.currentTick+8});
 const options={dimension:world.getDimension('overworld'),checkForBlocks:true};
 if(yaw!==undefined)options.rotation={x:0,y:yaw};
 if(!p.tryTeleport(target,options)){
  forcefieldTickets.delete(p.id);return false;
 }
 cooldowns.set(p.id,system.currentTick+teleportCooldown(p));
 return true;
}
const queueMovement=createQueueMovement({world,system});
const generatorRush=createGeneratorRush({world,system,queueMovement,ready:rushReady,
 catalog:GENS.map(g=>({name:g.name,core:GENERATOR_CORE_BY_NAME.get(g.name),output:g.block})),
 canPlay:p=>isNearDistrictStation(p,RUSH_STATION)&&[GameMode.Survival,GameMode.Adventure].includes(p.getGameMode())&&
  !remoteGames.involved(p)&&!creativeEconomyBlocked(p)&&!pending.has(p.id)&&!spawnStages.has(p.id)&&
  system.currentTick>=(cooldowns.get(p.id)??0),
 isMenuItem:item=>toolmatch(item,TOOLS[0]),safeReturn:safeStandingLocation,travel:rushTravel,rescueSpawn:(p,onArrival)=>safeSpawnTravel(p,true,onArrival),onWin:settleRushWin,
 onLabel:(dimension,label)=>updateDistrictText(dimension,label,DISTRICT_DISPLAY_TAG,'§f'+label.label),
 onStatus:(p,match,slot)=>{
  if(match.phase==='countdown')return p.onScreenDisplay.setActionBar('§eRush starts in '+Math.max(1,Math.ceil((match.starts-system.currentTick)/20))+'s');
  const {products,orders}=match.contract;
  const harvest=slot.harvestNotice;
  if(harvest&&system.currentTick<harvest.until){
   return p.onScreenDisplay.setActionBar('§a+1 '+products[harvest.index].name+' §f· '+slot.stock[harvest.index]+' in Rush stock');
  }
  const order=orders[slot.order];
  const progress=order.need.flatMap((need,index)=>need?[products[index].name+' '+Math.min(need,slot.stock[index])+'/'+need]:[]).join(' · ');
  p.onScreenDisplay.setActionBar('§6'+Math.ceil((match.ends-system.currentTick)/20)+'s §f'+order.name+' · '+progress);
 }});
function rushLeaderboard(p,page=0){
 const rows=rankRoster(playerRoster.records(),'rush',new Map());
 const last=Math.max(0,Math.ceil(rows.length/8)-1),index=Math.max(0,Math.min(last,page));
 const entries=[];
 if(index>0)entries.push(['Previous Page',viewer=>rushLeaderboard(viewer,index-1)]);
 if(index<last)entries.push(['Next Page',viewer=>rushLeaderboard(viewer,index+1)]);
 const body=rows.slice(index*8,index*8+8).map((row,i)=>(index*8+i+1)+'. '+row.name+' · '+row.score+' wins').join('\n');
 navForm(p,'Generator Rush Wins',(body||'Waiting for the first player.')+'\nPage '+(index+1)+' / '+(last+1),entries,rushMenu);
}
function rushMenu(p){
 if(!rushReady())return navForm(p,'Generator Rush','The Colosseum opens when the city finishes building.',[],menu);
 const state=rushStats(profile(p)),inMatch=generatorRush.racing(p),queued=generatorRush.queued(p);
 const paid=state.week===centralWeekStart()?state.paid:0;
 const choices=[['Leaderboard · All Players',rushLeaderboard]];
 if(inMatch)choices.unshift(['Leave Match',viewer=>generatorRush.leave(viewer)]);
 else if(generatorRush.occupied(p))choices.unshift(['Return to Colosseum',viewer=>generatorRush.leave(viewer)]);
 else if(queued)choices.unshift(['Leave Queue',viewer=>generatorRush.leave(viewer)]);
 else choices.unshift(['Join 1v1 Queue',viewer=>generatorRush.join(viewer)]);
 if(state.pending)choices.push(['Claim Pending Prize',viewer=>{
  try{viewer.sendMessage(claimPendingRushReward(viewer))}catch(error){viewer.sendMessage('§eYour pending prize can be claimed after the economy is available.')}
  menuAgain(viewer,()=>rushMenu(viewer));
 }]);
 if(inMatch)return form(p,'Generator Rush','Mine generator outputs or use the note blocks below them. Harvests go to Rush stock for the order station.',choices.map(([name])=>name),i=>choices[i]?.[1](p));
 const stationCoordinates=[RUSH_STATION.x,RUSH_STATION.y,RUSH_STATION.z].join(', ');
 const seconds=generatorRush.queueTime();
 const queueStatus=seconds===undefined?'Two players open a '+MINIGAME_QUEUE_SECONDS+'-second queue window.':seconds+' seconds until the queue closes.';
 navForm(p,'Generator Rush','Colosseum · '+stationCoordinates+'\n1v1 · '+RUSH_MATCH_SECONDS/60+' minutes · First to fill three orders wins.\n'+
  queueStatus+'\nBoth racers get the same rotating generators and orders.\n'+
  'Wins '+state.wins+' · '+paid+'/'+RUSH_PAID_WINS+' weekly prizes earned · 750 Credits each.',choices,menu);
}

function arenaOverlapsLobby(spec,center,radius){
 const {origin,min,max}=spec;
 return center.x+radius>=origin.x+min&&center.x-radius<=origin.x+max&&
  center.z+radius>=origin.z+min&&center.z-radius<=origin.z+max;
}
const arenaBuilder=createArenaBuilder({world,system,cityReady:rushReady,
 locationAllowed:spec=>!arenaOverlapsLobby(spec,spawnPosition(),spawnLimit())&&!arenaOverlapsLobby(spec,C.spawn,spawnLimit())
});
const remoteGames=createRemoteMinigames({world,system,queueMovement,
 ready:arenaBuilder.ready,
 prepare:arenaBuilder.prepare,
 canJoin:p=>!generatorRush.occupied(p)&&!generatorRush.queued(p)&&!creativeEconomyBlocked(p)&&!tradeBusy(p)&&
  !pending.has(p.id)&&!spawnStages.has(p.id)&&!loginPending.has(p.id)&&!returnStages.has(p.id)&&
  system.currentTick>=(cooldowns.get(p.id)??0),
 isCompass:i=>toolmatch(i,TOOLS[0]),heldCompass:p=>toolmatch(inventory(p)?.getItem(p.selectedSlotIndex),TOOLS[0]),
 safeReturn:safeStandingLocation,travel:rushTravel,
 rescueSpawn:(p,onArrival)=>safeSpawnTravel(p,true,onArrival),
 openMenu:arenaMenu,onIdentity:p=>applyRankIdentity(p,profile(p).rank),onResult:settleArenaResult,
 canInspect:p=>isAdmin(p)&&!generatorRush.occupied(p)&&!generatorRush.queued(p)&&
  !pending.has(p.id)&&!spawnStages.has(p.id)&&!loginPending.has(p.id)&&!returnStages.has(p.id),
 canOpenInspection:holdingAdminAxe,
 isAdminAxe:adminAxe,openAdmin:adminMenu
});
function claimPendingKingReward(p){
 recoverEconomicTxn(p);assertBankUnlocked(p);
 const d=profile(p),state=kingStats(d);
 if(!state.pending)return '§eNo King of the Hill reward is pending.';
 const destination=payoutDestination(d,KING_CREDITS);
 if(destination===undefined)return '§e750 Credits are pending. '+noPayoutRoom(d,KING_CREDITS);
 creditPayout(d,destination,KING_CREDITS);
 d.kingOfTheHill={...state,pending:state.pending-KING_CREDITS};
 save(p,d);
 return '§aKing of the Hill · 750 Credits to '+destinationName(d,destination)+'.';
}
function mirrorArenaStats(p){
 const flag=flagStats(world,p.id);
 const values=[kingStats(profile(p)).wins,flag.wins,flag.captures];
 ARENA_BOARDS.forEach((board,index)=>{
  const objective=world.scoreboard.getObjective(board.objective);
  if(objective&&objective.getScore(p)!==Math.min(2147483647,values[index]))
   objective.setScore(p,Math.min(2147483647,values[index]));
 });
}
const flagResults=createFlagResultQueue({world,system,onSettled:(rows,notice)=>{
 const ids=new Set(rows.map(row=>row.id));
 for(const player of world.getAllPlayers()){
  if(!ids.has(player.id))continue;
  try{mirrorArenaStats(player)}
  catch(error){console.warn('[Capture the Flag] Scoreboard refresh: '+error)}
  if(notice)player.sendMessage('§aCapture the Flag result saved.');
 }
}});
function settleArenaResult(match,result){
 if(match.spec.id==='ctf'){
  const rows=match.slots.filter(slot=>slot.score||!slot.withdrawn).map(slot=>({
   id:slot.id,winner:!slot.withdrawn&&Boolean(result.team)&&slot.team===result.team,captures:slot.score
  }));
  return flagResults.submit(match.id,rows);
 }
 const p=result.winner?.player;
 if(!p?.isValid)return;
 const d=profile(p),reward=recordKingWin(d,match.id);
 if(reward===undefined)return;
 save(p,d);
 try{mirrorArenaStats(p)}catch(error){console.warn('[SkyGen Arenas] Score mirror: '+error);}
 if(!reward)return p.sendMessage('§aWin recorded. You earned this week’s three Credit prizes.');
 try{p.sendMessage(claimPendingKingReward(p))}
 catch(error){
  console.warn('[SkyGen Arenas] King Credits pending: '+error);
  p.sendMessage('§eWin recorded. Your 750 Credits are waiting in the Claim Box.');
 }
}
function arenaLeaderboard(p,board,page=0){
 const roster=playerRoster.records();
 const rows=rankRoster(roster,board.metric,arenaMetricScores(world,roster,board.metric));
 const last=Math.max(0,Math.ceil(rows.length/8)-1),index=Math.min(last,Math.max(0,page));
 const back=viewer=>arenaMenu(viewer,board.metric==='kingWins'?'koth':'ctf');
 const body=rows.slice(index*8,index*8+8).map((row,i)=>(index*8+i+1)+'. '+row.name+' · '+(row.score??'—')).join('\n');
 const entries=[];
 if(index>0)entries.push(['Previous Page',viewer=>arenaLeaderboard(viewer,board,index-1)]);
 if(index<last)entries.push(['Next Page',viewer=>arenaLeaderboard(viewer,board,index+1)]);
 navForm(p,board.title,(body||'Waiting for the first player.')+'\nPage '+(index+1)+' / '+(last+1),entries,back);
}
function arenaMenu(p,id){
 const spec=REMOTE_ARENAS.find(candidate=>candidate.id===id);
 if(!spec)return menu(p);
 const view=remoteGames.view(p,id),king=id==='koth';
 const choices=[];
 if(view.visiting)choices.push(['Return to Colosseum',viewer=>remoteGames.leave(viewer)]);
 else if(view.playing||view.returning)choices.push(['Leave Match / Return',viewer=>remoteGames.leave(viewer)]);
 else if(view.queued)choices.push(['Leave Queue',viewer=>remoteGames.leave(viewer)]);
 else if(!view.busy&&arenaBuilder.ready(spec))choices.push(['Join Queue',viewer=>remoteGames.join(viewer,id)]);
 for(const board of ARENA_BOARDS.filter(board=>(board.metric==='kingWins')===king)){
  choices.push([board.title+' · All Players',viewer=>arenaLeaderboard(viewer,board)]);
 }
 const queue=view.visiting?'Visiting arena.':view.playing?'Match in progress.':view.returning?'Returning to the Colosseum.':
  view.busy?'Wait for the current match to finish.':
  !arenaBuilder.ready(spec)?arenaBuilder.status(spec):
  'Queue '+view.count+'/10 · '+(view.time===undefined?'Two players open a '+ARENA_QUEUE_SECONDS+'-second join window.':view.time+' seconds left to join.');
 const rules=king?'Hold the gold summit alone for 60 seconds. Swing a melee weapon to damage opponents or use the Compass to shove. Weekly prize: '+
  KING_CREDITS+' Credits for the first '+KING_PAID_WINS+' wins.':
  'First to three captures wins. Bring the enemy flag to your glass stand while your flag is home. Use melee weapons or the Compass to knock out opponents.';
 const body=queue+'\n2–10 players. '+rules+'\nCrouch and use the Compass to open this menu in a live match.';
 if(view.visiting||view.playing||view.returning)return form(p,spec.title,body,choices.map(([label])=>label),i=>choices[i]?.[1](p));
 navForm(p,spec.title,body,choices,menu);
}
system.afterEvents.scriptEventReceive.subscribe(({id,message,sourceEntity:p})=>{
 if(id!=='skygen:arenas'||p?.typeId!=='minecraft:player'||!isOperator(p))return;
 const command=message.trim().toLowerCase();
 try{
  if(command==='resume')return p.sendMessage(arenaBuilder.resume()?'§aArena build resumed.':'§eThe arena builder is busy or the city is preparing.');
  if(command&&command!=='status')return p.sendMessage('§eUse /scriptevent skygen:arenas status or resume.');
  p.sendMessage('§6Colosseum §r· '+arenaBuilder.lobbyStatus());
  for(const spec of REMOTE_ARENAS)p.sendMessage('§6'+spec.title+' §r· '+arenaBuilder.status(spec));
 }catch(error){p.sendMessage('§cArena builder: '+error.message)}
});
function districtShopMenu(p,catalog,onBack=menu,page=0){
 const store=DISTRICT_SHOP_CATALOGS[catalog],size=8;
 if(!districtOrdersReady())return navForm(p,store.title,'This catalog opens after the city finishes building.',[],onBack);
 const available=store.items.filter(item=>ItemTypes.get(item.id)),pages=Math.max(1,Math.ceil(available.length/size));
 const current=Math.max(0,Math.min(page,pages-1));
 const entries=available.slice(current*size,current*size+size).map(item=>[
  item.label+' · '+item.price+' Cr'+(item.bundle?' · 4 for '+item.bundle+' Cr':''),
  viewer=>{
   const details=item.label+' · 1 for '+item.price+' Credits'+(item.bundle?' · 4 for '+item.bundle+' Credits':'');
   const options=(item.bundle?[1,4]:[1]).map(count=>{
    const price=districtShopPrice(catalog,item.id,count);
    return ['Buy '+count+' · '+price+' Credits',buyer=>{
     const quote=skyMessage().title('Confirm Purchase').body(count+' × '+item.label+' for '+price+' Credits.')
      .button1('Back').button2('Buy');
     showUI(buyer,quote).then(answer=>{
      if(answer.canceled)return;
      if(answer.selection===1&&buyDistrictShopOffer(buyer,catalog,item.id,count,price))
       buyer.sendMessage('§aPurchased '+count+' × '+item.label+'.');
      menuAgain(buyer,()=>districtShopMenu(buyer,catalog,onBack,current));
     }).catch(error=>buyer.sendMessage('§cShop purchase could not be completed: '+error));
    }];
   });
   navForm(viewer,store.title,details,options,
    player=>districtShopMenu(player,catalog,onBack,current));
  }
 ]);
 if(current>0)entries.push(['Previous Page',viewer=>districtShopMenu(viewer,catalog,onBack,current-1)]);
 if(current+1<pages)entries.push(['Next Page',viewer=>districtShopMenu(viewer,catalog,onBack,current+1)]);
 navForm(p,store.title,'Prices in Credits.\nPage '+(current+1)+' / '+pages,entries,onBack);
}
system.runInterval(()=>{
 if(!districtOrdersReady())return;
 const dim=world.getDimension('overworld');
 for(const station of DISTRICT_STATIONS){
  try{
   if(!dim.isChunkLoaded(station)||dim.getBlock(station)?.typeId!==station.block)continue;
   const title=station.id==='market'?'§6District Orders\n§7Weekly Market requests':
    '§6'+DISTRICT_SHOP_CATALOGS[station.id].title;
   updateDistrictText(dim,{...station,text:{x:station.x+0.5,y:station.y+2,z:station.z+0.5}},DISTRICT_DISPLAY_TAG,title);
  }catch(error){console.warn('[District Station] '+error)}
 }
 if(!collectionHallReady())return;
 for(const station of COLLECTION_HALL_STATIONS){
  try{
   if(!dim.isChunkLoaded(station)||dim.getBlock(station)?.typeId!==station.block)continue;
   const subtitle=station.collectionId?'Open the display':'Guild Hall · Three badge collections';
   updateDistrictText(dim,station,DISTRICT_DISPLAY_TAG,'§6'+station.title+'\n§7'+subtitle);
  }catch(error){console.warn('[Collection Hall] '+error)}
 }
 if(rushReady()){
  try{
   rushScoreboard();
   if(dim.isChunkLoaded(RUSH_STATION)&&dim.getBlock(RUSH_STATION)?.typeId===RUSH_STATION.block){
    updateDistrictText(dim,RUSH_STATION,DISTRICT_DISPLAY_TAG,'§6Generator Rush\n§7Colosseum · 1v1');
   }
   generatorRush.labelStations();
   for(const spec of REMOTE_ARENAS){
    if(!arenaBuilder.ready(spec))continue;
    const {station}=spec;
    if(dim.isChunkLoaded(station)&&dim.getBlock(station)?.typeId===station.block){
     updateDistrictText(dim,{...station,id:spec.id,text:{x:station.x+.5,y:station.y+2,z:station.z+.5}},
      DISTRICT_DISPLAY_TAG,'§6'+spec.title+'\n§7Colosseum · 2–10 players');
    }
    for(const board of ARENA_BOARDS.filter(board=>(board.metric==='kingWins')===(spec.id==='koth'))){
     if(!world.scoreboard.getObjective(board.objective))world.scoreboard.addObjective(board.objective,board.title);
    }
   }
  }catch(error){console.warn('[Generator Rush] Lobby: '+error)}
 }
},40);
function menu(p){
 const arena=remoteGames.gameFor(p);
 if(arena&&remoteGames.occupied(p))return arenaMenu(p,arena.id);
 if(generatorRush.occupied(p))return rushMenu(p);
 const d=profile(p);
 const body=`§6Royal Ledger  §8|  §dRank ${d.rank}/1000  §eXP ${formattedXP(d.xpProgress)}\n§eCredits: ${Number(d.credits).toLocaleString()}  §5Orbits: ${Number(d.orbits).toLocaleString()}\n§aPlot: #${d.plot+1}  §bSkill points: ${skillAvailable(d)}\n§7Select a SkyGen destination:`;
 const actions=[['§eQuests',dailyQuests],['§6Claim Box',claimBoxMenu],['§aMy Plot',plotMenu],['§bGenerators',genMenu]];
 if(firstGeneratorState(d).stage!=='complete')actions.push(['§aFirst Generator',firstGeneratorMenu]);
 actions.push(
  ['§dRanks & Skills',skyMenuRanksSkills],['§6Shops & Trading',skyMenuShops],
  ['§eBank & Wallet',skyMenuBankWallet],['§bTravel & Visitors',skyMenuTravelVisitors],
  ['§dProfile & Cosmetics',skyMenuProfileCosmetics],['§7Help & Rulebook',skyMenuHelpRulebook],
  ['§6Nexus Beacon',nexusBeaconMenu],['§6District Orders',districtOrdersMenu],
  ['§6Collection Hall',collectionHallMenu],['§6Generator Rush',rushMenu],
  ['§6King of the Hill',viewer=>arenaMenu(viewer,'koth')],['§cCapture the Flag',viewer=>arenaMenu(viewer,'ctf')]
 );
 form(p,'SkyGen Core',body,actions.map(([label])=>label),i=>{
  if(!Number.isInteger(i)||i<0||i>=actions.length)return;
  // Do not accept a stale operator-only button after permissions change.
  if(actions[i][1]===adminMenu&&!isOperator(p))return p.sendMessage('§cOperator access required.');
  actions[i][1](p);
 });
}
const HELP_SHORTCUTS={
 plot:['Open My Plot',plotMenu],visit:['Open Visit Other Plots',visitMenu],teleport:['Open Teleport Menu',teleports],
 generators:['Open Generators',genMenu],farming:['Open Farming Shop',farmingShop],shops:['Open Server Shop',shop],
 food:['Open Food Shop',foodShop],pro:['Open Pro Shop',proShop],wallet:['Open Wallet / Exchange',wallet],
 bank:['Open Bank',bankMenu],ranks:['Open Ranks',ranks],skills:['Open Skill Tree',skillTree],quests:['Open Daily Quests',dailyQuests],
 market:['Open Marketplace',market],trade:['Open Player Trading',trade],sidebar:['Open Personal Sidebar',sidebarMenu]
};
function helpLines(page){
 if(!page.branch)return page.lines;
 return [...page.lines,...SKILLS.filter(skill=>skill.branch===page.branch).map(skill=>
  `${skill.name} (Rank ${skill.rank}, ${skill.cost} SP) · ${skill.desc}`)];
}
function helpMenu(p){
 const topics=HELP_TOPICS.filter(topic=>!topic.operator||isOperator(p));
 form(p,'Help & Commands','Pick a topic to see steps, tips, and shortcuts.',
  [...topics.map(topic=>topic.title),'Back to Help & Rulebook'],i=>{
   if(i===topics.length)return skyMenuHelpRulebook(p);
   if(topics[i])helpTopic(p,topics[i]);
  });
}
function rulebookMenu(p){helpTopic(p,RULEBOOK_TOPIC,skyMenuHelpRulebook)}
function helpTopic(p,topic,returnTo=helpMenu){
 if(topic.operator&&!isOperator(p))return helpMenu(p);
 form(p,topic.title,topic.intro??'Choose the task you want help with.',
  [...topic.pages.map(page=>page.title),returnTo===skyMenuHelpRulebook?'Back to Help & Rulebook':'Back to Help Topics'],i=>{
   if(i===topic.pages.length)return returnTo(p);
   if(topic.pages[i])helpPage(p,topic,i,returnTo);
  });
}
function helpPage(p,topic,index,returnTo){
 if(topic.operator&&!isOperator(p))return helpMenu(p);
 const page=topic.pages[index];
 const actions=[];
 if(page.shortcut)actions.push(HELP_SHORTCUTS[page.shortcut]);
 if(index>0)actions.push(['Previous Page',()=>helpPage(p,topic,index-1,returnTo)]);
 if(index+1<topic.pages.length)actions.push(['Next Page',()=>helpPage(p,topic,index+1,returnTo)]);
 actions.push(['Back to '+topic.title,()=>helpTopic(p,topic,returnTo)],['Help Topics',helpMenu],['Main Menu',menu]);
 form(p,page.title,`Page ${index+1}/${topic.pages.length}\n\n`+helpLines(page).join('\n'),
  actions.map(([label])=>label),i=>{
   if(topic.operator&&!isOperator(p))return helpMenu(p);
   actions[i]?.[1](p);
  });
}

function plotMenu(p){
 const d=profile(p);
 if(d.plot<0)return p.sendMessage('§cYour plot is not assigned. Rejoin to retry.');
 const c=coords(d.plot),r=plotRadius(d.plot);
 const details=`§aPlot #${d.plot+1} (permanently assigned)\n§fCenter: ${c.x}, ${c.y}, ${c.z}\n§fProtected X: ${c.x-r} to ${c.x+r}\n§fProtected Z: ${c.z-r} to ${c.z+r}\n§eOnly you and trusted players can build here.
§bForcefield: only operators walk across. Use teleport menus for authorized visits.\n§7One plot per player; claiming another is disabled.`;
 form(p,'§aMY PLOT',details,['Go to Plot','Buy Plot Expansion','Show Boundaries in Chat','Manage Trusted Players','Manage Visitors','Visit Other Plots','Back'],i=>{
  if(i===0)tpPlot(p);
  if(i===1)return plotUpgradeMenu(p);
  if(i===2){p.sendMessage('§a'+details.replaceAll('\n',' §7| '));plotMenu(p)}
  if(i===3)trustMenu(p);
  if(i===4)visitorOwnerMenu(p);
  if(i===5)visitMenu(p);
  if(i===6)back(p);
 });
}

function trustMenu(p){
 const d=profile(p),id=d.plot;
 if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cOnly the plot owner can manage trust.');
 const list=trusted(id),online=world.getAllPlayers().filter(q=>q.id!==p.id);
 const buttons=[...online.map(q=>(list.includes(q.id)?'§aTrusted: ':'§7Visitor: ')+q.name),'Remove All Trust','Back'];
 form(p,'§aPLOT PERMISSIONS',`Plot #${id+1}\nTrusted IDs: ${list.length}\nSelect an online player to toggle build permission.`,buttons,i=>{
  if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. No trust permissions altered.');
  if(i===online.length){
   return showUI(p,skyMessage().title('Revoke All Trusted Players').body('Remove all trusted builder permissions from plot #'+(id+1)+'?').button1('Cancel').button2('Revoke All')).then(r=>{
    if(r.canceled||r.selection!==1)return;
    if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. Nothing revoked.');
    world.setDynamicProperty('sg_trust_'+id,'[]');p.sendMessage('§eAll plot trust revoked.');trustMenu(p);
   }).catch(e=>console.warn('[Sky Realm] trust removal: '+e));
  }
  if(i===online.length+1)return plotMenu(p);
  const q=online[i];if(!q||!world.getAllPlayers().some(x=>x.id===q.id))return;
  const latest=trusted(id),n=latest.includes(q.id)?latest.filter(v=>v!==q.id):[...latest,q.id];
  world.setDynamicProperty('sg_trust_'+id,JSON.stringify([...new Set(n)]));
  p.sendMessage(`§a${q.name}: ${n.includes(q.id)?'trusted':'untrusted'}`);trustMenu(p);
 });
}


// Visiting permissions are separate from building permissions. Owner grants are
// stored in world dynamic properties so they persist after restart and logout.
function visitTeleport(p,id){
 if(!canVisit(p,id))return p.sendMessage('§cYou do not have permission to visit this plot.');
 stageAndBuildPlot(p,id,true);
}
function visitorOwnerMenu(p){
 const id=profile(p).plot;if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cOnly the plot owner can manage visitors.');
 const list=visitors(id),online=world.getAllPlayers().filter(q=>q.id!==p.id);
 const choices=[...online.map(q=>`${list.includes(q.id)?'§aAllowed':'§7Not allowed'}: ${q.name}`),'Revoke All Visitors','Back'];
 form(p,'§aPLOT VISIT PERMISSIONS',`Plot #${id+1} | ${list.length} invited player(s)
Granting visit access does NOT grant building access.
Select a player to allow or revoke access.`,choices,i=>{
  if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. No visitor permissions altered.');
  if(i===online.length){
   return showUI(p,skyMessage().title('Revoke All Visitors').body('Remove every visitor from plot #'+(id+1)+'? Building permissions are separate.').button1('Cancel').button2('Revoke All')).then(r=>{
    if(r.canceled||r.selection!==1)return;
    if(profile(p).plot!==id||ownerId(id)!==p.id)return p.sendMessage('§cOwnership changed. Nothing revoked.');
    setVisit(id,[]);p.sendMessage('§eAll visitor access revoked.');visitorOwnerMenu(p);
   }).catch(e=>console.warn('[Sky Realm] visitor removal: '+e));
  }
  if(i===online.length+1)return plotMenu(p);
  const q=online[i];if(!q)return;
  const latest=visitors(id),allowed=!latest.includes(q.id);setVisit(id,allowed?[...latest,q.id]:latest.filter(v=>v!==q.id));
  p.sendMessage(`${allowed?'§aGranted':'§eRevoked'} visit access: ${q.name}`);
  q.sendMessage(allowed?`§a${p.name} allowed you to visit plot #${id+1}. Open SkyGen Menu → Visit Other Plots.`:`§e${p.name} revoked your access to plot #${id+1}.`);
  visitorOwnerMenu(p);
 });
}
function visitMenu(p){
 const accessible=world.getAllPlayers().filter(q=>q.id!==p.id&&profile(q).plot>=0&&canVisit(p,profile(q).plot));
 const online=world.getAllPlayers().filter(q=>q.id!==p.id&&profile(q).plot>=0&&!canVisit(p,profile(q).plot));
 const choices=[...accessible.map(q=>`§aVisit ${q.name} — #${profile(q).plot+1}`),'Request Access from Player','Incoming Requests','Back'];
 form(p,'§bVISIT PLAYER PLOTS',`You may teleport only to plots whose owners have allowed you.
Visits use the normal 5-second countdown and cooldown.
Visitors cannot build unless separately trusted.`,choices,i=>{
  if(i<accessible.length){const q=accessible[i];return visitTeleport(p,profile(q).plot)}
  if(i===accessible.length)return requestVisitMenu(p,online);
  if(i===accessible.length+1)return incomingVisits(p);
  back(p);
 });
}
function requestVisitMenu(p,online){
 form(p,'§bREQUEST PLOT ACCESS','Choose an online player. They must accept before you can visit.',[...online.map(q=>`${q.name} — Plot #${profile(q).plot+1}`),'Back'],i=>{
  if(i>=online.length)return visitMenu(p);
  const owner=online[i],id=profile(owner).plot;
  if(id<0||ownerId(id)!==owner.id)return p.sendMessage('§cPlot owner unavailable.');
  const key=`${owner.id}:${p.id}`;
  visitRequests.set(key,{ownerId:owner.id,requesterId:p.id,plot:id,expires:system.currentTick+1200});
  p.sendMessage(`§aVisit request sent to ${owner.name}.`);
  owner.sendMessage(`§e${p.name} requests permission to visit your plot. Open SkyGen Menu → Visit Other Plots → Incoming Requests to respond.`);
 });
}
function incomingVisits(p){
 const id=profile(p).plot;
 if(id<0||ownerId(id)!==p.id)return p.sendMessage('§cOnly plot owners can approve requests.');
 const requests=[...visitRequests.entries()].filter(([key,r])=>r.ownerId===p.id&&r.plot===id&&r.expires>=system.currentTick&&world.getAllPlayers().some(q=>q.id===r.requesterId));
 form(p,'§aINCOMING VISIT REQUESTS',`Requests expire after 60 seconds.
Pending: ${requests.length}`,[...requests.map(([key,r])=>world.getAllPlayers().find(q=>q.id===r.requesterId)?.name||'Offline'),'Back'],i=>{
  if(i>=requests.length)return visitMenu(p);
  const [key,r]=requests[i],requester=world.getAllPlayers().find(q=>q.id===r.requesterId);
  if(!requester||r.expires<system.currentTick||profile(p).plot!==r.plot||ownerId(r.plot)!==p.id){visitRequests.delete(key);return p.sendMessage('§cRequest expired.');}
  showUI(p,skyMessage().title('Allow Plot Visit?').body(`Allow ${requester.name} to visit plot #${id+1}?
They will not receive building permission.
You can revoke access any time.`).button1('Deny').button2('Allow')).then(res=>{
   if(res.canceled)return;
   visitRequests.delete(key);
   if(res.selection===1&&profile(p).plot===id&&ownerId(id)===p.id){setVisit(id,[...visitors(id),requester.id]);p.sendMessage(`§a${requester.name} may now visit your plot.`);requester.sendMessage(`§a${p.name} approved your visit! SkyGen Menu → Visit Other Plots.`)}
   else requester.sendMessage(`§c${p.name} denied your visit request.`);
  }).catch(e=>console.warn('SkyGen visit approval '+e));
 });
}

function genMenu(p){
 const count=generatorOwnerCount(p),cap=generatorSlots(p);
 form(p,'§bGENERATORS',`42 generator types across four categories.\nOwned: ${count}/${cap} slots. Upgrade production to Level 10.\n§7Use the custom generator token while looking at an open plot floor block.`,
 ['Buy Generator','My Generators / Upgrade','Back'],i=>{if(i===0)return genCategories(p);if(i===1)return myGenerators(p);back(p)});
}
function genCategories(p){
 const categories=['Starter','Mining','Nature','Endgame'];
 form(p,'§bGENERATOR TYPES',`42 types. Original generator purchases and tokens remain valid. Unlock new tiers as you rank up.`,
 [...categories.map(c=>`${c} (${GENS.filter(g=>g.category===c).length})`),'Back'],i=>{
  if(i>=categories.length)return genMenu(p);
  buyGen(p,categories[i],0);
 });
}
function myGenerators(p,page=0){
 const all=[...generators.entries()].filter(([key,g])=>g.owner===p.id);
 const pageSize=8,pages=Math.max(1,Math.ceil(all.length/pageSize)),current=Math.max(0,Math.min(page,pages-1));
 const a=all.slice(current*pageSize,current*pageSize+pageSize);
 form(p,'§bMY GENERATORS',`Owned: ${all.length}/${generatorSlots(p)} • Page ${current+1}/${pages}`,
 [...a.map(([key,g])=>`${g.type} Lv${g.level||1} @ ${g.x},${g.y},${g.z}`),
 ...(current>0?['Previous Page']:[]),...(current<pages-1?['Next Page']:[]),'Back'],i=>{
  if(i<a.length){const [key,g]=a[i];return manageGenerator(p,key,g)}
  let j=a.length;if(current>0){if(i===j)return myGenerators(p,current-1);j++}
  if(current<pages-1){if(i===j)return myGenerators(p,current+1)}
  genMenu(p);
 });
}
function manageGenerator(p,key,g){
 if(g.owner!==p.id||generators.get(key)!==g)return myGenerators(p);
 const lv=g.level||1;
 const spec=GEN_BY_NAME.get(g.type);
 const rawCost=spec?spec.cost*lv*2:0;
 const cost=discountedPrice(rawCost,perkValue(profile(p),'generatorPrice'));
 form(p,'§bMANAGE GENERATOR',`${g.type} • Level ${lv}/${GENERATOR_MAX_LEVEL}\nLocation: ${g.x}, ${g.y}, ${g.z}\nUpgrade cost: ${lv>=GENERATOR_MAX_LEVEL?'MAX LEVEL':cost+' Credits'}\nDeletion permanently removes the generator; no refund.`,['Upgrade','Delete Generator','Diagnose Generator','Back'],i=>{
  if(i===2){
   const dim=world.getDimension('overworld');
   let base='unloaded',output='unloaded';
   try{base=dim.getBlock({x:g.x,y:g.y,z:g.z})?.typeId||'unloaded';output=dim.getBlock({x:g.x,y:g.y+1,z:g.z})?.typeId||'unloaded'}catch(e){genError('inspect '+e)}
   const interval=(effectivePeriod(g)/20).toFixed(2);
   const age=genLastTick<0?'never':String(system.currentTick-genLastTick)+' ticks ago';
   const lines=[`§bSkyGen Generator Diagnostics v0.10.25`,`Generator: ${g.type} level ${lv} at ${g.x},${g.y},${g.z}`,`Registered: ${generators.get(key)===g} | Registry size: ${generators.size}`,`Base: ${base} | Output: ${output} | Expected: ${spec?.block||g.block}`,`Target interval: ${interval}s | Empty since tick: ${genEmptySeconds.get(key)??"none"}`,`Watchdog runs: ${genWatchdogRuns} | Last heartbeat: ${age}`,`Script uptime: ${system.currentTick-genStartupTick} ticks | Current tick: ${system.currentTick}`,`Last error: ${genLastError}`,`Recent errors: ${genErrors.slice(-3).join(' ; ')||'none'}`];
   for(const line of lines)p.sendMessage(line);
   return menuAgain(p,()=>manageGenerator(p,key,g));
  }
  if(i===0){
   if(lv>=GENERATOR_MAX_LEVEL){p.sendMessage('§eAlready max level.');return menuAgain(p,()=>manageGenerator(p,key,g));}
   showUI(p,skyMessage().title('Upgrade Generator').body(`Level ${lv} → ${lv+1}\nCost: ${cost} Credits\nProduction interval reduced by 15%; level 10 is instant.`).button1('Cancel').button2('Upgrade')).then(r=>{
    if(r.canceled)return;
    if(r.selection!==1)return menuAgain(p,()=>manageGenerator(p,key,g));
    try{
    if(g.owner!==p.id||generators.get(key)!==g||g.level!==undefined&&g.level!==lv)return p.sendMessage('§cGenerator changed. Open the menu again.');
    const d=profile(p);if(d.credits<cost)return p.sendMessage('§cNot enough Credits.');
    if(!generatorRegistryLoaded)return p.sendMessage('§cGenerator registry unavailable. No charge.');
    let tx;
    try{tx=beginEconomicTxn(p,'gen',{generator:key,cost,levelBefore:lv,levelAfter:lv+1})}
    catch(err){return p.sendMessage('§cUpgrade locked: '+err)}
    const oldPeriod=g.period,oldLevel=g.level;
    try{
     const fresh=profile(p);
     if(fresh.credits!==tx.before||fresh.credits<cost)throw Error('Generator Credits changed');
     fresh.credits-=cost;fresh.sg_last_econ_txn=tx.id;save(p,fresh);
     g.level=lv+1;g.period=Math.max(10,Math.round(g.period*0.85));
     if(!genSave())throw Error('Generator upgrade save unavailable');
     endEconomicTxn(p,tx,true);
     p.sendMessage(`§a${g.type} upgraded to level ${g.level}.`);
    }catch(err){
     // Registry may already have committed; never automatically refund or
     // reapply the upgrade when uncertain. Require manual operator review.
     g.level=oldLevel;g.period=oldPeriod;
     economicTxnReview(p,tx,'Generator upgrade charge/save uncertain: '+err);
     p.sendMessage('§cGenerator upgrade requires operator review.');
    }
    }finally{menuAgain(p,()=>manageGenerator(p,key,g))}
   }).catch(e=>console.warn('SkyGen upgrade UI '+e));
  }else if(i===1){
   showUI(p,skyMessage().title('§cDELETE GENERATOR?').body(`Permanently delete ${g.type} Lv${lv} at ${g.x}, ${g.y}, ${g.z}?\nThis cannot be undone. No Credits or egg will be refunded.`).button1('Keep Generator').button2('DELETE')).then(r=>{
    if(r.canceled)return;
    if(r.selection!==1)return menuAgain(p,()=>manageGenerator(p,key,g));
    try{
    if(g.owner!==p.id||generators.get(key)!==g)return p.sendMessage('§cGenerator changed. Open the menu again.');
    try{
     const dim=world.getDimension('overworld');
     const base=dim.getBlock({x:g.x,y:g.y,z:g.z});
     const output=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
     if(!base||!output)return p.sendMessage('§cGenerator chunk is not loaded. Stand near it and try again.');
     if(!isGeneratorBase(g,base))return p.sendMessage('§cGenerator base missing/mismatched. Deletion cancelled to protect nearby blocks.');
     // Remove the registry first and verify. If block removal fails, restore registry.
     generators.delete(key);clearGeneratorRefill(key);generatorOutputReady.delete(key);
     if(!genSave()){generators.set(key,g);return p.sendMessage('§cCannot save registry; nothing deleted.')}
     try{
      eraseGeneratorWorldBlocks(dim,g);
     }catch(err){generators.set(key,g);if(!genSave())genError('CRITICAL: generator rollback save failed '+key,'rollback');throw err}
     p.sendMessage(`§a${g.type} generator deleted. No refund issued.`);
    }catch(e){p.sendMessage('§cCould not delete generator. Stand near it and retry.');console.warn('SkyGen delete generator '+e)}
    }finally{menuAgain(p,()=>manageGenerator(p,key,g))}
   }).catch(e=>console.warn('SkyGen delete UI '+e));
  }else myGenerators(p);
 });
}
function buyGen(p,category='Starter',page=0){
 const d=profile(p),list=GENS.filter(g=>g.category===category);
 const stay=()=>menuAgain(p,()=>buyGen(p,category,current));
 const pages=Math.ceil(list.length/8),current=Math.max(0,Math.min(page,pages-1));
 const slice=list.slice(current*8,current*8+8);
 const heading=`${category} • Page ${current+1}/${pages}\nRank ${d.rank} / 1000\nCredits ${d.credits}`;
 form(p,'§bBUY '+category.toUpperCase(),heading,
 [...slice.map(g=>`${d.rank<g.unlock?'§8LOCKED ':'§a'}${g.name} — ${discountedPrice(g.cost,perkValue(d,'generatorPrice'))} Credits (Rank ${g.unlock})`),
 ...(current>0?['Previous Page']:[]),...(current<pages-1?['Next Page']:[]),'Back'],i=>{
  if(i>=slice.length){let idx=slice.length;
   if(current>0){if(i===idx)return buyGen(p,category,current-1);idx++}
   if(current<pages-1){if(i===idx)return buyGen(p,category,current+1)}
   return genCategories(p);
  }
  try{recoverEconomicTxn(p);if(readEconomicTxn(p)){p.sendMessage('§cPending economic review; purchases are locked.');return stay();}}catch(err){p.sendMessage('§cCannot verify economy: '+err);return stay();}
  if(!generatorRegistryLoaded){p.sendMessage('§cGenerators still loading or registry corrupt. Purchases disabled.');return stay();}
  const g=slice[i],latest=profile(p),cost=discountedPrice(g.cost,perkValue(latest,'generatorPrice'));
  if(latest.rank<g.unlock){p.sendMessage(`§c${g.name} requires Rank ${g.unlock}.`);return stay();}
  if(latest.credits<cost){p.sendMessage('§cNot enough Credits.');return stay();}
  if(!generatorTokenCustomReady){p.sendMessage('§cGenerator custom-item use handler unavailable. Purchases disabled.');return stay();}
  showUI(p,skyMessage().title('Generator Purchase')
   .body('§6'+g.name+' Generator Token\n§7Category: '+g.category+'\n§ePrice: '+cost.toLocaleString()+' Credits\n§dRequired Rank: '+g.unlock+'\n§7The token is placed on your plot. No generator is placed automatically.')
   .button1('Cancel').button2('Buy Token')).then(r=>{
    if(r.canceled)return;
    if(r.selection!==1)return stay();
    try{
    const fresh=profile(p);
    if(fresh.rank<g.unlock)return p.sendMessage('§cRank requirement not met.');
    if(fresh.credits<discountedPrice(g.cost,perkValue(fresh,'generatorPrice')))return p.sendMessage('§cInsufficient Credits.');
    if(!generatorRegistryLoaded||!generatorTokenCustomReady||!validGeneratorOutput(g))return p.sendMessage('§cGenerator block or system unavailable; no purchase made.');
    issueGeneratorToken(p,g,discountedPrice(g.cost,perkValue(fresh,'generatorPrice')));
    }finally{stay()}
  }).catch(e=>console.warn('[Sky Realm] generator confirmation: '+e));
 });
}
function plainCommerceMetadata(it){
 try{
  if(!it||typeof it.getDynamicPropertyIds!=='function'||it.getDynamicPropertyIds().length)return false;
  if(typeof it.getCanPlaceOn!=='function'||it.getCanPlaceOn().length)return false;
  if(typeof it.getCanDestroy!=='function'||it.getCanDestroy().length)return false;
  const en=it.getComponent?.('minecraft:enchantable');
  if(en?.getEnchantments?.().length)return false;
  const dura=it.getComponent?.('minecraft:durability');
  if(dura&&dura.damage>0)return false;
  // Potion & dye components have value-bearing variants; plain shop goods
  // never need to destroy their custom forms.
  if(it.getComponent?.('minecraft:potion')||it.getComponent?.('minecraft:dyeable'))return false;
  return true;
 }catch{return false}
}
function eligibleShopItem(it,id){return !!it&&it.typeId===id&&!it.nameTag&&!it.keepOnDeath&&it.lockMode===ItemLockMode.none&&!isTool(it)&&(!it.getLore||it.getLore().length===0)&&plainCommerceMetadata(it)}
function inventoryCapacity(p,stack){const inv=inventory(p);if(!inv)return false;let free=0;for(let i=0;i<inv.size;i++){const it=inv.getItem(i);if(!it){free+=stack.maxAmount;continue}if(it.typeId===stack.typeId&&!it.nameTag&&it.lockMode===ItemLockMode.none&&(!it.getLore||it.getLore().length===0)&&plainCommerceMetadata(it))free+=Math.max(0,it.maxAmount-it.amount)}return free>=stack.amount}
function shopTotal(item,buying,count,d){
 if(buying)return count*discountedPrice(item.buy/item.count,perkValue(d,'buy'));
 const merchantBonus=emblemEnabled(d,'merchant_insignia')?MERCHANT_SALE_BONUS:0;
 return Math.floor(count*item.sell*(100+perkValue(d,'sell')+merchantBonus)/(item.count*100));
}
// Preflight all destinations before debiting. Bundles and single items share
// one journal and one debit. An ambiguous inventory write stays review-locked.
function buyShopItems(p,lines,total){
 const inv=inventory(p);
 if(!inv)return p.sendMessage('§cInventory unavailable.');
 if(!Number.isSafeInteger(total)||total<1||total>2000000000)return p.sendMessage('§cInvalid purchase total.');
 if(profile(p).credits<total)return p.sendMessage('§cNot enough Credits.');
 const available=[];
 for(let slot=0;slot<inv.size;slot++){
  const original=inv.getItem(slot);
  available.push({slot,original,next:original});
 }
 for(const {id,count,enchantments} of lines){
  const sample=new ItemStack(id,1);
  if(enchantments){
   try{enchantProItem(sample,enchantments)}
   catch(err){p.sendMessage('§cPro Shop gear is unavailable: '+err.message);return false}
  }
  let remaining=count;
  for(const entry of available){
   if(!remaining)break;
   if(enchantments||!eligibleShopItem(entry.next,id)||!entry.next.isStackableWith(sample))continue;
   const amount=Math.min(remaining,entry.next.maxAmount-entry.next.amount);
   if(!amount)continue;
   const stack=entry.next.clone();stack.amount+=amount;
   entry.next=stack;remaining-=amount;
  }
  for(const entry of available){
   if(!remaining)break;
   if(entry.next)continue;
   const amount=Math.min(remaining,sample.maxAmount);
   entry.next=enchantments?sample.clone():new ItemStack(id,amount);
   if(enchantments){
    entry.next.amount=amount;
    entry.enchantments=enchantments;
   }
   remaining-=amount;
  }
  if(remaining)return p.sendMessage('§cNot enough inventory space.');
 }
 const changes=available.filter(entry=>entry.original!==entry.next);
 let tx;
 try{
  tx=beginEconomicTxn(p,'buy',{item:lines.map(line=>line.id).join(', '),
   count:lines.reduce((sum,line)=>sum+line.count,0),total,
   slots:changes.map(({slot,original,next,enchantments})=>
    [slot,original?.amount??0,next.typeId,next.amount,...(enchantments?[enchantments]:[])])});
 }catch(e){return p.sendMessage('§cPurchase locked: '+e)}
 try{
  const d=profile(p);
  if(d.credits!==tx.before||d.credits<total)throw Error('Credits changed');
  d.credits-=total;d.sg_last_econ_txn=tx.id;save(p,d);
 }catch(e){
  try{
   const state=profile(p);
   if(state.credits!==tx.before)economicTxnReview(p,tx,'Payment verification failed: '+e);
   else endEconomicTxn(p,tx,true);
  }catch(err){economicTxnReview(p,tx,err)}
  return p.sendMessage('§cPayment could not be verified. No items delivered.');
 }
 const written=[];
 try{
  for(const change of changes){
   written.push(change);
   inv.setItem(change.slot,change.next);
   const actual=inv.getItem(change.slot);
   if(actual?.typeId!==change.next.typeId||actual.amount!==change.next.amount||
      (change.enchantments&&!hasProEnchantments(actual,change.enchantments)))
    throw Error('Inventory delivery verification failed');
  }
 }catch(e){
  let restored=true;
  for(const {slot,original,next} of written.reverse()){
   try{
    const actual=inv.getItem(slot);
    const same=(expected)=>expected===undefined?actual===undefined:
     eligibleShopItem(actual,expected.typeId)&&actual.amount===expected.amount;
    if(same(original))continue;
    if(!same(next)){restored=false;continue}
    inv.setItem(slot,original);
    const verified=inv.getItem(slot);
    if(verified?.typeId!==original?.typeId||verified?.amount!==original?.amount)restored=false;
   }catch{restored=false}
  }
  try{
   if(!restored)throw e;
   const d=profile(p);
   if(d.sg_last_econ_txn!==tx.id||d.credits!==tx.before-total)throw Error('Refund cannot be verified');
   d.credits=tx.before;save(p,d);
   endEconomicTxn(p,tx,true);
   return p.sendMessage('§cPurchase failed. Credits returned and inventory restored.');
  }catch(err){economicTxnReview(p,tx,err);return false}
 }
 try{endEconomicTxn(p,tx,true);return true}
 catch(e){economicTxnReview(p,tx,'Delivery completed; journal cleanup uncertain: '+e);return false}
}
function planInventoryDebit(inv,count,eligible){
 if(!inv||!Number.isSafeInteger(count)||count<1)return null;
 const slots=[];
 let remaining=count;
 for(let i=0;i<inv.size&&remaining>0;i++){
  const item=inv.getItem(i);
  if(!eligible(item))continue;
  const quantity=Math.min(remaining,item.amount);
  slots.push([i,quantity,item.clone()]);
  remaining-=quantity;
 }
 return remaining===0?slots:null;
}
function safeShopSell(p,s){
 if(creativeEconomyBlocked(p)){p.sendMessage('§cSelling disabled: Creative inventory requires operator clearance.');return false;}

 const slots=planInventoryDebit(inventory(p),s.count,item=>eligibleShopItem(item,s.id));
 if(!slots){p.sendMessage('§cNot enough ordinary unlocked items.');return false}
 if(!Number.isSafeInteger(s.sell)||s.sell<1||s.sell>CREDIT_CAP){
  p.sendMessage('§cInvalid sale payout.');return false;
 }
 const d=profile(p),destination=payoutDestination(d,s.sell);
 if(destination===undefined){
  p.sendMessage('§cSale could not be paid. '+noPayoutRoom(d,s.sell));return false;
 }
 let guideStage;
 const committed=commitInventoryDebit(p,slots,'sell',{item:s.id,count:s.count,total:s.sell,destination},(latest,tx)=>{
  if(latest.credits!==tx.before)throw Error('Wallet changed');
  creditPayout(latest,destination,s.sell);
  latest.sg_last_econ_txn=tx.id;
  recordDaily(p,latest,['sold'],s.count,s.id,s.sell);
  guideStage=markFirstGenerator(latest,'sell',{item:s.id});
  save(p,latest);
 });
 if(committed&&destination!=='wallet')p.sendMessage('§aSale Credits deposited into '+destinationName(d,destination)+'.');
 if(committed)announceFirstGenerator(p,guideStage);
 return committed;
}
function commitInventoryDebit(p,slots,kind,details,commit,hasReceipt){
 const inv=inventory(p);
 if(!inv)return false;
 const slotDetails=slots.map(([slot,amount,item])=>[slot,item.typeId,item.amount,amount]);
 let tx;
 try{tx=beginEconomicTxn(p,kind,{...details,slots:slotDetails})}
 catch(e){p.sendMessage('§cTransaction locked: '+e);return false}
 const changed=[];
 try{
  for(const [slot,n,expected] of slots){
   const current=inv.getItem(slot);
   if(!current||!eligibleShopItem(current,expected.typeId)||current.amount!==expected.amount)throw Error('Inventory changed');
   changed.push([slot,expected]);
   if(n===current.amount)inv.setItem(slot,undefined);
   else{const reduced=current.clone();reduced.amount-=n;inv.setItem(slot,reduced)}
   const after=inv.getItem(slot),expectedAmount=expected.amount-n;
   if(expectedAmount===0?after!==undefined:!eligibleShopItem(after,expected.typeId)||after.amount!==expectedAmount)
    throw Error('Inventory removal was not verified');
  }
  commit(profile(p),tx);
  endEconomicTxn(p,tx,true);
  return true;
 }catch(e){
  // A committed payout or contribution precludes restoring the debited inventory.
  let latest,receipt;
  try{latest=profile(p);receipt=hasReceipt?.(tx)}
  catch(err){economicTxnReview(p,tx,'Could not verify transaction receipt: '+err);return false}
  if(receipt||latest.sg_last_econ_txn===tx.id||latest.credits!==tx.before){
   economicTxnReview(p,tx,'Payout state uncertain: '+e);return false;
  }
  // Restore exactly ONLY if every affected slot still matches the write we
  // performed. If uncertain, do not overwrite another item or credit twice.
  let restored=true;
  for(const [slot,original] of changed){
   try{const current=inv.getItem(slot),n=slots.find(x=>x[0]===slot)[1];
    // The failed write may have left the original stack unchanged.
    if(current&&eligibleShopItem(current,original.typeId)&&current.amount===original.amount)continue;
    if(current&&(!eligibleShopItem(current,original.typeId)||current.amount!==original.amount-n)){restored=false;continue}
    if(!current&&original.amount!==n){restored=false;continue}
    inv.setItem(slot,original);
    const verified=inv.getItem(slot);
    if(!eligibleShopItem(verified,original.typeId)||verified.amount!==original.amount)restored=false;
   }catch{restored=false}
  }
  if(restored){try{endEconomicTxn(p,tx,true)}catch(err){economicTxnReview(p,tx,err)}}
  else economicTxnReview(p,tx,'Inventory or wallet uncertain: '+e);
  p.sendMessage('§cTransaction failed; '+(restored?'items restored.':'operator review required.'));
  return false;
 }
}
function countShopInventory(p,id){
 const inv=inventory(p);if(!inv)return 0;let count=0;
 for(let slot=0;slot<inv.size;slot++){const it=inv.getItem(slot);if(eligibleShopItem(it,id))count+=it.amount;}
 return count;
}
function deathneriteShop(p){
 const groups=DEATHNERITE_SHOP.map(group=>({
  name:group.name,
  items:group.items.filter(item=>item.ids.every(id=>ItemTypes.get(id)))
 })).filter(group=>group.items.length);
 const money=amount=>amount.toLocaleString()+' Credits';
 form(p,'DEATHNERITE SHOP','Buy materials, finished gear and armor sets with Credits.',
  [...groups.map(group=>group.name),'Back'],i=>{
  if(i===groups.length)return skyMenuShops(p);
  const group=groups[i];
  const browse=()=>form(p,group.name,'Balance: '+money(profile(p).credits),
   [...group.items.map(item=>item.name+' · '+money(item.price)),'Back'],selected=>{
    if(selected===group.items.length)return deathneriteShop(p);
    const item=group.items[selected];
    const confirm=skyMessage().title('Confirm Deathnerite Purchase')
     .body(item.name+'\n'+money(item.price)+'\n'+item.ids.join('\n')).button1('Back').button2('Buy');
    showUI(p,confirm).then(r=>{
     if(r.canceled)return;
     try{
      if(r.selection!==1)return;
      const lines=item.ids.map(id=>({id,count:1}));
      if(buyShopItems(p,lines,item.price))p.sendMessage('§aPurchased '+item.name+' for '+money(item.price)+'.');
     }finally{menuAgain(p,browse)}
    }).catch(e=>p.sendMessage('§cDeathnerite purchase failed: '+e));
   });
  browse();
 });
}
// Phase 4: separate Orbit purchase; reserved journal prevents double delivery.
// A dual-currency Pro Shop item is eligible for Orbit checkout only after
// its owner-approved 10% integer discount is re-verified at confirmation.
// Enchanted delivery is inspected before debit and verified after delivery.
function purchaseOrbitItem(p,item){
 let amount;
 try{
  if(!item||!Number.isSafeInteger(item.orbitPrice)||item.orbitPrice<=0||
     !Number.isSafeInteger(item.price)||item.lines?.length!==1||item.lines[0].count!==1)
   throw Error('Orbit SKU not approved');
  exactOrbitQuote(item.price,item.orbitPrice);
  amount=item.orbitPrice;
 }catch(e){p.sendMessage('§cOrbit price needs review: '+e.message);return false}
 const inv=inventory(p);if(!inv)return false;
 let sample;
 try{
  sample=new ItemStack(item.lines[0].id,1);
  if(item.lines[0].enchantments)enchantProItem(sample,item.lines[0].enchantments);
 }catch(e){p.sendMessage('§cPro Shop gear is unavailable: '+e.message);return false}
 let slot=-1;for(let i=0;i<inv.size;i++)if(!inv.getItem(i)){slot=i;break}
 if(slot<0)return p.sendMessage('§cFree one inventory slot first.');
 const pre=profile(p);if(creativeEconomyBlocked(p))return p.sendMessage('§cCreative inventory requires operator clearance.');
 if(pre.orbits<amount)return p.sendMessage('§cNot enough Orbits.');
 let tx;
 try{
  tx=beginEconomicTxn(p,'buy',{currency:'orbits',cost:amount,item:sample.typeId,slot,beforeOrbits:pre.orbits,
    enchanted:!!item.lines[0].enchantments,sku:item.name});
  const d=profile(p);
  if(d.orbits!==tx.beforeOrbits||d.orbits<amount)throw Error('Orbit balance changed');
  if(inv.getItem(slot)!==undefined)throw Error('Delivery slot changed');
  d.orbits-=amount;d.sg_last_econ_txn=tx.id;save(p,d);
  if(inv.getItem(slot)!==undefined)throw Error('Purchase destination changed');
  inv.setItem(slot,sample);
  const received=inv.getItem(slot);
  if(received?.typeId!==sample.typeId||received.amount!==1||
    (item.lines[0].enchantments&&!hasProEnchantments(received,item.lines[0].enchantments)))
   throw Error('Orbit delivery or enchantments not verified');
  endEconomicTxn(p,tx,true);p.sendMessage('§aPurchased '+item.name+' for '+amount+' Orbits.');return true;
 }catch(e){
  if(tx){
   try{
    const d=profile(p);
    // Reverse only when the entire delivery slot is still empty and the
    // exact transaction debit can be proven. Never erase a delivered item.
    if(d.sg_last_econ_txn===tx.id&&inv.getItem(slot)===undefined&&d.orbits===tx.beforeOrbits-amount){
     d.orbits=tx.beforeOrbits;save(p,d);endEconomicTxn(p,tx,true);
     p.sendMessage('§ePurchase reversed; Orbits restored.');return false;
    }
    // If prepared but never debited, no payment or item can be refunded.
    if(d.sg_last_econ_txn!==tx.id&&d.orbits===tx.beforeOrbits&&inv.getItem(slot)===undefined){
     endEconomicTxn(p,tx,true);p.sendMessage('§cOrbit purchase canceled; no debit.');return false;
    }
   }catch{}
   economicTxnReview(p,tx,'Orbit purchase needs reconciliation: '+e);
  }
  p.sendMessage('§cOrbit purchase incomplete; contact operator if paid: '+String(e).slice(0,100));return false;
 }
}

function purchaseSellChest(p){
 const inv=inventory(p),before=profile(p);
 if(before.sellChestLicense)return p.sendMessage('§eYou already own a Sell-All Chest license. Open its manager.');
 if(!inv||before.credits<55000)return p.sendMessage('§cRequires 55,000 Credits and inventory space.');
 let slot=-1;for(let i=0;i<inv.size;i++)if(!inv.getItem(i)){slot=i;break}
 if(slot<0)return p.sendMessage('§cFree one inventory slot first.');
 let tx;
 try{
  tx=beginEconomicTxn(p,'buy',{currency:'credits',cost:55000,item:'sell_chest_license',slot});
  const d=profile(p);if(d.credits!==tx.before||d.sellChestLicense)throw Error('Purchase eligibility changed');
  d.credits-=55000;d.sellChestLicense=true;d.sg_last_econ_txn=tx.id;save(p,d);
  if(inv.getItem(slot))throw Error('Destination changed');
  inv.setItem(slot,new ItemStack('minecraft:chest',1));
  if(inv.getItem(slot)?.typeId!=='minecraft:chest')throw Error('Chest not delivered');
  endEconomicTxn(p,tx,true);p.sendMessage('§aSell-All Chest purchased. Place it on your plot, look at it, then open Pro Shop → Manage Sell-All Chest to bind.');return true;
 }catch(e){if(tx){
   try{const d=profile(p);if(d.sg_last_econ_txn===tx.id&&inv.getItem(slot)===undefined&&d.credits===tx.before-55000){d.credits=tx.before;d.sellChestLicense=false;save(p,d);endEconomicTxn(p,tx,true);p.sendMessage('§eChest purchase rolled back.');return false}}catch{}
   economicTxnReview(p,tx,e);
  }p.sendMessage('§cChest purchase needs review: '+String(e).slice(0,100));return false}
}
function starterKitSource(p,location){
 if(!p.isValid||p.dimension.id!=='minecraft:overworld'||!publicStarterEnabled()||
    Math.hypot(p.location.x-location.x-.5,p.location.y-location.y,p.location.z-location.z-.5)>6)return;
 const block=loadedPlotBlock(p.dimension,location.x,location.y,location.z);
 return shulkerBox(block?.typeId)&&chestContents(block);
}
function claimStarterKit(p,location){
 const source=starterKitSource(p,location);
 if(!source)throw Error('Return to the starter shulker to claim your kit.');
 if(![GameMode.Survival,GameMode.Adventure].includes(p.getGameMode())||creativeEconomyBlocked(p))
  throw Error('Starter kits require eligible Survival play.');
 const now=Date.now(),d=profile(p);
 if(nextStarterKit(d)>now)throw Error('Your starter kit is still on cooldown.');
 const inv=inventory(p),expected=starterKitStock(location);
 if(!inv||!expected)throw Error('Starter kit inventory is unavailable.');
 const {slots,needed}=planStarterKit(source,inv,expected);
 if(!slots)throw Error('Free '+needed+' inventory slots to receive the full kit.');
 const tx=beginEconomicTxn(p,'starter_kit',{
  nextAt:now+STARTER_KIT_COOLDOWN,station:location,slots:slots.map(([i,it])=>[i,it.typeId,it.amount]),
 });
 const written=[];
 try{
  advanceEconomicTxn(p,tx,'delivering');
  for(const [slot,item] of slots){
   if(inv.getItem(slot))throw Error('Inventory changed during delivery');
   written.push(slot);
   inv.setItem(slot,item);
   const current=inv.getItem(slot);
   if(current?.typeId!==item.typeId||current.amount!==item.amount)throw Error('Could not verify kit delivery');
  }
  const latest=profile(p);
  latest.starterKitNextAt=tx.nextAt;
  latest.sg_last_econ_txn=tx.id;
  save(p,latest);
  endEconomicTxn(p,tx,true);
  p.sendMessage('§aStarter kit claimed. Your next kit is available in 24 hours.');
  return true;
 }catch(error){
  try{
   if(profile(p).sg_last_econ_txn!==tx.id){
    // These slots were empty when this synchronous callback started writing.
    for(const slot of written){
     inv.setItem(slot,undefined);
     if(inv.getItem(slot))throw Error('Could not verify starter kit rollback');
    }
    endEconomicTxn(p,tx,true);
    p.sendMessage('§eStarter kit delivery was rolled back. Your claim is still available.');
    return false;
   }
  }catch(recovery){console.warn('[SkyGen KIT] Delivery rollback: '+recovery)}
  economicTxnReview(p,tx,'Starter kit delivery needs review: '+error);
  return false;
 }
}
function starterKitMenu(p,location){
 try{
  if(!starterKitSource(p,location))return;
  const remaining=Math.max(0,nextStarterKit(profile(p))-Date.now());
  const minutes=Math.ceil(remaining/60000);
  const body=remaining?'Next kit in '+Math.floor(minutes/60)+'h '+minutes%60+'m.':
   'One full starter kit every 24 hours, shared across all four shulkers.';
  form(p,'§6STARTER KIT',body,remaining?['Close']:['Claim Full Kit','Close'],i=>{
   if(!remaining&&i===0)try{claimStarterKit(p,location)}
   catch(error){p.sendMessage('§c'+error.message)}
  });
 }catch(error){p.sendMessage('§c'+error.message)}
}
function sellChestKey(loc){return 'sg_sale_chest_'+loc.x+'_'+loc.y+'_'+loc.z}
function chestBlockAt(loc){return world.getDimension('overworld').getBlock(loc)}
function boundSaleChestOwner(loc){return world.getDynamicProperty(sellChestKey(loc))}
function chestContents(block){return block?.getComponent('minecraft:inventory')?.container}
function chestEnvironmentSafe(block,dimension){
 try{
  if(block?.typeId!=='minecraft:chest'||chestContents(block)?.size!==27)return false;
  const loc=block.location;
  const offsets=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  const machine=/^minecraft:(?:hopper|piston|sticky_piston|moving_block|dropper|dispenser|chest|trapped_chest)$/;
  if(offsets.some(([dx,dy,dz])=>{const b=dimension.getBlock({x:loc.x+dx,y:loc.y+dy,z:loc.z+dz});return !b||machine.test(b.typeId)}))return false;
  // Automated hopper minecarts can reach into ordinary vanilla containers.
  // Fail closed rather than pretending that player-interaction guards stop them.
  const carts=dimension.getEntities({type:'minecraft:hopper_minecart',location:{x:loc.x+.5,y:loc.y+.5,z:loc.z+.5},maxDistance:3});
  if(carts.length)return false;
  return true;
 }catch{return false}
}
function manageSellChest(p){
 const d=profile(p);
 if(!d.sellChestLicense)return p.sendMessage('§eBuy a Sell-All Chest in the Pro Shop first.');
 form(p,'§eSELL-ALL CHEST',`Owner-only chest · sales begin when you close it.\nUnsellable items stay inside.\n${d.sellChestPos?'Bound at '+JSON.stringify(d.sellChestPos):'Not bound yet'}`,
  ['Bind Chest I Am Looking At','Unbind Empty Chest','Back'],i=>{
   if(i===2)return proShop(p);
   try{
    const fresh=profile(p),old=fresh.sellChestPos;
    if(i===1){
     if(!old)return p.sendMessage('§7No chest is bound.');
     const block=chestBlockAt(old),inv=chestContents(block);
     if(block?.typeId==='minecraft:chest'&&(!inv||Array.from({length:inv.size},(_,j)=>inv.getItem(j)).some(Boolean)))return p.sendMessage('§cEmpty the bound chest before unbinding.');
     // If the original block was destroyed by an external mechanism, owner
     // may recover the license only after its authoritative owner key is checked.
     const key=sellChestKey(old);if(world.getDynamicProperty(key)!==p.id)throw Error('Owner registry mismatch');
     // Fail closed: losing an index cannot transfer the license to anyone else.
     delete fresh.sellChestPos;save(p,fresh);
     world.setDynamicProperty(key,undefined);p.sendMessage('§aEmpty chest unbound; license retained.');return;
    }
    if(old)return p.sendMessage('§eUnbind the old empty chest before moving it.');
    const block=p.getBlockFromViewDirection?.({maxDistance:5})?.block,loc=block?.location;
    if(block?.typeId!=='minecraft:chest'||!loc||p.dimension?.id!=='minecraft:overworld')return p.sendMessage('§cLook directly at a single chest on your plot.');
    if(!belongs(p,loc.x,loc.z))return p.sendMessage('§cChest must be on your own plot.');
    const inv=chestContents(block);    if(!inv||inv.size!==27||!chestEnvironmentSafe(block,p.dimension))return p.sendMessage('§cBind only a single chest away from hoppers, pistons, and hopper minecarts.');
    if(Array.from({length:inv.size},(_,j)=>inv.getItem(j)).some(Boolean))return p.sendMessage('§cBind an empty chest before depositing items.');
    const neighbors=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
    if(neighbors.some(([dx,dy,dz])=>p.dimension.getBlock({x:loc.x+dx,y:loc.y+dy,z:loc.z+dz})?.typeId==='minecraft:hopper'))return p.sendMessage('§cRemove all adjacent hoppers before binding this chest.');
    const key=sellChestKey(loc),current=world.getDynamicProperty(key);
    if(current&&current!==p.id)return p.sendMessage('§cAnother player owns this chest.');
    world.setDynamicProperty(key,p.id);
    if(world.getDynamicProperty(key)!==p.id)throw Error('Owner index could not be verified');
    fresh.sellChestPos={x:loc.x,y:loc.y,z:loc.z};save(p,fresh);
    p.sendMessage('§aChest bound to you. Close it to sell eligible items.');
   }catch(e){p.sendMessage('§cChest binding needs operator review: '+String(e).slice(0,110))}
  });
}
function payoutBalance(d,destination){
 if(destination==='wallet')return d.credits;
 return d.bank?.accounts?.find(a=>a.id===destination)?.credits;
}
function chestShopPrice(id,count,d){
 const catalogs=[...SHOP,...FOOD_SHOP,...Object.values(FARMING_SHOP).flat()];
 const entry=catalogs.find(t=>t.id===id&&t.sell>0);
 if(!entry)return 0;
 return shopTotal(entry,false,count,d);
}
// All-or-none chest sale with same prepared/review journal semantics as inventory sales.
function sellBoundChestOnClose(e){
 const block=e.block,loc=block?.location,source=e.closeSource?.entity;
 if(block?.typeId!=='minecraft:chest'||!loc||!source||source.typeId!=='minecraft:player')return;
 if(e.dimension?.id!=='minecraft:overworld'||boundSaleChestOwner(loc)!==source.id)return;
 const p=source,d=profile(p),position=d.sellChestPos;
 if(!d.sellChestLicense||!position||sellChestKey(position)!==sellChestKey(loc)||!belongs(p,loc.x,loc.z))return;
 if(creativeEconomyBlocked(p))return p.sendMessage('§cSell-All Chest disabled: Creative inventory requires operator clearance.');
 const inv=chestContents(block);if(!inv||inv.size!==27||!chestEnvironmentSafe(block,p.dimension))return p.sendMessage('§cSell chest unsafe: check double chests, hoppers, minecarts, and pistons; contents retained.');
 const slots=[];let total=0,count=0;
 for(let i=0;i<inv.size;i++){
  const item=inv.getItem(i);
  if(!item||!eligibleShopItem(item,item.typeId))continue;
  const sell=chestShopPrice(item.typeId,item.amount,d);
  if(!Number.isSafeInteger(sell)||sell<=0)continue;
  total+=sell;count+=item.amount;slots.push([i,item.clone(),sell]);
 }
 if(!slots.length)return;
 if(!Number.isSafeInteger(total)||total>CREDIT_CAP)return p.sendMessage('§cSale value exceeded limit. Contents untouched.');
 const destination=payoutDestination(d,total);
 const destinationBefore=payoutBalance(d,destination);
 if(destination===undefined)return p.sendMessage('§cNo wallet/bank room for '+total+' Credits. Chest contents retained.');
 let tx;const changed=[];
 try{
  tx=beginEconomicTxn(p,'sell',{source:'chest',chest:loc,owner:p.id,slots:slots.map(([i,it])=>[i,it.typeId,it.amount]),count,total,destination,destinationBefore,destinationAfter:destinationBefore+total});
  const live=profile(p);
  if(boundSaleChestOwner(loc)!==p.id||live.credits!==tx.before||payoutBalance(live,destination)!==destinationBefore)throw Error('Owner or destination changed');
  if(!chestEnvironmentSafe(block,p.dimension))throw Error('Unsafe automation beside sale chest');
  for(const [i,item] of slots){
   const current=inv.getItem(i);
   if(!current||!eligibleShopItem(current,item.typeId)||current.amount!==item.amount)throw Error('Chest inventory changed');
   changed.push([i,item]);inv.setItem(i,undefined);
   if(inv.getItem(i)!==undefined)throw Error('Chest item removal not verified');
  }
  const latest=profile(p);
  if(payoutBalance(latest,destination)!==destinationBefore)throw Error('Payout destination changed during sale');
  creditPayout(latest,destination,total);latest.sg_last_econ_txn=tx.id;
  for(const [,soldItem,proceeds] of slots)recordDaily(p,latest,['sold'],soldItem.amount,soldItem.typeId,proceeds);
  save(p,latest);
  endEconomicTxn(p,tx,true);p.sendMessage('§aChest sold '+count+' eligible items for '+total+' Credits.');
 }catch(err){
  if(!tx){p.sendMessage('§cChest sale was not started: '+String(err).slice(0,95));return}
  try{
   const latest=profile(p);
   if(latest.sg_last_econ_txn!==tx.id&&latest.credits===tx.before&&payoutBalance(latest,tx.destination)===tx.destinationBefore){
    let restored=true;
    for(const [i,item] of changed){const current=inv.getItem(i);if(current===undefined){inv.setItem(i,item);if(inv.getItem(i)?.amount!==item.amount)restored=false}else if(current.typeId!==item.typeId||current.amount!==item.amount)restored=false}
    if(restored){endEconomicTxn(p,tx,true);p.sendMessage('§cChest sale aborted; items restored.');return}
   }
  }catch{}
  economicTxnReview(p,tx,'Chest settlement uncertain: '+err);
 }
}
try{world.afterEvents.blockContainerClosed?.subscribe(e=>{try{sellBoundChestOnClose(e)}catch(err){console.warn('[SkyGen CHEST] Close error '+err)}})}
catch(err){console.warn('[SkyGen CHEST] Close event unavailable '+err)}

// A saved equip flag powers both the emblem icon and the perk.
function myCosmetics(p,returnTo=skyMenuProfileCosmetics){
 let c;try{c=validateCosmetics(profile(p))}catch(err){return p.sendMessage('§cCosmetics require operator review: '+String(err).slice(0,100))}
 const ids=Object.keys(COSMETIC_BADGES);
 const list=ids.map(id=>COSMETIC_BADGES[id].name+' · '+(!c.owned.includes(id)?'Locked':c.equipped.includes(id)?'On':'Off'));
 const body='Tap an emblem to switch it on or off. On emblems stay active everywhere until you switch them off.\n\n'+
  ids.map(id=>COSMETIC_BADGES[id].name+' · '+COSMETIC_BADGES[id].perk).join('\n');
 form(p,'§bMY COSMETICS',body,[...list,'Back'],i=>{
  if(i>=ids.length)return returnTo(p);
  const id=ids[i];
  try{
   const fresh=profile(p),v=validateCosmetics(fresh);
   if(!v.owned.includes(id)){const offer=APPROVED_COSMETIC_BUNDLES.find(b=>b.badge===id);return offer?cosmeticBundleMenu(p,offer):myCosmetics(p,returnTo)}
   const enabled=!c.equipped.includes(id);
   fresh.cosmetics=setCosmeticEquipped(fresh,id,enabled);
   save(p,fresh);
   p.sendMessage('§a'+COSMETIC_BADGES[id].name+' · '+(enabled?'On':'Off'));
  }catch(err){p.sendMessage('§cCosmetic selection failed: '+String(err).slice(0,100))}
  menuAgain(p,()=>myCosmetics(p,returnTo));
 });
}
// v0.10.54: Cosmetic checkout grants ONLY a permanent badge entitlement.
// No inventory delivery, Totems, Enchanted Apples, chest or chest license.
// The economic journal still protects exact-once debits/ownership.
function purchaseCosmeticBundle(p,bundle,withOrbit){
 let tx;
 try{
  validateBundle(bundle);
  if(creativeEconomyBlocked(p))throw Error('Creative inventory requires operator clearance');
  const first=profile(p),owned=validateCosmetics(first);
  if(owned.owned.includes(bundle.badge))throw Error('You already own this badge');
  const amount=withOrbit?bundle.orbitPrice:bundle.price;
  if((withOrbit?first.orbits:first.credits)<amount)throw Error('Insufficient '+(withOrbit?'Orbits':'Credits'));
  tx=beginEconomicTxn(p,'buy',{sku:bundle.id,badge:bundle.badge,badgeOnly:true,
   currency:withOrbit?'orbits':'credits',cost:amount,beforeOrbits:first.orbits,slots:[]});
  const fresh=profile(p);
  if(validateCosmetics(fresh).owned.includes(bundle.badge))throw Error('Ownership changed');
  if(fresh.credits!==tx.before||fresh.orbits!==tx.beforeOrbits)throw Error('Currency balance changed');
  fresh.cosmetics=grantCosmetic(fresh,bundle.badge);
  if(withOrbit)fresh.orbits-=amount;else fresh.credits-=amount;
  fresh.sg_last_econ_txn=tx.id;
  save(p,fresh); // Ownership, debit, nonce: one persisted profile write.
  endEconomicTxn(p,tx,true);
  p.sendMessage('§aUnlocked '+bundle.name+' for '+amount.toLocaleString()+' '+(withOrbit?'Orbits':'Credits')+'. Turn it on in My Cosmetics.');
  return true;
 }catch(err){
  if(tx){
   try{
    const now=profile(p);
    const unpaid=now.sg_last_econ_txn!==tx.id&&now.credits===tx.before&&
     now.orbits===tx.beforeOrbits&&!validateCosmetics(now).owned.includes(bundle.badge);
    if(unpaid){endEconomicTxn(p,tx,true);p.sendMessage('§cBadge purchase canceled without payment.');return false}
   }catch{}
   // Fail closed after an ambiguous profile write; never refund twice.
   economicTxnReview(p,tx,'Badge-only cosmetic requires reconciliation: '+err);
  }
  p.sendMessage('§cBadge purchase unavailable: '+String(err).slice(0,110));return false;
 }
}
function cosmeticBundleMenu(p,bundle){
 try{validateBundle(bundle)}catch(err){p.sendMessage('§cBadge not ready: '+err);return}
 let current;
 try{current=profile(p)}catch(err){return p.sendMessage('§cCould not read balance: '+err)}
 const owned=validateCosmetics(current).owned.includes(bundle.badge);
 const available='§eCredits: '+current.credits.toLocaleString()+' / '+bundle.price.toLocaleString()+
  '  §5Orbits: '+current.orbits.toLocaleString()+' / '+bundle.orbitPrice;
 const price=bundle.price.toLocaleString()+' Credits',orbits=bundle.orbitPrice+' Orbit';
 form(p,'PRO SHOP · '+bundle.name,
  '§b'+COSMETIC_BADGES[bundle.badge].perk+' while on. Switch it in My Cosmetics.\n'+
  available+'\n§7Pay '+price+' or '+orbits+' (10% Orbit savings).\n'+
  (owned?'§aAlready owned. Open My Cosmetics to manage it.':'§7Permanent emblem unlock.'),
  owned?['Open My Cosmetics','Back']:['Buy with Credits','Buy with Orbits','Back'],i=>{
   if(owned)return i===0?myCosmetics(p,proShopBadges):proShopBadges(p);
   if(i===2)return proShopBadges(p);
   const withOrbit=i===1,cost=withOrbit?bundle.orbitPrice:bundle.price;
   let fresh;try{fresh=profile(p)}catch(err){return p.sendMessage('§cCould not read your wallet: '+err)}
   if((withOrbit?fresh.orbits:fresh.credits)<cost){
    p.sendMessage('§eNot enough '+(withOrbit?'Orbits':'Credits')+'. You need '+
     (cost-(withOrbit?fresh.orbits:fresh.credits)).toLocaleString()+' more. No purchase was attempted.');
    return menuAgain(p,()=>cosmeticBundleMenu(p,bundle));
   }
   showUI(p,skyMessage().title('Confirm Badge Unlock').body(bundle.name+'\n'+
    (withOrbit?orbits:price)+'\nPermanent emblem with a toggleable perk.').button1('Cancel').button2('Purchase')).then(r=>{
    if(!r.canceled&&r.selection===1)purchaseCosmeticBundle(p,bundle,withOrbit);
    menuAgain(p,()=>proShopBadges(p));
   }).catch(err=>p.sendMessage('§cBadge confirmation failed: '+err));
  });
}
// Four-piece Elite armor requires multiple verified slots, unlike one-piece
// Elytra. Use a journal and lock ambiguous deliveries for operator review.
function purchaseOrbitArmor(p,item){
 let tx,delivery=[];
 try{
  if(!item||item.lines?.length!==4||!Number.isSafeInteger(item.orbitPrice))throw Error('Unknown Orbit armor SKU');
  exactOrbitQuote(item.price,item.orbitPrice);
  if(creativeEconomyBlocked(p))throw Error('Creative inventory requires operator clearance');
  const inv=inventory(p),first=profile(p);
  if(!inv||first.orbits<item.orbitPrice)throw Error('Insufficient Orbits or unavailable inventory');
  const free=[];for(let i=0;i<inv.size;i++)if(inv.getItem(i)===undefined)free.push(i);
  if(free.length<4)throw Error('Requires four empty inventory slots');
  delivery=item.lines.map((line,i)=>{
   if(line.count!==1||!line.enchantments)throw Error('Unsupported armor set');
   const stack=new ItemStack(line.id,1);enchantProItem(stack,line.enchantments);
   if(!hasProEnchantments(stack,line.enchantments))throw Error('Enchantment verification failed');
   return {slot:free[i],item:stack,enchants:line.enchantments};
  });
  tx=beginEconomicTxn(p,'buy',{currency:'orbits',beforeOrbits:first.orbits,
   sku:item.name,armorSet:true,cost:item.orbitPrice,slots:delivery.map(v=>[v.slot,v.item.typeId])});
  const fresh=profile(p);
  if(fresh.orbits!==tx.beforeOrbits||fresh.orbits<item.orbitPrice)throw Error('Orbit balance changed');
  for(const x of delivery)if(inv.getItem(x.slot)!==undefined)throw Error('Destination occupied');
  fresh.orbits-=item.orbitPrice;fresh.sg_last_econ_txn=tx.id;save(p,fresh);
  for(const x of delivery){
   if(inv.getItem(x.slot)!==undefined)throw Error('Delivery slot changed');
   inv.setItem(x.slot,x.item);
   const actual=inv.getItem(x.slot);
   if(actual?.typeId!==x.item.typeId||actual.amount!==1||!hasProEnchantments(actual,x.enchants))throw Error('Armor delivery or enchantments incorrect');
  }
  endEconomicTxn(p,tx,true);
  p.sendMessage('§aPurchased '+item.name+' for '+item.orbitPrice+' Orbits.');return true;
 }catch(err){
  if(tx){
   try{const fresh=profile(p);if(fresh.sg_last_econ_txn!==tx.id&&fresh.orbits===tx.beforeOrbits&&fresh.credits===tx.before&&delivery.every(x=>inventory(p).getItem(x.slot)===undefined)){
    endEconomicTxn(p,tx,true);p.sendMessage('§cArmor purchase canceled without payment.');return false;
   }}catch{}
   economicTxnReview(p,tx,'Armor set purchase needs reconciliation: '+err);
  }
  p.sendMessage('§cArmor purchase unavailable: '+String(err).slice(0,110));return false;
 }
}
function proShop(p){
 navForm(p,'§6PRO SHOP',
  'Choose gear, utility items, or permanent emblems.\n§7Orbit checkout saves 10% at the wallet exchange rate.',
  [['Wings / Elytra',p=>proShopCatalog(p,'wings')],
   ['Elite Armor Sets',p=>proShopCatalog(p,'armor')],
   ['Emblems',proShopBadges],
   ['Utility Items & Sell-All Chest',p=>proShopCatalog(p,'utility')],
   ['My Cosmetics',p=>myCosmetics(p,proShop)]],skyMenuShops);
}
function proShopBadges(p){
 const bundles=APPROVED_COSMETIC_BUNDLES;
 navForm(p,'§dEMBLEMS',
  'Each emblem has a perk you can switch on or off in My Cosmetics.\n20,000,000 Credits or 1 Orbit each.',
  bundles.map(bundle=>[bundle.name+' · 20M Credits / 1 Orbit',p=>cosmeticBundleMenu(p,bundle)]),proShop);
}
function proShopCatalog(p,category){
 const valid=PRO_SHOP.filter(item=>item.lines.every(({id})=>ItemTypes.get(id)));
 const items=valid.filter(item=>category==='wings'?item.name.includes('Elytra'):
  category==='armor'?item.lines.length===4:category==='utility'&&item.lines.length!==4&&!item.name.includes('Elytra'));
 const title=category==='wings'?'WINGS / ELYTRA':category==='armor'?'ELITE ARMOR':'UTILITY ITEMS';
 const priceLabel=item=>item.price.toLocaleString()+' Credits'+(item.orbitPrice?' or '+item.orbitPrice+' Orbits':'');
 const entries=items.map(item=>[item.name+' · '+priceLabel(item),p=>proShopItem(p,item,category)]);
 if(category==='utility'){
  entries.push(['Sell-All Chest · 55,000 Credits',p=>{
   showUI(p,skyMessage().title('Buy Sell-All Chest').body('55,000 Credits for one owner-bound chest license. Items sell on close; unsellable contents remain.').button1('Cancel').button2('Buy')).then(r=>{
    if(!r.canceled&&r.selection===1)purchaseSellChest(p);
    menuAgain(p,()=>proShopCatalog(p,category));
   }).catch(err=>p.sendMessage('§cSell-All Chest confirmation failed: '+err));
  }],['Manage Sell-All Chest',manageSellChest]);
 }
 navForm(p,'§6PRO SHOP · '+title,'§7Review the exact item and currency before confirming.\n§eCredits: '+profile(p).credits.toLocaleString()+'  §5Orbits: '+profile(p).orbits.toLocaleString(),entries,proShop);
}
function proShopItem(p,item,category){
 const price=item.price.toLocaleString()+' Credits';
 const gear=item.lines.map(line=>line.id.split(':').at(-1).replaceAll('_',' ')+(line.enchantments?' • '+line.enchantments.map(([id,level])=>id+' '+level).join(', '):''));
 let approvedOrbits=false;
 if(item.orbitPrice){
  try{exactOrbitQuote(item.price,item.orbitPrice);approvedOrbits=true}
  catch(err){console.warn('[SkyGen PRO SHOP] Inconsistent Orbit quote '+item.name+': '+err)}
 }
 const actions=approvedOrbits?['Buy with Credits','Buy with Orbits','Back']:['Buy with Credits','Back'];
 form(p,'PRO SHOP · '+item.name,price+(approvedOrbits?' or '+item.orbitPrice+' Orbits':'')+'\n'+gear.join('\n')+'\n'+
  (approvedOrbits?'Orbit checkout saves exactly 10% versus Credit payment at the wallet exchange rate.':'No approved Orbit price for this item.'),actions,choice=>{
  if(choice>=actions.length-1)return proShopCatalog(p,category);
  const withOrbit=approvedOrbits&&choice===1;
  showUI(p,skyMessage().title('Confirm Pro Shop Purchase').body(item.name+'\n'+(withOrbit?item.orbitPrice+' Orbits':price)+'\n'+gear.join('\n')).button1('Cancel').button2('Buy')).then(r=>{
   if(!r.canceled&&r.selection===1){
    if(withOrbit){if(item.lines.length===4)purchaseOrbitArmor(p,item);else purchaseOrbitItem(p,item)}
    else if(buyShopItems(p,item.lines,item.price))p.sendMessage('§aPurchased '+item.name+' for '+price+'.');
   }
   menuAgain(p,()=>proShopCatalog(p,category));
  }).catch(err=>p.sendMessage('§cPro Shop purchase failed: '+err));
 });
}

function foodShop(p){shopCatalog(p,true,'food')}
function farmingShop(p){
 form(p,'FARMING SHOP','Buy farm supplies or sell eligible harvests for Credits.',
  ['Buy Supplies','Sell Harvest','Back'],i=>{
   if(i===2)return skyMenuShops(p);
   shopCatalog(p,i===0,'farming');
  });
}
function shop(p){
 form(p,'§6SERVER SHOP','Buy goods or sell eligible items from your inventory.',
  ['Buy','Sell From Inventory','Back'],i=>{
   if(i===2)return skyMenuShops(p);
   shopCatalog(p,i===0);
  });
}
function shopCatalog(p,buying,catalog='server'){
 const food=catalog==='food',farming=catalog==='farming';
 const returnShop=()=>food?skyMenuShops(p):farming?farmingShop(p):shop(p);
 const groupMap=farming?Object.fromEntries(Object.entries(FARMING_SHOP).map(([category,items])=>
  [category,items.filter(item=>ItemTypes.get(item.id)&&(buying?item.buy>0:item.sell>0))])):
  food?Object.fromEntries(FOOD_CATEGORIES.map(category=>[category,FOOD_SHOP.filter(item=>item.category===category)])):
  {Starter:[...SHOP.slice(0,2),...SHOP.filter(item=>item.category==='Starter')],
   Ores:[...SHOP.slice(2,4),...SHOP.filter(item=>item.category==='Ores')],
   Nether:SHOP.filter(item=>item.category==='Nether'),Endgame:SHOP.filter(item=>item.category==='Endgame')};
 if(catalog==='server'&&!buying){
  const serverIds=new Set(SHOP.map(item=>item.id));
  groupMap.Food=FOOD_SHOP.filter(item=>!serverIds.has(item.id));
 }
 function showCategories(){
  const groups=Object.entries(groupMap).map(([name,items])=>
   [name,items.filter(item=>buying||countShopInventory(p,item.id)>0)]).filter(([,items])=>items.length);
  const title=farming?(buying?'BUY FARM SUPPLIES':'SELL HARVEST'):food?'FOOD SHOP':buying?'BUY ITEMS':'SELL FROM INVENTORY';
  const actions=groups.map(([name,items])=>[`${name} (${items.length})`,()=>showPage(name,0)]);
  if(buying&&farming)actions.push(['Saplings',()=>districtShopMenu(p,'saplings',showCategories)]);
  if(buying&&catalog==='server')actions.push(['Armor Trims',()=>districtShopMenu(p,'trims',showCategories)]);
  actions.push(['Back',returnShop]);
  form(p,title,actions.length>1?'Choose a category.':'No eligible items in your inventory.',
   actions.map(([label])=>label),i=>actions[i]?.[1]());
 }
 function showPage(category,page){
  const items=groupMap[category].filter(item=>buying||countShopInventory(p,item.id)>0);
  if(!items.length)return showCategories();
  const last=Math.ceil(items.length/8)-1;
  page=Math.min(page,last);
  const slice=items.slice(page*8,page*8+8);
  const actions=slice.map(item=>[
   `${item.name} · ${buying?item.buy:item.sell} Credits / ${item.count}${buying?'':' · Owned: '+countShopInventory(p,item.id)}`,
   ()=>shopQuantity(p,item,buying,()=>showPage(category,page))
  ]);
  if(page>0)actions.push(['Previous Page',()=>showPage(category,page-1)]);
  if(page<last)actions.push(['Next Page',()=>showPage(category,page+1)]);
  actions.push(['Back',showCategories]);
  form(p,buying?'BUY ITEMS':'SELL ITEMS',`${category} · Page ${page+1}/${last+1}`,
   actions.map(([label])=>label),i=>actions[i]?.[1]());
 }
 showCategories();
}
function shopQuantity(p,item,buying,returnToList){
 const stay=()=>menuAgain(p,returnToList);
 const confirm=(count)=>{
  const d=profile(p),total=shopTotal(item,buying,count,d);
  if(total<1||!Number.isSafeInteger(total)||total>2000000000){
   p.sendMessage('§cTransaction price must be at least 1 Credit and within wallet limits.');return stay();
  }
  const ui=skyMessage().title('Confirm Shop Transaction')
   .body(`${buying?'Buy':'Sell'} ${count} × ${item.id}\n${total} Credits`).button1('Back').button2('Confirm');
  showUI(p,ui).then(r=>{
   if(r.canceled)return;
   try{
    if(r.selection!==1)return;
    if(shopTotal(item,buying,count,profile(p))!==total)return p.sendMessage('§eThe price changed. Open a new quote.');
    if(!buying&&count>countShopInventory(p,item.id))return p.sendMessage('§cInventory changed. Open a new quote.');
    const success=buying?buyShopItems(p,[{id:item.id,count}],total):safeShopSell(p,{id:item.id,count,sell:total});
    if(success)p.sendMessage(`§a${buying?'Purchased':'Sold'} ${count} × ${item.id} for ${total} Credits.`);
   }finally{stay()}
  }).catch(e=>p.sendMessage('§cShop confirmation failed: '+e));
 };
 const custom=()=>{
  const max=buying?2304:countShopInventory(p,item.id);
  const ui=skyModal().title(buying?'Buy Quantity':'Sell Quantity')
   .textField('Enter a quantity (1–'+max+')','16',{defaultValue:String(Math.min(16,max))});
  showUI(p,ui).then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();
   const count=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   if(!Number.isSafeInteger(count)||count<1||count>max||(!buying&&count>countShopInventory(p,item.id))){
    p.sendMessage('§cEnter a whole quantity within the available limit.');return stay();
   }
   confirm(count);
  }).catch(e=>p.sendMessage('§cShop quantity failed: '+e));
 };
 if(buying)return custom();
 form(p,'SELL QUANTITY',`${item.id} · Eligible inventory: ${countShopInventory(p,item.id)}`,
  ['Custom Amount','Sell All','Back'],i=>{
   if(i===0)return custom();
   if(i===1)return confirm(countShopInventory(p,item.id));
   if(i===2)return stay();
  });
}
function wallet(p){
 const d=profile(p);
 form(p,'§eWALLET',`Credits: ${d.credits}\nOrbits: ${d.orbits}\nExchange: ${C.exchange} Credits = 1 Orbit`,['Convert Credits to Orbits','Back'],i=>{
  if(i===1)return skyMenuBankWallet(p);
  if(i!==0)return;
  try{recoverEconomicTxn(p);if(readEconomicTxn(p))return p.sendMessage('§cWallet conversion locked pending transaction review.')}catch(e){return p.sendMessage('§cTransaction recovery: '+e)}
  const latest=profile(p),max=Math.floor(Number(latest.credits||0)/C.exchange);
  const ui=skyModal().title('§eEXCHANGE CREDITS')
   .textField('How many Orbits do you want? (Max affordable: '+max+')','Enter whole number',{defaultValue:'1'});
  adminShow(p,ui,'exchange quantity',0,false).then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();
   const count=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   const cost=count*C.exchange;
   if(!Number.isSafeInteger(count)||!Number.isSafeInteger(cost)||count<1||cost>2000000000)
    return p.sendMessage('§cEnter a valid whole number of Orbits.');
   const now=profile(p);
   if(!Number.isSafeInteger(Number(now.credits))||now.credits<cost)
    return p.sendMessage('§cInsufficient Credits. Need '+cost+', have '+now.credits+'.');
   if(!Number.isSafeInteger(Number(now.orbits))||now.orbits+count>2000000000)
    return p.sendMessage('§cOrbit wallet limit exceeded.');
   const confirm=skyMessage().title('§eCONFIRM EXCHANGE')
    .body('Receive: '+count+' Orbits\nCost: '+cost+' Credits\nRemaining Credits: '+(now.credits-cost))
    .button1('Cancel').button2('Confirm Exchange');
   adminShow(p,confirm,'exchange confirmation',0,false).then(c=>{
    if(c.canceled)return;
    if(c.selection!==1)return menuAgain(p,()=>wallet(p));
    try{
     const fresh=profile(p);
     if(!Number.isSafeInteger(Number(fresh.credits))||fresh.credits<cost)
      return p.sendMessage('§cInsufficient Credits; exchange canceled.');
     if(!Number.isSafeInteger(Number(fresh.orbits))||fresh.orbits+count>2000000000)
      return p.sendMessage('§cOrbit wallet limit exceeded; exchange canceled.');
     fresh.credits-=cost;fresh.orbits+=count;save(p,fresh);
     p.sendMessage('§aExchanged '+cost+' Credits for '+count+' Orbits.');
    }catch(e){p.sendMessage('§cExchange failed: '+e)}finally{menuAgain(p,()=>wallet(p))}
   }).catch(e=>p.sendMessage('§cExchange confirmation error: '+e));
  }).catch(e=>p.sendMessage('§cExchange quantity form error: '+e));
 });
}
// One 10-button entry menu; each section has 100 selectable rank rows.
// A 100-button list is only constructed for the selected section, not for all 1,000 ranks.
function ranks(p){
 const d=profile(p),progress=parseProgress(d.xpProgress),next=d.rank>=MAX_RANK?null:transitionCost(d.rank);
 const remaining=next===null?null:next>progress?next-progress:0n;
 const choices=Array.from({length:10},(_,i)=>'Ranks '+(i*100+1)+'–'+((i+1)*100));
 form(p,'§dRANK CODEX',`Current: ${d.rank}/${MAX_RANK} — ${rankName(d.rank)}\nXP: ${formattedXP(progress)} / ${next===null?'MAX':formattedXP(next)}\nTo Next: ${remaining===null?'MAX':formattedXP(remaining)}\nSkill Points available: ${skillAvailable(d)}\nSelect a group to browse its 100 ranks.`,[...choices,'Back'],i=>{
  if(i===10)return skyMenuRanksSkills(p);
  if(i>=0&&i<10)return rankGroup(p,i);
 });
}
function rankGroup(p,group){
 if(!Number.isInteger(group)||group<0||group>9)return ranks(p);
 const start=group*100+1,end=start+99,current=profile(p).rank;
 const buttons=Array.from({length:100},(_,i)=>{
  const n=start+i,req=n===MAX_RANK?'MAX RANK':formattedXP(transitionCost(n))+' XP';
  const status=n<current?'§a✓ ':n===current?'§e➤ ':'§7';
  return status+'#'+n+' '+rankName(n)+' §8• '+req;
 });
 form(p,'§dRANKS '+start+'–'+end,'Select any rank to view its requirements. Scroll to see all 100 ranks.',[...buttons,'Back to Rank Codex'],i=>{
  if(i===100)return ranks(p);
  if(i>=0&&i<100)return rankDetails(p,start+i,group);
 });
}
function rankDetails(p,n,group){
 if(!Number.isSafeInteger(n)||n<1||n>MAX_RANK)return rankGroup(p,group);
 const d=profile(p),currentXP=cumulativeXP(d.rank,d.xpProgress);
 const required=cumulativeXP(n,'0');
 const toReach=required>currentXP?required-currentXP:0n;
 const next=n===MAX_RANK?null:transitionCost(n);
 const status=n<d.rank?'Completed':n===d.rank?'Current rank':'Locked';
 form(p,'§dRANK '+n+' — '+rankName(n),
  'Status: '+status+'\nXP to reach this rank: '+formattedXP(required)+
  '\nRemaining XP to reach: '+formattedXP(toReach)+
  '\nXP to next rank: '+(next===null?'MAX RANK':formattedXP(next))+
  '\nCurrent rank: '+d.rank+' — '+rankName(d.rank),
  ['Back to Ranks '+(group*100+1)+'–'+((group+1)*100),'Back to Rank Codex'],i=>{
   if(i===0)return rankGroup(p,group);
   if(i===1)return ranks(p);
  });
}
function teleports(p){form(p,'§bTELEPORTS','All teleports have a 5-second stand-still warmup and 5-second cooldown.',['Go to Spawn','Go to Plot','Back'],i=>{if(i===0)safeSpawnTravel(p);if(i===1)tpPlot(p);if(i===2)skyMenuTravelVisitors(p)})}
// Only these ordinary materials can be reconstructed by type without losing
// enchantments, damage, or other complex item data. Legacy unknown items are
// quarantined, not sold as replacements.
const MARKET_COMMODITIES=new Set([
 'minecraft:cobblestone','minecraft:stone','minecraft:dirt','minecraft:grass_block',
 'minecraft:oak_log','minecraft:oak_planks','minecraft:spruce_log','minecraft:birch_log',
 'minecraft:iron_ingot','minecraft:gold_ingot','minecraft:copper_ingot',
 'minecraft:coal','minecraft:charcoal','minecraft:diamond','minecraft:emerald',
 'minecraft:redstone','minecraft:lapis_lazuli','minecraft:quartz',
 'minecraft:coal_ore','minecraft:iron_ore','minecraft:gold_ore',
 'minecraft:diamond_ore','minecraft:emerald_ore',
 'minecraft:obsidian','minecraft:deepslate','minecraft:gravel','minecraft:sand'
]);
for(const item of SHOP)MARKET_COMMODITIES.add(item.id);
for(const g of GENS)MARKET_COMMODITIES.add(g.block);
const MARKET_LOCK=new Set();
function marketLock(id,fn){
 if(MARKET_LOCK.has(id))return false;
 MARKET_LOCK.add(id);
 try{return fn()}catch(e){console.warn('[SkyGen MARKET] operation failed '+e);return false}
 finally{MARKET_LOCK.delete(id)}
}
function validListing(l){return !!l&&typeof l==='object'&&typeof l.id==='string'&&l.id.length>0&&typeof l.seller==='string'&&l.seller.length>0&&typeof l.type==='string'&&Number.isSafeInteger(l.count)&&l.count>=1&&l.count<=64&&Number.isSafeInteger(l.price)&&l.price>0&&l.price<=2000000000}
function marketPlain(it){
 try{
  // Marketplace reconstructs by type+quantity only. Reject all optional item
  // metadata that would otherwise disappear on purchase or cancellation.
  return !!it&&MARKET_COMMODITIES.has(it.typeId)&&it.amount>=1&&it.amount<=64&&
   !it.nameTag&&!it.keepOnDeath&&it.lockMode===ItemLockMode.none&&
   (!it.getLore||it.getLore().length===0)&&
   (!it.getCanPlaceOn||it.getCanPlaceOn().length===0)&&
   (!it.getCanDestroy||it.getCanDestroy().length===0)&&
   plainCommerceMetadata(it);
 }catch(e){return false}
}
// Seller payout queue: each entry has a unique, increasing sequence number.
// The paid watermark is saved in the SAME player profile write as the Credits.
// Clearing the world queue afterward can fail without issuing duplicate Credits.
function sellerQueueKey(id){return 'sg_proceeds_v2_'+id}
function sellerSeqKey(id){return 'sg_proceeds_seq_'+id}
function queueSellerPayout(seller,listingId,price){
 if(!Number.isSafeInteger(price)||price<=0||price>2000000000)throw Error('Invalid proceeds amount');
 const key=sellerQueueKey(seller),raw=world.getDynamicProperty(key);
 let queue=raw===undefined||raw===null?[]:JSON.parse(String(raw));
 if(!Array.isArray(queue))throw Error('Invalid seller proceeds queue');
 if(queue.some(x=>x.id===listingId))return true; // retry cannot enqueue twice
 const seq=Number(world.getDynamicProperty(sellerSeqKey(seller))||0);
 if(!Number.isSafeInteger(seq)||seq<0||seq>=2000000000)throw Error('Seller settlement sequence exhausted');
 const entry={id:listingId,seq:seq+1,price};
 const value=JSON.stringify([...queue,entry]);
 if(value.length>24000)throw Error('Seller payout queue capacity reached; operator review');
 world.setDynamicProperty(sellerSeqKey(seller),seq+1);
 if(world.getDynamicProperty(sellerSeqKey(seller))!==seq+1)throw Error('Payout sequence write failed');
 world.setDynamicProperty(key,value);
 if(world.getDynamicProperty(key)!==value)throw Error('Seller payout queue verification failed');
 return true;
}
function settleSellerProceeds(p,d){
 const legacyKey='sg_proceeds_'+p.id,legacy=Number(world.getDynamicProperty(legacyKey)||0);
 const key=sellerQueueKey(p.id),raw=world.getDynamicProperty(key);
 if(!legacy&&(raw===undefined||raw===null||raw==='[]'))return 0;
 assertBankUnlocked(p);
 let paid=0;
 if(legacy>0){
  if(!Number.isSafeInteger(legacy)||legacy>CREDIT_CAP)throw Error('Invalid legacy seller proceeds');
  if(!d.marketLegacyProceedsApplied){
   const destination=payoutDestination(d,legacy);
   if(destination===undefined){p.sendMessage('§eSale Credits pending. '+noPayoutRoom(d,legacy));return 0;}
   creditPayout(d,destination,legacy);
   d.marketLegacyProceedsApplied=true;
   save(p,d);
   paid+=legacy;
  }
  world.setDynamicProperty(legacyKey,0);
  if(world.getDynamicProperty(legacyKey)!==0)throw Error('Legacy proceeds clear not verified');
 }
 if(raw!==undefined&&raw!==null){
  const entries=JSON.parse(String(raw));
  if(!Array.isArray(entries)||entries.some(entry=>!entry||!Number.isSafeInteger(entry.seq)||entry.seq<1||
     !Number.isSafeInteger(entry.price)||entry.price<1||entry.price>CREDIT_CAP))throw Error('Invalid seller payout list');
  entries.sort((a,b)=>a.seq-b.seq);
  let watermark=Number(d.marketPayoutSeq||0);
  for(const entry of entries){
   if(entry.seq<=watermark)continue;
   const destination=payoutDestination(d,entry.price);
   if(destination===undefined){
    p.sendMessage('§eSale Credits pending. '+noPayoutRoom(d,entry.price));
    break;
   }
   creditPayout(d,destination,entry.price);
   d.marketPayoutSeq=entry.seq;
   save(p,d); // Balance and replay marker persist together.
   watermark=entry.seq;
   paid+=entry.price;
  }
  const value=JSON.stringify(entries.filter(x=>x.seq>watermark));
  if(value!==raw){
   world.setDynamicProperty(key,value);
   if(world.getDynamicProperty(key)!==value)throw Error('Seller payout cleanup needs review (safe to retry)');
  }
 }
 if(paid)p.sendMessage('§aMarketplace sales collected: '+paid+' Credits.');
 return paid;
}
function securityReviewCommand(actor){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 try{
  const ids=world.getDynamicPropertyIds();let flagged=0;
  for(const key of ids){
   if(key.startsWith('sg_token_')&&key!==TOKEN_SEQ_KEY){
    let r;try{r=JSON.parse(String(world.getDynamicProperty(key)))}catch{}
    if(!r||['pending','redeeming','review'].includes(r.status)){
     flagged++;if(flagged<=20)actor.sendMessage('§eTOKEN '+key+' '+String(r?.status||'corrupt')+' owner='+String(r?.owner||'?')+' '+String(r?.reason||''));
    }
   }else if(key.startsWith('sg_trade_review_')){
    flagged++;if(flagged<=20)actor.sendMessage('§cTRADE '+key+' '+String(world.getDynamicProperty(key)).slice(0,130));
   }
  }
  actor.sendMessage('§eSkyGen security review: '+flagged+' flagged records (showing first 20). Review logs and player inventories before changing them.');
 }catch(err){actor.sendMessage('§cSecurity records unavailable: '+String(err).slice(0,100))}
}
function marketReviewCommand(actor){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 const flagged=marketRead().filter(l=>l.status==='review'||l.status==='reserved'||l.status==='returning'||l.status==='creating'||l.status==='sold');
 actor.sendMessage('§eSkyGen market transactions needing review: '+flagged.length);
 for(const l of flagged.slice(0,25))actor.sendMessage('§6'+l.id+' §7'+l.status+' seller='+l.sellerName+' buyer='+(l.buyer||'none')+' '+l.type+' ×'+l.count+' Credits='+l.price+' '+String(l.reviewReason||''));
}
function marketRecover(){
 const records=marketRead();let dirty=false;
 for(const l of records){
  if(!l||typeof l!=='object')throw Error('Invalid market entry; refusing to modify saved marketplace without manual backup');
  if(!validListing(l)||!MARKET_COMMODITIES.has(l.type)){
   if(l.status!=='review'){l.status='review';l.reviewReason='Legacy/unsupported item; do not reconstruct metadata';dirty=true}
  }else if(['reserved','sold','returning','creating'].includes(l.status)){
   l.reviewReason='Interrupted '+l.status+' transaction; operator must reconcile inventory and wallet';l.status='review';dirty=true;
  }
 }
 if(dirty){try{marketSave(records)}catch(e){console.warn('[SkyGen MARKET] recovery markers could not save '+e)}}
}
system.runTimeout(()=>{try{marketRecover()}catch(e){console.warn('[SkyGen MARKET] Recovery blocked; data preserved '+e)}},60);
function market(p){
 const d=profile(p),all=marketRead(),reviews=all.filter(l=>l.status==='review').length;
 form(p,'§6PLAYER MARKET',`Active listings: ${all.filter(l=>!l.status||l.status==='active').length}/${MAX_LISTINGS}\nCredits: ${d.credits}\nRestricted to plain commodity items.${reviews?'\n§c'+reviews+' listing(s) need operator review.':''}`,
 ['Browse Listings','List an Item','My Listings / Cancel','Back'],i=>{if(i===0)marketBrowse(p);if(i===1)marketCreate(p);if(i===2)marketMine(p);if(i===3)skyMenuShops(p)});
}
function marketCreate(p){
 if(creativeEconomyBlocked(p))return p.sendMessage('§cCreative inventory cannot enter the Marketplace.');
 const choices=itemChoices(p).filter(x=>marketPlain(x.it));
 if(!choices.length){p.sendMessage('§cNo ordinary supported commodity items to list.');return menuAgain(p,()=>market(p));}
 form(p,'LIST COMMODITY','Only plain, unlocked commodity stacks are eligible.',
  [...choices.map(x=>`${x.it.typeId} ×${x.it.amount}`),'Back'],i=>{
  if(i>=choices.length)return market(p);
  const x=choices[i];const ui=skyModal().title('Set Listing Price').textField('Credits (1–2,000,000,000)','Example: 1000');
  showUI(p,ui).then(r=>{
   if(r.canceled)return;
   const raw=String(r.formValues?.[0]??'').trim();const price=/^[1-9][0-9]*$/.test(raw)?Number(raw):NaN;
   if(!Number.isSafeInteger(price)||price>2000000000){p.sendMessage('§cInvalid whole-number listing price.');return menuAgain(p,()=>marketCreate(p));}
   try{marketLock('market',()=>{
    if(creativeEconomyBlocked(p))return p.sendMessage('§cCreative inventory cannot enter the Marketplace.');
    let all=marketRead();if(all.filter(l=>!l.status||l.status==='active').length>=MAX_LISTINGS)return p.sendMessage('§cMarket active listing capacity reached.');
    if(all.filter(l=>l.seller===p.id&&(!l.status||l.status==='active')).length>=5)return p.sendMessage('§cYou may have at most five active listings.');
    const it=inventory(p)?.getItem(x.slot);
    if(!marketPlain(it)||it.typeId!==x.it.typeId||it.amount!==x.it.amount)return p.sendMessage('§cItem changed. Try again.');
    const stack=it.clone(),id=p.id+':'+system.currentTick+':'+Math.floor(Math.random()*100000);
    const listing={id,seller:p.id,sellerName:p.name,type:it.typeId,count:it.amount,price,status:'creating'};
    try{marketSave([...all,listing])}catch(e){return p.sendMessage('§cMarketplace storage unavailable; item retained.')} 
    try{
     if(!removeExact(p,x.slot,it.typeId,it.amount))throw Error('Item changed during escrow');
    }catch(e){
     // setItem can throw AFTER a partial write. Never erase the escrow proof
     // when removal status is uncertain: that would permanently lose items.
     try{
      const entries=marketRead(),record=entries.find(l=>l?.id===id);
      if(record){record.status='review';record.reviewReason='Escrow item removal uncertain; inspect inventory before restoring or clearing';marketSave(entries)}
     }catch(err){console.warn('[SkyGen MARKET] escrow review marker failed '+err)}
     console.warn('[SkyGen MARKET] ESCROW REVIEW '+id+' '+e);
     return p.sendMessage('§cListing escrow requires operator review. Do not retry this listing. ID: '+id);
    }
    all=marketRead();const record=all.find(l=>l.id===id);
    if(!record){console.warn('[SkyGen MARKET] CRITICAL: escrow record disappeared '+id);return p.sendMessage('§cEscrow needs operator review: '+id)}
    record.status='active';
    try{marketSave(all);p.sendMessage('§aCommodity listed and securely escrowed.')}
    catch(e){
     // Do not place item back into inventory if storage state is uncertain,
     // because another process could still see the active listing.
     console.warn('[SkyGen MARKET] CRITICAL: listing activation failed '+id+' '+e);
     p.sendMessage('§cEscrow pending review; contact an operator with listing '+id);
    }
   });}finally{menuAgain(p,()=>market(p))}
  }).catch(e=>p.sendMessage('§cListing UI error: '+e));
 });
}
function marketBrowse(p){
 const a=marketRead().filter(validListing).filter(l=>(!l.status||l.status==='active')&&MARKET_COMMODITIES.has(l.type));
 if(!a.length)return form(p,'MARKET','No available commodity listings.',['Back'],()=>market(p));
 form(p,'§6BUY COMMODITIES','Select a listing to purchase.',[...a.map(x=>`${x.type} ×${x.count} — ${x.price} Credits (${x.sellerName})`),'Back'],i=>{
  if(i>=a.length)return market(p);
  const listing=a[i];if(listing.seller===p.id){p.sendMessage('§eCannot buy your own listing.');return menuAgain(p,()=>marketBrowse(p));}
  showUI(p,skyMessage().title('Confirm Purchase').body(`${listing.type} ×${listing.count}\nCost: ${listing.price} Credits`).button1('Cancel').button2('Buy')).then(r=>{
   if(r.canceled)return;
   if(r.selection!==1)return menuAgain(p,()=>marketBrowse(p));
   try{marketLock('market',()=>{
    const all=marketRead(),idx=all.findIndex(l=>l.id===listing.id&&(!l.status||l.status==='active'));
    if(idx<0)return p.sendMessage('§cListing unavailable.');
    const l=all[idx];if(!validListing(l)||!MARKET_COMMODITIES.has(l.type))return p.sendMessage('§cListing needs operator review.');
    const d=profile(p);if(d.credits<l.price)return p.sendMessage('§cNot enough Credits.');
    const stack=new ItemStack(l.type,l.count);if(!inventoryCapacity(p,stack))return p.sendMessage('§cFree inventory space first.');
    l.status='reserved';l.buyer=p.id;l.buyerName=p.name;
    try{marketSave(all)}catch(e){return p.sendMessage('§cCannot reserve listing; no payment taken.')} 
    try{d.credits-=l.price;save(p,d)}catch(e){
     l.status='review';l.reviewReason='Buyer debit status uncertain; operator review required';
     try{marketSave(all)}catch{}return p.sendMessage('§cPayment error; operator review required. No automatic retry.');
    }
    try{if(inventory(p).addItem(stack))throw Error('Inventory capacity changed during delivery')}
    catch(e){
     l.status='review';l.reviewReason='Buyer charged; item delivery uncertain. Check inventory before any refund';
     try{marketSave(all)}catch{}return p.sendMessage('§cDelivery requires operator review. Do not repurchase listing.');
    }
    l.status='sold';
    try{marketSave(all)}catch(e){return p.sendMessage('§cItem delivered; seller settlement requires operator review.')} 
    try{
     queueSellerPayout(l.seller,l.id,l.price);
     // Delete the sold listing only after the settlement is in the verified queue.
     marketSave(marketRead().filter(x=>x.id!==l.id));
     p.sendMessage('§aPurchase complete!');
     const seller=world.getAllPlayers().find(q=>q.id===l.seller);
     if(seller){
      try{settleSellerProceeds(seller,profile(seller));}
      catch(err){
       console.warn('[SkyGen MARKET] Seller payout #'+l.id+': '+err);
       seller.sendMessage('§eSale Credits are pending. Check Compass → Bank → Collect Pending Payouts.');
      }
     }
    }catch(err){
     console.warn('[SkyGen MARKET] SALE REVIEW: '+l.id+' '+err);
     p.sendMessage('§eDelivered. Seller payment needs operator review; do not rebuy this listing.');
    }
   });}finally{menuAgain(p,()=>marketBrowse(p))}
  }).catch(e=>p.sendMessage('§cPurchase form error: '+e));
 });
}
function marketMine(p){
 const mine=marketRead().filter(l=>l.seller===p.id);
 const active=mine.filter(l=>(!l.status||l.status==='active')&&validListing(l)&&MARKET_COMMODITIES.has(l.type));
 const needsReview=mine.filter(l=>l.status==='review');
 form(p,'MY MARKET LISTINGS',needsReview.length?'§c'+needsReview.length+' item(s) require operator review. Use /scriptevent skygen:marketreview as operator.':'Cancel active listings to recover commodity items.',
 [...active.map(x=>`${x.type} ×${x.count} — ${x.price} Credits`),'Back'],i=>{
  if(i>=active.length)return market(p);
  const selected=active[i];
  marketLock('market',()=>{
   const all=marketRead(),idx=all.findIndex(l=>l.id===selected.id&&l.seller===p.id&&(!l.status||l.status==='active'));
   if(idx<0)return p.sendMessage('§cListing unavailable.');
   const l=all[idx];const stack=new ItemStack(l.type,l.count);
   if(!inventoryCapacity(p,stack))return p.sendMessage('§cFree inventory space first.');
   l.status='returning';try{marketSave(all)}catch(e){return p.sendMessage('§cCould not reserve cancellation.')} 
   try{if(inventory(p).addItem(stack))throw Error('Inventory changed during return')}
   catch(e){
    l.status='review';l.reviewReason='Return delivery uncertain; inspect inventory before reactivation';
    try{marketSave(all)}catch{}return p.sendMessage('§cCancellation needs operator review.');
   }
   try{marketSave(marketRead().filter(x=>x.id!==l.id));p.sendMessage('§aListing cancelled; commodity returned.')}
   catch(e){p.sendMessage('§cReturn delivered; listing cleanup needs operator review.');console.warn('[SkyGen MARKET] return listing cleanup '+l.id+' '+e)}
  });
 });
}
function tradeBusy(p){const t=trades.get(p.id);if(!t)return false;const online=world.getAllPlayers();if(t.closed||system.currentTick-t.created>600||!online.some(x=>x.id===t.a)||!online.some(x=>x.id===t.b)){tradeClose(t,'Expired or abandoned trade cleared.');return false;}return true}
function trade(p){const online=world.getAllPlayers().filter(q=>q.id!==p.id);form(p,'§dDIRECT TRADING','Select an online player to propose an item-for-item trade. Both must confirm the exact offers.',[...online.map(q=>q.name),'Back'],i=>{if(i>=online.length)return skyMenuShops(p);const q=online[i];if(tradeBusy(p)||tradeBusy(q))return p.sendMessage('§cOne player is already trading. Ask them to cancel or wait up to 30 seconds.');tradeOffer(p,q)})}
const TRADE_ARMOR_NOTICE='Armor that can hold a trim is unavailable in Direct Trading because the trim cannot be verified.';
function tradeCanVerifyTrim(item){return !!item&&!item.hasTag('minecraft:trimmable_armors')}
function eligibleTradeItem(item){
 // These item types can carry inventory or other state the trade cannot verify.
 if(/(?:shulker_box|bundle|_bucket|_boat|_raft|_minecart|written_book|writable_book|filled_map|firework_rocket|firework_star|ominous_bottle|banner|decorated_pot)$/.test(item?.typeId??''))return false;
 try{
  return tradeCanVerifyTrim(item)&&!item.nameTag&&!item.keepOnDeath&&item.lockMode===ItemLockMode.none&&
   (!item.getLore||item.getLore().length===0)&&
   // Trade cannot promise preservation of opaque data it cannot fingerprint.
   typeof item.getDynamicPropertyIds==='function'&&item.getDynamicPropertyIds().length===0;
 }catch{return false}
}
function tradeGearDetails(item){
 const enchantable=item.getComponent('minecraft:enchantable');
 const durability=item.getComponent('minecraft:durability');
 const dyeable=item.getComponent('minecraft:dyeable');
 const dye=dyeable?.color;
 const potion=item.getComponent('minecraft:potion');
 return {
  enchantments:enchantable?.getEnchantments().map(({type,level})=>type.id+' '+level).sort()??[],
  durability:durability?[durability.damage,durability.maxDurability]:null,
  dye:dye?[dye.red,dye.green,dye.blue]:null,
  potion:potion?[potion.potionDeliveryType.id,potion.potionEffectType.id]:null,
  canPlaceOn:typeof item.getCanPlaceOn==='function'?item.getCanPlaceOn().slice().sort():[],
  canDestroy:typeof item.getCanDestroy==='function'?item.getCanDestroy().slice().sort():[]
 };
}
const TRADE_RESERVATION_LORE='§8Reserved for Direct Trading ';
let tradeSequence=0;
function tradeReservation(item){
 if(item?.lockMode!==ItemLockMode.slot)return;
 const marker=item.getLore()[0];
 if(marker?.startsWith(TRADE_RESERVATION_LORE))return marker.slice(TRADE_RESERVATION_LORE.length);
}
function tradeOfferMatches(item,offer){
 return tradeCanVerifyTrim(item)&&item.typeId===offer.type&&item.amount===offer.count&&
  JSON.stringify(tradeGearDetails(item))===JSON.stringify(offer.details);
}
function reserveTradeOffer(p,offer,marker){
 const inv=inventory(p),item=inv?.getItem(offer.slot);
 if(!eligibleTradeItem(item)||!tradeOfferMatches(item,offer))return false;
 // Keep the native stack in its slot. Bedrock's slot lock prevents players
 // from moving it into smithing or swapping hidden item data during review.
 item.setLore([TRADE_RESERVATION_LORE+marker]);
 item.lockMode=ItemLockMode.slot;
 inv.setItem(offer.slot,item);
 return tradeReservation(inv.getItem(offer.slot))===marker;
}
function recoverTradeInventory(p){
 if(!p.isValid||trades.has(p.id))return;
 try{
  const inv=inventory(p);
  for(let slot=0;slot<(inv?.size??0);slot++){
   const item=inv.getItem(slot);
   if(!tradeReservation(item))continue;
   item.setLore(item.getRawLore().slice(1));
   item.lockMode=ItemLockMode.none;
   inv.setItem(slot,item);
  }
 }catch(error){console.warn('[SkyGen TRADE] Reservation cleanup '+p.id+' '+error)}
}
function tradeItemLabel(type,count,details){
 const traits=details.enchantments.map(enchantment=>enchantment.replace(/^minecraft:/,'').replaceAll('_',' '));
 if(details.durability){
  const [damage,maximum]=details.durability;
  traits.push(`Durability ${maximum-damage}/${maximum}`);
 }
 if(details.dye)traits.push('Dye '+details.dye.join('/'));
 if(details.potion)traits.push('Potion '+details.potion.join('/'));
 return `${type} ×${count}${traits.length?' · '+traits.join(', '):''}`;
}
function tradeChoices(p){
 return itemChoices(p).filter(({it})=>eligibleTradeItem(it)).map(({slot,it})=>{
  const details=tradeGearDetails(it);
  return {slot,type:it.typeId,count:it.amount,details,label:'Slot '+(slot+1)+' · '+tradeItemLabel(it.typeId,it.amount,details)};
 });
}
function tradeOffer(p,q){
 if(remoteGames.involved(p)||remoteGames.involved(q))return p.sendMessage('§cTrade after both players leave the arena or queue.');
 if(creativeEconomyBlocked(p)||creativeEconomyBlocked(q))return p.sendMessage('§cCreative inventory cannot be traded until cleared by an operator.');
 recoverTradeInventory(p);recoverTradeInventory(q);
 const items=tradeChoices(p);
 if(!items.length)return p.sendMessage('§cNo eligible item stacks. '+TRADE_ARMOR_NOTICE);
 form(p,'OFFER ITEM',`Trading with ${q.name}. The stack you select is reserved until the trade closes.\n${TRADE_ARMOR_NOTICE}`,[...items.map(x=>x.label),'Cancel'],i=>{
  const offer=items[i];
  if(offer)tradeInvite(p,q,offer);
 });
}
function tradeInvite(p,q,offer){
 if(!p.isValid||!q.isValid)return;
 if(remoteGames.involved(p)||remoteGames.involved(q))return p.sendMessage('§cTrade after both players leave the arena or queue.');
 if(tradeBusy(p)||tradeBusy(q))return p.sendMessage('§cA trade is already active.');
 if(creativeEconomyBlocked(p)||creativeEconomyBlocked(q))return p.sendMessage('§cCreative inventory cannot be traded until cleared by an operator.');
 const t={id:Date.now().toString(36)+'-'+(++tradeSequence).toString(36),a:p.id,b:q.id,aOffer:offer,created:system.currentTick,closed:false};
 trades.set(p.id,t);trades.set(q.id,t);
 try{
  if(!reserveTradeOffer(p,offer,t.id+'-a'))return tradeClose(t,'The offered item changed.');
 }catch(error){return tradeClose(t,'Could not reserve your offer: '+error)}
 const current=()=>trades.get(p.id)===t&&trades.get(q.id)===t;
 const cancel=()=>{if(current())tradeClose(t,'Trade cancelled.')};
 system.runTimeout(()=>{if(current())tradeClose(t,'Trade timed out after 30 seconds.');},600);
 form(q,'§dTRADE REQUEST',`${p.name} offers ${tradeItemLabel(offer.type,offer.count,offer.details)}. Choose a stack to exchange.`,['Choose My Item','Decline'],i=>{
  if(!current())return;
  if(i!==0)return cancel();
  const items=tradeChoices(q);
  if(!items.length)return tradeClose(t,'No eligible trade items. '+TRADE_ARMOR_NOTICE);
  form(q,'YOUR OFFER',`Exchange with ${p.name}\n${TRADE_ARMOR_NOTICE}`,[...items.map(x=>x.label),'Cancel'],j=>{
   if(!current())return;
   const counteroffer=items[j];if(!counteroffer)return cancel();
   try{
    if(!reserveTradeOffer(q,counteroffer,t.id+'-b'))return tradeClose(t,'The counteroffer changed.');
   }catch(error){return tradeClose(t,'Could not reserve the counteroffer: '+error)}
   t.bOffer=counteroffer;t.aOK=false;t.bOK=false;
   tradeConfirm(p,q,t);
  },cancel);
 },cancel);
}
function tradeClose(t,message){
 if(t.closed)return;
 t.closed=true;
 for(const id of [t.a,t.b])if(trades.get(id)===t)trades.delete(id);
 for(const p of world.getAllPlayers())if(p.id===t.a||p.id===t.b){
  recoverTradeInventory(p);
  if(p.isValid)p.sendMessage('§e'+message);
 }
}
function tradeConfirm(p,q,t){
 const {aOffer,bOffer}=t;
 const body=`${p.name}: ${tradeItemLabel(aOffer.type,aOffer.count,aOffer.details)}\n${q.name}: ${tradeItemLabel(bOffer.type,bOffer.count,bOffer.details)}\nBoth players must accept the reserved stacks. No currency is transferred.`;
 for(const [player,field] of [[p,'aOK'],[q,'bOK']])showUI(player,skyMessage().title('§dCONFIRM TRADE').body(body).button1('Decline').button2('Accept')).then(r=>{
  if(trades.get(player.id)!==t)return;
  if(r.canceled||r.selection!==1)return tradeClose(t,'Trade cancelled.');
  t[field]=true;
  if(t.aOK&&t.bOK)system.run(()=>tradeExecute(p,q,t));
 }).catch(()=>tradeClose(t,'Trade UI closed.'));
}
function tradeExecute(p,q,t){
 if(trades.get(p.id)!==t||trades.get(q.id)!==t||!t.aOK||!t.bOK||t.executing||t.closed)return;
 t.executing=true;
 try{
  if(p.isValid===false||q.isValid===false)return tradeClose(t,'Trade canceled: player disconnected.');
  if(remoteGames.involved(p)||remoteGames.involved(q))return tradeClose(t,'Trade canceled: one player entered an arena or joined its queue.');
  if(creativeEconomyBlocked(p)||creativeEconomyBlocked(q))return tradeClose(t,'Trade canceled: Creative inventory needs operator clearance.');
  const {aOffer,bOffer}=t;
  const aInv=inventory(p),bInv=inventory(q);
  const ai=aInv?.getItem(aOffer.slot),bi=bInv?.getItem(bOffer.slot);
  if(tradeReservation(ai)!==t.id+'-a'||tradeReservation(bi)!==t.id+'-b'||
     !tradeOfferMatches(ai,aOffer)||!tradeOfferMatches(bi,bOffer))return tradeClose(t,'An offered stack changed. Trade canceled.');
  if(typeof aInv.swapItems!=='function')return tradeClose(t,'Trade unavailable: atomic slot swapping not supported by this server.');
  try{
   aInv.swapItems(aOffer.slot,bOffer.slot,bInv);
   const aNow=aInv.getItem(aOffer.slot),bNow=bInv.getItem(bOffer.slot);
   if(tradeReservation(aNow)!==t.id+'-b'||tradeReservation(bNow)!==t.id+'-a'||
      !tradeOfferMatches(aNow,bOffer)||!tradeOfferMatches(bNow,aOffer))throw Error('Swap verification uncertain');
  }catch(err){
   console.warn('[SkyGen TRADE] operator review '+t.id+' '+err);
   try{world.setDynamicProperty('sg_trade_review_'+t.id,JSON.stringify({a:t.a,b:t.b,at:Date.now(),aSlot:aOffer.slot,bSlot:bOffer.slot,aType:aOffer.type,bType:bOffer.type,reason:String(err).slice(0,100)}))}catch(e){console.warn('[SkyGen TRADE] failed to record review '+e)}
   return tradeClose(t,'Trade result needs operator review. Do not repeat this trade until inventories are checked.');
  }
  return tradeClose(t,'Trade completed successfully!');
 }catch(e){return tradeClose(t,'Trade canceled safely: '+e)}
}
world.afterEvents.worldLoad.subscribe(()=>system.run(()=>{
 for(const player of world.getAllPlayers())recoverTradeInventory(player);
}));
world.afterEvents.entityDie.subscribe(({deadEntity})=>{
 if(deadEntity.typeId!=='minecraft:player')return;
 const trade=trades.get(deadEntity.id);
 if(trade)tradeClose(trade,'Trade cancelled after a participant died.');
});
world.afterEvents.playerInventoryItemChange?.subscribe(({player,beforeItemStack,itemStack})=>{
 if(!player.isValid||(!tradeReservation(beforeItemStack)&&!tradeReservation(itemStack)))return;
 const trade=trades.get(player.id);
 if(!trade)return recoverTradeInventory(player);
 if(trade.executing)return;
 const side=player.id===trade.a?'a':'b',offer=side==='a'?trade.aOffer:trade.bOffer;
 if(offer&&tradeReservation(inventory(player)?.getItem(offer.slot))!==trade.id+'-'+side)
  tradeClose(trade,'An offered stack moved. Trade canceled.');
});
function removeItemType(p,type,count){const inv=inventory(p);for(let i=0;i<inv.size&&count>0;i++){const it=inv.getItem(i);if(it?.typeId!==type||it.nameTag)continue;const n=Math.min(count,it.amount);removeExact(p,i,type,n);count-=n}}
// v0.10.6: Login must not override vanilla Bedrock's saved position.
// Our checkpoint is a fail-safe for servers that previously forced spawn on join.
// All location checkpoints are per-player, never shared by name, rank or plot ID.
const LAST_SAFE_KEY='sg_last_safe_location_v0106';
const RETURN_AREAS_KEY='sg_login_areas_v0106';
const lastSafeWriteTick=new Map(),loginPending=new Set(),returnStages=new Map(),returnCheckpointHold=new Map();
const MAX_RETURN_STAGES=2,RETURN_MAX_WAIT=240;
const VALID_RETURN_DIMS=new Set(['minecraft:overworld','minecraft:nether','minecraft:the_end']);
function validReturnRecord(record){
 return !!record&&record.v===1&&VALID_RETURN_DIMS.has(record.dim)&&
  ['x','y','z'].every(k=>typeof record[k]==='number'&&Number.isFinite(record[k]))&&
  Math.abs(record.x)<29000000&&Math.abs(record.z)<29000000&&record.y>=-63&&record.y<=319;
}
function lastSafeRecord(p){
 try{
  const raw=p.getDynamicProperty(LAST_SAFE_KEY);
  if(typeof raw!=='string')return undefined;
  const d=JSON.parse(raw);
  return validReturnRecord(d)?d:undefined;
 }catch(e){console.warn('[SkyGen LOGIN] invalid last-location checkpoint for '+p.id+': '+e);return undefined}
}
function lastLocationAllowed(p,d){
 if(!validReturnRecord(d))return false;
 if(d.dim==='minecraft:overworld'){
  if(arenaAt(d.x,d.z))return false;
  const area=fieldAt(d.x,d.z);
  if(area?.kind==='plot'&&!fieldAccess(p,area))return false;
 }
 return true;
}
function safeStandingLocation(dim,location){
 if(!dim||!location||!Number.isFinite(location.x)||!Number.isFinite(location.y)||!Number.isFinite(location.z))return false;
 const x=Math.floor(location.x),y=Math.floor(location.y),z=Math.floor(location.z);
 if(y<-63||y>319)return false;
 // Reject unloaded chunks, void, fire, dangerous surfaces and obstructed headroom.
 const floor=loadedPlotBlock(dim,x,y-1,z),feet=loadedPlotBlock(dim,x,y,z),head=loadedPlotBlock(dim,x,y+1,z),upper=loadedPlotBlock(dim,x,y+2,z);
 const deadly=new Set(['minecraft:water','minecraft:lava','minecraft:magma','minecraft:fire','minecraft:soul_fire','minecraft:cactus','minecraft:powder_snow','minecraft:campfire','minecraft:soul_campfire','minecraft:sweet_berry_bush']);
 return !!floor&&!floor.isAir&&!deadly.has(floor.typeId)&&!!feet&&feet.isAir&&!!head&&head.isAir&&!!upper&&upper.isAir;
}
function checkpointPlayer(p){
 if(!p?.isValid||remoteGames.occupied(p)||generatorRush.occupied(p)||loginPending.has(p.id)||returnStages.has(p.id)||pending.has(p.id)||spawnStages.has(p.id))return false;
 const dim=p.dimension,loc=p.location;
 const hold=returnCheckpointHold.get(p.id);
 // If the destination failed to load, do not quietly overwrite the old saved
 // location with the fallback spawn while the user is standing still.
 if(hold){
  if(dim?.id===hold.dim&&Math.hypot(loc.x-hold.x,loc.y-hold.y,loc.z-hold.z)<3)return false;
  returnCheckpointHold.delete(p.id);
 }
 if(!VALID_RETURN_DIMS.has(dim?.id)||!safeStandingLocation(dim,loc))return false;
 const d={v:1,dim:dim.id,x:loc.x,y:loc.y,z:loc.z};
 if(!lastLocationAllowed(p,d))return false;
 const current=lastSafeRecord(p);
 if(current&&current.dim===d.dim&&Math.hypot(d.x-current.x,d.y-current.y,d.z-current.z)<.25)return true;
 try{
  const value=JSON.stringify(d);p.setDynamicProperty(LAST_SAFE_KEY,value);
  if(p.getDynamicProperty(LAST_SAFE_KEY)!==value)throw Error('checkpoint verification failed');
  lastSafeWriteTick.set(p.id,system.currentTick);return true;
 }catch(e){console.warn('[SkyGen LOGIN] last location persistence failed for '+p.id+': '+e);return false}
}
// A live player's safe location is checkpointed every 2s. The before-leave
// callback cannot write dynamic properties (restricted execution), so we never
// depend on an unreliable write during disconnect. Worst-case lag is ~2s.
system.runInterval(()=>{
 for(const p of world.getAllPlayers()){
  try{checkpointPlayer(p)}catch(e){console.warn('[SkyGen LOGIN] checkpoint error: '+e)}
 }
},40);
function returnAreaEntries(){
 try{
  const v=JSON.parse(String(world.getDynamicProperty(RETURN_AREAS_KEY)||'[]'));
  return Array.isArray(v)?v.filter(x=>x&&/^(sg_ret_[a-f0-9]{8})$/.test(x.name)&&VALID_RETURN_DIMS.has(x.dim)).slice(0,25):[];
 }catch{return []}
}
function trackReturnArea(name,dim,add){
 const list=returnAreaEntries().filter(v=>v.name!==name);
 if(add)list.push({name,dim});
 world.setDynamicProperty(RETURN_AREAS_KEY,JSON.stringify(list));
}
function returnAreaName(p){
 let hash=2166136261;
 for(const c of String(p.id)){hash^=c.charCodeAt(0);hash=Math.imul(hash,16777619)}
 return 'sg_ret_'+(hash>>>0).toString(16).padStart(8,'0');
}
function sweepReturnAreas(){
 for(const r of returnAreaEntries()){
  try{world.getDimension(r.dim.replace('minecraft:','')).runCommand('tickingarea remove '+r.name)}catch(e){console.warn('[SkyGen LOGIN] orphan return area '+r.name+': '+e)}
  try{trackReturnArea(r.name,r.dim,false)}catch(e){console.warn('[SkyGen LOGIN] return registry cleanup: '+e)}
 }
}
system.runTimeout(sweepReturnAreas,25);
function rescueIfVoid(p){
 if(p.isValid&&p.dimension?.id==='minecraft:overworld'&&p.location.y<-50&&!spawnStages.has(p.id))safeSpawnTravel(p,true);
}
function restorePlayerLocation(p){
 if(!p?.isValid)return;
 if(returnStages.has(p.id))return;
 const saved=lastSafeRecord(p),id=p.id;
 if(!saved){loginPending.delete(id);rescueIfVoid(p);return}
 if(!lastLocationAllowed(p,saved)){
  returnCheckpointHold.set(id,{dim:p.dimension.id,...p.location});
  loginPending.delete(id);p.sendMessage('§eYour saved location is no longer accessible. A private plot may have changed permissions.');
  rescueIfVoid(p);return;
 }
 const here=p.location;
 if(p.dimension?.id===saved.dim&&Math.hypot(here.x-saved.x,here.y-saved.y,here.z-saved.z)<1.25){
  // Vanilla has already done the correct thing. Do not add a ticking area.
  loginPending.delete(id);return;
 }
 // A loaded, permitted non-spawn position from vanilla is more precise than
 // our 2-second checkpoint. Trust the normal server's reconnect location
 // instead of rewinding a legitimate player to an older sample.
 const currentPermitted={v:1,dim:p.dimension.id,x:here.x,y:here.y,z:here.z};
 if(lastLocationAllowed(p,currentPermitted)&&safeStandingLocation(p.dimension,here)&&
    (p.dimension.id!=='minecraft:overworld'||!inSpawn(here.x,here.z))){
  loginPending.delete(id);checkpointPlayer(p);return;
 }
 const stage={name:returnAreaName(p),dim:saved.dim,created:system.currentTick,areaActive:false,finished:false};
 returnStages.set(id,stage);
 function finish(success=false){
  if(stage.finished)return;
  stage.finished=true;
  loginPending.delete(id);
  const release=()=>{
   if(returnStages.get(id)===stage)returnStages.delete(id);
   if(stage.areaActive){
    try{world.getDimension(stage.dim.replace('minecraft:','')).runCommand('tickingarea remove '+stage.name)}catch(e){console.warn('[SkyGen LOGIN] could not release return area: '+e)}
   }
   try{trackReturnArea(stage.name,stage.dim,false)}catch(e){console.warn('[SkyGen LOGIN] could not clean return registry: '+e)}
  };
  // Keep the destination loaded for 2s to support client chunk handoff.
  if(success)system.runTimeout(release,40);else release();
 }
 function poll(){
  if(stage.finished)return;
  if(!p.isValid){finish();return}
  if(!lastLocationAllowed(p,saved)){finish();p.sendMessage('§cSaved location access was revoked; return cancelled.');rescueIfVoid(p);return}
  if(system.currentTick-stage.created>RETURN_MAX_WAIT){
   returnCheckpointHold.set(id,{dim:p.dimension.id,...p.location});
   finish();p.sendMessage('§eYour saved location could not be loaded. You have not been teleported into an unsafe chunk.');
   rescueIfVoid(p);return;
  }
  try{
   const dim=world.getDimension(saved.dim.replace('minecraft:',''));
   if(!stage.areaActive){
    const active=[...returnStages.values()].filter(v=>v.areaActive).length;
    if(active>=MAX_RETURN_STAGES){system.runTimeout(poll,10);return}
    trackReturnArea(stage.name,stage.dim,true); // Journal before any chunk allocation.
    const r=dim.runCommand(`tickingarea add circle ${Math.floor(saved.x)} ${Math.floor(saved.y)} ${Math.floor(saved.z)} 0 ${stage.name} false`);
    if(r?.successCount===0)throw Error('Destination ticking area rejected or limit reached');
    stage.areaActive=true;
   }
   if(!safeStandingLocation(dim,saved)){system.runTimeout(poll,10);return}
   if(typeof p.tryTeleport!=='function')throw Error('Safe teleport capability is not available');
   forcefieldTickets.set(id,{x:saved.x,y:saved.y,z:saved.z,expires:system.currentTick+20});
   if(!p.tryTeleport({x:saved.x,y:saved.y,z:saved.z},{dimension:dim,checkForBlocks:false})){
    forcefieldTickets.delete(id);system.runTimeout(poll,10);return;
   }
   forcefieldPrevious.delete(id);
   returnCheckpointHold.delete(id);
   p.sendMessage('§aWelcome back! Returned to your last safe location.');
   finish(true);
  }catch(e){
   forcefieldTickets.delete(id);
   returnCheckpointHold.set(id,{dim:p.dimension.id,...p.location});
   const message=String(e);
   // Ticking-area exhaustion is not a reason to use unsafe /tp or overwrite the save.
   finish();p.sendMessage('§eCould not prepare your last location: '+message.slice(0,100)+'. Operator: /tickingarea list all-dimensions');
   rescueIfVoid(p);
  }
 }
 system.runTimeout(poll,1);
}
world.afterEvents.playerSpawn.subscribe(e=>{
 const p=e.player,initial=!!e.initialSpawn;
 const newPlayer=initial&&p.getDynamicProperty('sg_profile')===undefined;
 lastExplorationDistrict.delete(p.id);
 forcefieldPrevious.delete(p.id);
 if(initial){
  try{rememberLeaderboardPlayer(p,profile(p))}catch(error){console.warn('[SkyGen Roster] Join: '+error)}
  loginPending.add(p.id);
  // Delay long enough to let vanilla restore the player and recover old
  // plot ticking-area orphans. Never teleport all logins to spawn.
  system.runTimeout(()=>{try{
   if(remoteGames.rejoin(p)||generatorRush.rejoin(p))loginPending.delete(p.id);
   else restorePlayerLocation(p);
  }catch(err){loginPending.delete(p.id);console.warn('[SkyGen LOGIN] safe return failed: '+err);rescueIfVoid(p)}},30);
 }
 system.runTimeout(()=>{try{
  // Death respawns are vanilla unless the player is falling into SkyGen void.
  // Fresh joins without a saved location are also rescued only if unsafe.
  if(!initial)rescueIfVoid(p);
  recoverTradeInventory(p);
  try{recoverEconomicTxn(p)}catch(err){p.sendMessage('§cPending economic review: contact a Realm operator.');console.warn('[SkyGen ECON] join recovery '+err)}
  const d=claim(p);
  try{settleSellerProceeds(p,d)}catch(err){console.warn('[SkyGen MARKET] Seller proceeds need operator review '+p.id+' '+err);p.sendMessage('§cMarketplace proceeds settlement needs operator review.');}
  rank(p,profile(p));ensure(p);
  try{mirrorArenaStats(p)}catch(error){console.warn('[SkyGen Arenas] Join score mirror: '+error)}
  if(initial)try{bank.recover(p)}catch(err){console.warn('[SkyGen BANK] deferred recovery while index rebuilds '+err)}
  p.sendMessage('§bSkyGen: menu compass slot 7, spawn horn slot 8, plot horn slot 9.');
  if(newPlayer&&firstGeneratorState(profile(p)).stage==='start'){
   p.sendMessage('§aNew to SkyGen? Open Compass → First Generator for the starter tutorial.');
  }
 }catch(err){console.warn('SkyGen join '+err)}},35);
});
try{
 world.afterEvents.playerDimensionChange?.subscribe(e=>{
  const p=e.player;if(!p||p.dimension?.id!=='minecraft:overworld'||isOperator(p))return;
  forcefieldPrevious.delete(p.id);
  system.runTimeout(()=>{
   if(!p.isValid||p.dimension?.id!=='minecraft:overworld')return;
   const region=fieldAt(p.location.x,p.location.z);
   if(region?.kind==='plot'&&!fieldAccess(p,region))safeSpawnTravel(p,true);
  },5);
 });
}catch(err){console.warn('[SkyGen SECURITY] dimension return guard unavailable '+err)}
world.afterEvents.itemUse.subscribe(e=>{
 const p=e.source,i=e.itemStack;
 if(queueMovement.has(p)&&(toolmatch(i,TOOLS[1])||toolmatch(i,TOOLS[2]))){
  p.sendMessage('§eLeave the minigame queue before traveling.');
  return;
 }
 if(remoteGames.involved(p)){
  if(toolmatch(i,TOOLS[0]))system.run(()=>remoteGames.compass(p));
  return;
 }
 if(generatorRush.queued(p)&&toolmatch(i,TOOLS[0])){system.run(()=>rushMenu(p));return}
 if(adminAxe(i)){system.run(()=>adminMenu(p));return}
 if(toolmatch(i,TOOLS[0]))system.run(()=>menu(p));
 if(toolmatch(i,TOOLS[1]))system.run(()=>{if(p.location.y<-50){const t=pending.get(p.id);pending.delete(p.id);finishPendingTeleport(t);safeSpawnTravel(p,true)}else safeSpawnTravel(p)});
 if(toolmatch(i,TOOLS[2]))system.run(()=>tpPlot(p));
});
// Generator tokens must be issued, uniquely identified, and redeemed by the server.
// The token record is authoritative, not the egg's display name or its lore.
// ItemStack dynamic properties require non-stackable items in Bedrock stable.
// Goat horns are non-stackable and reliably fire the existing itemUse event on Xbox.
// Legacy v0.9.2 goat horns remain redeemable; v0.9.3 purchases use custom items.
const GENERATOR_TOKEN_ITEM='minecraft:goat_horn';
let generatorTokenCustomReady=false;
const TOKEN_SEQ_KEY='sg_token_seq';
const generatorOutputReady=new Set();
function tokenKey(id){return 'sg_token_'+id}
function tokenId(it){try{return String(it?.getDynamicProperty?.('sg_token_id')||'')}catch{return ''}}
function tokenRead(id){
 if(!/^[1-9][0-9]*$/.test(String(id)))return null;
 const raw=world.getDynamicProperty(tokenKey(id));
 if(typeof raw!=='string')return null;
 const r=JSON.parse(raw);
 if(!r||r.v!==1||!['pending','issued','redeeming','spent','review'].includes(r.status)||typeof r.owner!=='string'||typeof r.type!=='string')return null;
 return r;
}
function tokenWrite(id,r){
 const value=JSON.stringify(r);world.setDynamicProperty(tokenKey(id),value);
 if(world.getDynamicProperty(tokenKey(id))!==value)throw Error('Generator token ledger write not verified');
}
function nextGeneratorTokenId(){
 const seq=Number(world.getDynamicProperty(TOKEN_SEQ_KEY)??0);
 if(!Number.isSafeInteger(seq)||seq<0||seq>=2000000000)throw Error('Generator issuance registry limit.');
 world.setDynamicProperty(TOKEN_SEQ_KEY,seq+1);
 if(world.getDynamicProperty(TOKEN_SEQ_KEY)!==seq+1)throw Error('Token sequence not saved');
 return String(seq+1);
}
function makeGeneratorToken(g,id){
 const item=new ItemStack(generatorItemId(g),1);
 if(item.maxAmount!==1)throw Error('Secure generator token is not non-stackable.');
 item.nameTag=`§bSkyGen ${g.name} Generator`;
 item.setLore([`Generator type: ${g.name}`,'Server-verified token. Use on your plot.']);
 item.setDynamicProperty('sg_token_id',id);
 if(tokenId(item)!==id)throw Error('Token identity did not survive an item read.');
 return item;
}
function claimGardenBlueprint(p){
 if(!p.isValid||!collectionHallReady()||generatorRush.occupied(p)||creativeEconomyBlocked(p)||
    ![GameMode.Survival,GameMode.Adventure].includes(p.getGameMode()))return false;
 const d=profile(p),state=blueprintState(d);
 if(state.delivered||state.caught!==GARDEN_FISH_GOAL||!hasFinishedSkyFeast(d))return false;
 const g=GEN_BY_NAME.get(BLUEPRINT_GENERATOR),inv=inventory(p);
 if(!inv||!generatorTokenCustomReady||!validGeneratorOutput(g))throw Error('Coal generator token unavailable.');
 const receipt={v:1,owner:p.id,type:g.name,price:0,source:'garden_blueprint'};
 if(!state.token){
  if(!Array.from({length:inv.size},(_,slot)=>inv.getItem(slot)).includes(undefined)){
   p.sendMessage('§eFree one inventory slot, then claim your Coal Generator.');return false;
  }
  const id=nextGeneratorTokenId();
  tokenWrite(id,{...receipt,status:'pending'});
  d.gardenBlueprint={...state,token:id};
  save(p,d);
 }
 const id=d.gardenBlueprint.token,record=tokenRead(id);
 if(!record||record.owner!==p.id||record.type!==g.name||record.source!==receipt.source)throw Error('Blueprint token ledger mismatch.');
 if(record.status==='review'||record.status==='redeeming')throw Error('Blueprint token needs operator review.');
 const held=Array.from({length:inv.size},(_,slot)=>inv.getItem(slot));
 if(!held.some(item=>tokenId(item)===id)&&record.status!=='spent'){
  const slot=held.indexOf(undefined);
  if(slot<0){p.sendMessage('§eFree one inventory slot, then claim your Coal Generator.');return false;}
  const token=makeGeneratorToken(g,id);
  inv.setItem(slot,token);
  if(tokenId(inv.getItem(slot))!==id)throw Error('Blueprint item delivery could not be verified.');
 }
 // Until the profile write commits, a retry can recover the same item ID.
 // Every copy still references one ledger entry and one possible placement.
 if(record.status==='pending')tokenWrite(id,{...record,status:'issued'});
 d.gardenBlueprint={...d.gardenBlueprint,delivered:true};
 save(p,d);
 p.sendMessage('§aClaimed your Coal Generator. Use the token on your plot.');
 return true;
}
function issueGeneratorToken(p,g,price){
 if(!generatorTokenCustomReady)return p.sendMessage('§cGenerator custom-item use handler is not active; cannot issue tokens.');
 if(!validGeneratorOutput(g))return p.sendMessage('§cGenerator output block is unavailable on this Bedrock version. No charge.');
 const latest=profile(p),inv=inventory(p);
 if(!inv||latest.rank<g.unlock||latest.credits<price)return p.sendMessage('§cNot eligible or Credits changed.');
 if(!inventoryCapacity(p,new ItemStack(generatorItemId(g),1)))return p.sendMessage('§cInventory full. No charge.');
 const guidePurchase=firstGeneratorPurchaseEligible(latest,price);
 const receipt={v:1,owner:p.id,type:g.name,price,...(guidePurchase?{firstGeneratorGuide:true}:{})};
 let id,egg;
 try{
  id=nextGeneratorTokenId();
  egg=makeGeneratorToken(g,id);
  tokenWrite(id,{...receipt,status:'pending'});
 }catch(err){return p.sendMessage('§cToken registry unavailable. No Credits spent. '+String(err).slice(0,90))}
 try{latest.credits-=price;save(p,latest)}catch(err){return p.sendMessage('§cWallet unavailable. Token issuance reserved but disabled; no item delivered.')}
 try{tokenWrite(id,{...receipt,status:'issued'})}catch(err){
  genError('CRITICAL: paid generator token '+id+' cannot activate '+err,'token');
  return p.sendMessage('§cToken activation needs operator review: #'+id);
 }
 try{
  if(inv.addItem(egg))throw Error('Inventory full or item delivery uncertain');
  p.sendMessage(`§aPurchased ${g.name} generator token (#${id}) for ${price} Credits.`);
 }catch(err){
  // NO AUTOMATIC REFUND: the item may already be delivered on an ambiguous write.
  try{tokenWrite(id,{...receipt,status:'review',reason:'Delivery uncertain'})}catch{}
  genError('CRITICAL: generator token delivery review '+id+' '+err,'token');
  return p.sendMessage('§cToken delivery needs operator review #'+id+'. Do not purchase another.');
 }
 if(guidePurchase)recordFirstGeneratorPurchase(p,price);
}
// Operator-reviewed migration path for genuine legacy generator eggs without issued IDs.
// The operator must verify the customer's older purchase; no name-only automatic redemption.
// Read-only reconciliation helper: IDs #25 and #26 remain locked until
// a human verifies wallets, inventory and world block/registry state.
function adminTokenStatus(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 const id=String(message||'').trim();
 if(!/^[1-9][0-9]*$/.test(id))return actor.sendMessage('§eUsage: /scriptevent skygen:tokenstatus 25');
 try{
  const r=tokenRead(id);
  if(!r)return actor.sendMessage('§cToken #'+id+' not found or invalid.');
  const matched=[...generators.values()].filter(g=>g.owner===r.owner&&g.type===r.type);
  actor.sendMessage('§eToken #'+id+' status='+r.status+' type='+r.type+' price='+r.price+' owner='+r.owner+' reason='+String(r.reason||'none'));
  actor.sendMessage('§7Owner has '+matched.length+' registered generator(s) of that type; compare with receipts and world blocks before settlement.');
 }catch(err){actor.sendMessage('§cToken read failed: '+String(err).slice(0,130))}
}
// Creative-taint removal requires a manual verified quarantine of *all*
// Creative-origin inventory/container items. The operator cannot infer origin.
function adminCreativeClear(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOperator permission required.');
 const target=playerByName(String(message||'').trim());
 if(!target)return actor.sendMessage('§cTarget player must be online: /scriptevent skygen:creativeclear PlayerName');
 if(target.getGameMode()===GameMode.Creative)return actor.sendMessage('§cSwitch target to Survival and quarantine Creative items first.');
 const inv=inventory(target);
 if(!inv||Array.from({length:inv.size},(_,i)=>inv.getItem(i)).some(it=>it&&!isTool(it)))return actor.sendMessage('§cClear target ordinary inventory and check armor, offhand, Ender chest, storage before staff clearance.');
 const key=creativeEconomyKey(target);
 world.setDynamicProperty(key,false);
 if(world.getDynamicProperty(key)!==false)return actor.sendMessage('§cCreative clearance could not be verified.');
 console.warn('[SkyGen SECURITY] Creative economy taint cleared by operator '+actor.name+' for '+target.name+' after stated manual inventory review');
 actor.sendMessage('§aCreative economy restriction cleared for '+target.name+'.');
}
function adminTokenRestore(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOnly operators can reissue verified generator tokens.');
 const match=/^\s*(.+?)\s*\|\s*(.+?)\s*$/.exec(String(message||''));
 if(!match)return actor.sendMessage('§eUsage: /scriptevent skygen:tokenrestore PlayerName | Generator Name');
 const target=playerByName(match[1]),g=GENS.find(x=>x.name.toLowerCase()===match[2].toLowerCase());
 if(!target||!g)return actor.sendMessage('§cOnline player or generator type not found.');
 try{
  if(profile(target).rank<g.unlock)return actor.sendMessage('§cTarget player has not unlocked this generator rank.');
  const before=Number(world.getDynamicProperty(TOKEN_SEQ_KEY)||0);
  issueGeneratorToken(target,g,0);
  const after=Number(world.getDynamicProperty(TOKEN_SEQ_KEY)||0);
  const delivered=after>before&&!![...Array(inventory(target)?.size||0).keys()].some(slot=>tokenId(inventory(target).getItem(slot))===String(after));
  if(delivered){console.warn('[SkyGen SECURITY] operator '+actor.name+' reissued '+g.name+' token to '+target.name+' #'+after);actor.sendMessage('§aIssued verified replacement token #'+after+'; inspect player inventory and records.');}
  else actor.sendMessage('§cToken restoration not verified; check player inventory and security records before retrying.');
 }catch(e){actor.sendMessage('§cToken restoration failed: '+String(e).slice(0,100))}
}
function rollbackGeneratorBlocks(dim,loc,spec,baseWasAir){
 try{const out=dim.getBlock({x:loc.x,y:loc.y+1,z:loc.z});if(out?.typeId===spec.block)out.setType('minecraft:air')}catch(e){genError('Generator output rollback '+e,'rollback')}
 if(baseWasAir)try{const base=dim.getBlock(loc),core=GENERATOR_CORE_BY_NAME.get(spec.name);if(base?.typeId===core)base.setType('minecraft:air')}catch(e){genError('Generator base rollback '+e,'rollback')}
}
// Staff Creative provenance guard. Once a player uses Creative, item origins
// cannot reliably be proven from vanilla inventory; refuse commerce until
// operator clears the flag after separately clearing acquired inventory.
function creativeEconomyKey(p){return 'sg_creative_econ_tainted_'+p.id}
function taintCreativePlayer(p){
 try{world.setDynamicProperty(creativeEconomyKey(p),true)}catch(err){console.warn('[SkyGen CREATIVE] could not mark '+p.id+': '+err)}
}
function creativeEconomyBlocked(p){
 try{
  if(p.getGameMode()===GameMode.Creative){taintCreativePlayer(p);return true}
  return world.getDynamicProperty(creativeEconomyKey(p))===true;
 }catch{return true}
}
try{world.afterEvents.playerGameModeChange?.subscribe(e=>{
 if(e.toGameMode===GameMode.Creative)taintCreativePlayer(e.player);
})}catch(err){console.warn('[SkyGen CREATIVE] mode event unavailable '+err)}
const completedGeneratorEvents=new Map();
function recentConsumedGeneratorEvent(p,id,stack,record){
 const key=p.id+':'+id,until=completedGeneratorEvents.get(key);
 if(until===undefined||system.currentTick>until)return false;
 return !!record&&['spent','review'].includes(record.status)&&tokenId(stack)!==id;
}
function placeGeneratorToken(p,selected,id){
 let record;
 try{
  if(!p?.isValid||remoteGames.occupied(p)||generatorRush.occupied(p))return;
  const inv=inventory(p),stack=inv?.getItem(selected);record=tokenRead(id);
  if(recentConsumedGeneratorEvent(p,id,stack,record))return; // stale second event, not a forged token
  if(!record||record.status!=='issued'||record.owner!==p.id||!stack||!validTokenItemType(stack.typeId,record.type)||stack.amount!==1||tokenId(stack)!==id){
   return p.sendMessage('§cInvalid, already used, or unissued generator token. Ask an operator for help.');
  }
  const g=GEN_BY_NAME.get(record.type);
  if(g&&!validGeneratorOutput(g))return p.sendMessage('§cGenerator block unavailable; token kept. Report '+g.block+' to an operator.');
  if(!g||stack.nameTag!==`§bSkyGen ${g.name} Generator`)return p.sendMessage('§cGenerator token identity mismatch.');
  const d=profile(p);
  if(d.rank<g.unlock||!belongs(p,p.location.x,p.location.z)||ownerId(d.plot)!==p.id||p.dimension?.id!=='minecraft:overworld')return p.sendMessage('§cGenerator requires its unlock rank and your own Overworld plot.');
  if(!generatorRegistryLoaded||generators.size>=GEN_REGISTRY_LIMIT)return p.sendMessage('§cGenerator registry unavailable or full. Token retained.');
  if(generatorOwnerCount(p)>=generatorSlots(p))return p.sendMessage('§cGenerator slot limit reached.');
  if(g.name==='Ancient Debris'&&[...generators.values()].some(x=>x.owner===p.id&&x.type===g.name))return p.sendMessage('§cOnly one Ancient Debris generator per player.');
  const hit=p.getBlockFromViewDirection({maxDistance:6,includeLiquidBlocks:false,includePassableBlocks:false});
  if(!hit?.block)return p.sendMessage('§cLook directly at a block inside your plot.');
  const target=hit.block.location,loc={x:target.x,y:target.y+1,z:target.z};
  if(plotAt(loc.x,loc.z)!==d.plot||loc.y<1||loc.y>300)return p.sendMessage('§cInvalid generator placement location.');
  const key=`${loc.x},${loc.y},${loc.z}`;
  if(generators.has(key))return p.sendMessage('§cGenerator already registered at that location.');
  const dim=world.getDimension('overworld'),base=dim.getBlock(loc),out=dim.getBlock({x:loc.x,y:loc.y+1,z:loc.z});
  if(!base||!out||!base.isAir||!out.isAir)return p.sendMessage('§cTwo free spaces required; existing blocks are never replaced. Token retained.');
  const baseWasAir=base.isAir;
  // Reserve first, then debit the exact event slot before granting anything.
  tokenWrite(id,{...record,status:'redeeming'});
  try{
   const current=inv.getItem(selected);
   if(!current||current.amount!==1||tokenId(current)!==id)throw Error('Token changed before debit');
   inv.setItem(selected,undefined);
   if(inv.getItem(selected))throw Error('Token debit could not be verified');
  }catch(e){
   // The slot may be uncertain. Quarantine the token instead of allowing reuse.
   try{tokenWrite(id,{...record,status:'review',reason:'Debit uncertain'})}catch{}
   return p.sendMessage('§cToken debit uncertain. Operator review required #'+id);
  }
  const guideToken=record.firstGeneratorGuide===true&&record.price>0?{firstGeneratorToken:id}:{};
  const gen={...loc,owner:p.id,type:g.name,period:g.period,block:g.block,last:system.currentTick,elapsed:0,...guideToken};
  let committed=false;
  try{
   if(!buildGenerator(gen))throw Error('Generator placement blocked');
   generators.set(key,gen);
   if(!genSave())throw Error('Generator storage commit failed');
   committed=true;
  }catch(err){
   generators.delete(key);generatorOutputReady.delete(key);
   rollbackGeneratorBlocks(dim,loc,g,baseWasAir);
   // Do not refund if the registry commit might have reached disk despite a failed verification.
   // Hold the original token in a review ledger for manual reconciliation.
   try{tokenWrite(id,{...record,status:'review',reason:'Generator commit/rollback uncertain: '+String(err).slice(0,70)})}catch{}
   completedGeneratorEvents.set(p.id+':'+id,system.currentTick+10);
   genError('Generator redemption requires review #'+id+' '+err,'redemption');
   return p.sendMessage('§cGenerator placement failed. Token #'+id+' held for operator recovery; no automatic duplicate item.');
  }
  if(committed){
   generatorOutputReady.add(key);
   completedGeneratorEvents.set(p.id+':'+id,system.currentTick+10);
   try{tokenWrite(id,{...record,status:'spent'})}catch(err){genError('Token spent marker unavailable #'+id+' '+err,'token')}
   try{
    const pd=profile(p);recordDaily(p,pd,['placements'],1,g.name);
    const guideStage=recordFirstGeneratorPlacement(pd,p,'placement',gen,key);
    save(p,pd);announceFirstGenerator(p,guideStage);
   }catch(err){console.warn('[SkyGen DAILY] generator placement '+err)}
   p.sendMessage(`§aPlaced ${g.name} custom-core generator at ${loc.x},${loc.y},${loc.z}.`);
  }
 }catch(err){
  genError('CRITICAL generator token redemption #'+id+' '+err,'redemption');
  p?.sendMessage?.('§cGenerator redemption failed safely; operator review #'+id);
 }
}
// Namespaced component shared by 42 distinct non-stackable custom items.
// Handler registration occurs in Bedrock's early startup event, not on a join.
// Both controller 'use in air' and 'use on block' enter the same secured path.
const customTokenUsePending=new Set();
function queueCustomGeneratorUse(event){
 const p=event.source,item=event.itemStack;
 if(!p||!item||!GENERATOR_ITEM_TYPE_IDS.has(item.typeId))return;
 const id=tokenId(item),slot=p.selectedSlotIndex;
 const dedupe=p.id+':'+slot+':'+id;
 if(customTokenUsePending.has(dedupe))return;
 customTokenUsePending.add(dedupe);
 system.run(()=>{
  try{placeGeneratorToken(p,slot,id)}
  finally{customTokenUsePending.delete(dedupe)}
 });
}
try {
 if(!system.beforeEvents?.startup?.subscribe)throw Error('Script API startup registry unavailable');
 system.beforeEvents.startup.subscribe(ev=>{
  try{
   ev.itemComponentRegistry.registerCustomComponent('skygen:generator_token_use',{
    onUse:queueCustomGeneratorUse,
    onUseOn:queueCustomGeneratorUse
   });
   generatorTokenCustomReady=true;
  }catch(err){generatorTokenCustomReady=false;console.warn('[SkyGen] CRITICAL custom generator item registration failed '+err)}
 });
}catch(err){console.warn('[SkyGen] CRITICAL custom item startup unavailable '+err)}
// Keep the v0.9.2 horn event subscribed so outstanding valid horns still redeem.
let generatorTokenUseGuardReady=false;
try{
 if(!world.beforeEvents.itemUse?.subscribe)throw Error('beforeEvents.itemUse is unavailable');
 world.beforeEvents.itemUse.subscribe(e=>{
  const i=e.itemStack;
  if(tradeReservation(i)){e.cancel=true;return;}
  // Block legacy name-only eggs but never accept them as authenticated tokens.
  if(i?.typeId==='minecraft:egg'&&i.nameTag?.startsWith('§bSkyGen ')){
   e.cancel=true;
   system.run(()=>e.source?.sendMessage?.('§cOld generator egg cannot be verified. Ask an operator to inspect and replace it.'));
   return;
  }
  // Controller compatibility fallback: if Bedrock emits a normal use event
  // for a custom item, cancel vanilla behavior and use the same deduplicated path.
  if(i&&GENERATOR_ITEM_TYPE_IDS.has(i.typeId)){
   e.cancel=true;
   queueCustomGeneratorUse({source:e.source,itemStack:i});
   return;
  }
  if(i?.typeId!==GENERATOR_TOKEN_ITEM||(!i.nameTag?.startsWith('§bSkyGen ')&&!tokenId(i)))return;
  e.cancel=true; // Stop vanilla horn use; the token is consumed only after validation.
  const player=e.source,selected=player?.selectedSlotIndex,id=tokenId(i);
  queueCustomGeneratorUse({source:player,itemStack:i});
 });
 generatorTokenUseGuardReady=true;
}catch(err){console.warn('[SkyGen] CRITICAL generator token use guard unavailable; redemption disabled '+err)}
try{
 if(!world.beforeEvents.explosion?.subscribe)throw Error('explosion guard unavailable');
 world.beforeEvents.explosion.subscribe(e=>{
  try{
   if(e.dimension?.id!=='minecraft:overworld')return;
   const blocks=e.getImpactedBlocks();
   const allowed=blocks.filter(b=>{const loc=b.location;return !blastProtected(loc.x,loc.z)&&!boundSaleChestOwner(loc)});
   if(allowed.length!==blocks.length)e.setImpactedBlocks(allowed);
  }catch(err){e.cancel=true;console.warn('[SkyGen] explosion filter failed closed '+err)}
 });
}catch(err){console.warn('[SkyGen] CRITICAL: explosion guard not installed '+err)}
// Stable pre-action security controls: cancel interacting with entities
// inside protected land, and cancel unauthorized damage including projectiles.
try{
 world.beforeEvents.playerInteractWithEntity?.subscribe(e=>{
  if(tradeReservation(e.itemStack)){e.cancel=true;return;}
  if(!e.player||!e.target||e.target.dimension?.id!=='minecraft:overworld')return;
  const loc=e.target.location;
  if(protectedAt(e.player,Math.floor(loc.x),Math.floor(loc.z),false))e.cancel=true;
 });
}catch(err){console.warn('[SkyGen SECURITY] Entity interaction guard unavailable '+err)}
// Purge Night: Bedrock @minecraft/server 2.9+ supports world.gameRules.pvp and
// cancellable world.beforeEvents.entityHurt (added in stable 2.6.0).
// Server-side pvp controls indirect player attacks too, including arrows.
// Citadel sanctuary is a separate per-damage cancellation, 24 hours a day.
let purgeNightActive=null;
let purgeAnnouncementUntil=0;
let purgeSecurityErrorTick=-100000;
let purgeDamageGuardActive=false;
function purgeStatusCommand(p){
 if(!isOperator(p))return p.sendMessage('§cRealm operator only.');
 try{p.sendMessage('§bSKYGEN PURGE NIGHT STATUS | Clock: '+world.getTimeOfDay()+' | Night: '+isPurgeNight()+' | PvP: '+world.gameRules.pvp+' | Center guard: '+purgeDamageGuardActive+' | Public mine: '+PUBLIC_STARTER_GENERATORS.length+' positions');}
 catch(err){p.sendMessage('§cPurge Night diagnostics failed: '+err)}
}
function isPurgeNight(){const t=world.getTimeOfDay();return t>=13000&&t<23000}
function purgeNightHeartbeat(){
 try{
  const active=purgeDamageGuardActive&&isPurgeNight();
  // Fail closed: preserve PvP OFF if the center-island damage guard failed to register.
  if(world.gameRules.pvp!==active)world.gameRules.pvp=active;
  if(world.gameRules.pvp!==active)throw Error('PvP gamerule verification failed');
  if(active!==purgeNightActive){
   purgeNightActive=active;
   purgeAnnouncementUntil=system.currentTick+160;
   for(const p of world.getAllPlayers()){
    p.onScreenDisplay.setTitle(active?'§4§lPURGE NIGHT':'§a§lDAYTIME SAFE', {fadeInDuration:10,stayDuration:90,fadeOutDuration:30,subtitle:active?'§cPvP ON outside central island':'§aPvP OFF across the Realm'});
    p.sendMessage(active?'§4PURGE NIGHT §7— PvP is ON; the center island remains safe.':'§aDAYTIME §7— PvP is OFF across the Realm.');
   }
  }
 }catch(err){
  if(system.currentTick-purgeSecurityErrorTick>=1200){console.warn('[SkyGen PURGE] CRITICAL gamerule enforcement failed: '+err);purgeSecurityErrorTick=system.currentTick}
 }
 system.runTimeout(purgeNightHeartbeat,10);
}
system.runTimeout(purgeNightHeartbeat,1);
try{
 const signal=world.beforeEvents.entityHurt;
 if(!signal?.subscribe)throw Error('Damage pre-event unavailable. Target @minecraft/server 2.9.0 or later.');
 signal.subscribe(e=>{
  const victim=e.hurtEntity;
  if(!victim||victim.dimension?.id!=='minecraft:overworld')return;
  const loc=victim.location;
  if(!loc)return;
  if(victim.typeId==='minecraft:player'){
   if(isCentralIslandSanctuary(loc.x,loc.z))e.cancel=true;
   return;
  }
  // Environmental blast damage must not kill protected plot livestock.
  // Players still take normal explosion damage; Purge Night PvP policy remains.
  const source=e.damageSource;
  const protectedLivestock=victim.matches({families:['animal']})||victim.matches({families:['villager']})||victim.matches({families:['golem']});
  const blast=String(source?.cause||'').toLowerCase().includes('explosion');
  if(blast&&protectedLivestock&&blastProtected(Math.floor(loc.x),Math.floor(loc.z))){e.cancel=true;return}
  // Only player-originated attacks against protected passive livestock.
  // Hostile mobs, ordinary natural damage, and owner-operated farms are unchanged.
  const attacker=source?.damagingEntity?.typeId==='minecraft:player'?source.damagingEntity:
   source?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
  if(attacker?.typeId!=='minecraft:player')return;
  const passive=victim.matches({families:['animal']})||victim.matches({families:['villager']})||victim.matches({families:['golem']});
  if(!passive)return;
  const id=plotAt(loc.x,loc.z);
  if(id>=0 && ownerId(id)!==attacker.id){e.cancel=true;return;}
  if((inSpawn(loc.x,loc.z)||inBuiltSkyRealm(loc.x,loc.z))&&!isOperator(attacker))e.cancel=true;
 });
 purgeDamageGuardActive=true;
}catch(err){console.warn('[SkyGen SECURITY] CRITICAL sanctuary damage guard unavailable: '+err)}
try{
 world.beforeEvents.entityHurt?.subscribe(e=>{
  if(e.cancel||e.hurtEntity.typeId!=='minecraft:player'||e.damage<=0)return;
  try{
   const {damagingEntity,damagingProjectile}=e.damageSource;
   if(damagingEntity?.typeId==='minecraft:player')return;
   const attacker=damagingProjectile?.getComponent('minecraft:projectile')?.owner??damagingEntity;
   if(!attacker||attacker.typeId==='minecraft:player'||!attacker.matches({families:['monster']}))return;
   if(emblemEnabled(profile(e.hurtEntity),'sky_guardian_crest'))e.damage*=1-GUARDIAN_DAMAGE_REDUCTION/100;
  }catch(err){console.warn('[SkyGen EMBLEM] Guardian damage check: '+err)}
 });
}catch(err){console.warn('[SkyGen EMBLEM] Guardian damage event unavailable: '+err)}
installPistonProtection(world,pistonArea,location=>boundSaleChestOwner(location)||anchoredStarterStock(location),dropProtectedPiston);
world.beforeEvents.playerBreakBlock.subscribe(e=>{
 if(tradeReservation(e.itemStack)){e.cancel=true;return;}
 const {x,y,z}=e.block.location;
 if(e.player.dimension?.id==='minecraft:overworld'&&boundSaleChestOwner({x,y,z})){
  e.cancel=true;e.player.sendMessage('§cUnbind the empty Sell-All Chest through Pro Shop before breaking it.');return;
 }
 if(e.player.dimension?.id!=='minecraft:overworld')return;
 if(publicStarterEnabled()&&anchoredStarterStock({x,y,z})){
  e.cancel=true;
  return;
 }
 const publicGen=publicStarterAt(x,y,z);
 if(publicGen&&publicStarterEnabled()&&e.block.typeId===publicGen.block)return;
 const registered=generators.get(`${x},${y},${z}`);
 if(registered&&isGeneratorBase(registered,e.block)){
  e.cancel=true;
  return;
 }
 const id=plotAt(x,z);
 // The owner can edit the top layer, including replacements; generator cores are checked above.
 if(protectedPlotFoundation(e.player,{x,y,z},id)){e.cancel=true;return;}
 if(protectedAt(e.player,x,z))e.cancel=true;
});
try{
 // Available only in some (beta/newer) runtimes; do not rely on it in stable 2.0.0.
 world.beforeEvents.playerPlaceBlock?.subscribe(e=>{
  if(!e.player||!e.block)return;
  const {x,y,z}=e.block.location;
  if(protectedAt(e.player,x,z)){e.cancel=true;return}
  // Placement within one block of a bound sale chest must not attach a
  // new container or automate withdrawal. No after-the-fact item deletion.
  const placed=e.permutationToPlace?.type?.id||e.itemStack?.typeId||'';
  if(e.player.dimension.id==='minecraft:overworld'&&pistonType(placed)&&nearPistonBoundary(x,z)){
   e.cancel=true;
   e.player.sendMessage('§cPistons need clearance from protected boundaries.');
   return;
  }
  const unsafe=/^minecraft:(?:chest|trapped_chest|hopper|piston|sticky_piston|dropper|dispenser)$/;
  if(unsafe.test(placed)&&[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]
    .some(([dx,dy,dz])=>boundSaleChestOwner({x:x+dx,y:y+dy,z:z+dz}))){e.cancel=true}
 });
}catch(err){console.warn('[SkyGen] Optional pre-place guard not supported: '+err)}
const FACE_OFFSETS={Down:[0,-1,0],Up:[0,1,0],South:[0,0,1],North:[0,0,-1],East:[1,0,0],West:[-1,0,0]};
try{
 // Stable pre-interaction protects chests and most block placements.
 if(world.beforeEvents.playerInteractWithBlock?.subscribe){
  world.beforeEvents.playerInteractWithBlock.subscribe(e=>{
   if(!e.player||!e.block)return;
   if(tradeReservation(e.itemStack)){e.cancel=true;return;}
   const {x,y,z}=e.block.location;
   const arena=REMOTE_ARENAS.find(({station})=>x===station.x&&y===station.y&&z===station.z&&
    e.block.typeId===station.block&&rushReady()&&isNearDistrictStation(e.player,station));
   if(arena){
    e.cancel=true;
    const viewer=e.player;
    if(e.isFirstEvent!==false)system.run(()=>{if(viewer.isValid)arenaMenu(viewer,arena.id)});
    return;
   }
   if(rushReady()&&x===RUSH_STATION.x&&y===RUSH_STATION.y&&z===RUSH_STATION.z&&
      e.block.typeId===RUSH_STATION.block&&isNearDistrictStation(e.player,RUSH_STATION)){
    e.cancel=true;
    const viewer=e.player;
    if(e.isFirstEvent!==false)system.run(()=>{if(viewer.isValid)rushMenu(viewer)});
    return;
   }
   if(nexusBeaconReady()){
    const station=nearbyBeaconStation(e.player);
    if(station&&x===station.x&&y===station.y&&z===station.z&&e.block.typeId===station.block){
     e.cancel=true;
     const viewer=e.player;
     if(e.isFirstEvent!==false)system.run(()=>{if(viewer.isValid)nexusBeaconMenu(viewer)});
     return;
    }
   }
   if(districtOrdersReady()&&e.player.dimension?.id==='minecraft:overworld'){
    const station=DISTRICT_STATIONS.find(entry=>entry.x===x&&entry.y===y&&entry.z===z);
    if(station&&e.block.typeId===station.block&&isNearDistrictStation(e.player,station)){
     e.cancel=true;
     const viewer=e.player;
     if(e.isFirstEvent!==false)system.run(()=>{
      if(!viewer.isValid)return;
      if(station.id==='market')districtOrdersMenu(viewer);
      else districtShopMenu(viewer,station.id);
     });
     return;
    }
   }
   if(collectionHallReady()){
    const station=COLLECTION_HALL_STATIONS.find(entry=>entry.x===x&&entry.y===y&&entry.z===z);
    if(station&&e.block.typeId===station.block&&isNearDistrictStation(e.player,station)){
     e.cancel=true;
     const viewer=e.player;
     if(e.isFirstEvent!==false)system.run(()=>{
      if(!viewer.isValid)return;
      if(station.collectionId)collectionDetails(viewer,station.collectionId);
      else collectionHallMenu(viewer);
     });
     return;
    }
   }
   if(e.player.dimension.id==='minecraft:overworld'&&pistonType(e.itemStack?.typeId)&&
      pistonPlacementBlocked(e.block,e.blockFace,nearPistonBoundary)){
    e.cancel=true;
    if(e.isFirstEvent!==false)e.player.sendMessage('§cPistons need clearance from protected boundaries.');
    return;
   }
   const chestOwner=boundSaleChestOwner({x,y,z});
   if(chestOwner&&chestOwner!==e.player.id){e.cancel=true;return;}
   if(/^minecraft:(?:hopper|chest|trapped_chest|piston|sticky_piston|dropper|dispenser)$/.test(e.itemStack?.typeId||'')&&
      [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]].some(([dx,dy,dz])=>boundSaleChestOwner({x:x+dx,y:y+dy,z:z+dz}))){e.cancel=true;return;}
   if(e.player.dimension.id==='minecraft:overworld'&&anchoredStarterStock({x,y,z})){
    e.cancel=true;
    if(y===1&&shulkerBox(e.block.typeId)&&e.isFirstEvent!==false){
     const viewer=e.player;
     system.run(()=>{if(viewer.isValid)starterKitMenu(viewer,{x,y,z})});
    }
    return;
   }
   if(e.player.dimension.id==='minecraft:overworld'&&
      /^minecraft:(?:hopper|hopper_minecart|dispenser|dropper)$/.test(e.itemStack?.typeId??'')){
    const [dx,dy,dz]=FACE_OFFSETS[e.blockFace]??[0,0,0];
    if(nearStarterStock({x,y,z})||nearStarterStock({x:x+dx,y:y+dy,z:z+dz})){e.cancel=true;return;}
   }
   if(canUseCityWorkstation(e))return;
   if(protectedAt(e.player,x,z)||[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dz])=>protectedAt(e.player,x+dx,z+dz)))e.cancel=true;
  });
  interactionGuardAvailable=true;
 }else console.warn('[SkyGen] CRITICAL: block interaction protection unavailable; plot visiting disabled.');
}catch(e){interactionGuardAvailable=false;console.warn('[SkyGen] CRITICAL: interaction guard failed: '+e)}
try{
 // Defense in depth for placement actions not routed through interaction.
 // Only removes the newly placed unauthorized block; use a world copy to test boundary cases.
 world.afterEvents.playerPlaceBlock?.subscribe(e=>{
  if(e.block){const loc=e.block.location;generatorOutputReady.delete(`${loc.x},${loc.y-1},${loc.z}`)}
  if(!e.player||!e.block)return;
  const {x,z}=e.block.location;
  const placed=e.block.typeId;
  if(e.player.dimension.id==='minecraft:overworld'&&(
     (pistonType(placed)&&nearPistonBoundary(x,z))||
     (/^minecraft:(?:hopper|dispenser|dropper)$/.test(placed)&&nearStarterStock(e.block.location)))){
   try{
    e.block.setType('minecraft:air');
    if(e.block.isAir&&e.player.getGameMode()!==GameMode.Creative)dropProtectedPiston(e.block.dimension,e.block.location,placed);
    e.player.sendMessage('§cThat machinery is too close to protected land or starter-kit stock.');
   }catch(err){console.warn('[SkyGen SECURITY] Placement rollback: '+err)}
   return;
  }
  if(protectedAt(e.player,x,z)){
   try{e.block.setType('minecraft:air');e.player.sendMessage('§cCannot build in this protected area.')}catch(err){console.warn('[SkyGen] unauthorized placed block could not be reverted: '+err)}
   return;
  }
  if(belongs(e.player,x,z))recordQuestActivity(e.player,'build',e.block.typeId);
 });
}catch(e){console.warn('[SkyGen] post-placement repair unavailable: '+e)}
world.afterEvents.entityDie.subscribe(({deadEntity,damageSource})=>{
 try{
  const player=damageSource.damagingEntity?.typeId==='minecraft:player'?damageSource.damagingEntity:
   damageSource.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
  if(player?.typeId==='minecraft:player'&&deadEntity.matches({families:['monster']})){
   recordQuestActivity(player,'kills',deadEntity.typeId);
   const {x,z}=deadEntity.location;
   if(deadEntity.dimension.id==='minecraft:overworld'&&belongs(player,x,z))awardCollectionItem(player,'guardian',deadEntity.typeId);
  }
 }catch(e){console.warn('[SkyGen QUEST] combat: '+e)}
});
const normalXpGate=new Map(),normalXpWindow=new Map();
function processSkyGenBlockBreak(e){
 try{
  const p=e.player,loc=e.block.location;
  const publicGen=publicStarterAt(loc.x,loc.y,loc.z);
  if(publicGen&&p.dimension?.id==='minecraft:overworld'&&publicStarterEnabled()){
   const mined=e.brokenBlockPermutation?.type?.id||e.brokenBlockPermutation?.typeId||'';
   if(mined!==''&&mined!==publicGen.block)return;
   publicStarterDue.set(`${loc.x},${loc.y},${loc.z}`,system.currentTick+publicGeneratorDelay(publicGen));
   if(publicGeneratorLevel(publicGen.block)>=GENERATOR_MAX_LEVEL)system.runTimeout(()=>refillPublicInstant(publicGen),1);
   if(p.getGameMode()===GameMode.Creative)return;
   const d=profile(p);recordDaily(p,d,['blocks','public'],1,publicGen.block);d.xp+=1;
   const guideStage=mined===publicGen.block&&p.getGameMode()===GameMode.Survival
    ?markFirstGenerator(d,'mine',{block:mined}):undefined;
   rank(p,d);announceFirstGenerator(p,guideStage);return;
  }
  if(!belongs(p,loc.x,loc.z))return;
  const key=`${loc.x},${loc.y-1},${loc.z}`,g=generators.get(key);
  const type=e.brokenBlockPermutation?.type?.id||e.brokenBlockPermutation?.typeId||'';
  const validHarvest=!!g&&g.owner===p.id&&(loc.y===g.y+1)&&(type===(GEN_BY_NAME.get(g.type)?.block||g.block));
  if(validHarvest){
   const tick=system.currentTick;
   genEmptySeconds.set(key,tick);
   scheduleGeneratorRefill(key,tick+effectivePeriod(g));
   if(Number(g.level||1)>=GENERATOR_MAX_LEVEL)system.runTimeout(()=>refillPrivateInstant(key,g),1);
  }
  const generated=validHarvest&&generatorOutputReady.delete(key);
  if(p.getGameMode()===GameMode.Creative)return;
  const d=profile(p);
  const mature=['minecraft:wheat','minecraft:carrots','minecraft:potatoes','minecraft:beetroot'].includes(type)&&e.brokenBlockPermutation.getState('growth')===7;
  recordDaily(p,d,mature?['blocks','crops']:['blocks'],1,type);
  if(generated){
   const bonus=perkValue(d,'miningXp');d.xp+=Math.ceil(5*(100+bonus)/100);
   recordDaily(p,d,['harvests'],1,type);
   const lucky=perkValue(d,'luck');
   if(lucky>0&&Math.random()*100<lucky){
    const prize=new ItemStack(g.block,1);
    if(inventoryCapacity(p,prize)){try{inventory(p)?.addItem(prize);p.sendMessage('§aLucky Strikes! +1 bonus block.')}catch{}}
   }
  }else{
   const last=normalXpGate.get(p.id)??-99999;
   const window=normalXpWindow.get(p.id);
   const current=(!window||system.currentTick-window.start>=1200)?{start:system.currentTick,count:0}:window;
   if(system.currentTick-last>=5&&current.count<10){d.xp+=1;current.count++;normalXpGate.set(p.id,system.currentTick)}
   normalXpWindow.set(p.id,current);
  }
  let guideStage;
  if(validHarvest&&g.firstGeneratorToken&&p.getGameMode()===GameMode.Survival){
   try{
    const base=p.dimension.getBlock({x:g.x,y:g.y,z:g.z});
    if(isGeneratorBase(g,base))guideStage=recordFirstGeneratorPlacement(d,p,'harvest',g,key);
   }catch(err){console.warn('[SkyGen First Generator] Harvest check: '+err)}
  }
  rank(p,d);announceFirstGenerator(p,guideStage);
  if(generated){
   const collection=type==='minecraft:coal_ore'||type==='minecraft:obsidian'?'guardian':'merchant';
   awardCollectionItem(p,collection,type);
  }
  if(mature)awardCollectionItem(p,'feast',type);
 }catch(err){console.warn('[SkyGen XP] could not record block break: '+err)}
}
world.afterEvents.playerBreakBlock.subscribe(processSkyGenBlockBreak);
function refillPrivateInstant(key,record){
 try{
  if(generators.get(key)!==record||!generatorRegistryLoaded||Number(record.level||1)<GENERATOR_MAX_LEVEL)return;
  const dim=world.getDimension('overworld');
  const base=dim.getBlock({x:record.x,y:record.y,z:record.z});
  const output=dim.getBlock({x:record.x,y:record.y+1,z:record.z});
  if(!base||!output||!isGeneratorBase(record,base)||!output.isAir)return;
  const expected=GEN_BY_NAME.get(record.type)?.block||record.block;
  if(!expected)return;
  output.setType(expected);
  if(output.typeId!==expected)throw Error('Private instant refill verification failed');
  generatorOutputReady.add(key);
  clearGeneratorRefill(key);
 }catch(err){genError('Level 10 refill '+key+' '+err,key)}
}
function unscheduleGeneratorRefill(key){
 const tick=genDueByKey.get(key);
 if(tick===undefined)return;
 const bucket=genDueBuckets.get(tick);
 bucket.delete(key);
 if(!bucket.size)genDueBuckets.delete(tick);
 genDueByKey.delete(key);
}
function clearGeneratorRefill(key){
 genEmptySeconds.delete(key);
 unscheduleGeneratorRefill(key);
}
function scheduleGeneratorRefill(key,tick){
 if(genDueByKey.get(key)===tick)return;
 unscheduleGeneratorRefill(key);
 let bucket=genDueBuckets.get(tick);
 if(!bucket){bucket=new Set();genDueBuckets.set(tick,bucket)}
 bucket.add(key);genDueByKey.set(key,tick);
}
function checkGeneratorRefill(key,g,dim,tick,heartbeat){
 try{
  if(!g||!dim.isChunkLoaded(g))return clearGeneratorRefill(key);
  const base=dim.getBlock({x:g.x,y:g.y,z:g.z}),output=dim.getBlock({x:g.x,y:g.y+1,z:g.z});
  const expected=GEN_BY_NAME.get(g.type)?.block||g.block;
  if(!base||!output||!migrateGeneratorCore(g,base)||!expected||!output.isAir)return clearGeneratorRefill(key);
  const detected=genEmptySeconds.get(key)??tick;
  genEmptySeconds.set(key,detected);
  const due=detected+effectivePeriod(g,heartbeat);
  if(tick<due)return scheduleGeneratorRefill(key,due);
  output.setType(expected);
  generatorOutputReady.add(key);
  clearGeneratorRefill(key);
 }catch(error){genError(key+' '+error,key)}
}
function genWatchdog(){
 const tick=system.currentTick;
 genWatchdogRuns++;genLastTick=tick;
 try{
  if(!generators.size||!generatorRegistryLoaded)return;
  const dim=world.getDimension('overworld');
  const heartbeat={players:new Map(world.getAllPlayers().map(player=>[player.id,player])),speedBonuses:new Map()};
  const handled=new Set();
  // Keep part of the budget available for newly loaded and previously unobserved blocks.
  for(const [due,bucket] of genDueBuckets){
   if(due>tick)continue;
   for(const key of bucket){
    unscheduleGeneratorRefill(key);
    handled.add(key);
    checkGeneratorRefill(key,generators.get(key),dim,tick,heartbeat);
    if(handled.size>=50)break;
   }
   if(handled.size>=50)break;
  }
  const budget=Math.min(100-handled.size,generators.size);
  for(let i=0;i<budget;i++){
   let next=genCursor?.next();
   if(!next||next.done){
    genCursor=generators.entries();
    next=genCursor.next();
    if(next.done)break;
    }
   const [key,g]=next.value;
   if(!handled.has(key))checkGeneratorRefill(key,g,dim,tick,heartbeat);
  }
 }catch(err){genError('watchdog '+err)}
}

try{
 world.afterEvents.playerLeave?.subscribe(e=>{
  const id=e.playerId||e.player?.id;
  lastExplorationDistrict.delete(id);
  rewardNotices.interrupt(id);
  personalSpawnBuild.delete(id);forcefieldTickets.delete(id);forcefieldPrevious.delete(id);forcefieldNotices.delete(id);playerCommandLastTick.delete(id);rankNativeUnsupported.delete(id);loginPending.delete(id);lastSafeWriteTick.delete(id);returnCheckpointHold.delete(id);
  const t=pending.get(id);pending.delete(id);finishPendingTeleport(t);
  const s=spawnStages.get(id);s?.release?.();
  // Return staging cleans up during its next scheduled tick; never delete
  // another player's temporary ticking area on this leave event.
  for(const [plot,session] of plotBuilds){if(session.playerId===id){try{session.cancel?.()}catch(err){console.warn('[SkyGen] plot cleanup on leave '+err)}}}
  const trade=trades.get(id);if(trade)tradeClose(trade,'Trade cancelled: player disconnected.');
  normalXpGate.delete(id);normalXpWindow.delete(id);skillLastEffects.delete(id);skillActiveEffects.delete(id);for(const key of skillCooldowns.keys())if(key.startsWith(id+':'))skillCooldowns.delete(key);
 });
}catch(e){console.warn('[SkyGen] leave cleanup unavailable '+e)}
system.runInterval(()=>{
 for(const p of world.getAllPlayers())ensure(p);
},200);
system.runInterval(()=>{
 if(!publicStarterEnabled()){
  lastExplorationDistrict.clear();
  return;
 }
 for(const p of world.getAllPlayers()){
  try{updateExplorationQuest(p)}
  catch(e){if(system.currentTick%200<4)console.warn('[SkyGen QUEST] Exploration '+p.name+': '+e)}
 }
},4);
// Chat help uses the same pages as the Compass, with operator checks at the entry point.
function helpCommand(actor,message){
 const topic=String(message||'').trim().toLowerCase(),operator=isOperator(actor);
 const send=page=>{
  actor.sendMessage('§b§lSKYGEN HELP §r· '+page.title);
  for(const line of helpLines(page))actor.sendMessage('§7'+line);
 };
 const commandPages=HELP_TOPICS.find(section=>section.title==='Commands').pages;
 const operatorPages=HELP_TOPICS.find(section=>section.operator).pages;
 if(!topic||topic==='player'||topic==='all'){
  for(const page of commandPages)send(page);
  if(topic==='all'&&operator)for(const page of operatorPages)send(page);
  return;
 }
 if(topic==='admin'||topic==='security'){
  if(!operator)return actor.sendMessage('§cOperator permission required for this help page.');
  for(const page of operatorPages)send(page);
  return;
 }
 const page=HELP_TOPICS.filter(section=>!section.operator).flatMap(section=>section.pages).find(page=>page.id===topic);
 if(page){send(page);return;}
 actor.sendMessage('§eUnknown help topic: '+topic.slice(0,30));
 actor.sendMessage('§7Try /scriptevent skygen:help player for chat topics, or open Compass → Help & Commands.');
}
function adminCommand(actor,message){
 if(!isOperator(actor))return actor.sendMessage('§cOnly Realm operators may grant or revoke SkyGen admin access.');
 const match=/^\s*(grant|revoke)\s+(.+?)\s*$/i.exec(String(message||''));
 if(!match)return actor.sendMessage('§eUsage: /scriptevent skygen:admin grant PlayerName  OR  /scriptevent skygen:admin revoke PlayerName');
 const action=match[1].toLowerCase(),name=match[2];
 const matches=world.getAllPlayers().filter(p=>p.name.toLowerCase()===name.toLowerCase());
 if(matches.length!==1)return actor.sendMessage('§cPlayer must be online. Check the exact name: '+name);
 const target=matches[0];
 const grant=action==='grant';
 try{world.setDynamicProperty('sg_admin_'+target.id,grant)}catch(err){return actor.sendMessage('§cUnable to save admin permission: '+err)}
 adminAudit(actor,grant?'GRANT ADMIN':'REVOKE ADMIN',target,'via command');
 actor.sendMessage('§aSkyGen admin '+(grant?'granted to ':'revoked from ')+target.name+'.');
 target.sendMessage(grant?'§aYou now have SkyGen Admin access.':'§cYour SkyGen Admin access was revoked.');
 if(grant)system.runTimeout(()=>issueAdminAxe(target),30);
}

system.runTimeout(()=>bootFixedSpawn(),1);
console.warn('[SkyGen] v0.10.12 fresh-city security interlock + v0.10.9 menu continuity, v0.10.8 infinite plot passives and v0.10.7 spawn horn repair with v0.10.6 persistent safe rejoin and chunk staging; rank badges and v0.10.4 security audit hardening with operator spawn location, Xbox UI fit, 42 generators, food shop and boundary forcefields loaded');


// ---- SkyGen v0.10.26: safe personal HUD + Monkey's Floating Text ----
// The legacy Personal Sidebar RP previously replaced hud_title_text globally,
// making personal stats cover the screen and hijacking normal Purge Night titles.
// Personal stats use an [SGHUD] title-keyword bridge to the right-side JSON UI panel.
// Other titles and combat systems remain untouched.
function sidebarEnabled(p){
 try{return p.getDynamicProperty('sg_sidebar_enabled')!==false}catch{return true}
}
function sidebarMenu(p){
 form(p,'§bPERSONAL SIDEBAR',
  '§7Shows your personal SkyGen stats on the right side of the screen.\n§7Purge Night and teleport titles stay in the center.\n§7Current status: '+(sidebarEnabled(p)?'§aEnabled':'§cDisabled'),
  ['Enable Sidebar','Disable Sidebar','Back to Profile'],i=>{
   if(i===2)return skyMenuProfileCosmetics(p);
   try{
    p.setDynamicProperty('sg_sidebar_enabled',i===0);
    if(i===1)p.onScreenDisplay.setTitle('[SGHUD]',{fadeInDuration:0,stayDuration:5,fadeOutDuration:0,subtitle:''});
    p.sendMessage(i===0?'§aPersonal sidebar enabled.':'§ePersonal sidebar disabled.');
   }catch(err){p.sendMessage('§cSidebar setting failed: '+err)}
   menuAgain(p,()=>sidebarMenu(p));
  });
}
function giveFloatingTextTool(p){
 if(!isOperator(p))return p.sendMessage('§cOnly Realm operators can create or edit floating texts/leaderboards.');
 try{
  const inv=inventory(p);
  if(!inv)throw Error('Inventory unavailable');
  for(let i=0;i<inv.size;i++){
   if(inv.getItem(i)?.typeId==='monkey:textmenu'){
    p.sendMessage('§aYour Floating Text Menu is already in your inventory. Use the item to open it.');
    return;
   }
  }
  const item=new ItemStack('monkey:textmenu',1);
  const leftover=inv.addItem(item);
  if(leftover)return p.sendMessage('§cInventory full; free one slot and try again.');
  p.sendMessage('§aFloating Text Menu added. Use the book for text signs and floating scoreboards.');
 }catch(err){p.sendMessage('§cCould not deliver floating text tool: '+err)}
}
// The [SGHUD] title marker is saved by the right-side JSON UI property bag.
// Actionbar messages keep their vanilla position; ordinary title messages
// (Purge Night, teleport countdown) are not re-positioned by the sidebar.
export function readSidebarStats(p){return sidebarStats(profile(p));}
function updatePersonalSidebar(p){
  try{
   // Reuse one authoritative profile snapshot for numeric scores, text and
   // entitlement markers. The previous implementation parsed sg_profile twice
   // per player every HUD refresh. Do not cache this between refresh cycles:
   // credits, quest rewards, rank and badge equips must update immediately.
   const currentProfile=profile(p);
   const stats=sidebarStats(currentProfile);
   try{updateNumericScores(p,stats)}catch(err){console.warn('[SkyGen STATS] '+p.name+': '+err)}
   rememberLeaderboardPlayer(p,currentProfile);
   const busy=pending.has(p.id)||spawnStages.has(p.id)||remoteGames.occupied(p)||generatorRush.occupied(p)||system.currentTick<purgeAnnouncementUntil;
   let displaying=busy;
   try{displaying=rewardNotices.update(p,currentProfile,busy)}
   catch(error){console.warn('[SkyGen Rewards] Notice: '+error);}
   if(displaying||!sidebarEnabled(p))return;
   const text='[SGHUD]'+sidebarLines(stats,true).join('\n')+equippedBadgeMarkers(currentProfile)+hudProgressMarkers(currentProfile.rank,currentProfile.xpProgress);
   // [SGHUD] is consumed by the existing independent right-side RP panel.
   // Other game titles retain their normal on-screen placement.
   p.onScreenDisplay.setTitle(text,{fadeInDuration:0,stayDuration:10,fadeOutDuration:0,subtitle:''});
  }catch(err){console.warn('[SkyGen SIDEBAR] '+err)}
}
system.runInterval(()=>{
  try{for(const p of world.getAllPlayers())updatePersonalSidebar(p)}
  catch(err){console.warn('[SkyGen SIDEBAR] update failed: '+err)}
},40);
// ---- End extension ----
