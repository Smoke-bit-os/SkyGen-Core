export const OVERWORLD = 'minecraft:overworld';

const king = {
    id: 'koth', title: 'King of the Hill', short: 'KOTH',
    origin: { x: -23989, y: 120, z: -23989 }, min: -75, max: 74, bottom: -6,
    pads: [[0, -53], [0, 53], [45, 26], [-45, -26], [26, -45], [-26, 45],
        [45, -26], [-45, 26], [-26, -45], [26, 45]],
    station: { x: -8, y: 1, z: 71, block: 'minecraft:gold_block' },
};
const flag = {
    id: 'ctf', title: 'Capture the Flag', short: 'CTF',
    origin: { x: -32000, y: 120, z: -24000 }, min: 0, max: 149, bottom: -1,
    spawnRows: [58, 66, 74, 82, 90],
    sides: {
        red: { name: 'Red', color: '§c', x: 11, bay: [6, 16], pedestal: [26, 74], exit: 17 },
        blue: { name: 'Blue', color: '§9', x: 138, bay: [133, 143], pedestal: [123, 74], exit: 132 },
    },
    station: { x: -8, y: 1, z: 55, block: 'minecraft:noteblock' },
};
export const REMOTE_ARENAS = [king, flag];
export const ARENA_RETURN = { x: -3.5, y: 1.02, z: 58.5 };

export const ARENA_BOARDS = [
    { title: 'King of the Hill Wins', objective: 'sg_koth_wins', metric: 'kingWins', x: -0.5, y: 3.2, z: 64.5 },
    { title: 'Capture the Flag Wins', objective: 'sg_ctf_wins', metric: 'flagWins', x: -5.5, y: 3.2, z: 64.5 },
    { title: 'Capture the Flag Captures', objective: 'sg_ctf_caps', metric: 'flagCaptures', x: -10.5, y: 3.2, z: 64.5 },
];

export function offset(spec, x, y, z) {
    const { origin } = spec;
    return { x: origin.x + x, y: origin.y + y, z: origin.z + z };
}

export function standing(spec, x, y, z) {
    return offset(spec, x + .5, y + .02, z + .5);
}

export function arenaAt(x, z, margin = 0) {
    return REMOTE_ARENAS.find(({ origin, min, max }) =>
        x >= origin.x + min - margin && x < origin.x + max + 1 + margin &&
        z >= origin.z + min - margin && z < origin.z + max + 1 + margin);
}

export function teamBay(point) {
    const x = Math.floor(point.x - flag.origin.x);
    const z = Math.floor(point.z - flag.origin.z);
    if (z < 54 || z > 95) return undefined;
    return ['red', 'blue'].find(team => {
        const [min, max] = flag.sides[team].bay;
        return x >= min && x <= max;
    });
}

function kingBlocks(add) {
    const { min, max } = king;
    const floor = 'polished_deepslate';
    add(min, -6, min, max, -6, max, 'deepslate_bricks');
    add(min, -1, min, max, -1, -9, floor);
    add(min, -1, 9, max, -1, max, floor);
    add(min, -1, -8, -9, -1, 8, floor);
    add(9, -1, -8, max, -1, 8, floor);
    add(-3, -5, -3, 3, 4, 3, 'gold_block');
    add(-2, 4, -2, 2, 4, 2, 'yellow_concrete');
    const steps = ['smooth_stone', 'stone_bricks', 'polished_andesite', 'prismarine_bricks', 'smooth_sandstone'];
    for (let y = 0; y < steps.length; y++) {
        const d = 12 - 2 * y, block = steps[y];
        add(-2, -5, d, 2, y, d + 1, block);
        add(-2, -5, -d - 1, 2, y, -d, block);
        add(d, -5, -2, d + 1, y, 2, block);
        add(-d - 1, -5, -2, -d, y, 2, block);
    }
    for (const [x, z] of king.pads) {
        add(x - 1, -1, z - 1, x + 1, -1, z + 1, 'cyan_concrete');
        add(x, -1, z, x, -1, z, 'sea_lantern');
    }
    for (const x of [-28, 28]) for (const z of [-28, 28]) {
        add(x - 1, 0, z - 1, x + 1, 2, z + 1, 'polished_blackstone_bricks');
        add(x, 2, z, x, 2, z, 'sea_lantern');
    }
}

function flagBlocks(add) {
    add(0, -1, 0, 74, -1, 149, 'red_terracotta');
    add(75, -1, 0, 149, -1, 149, 'blue_terracotta');
    const crossings = [[23, 42], [65, 84], [107, 126]];
    for (const [z0, z1] of crossings) add(35, -1, z0, 114, -1, z1, 'smooth_stone');
    add(31, -1, 23, 41, -1, 126, 'smooth_stone');
    add(108, -1, 23, 118, -1, 126, 'smooth_stone');
    let end = 0;
    for (const [z0, z1] of crossings) {
        add(72, 0, end, 77, 3, z0 - 1, 'polished_blackstone_bricks');
        add(72, -1, z0, 77, -1, z1, 'polished_andesite');
        end = z1 + 1;
    }
    add(72, 0, end, 77, 3, 149, 'polished_blackstone_bricks');
    const colors = [
        [6, 37, flag.sides.red, 'red_concrete', 'red_wool', 'red_stained_glass'],
        [112, 143, flag.sides.blue, 'blue_concrete', 'blue_wool', 'blue_stained_glass'],
    ];
    for (const [start, stop, side, base, accent, glass] of colors) {
        add(start, -1, 54, stop, -1, 95, base);
        add(side.bay[0], -1, 54, side.bay[1], -1, 95, accent);
        for (const z of flag.spawnRows) {
            add(side.x - 1, -1, z - 1, side.x + 1, -1, z + 1, base);
            add(side.x, -1, z, side.x, -1, z, 'sea_lantern');
        }
        const [x, z] = side.pedestal;
        add(x - 2, -1, z - 2, x + 2, -1, z + 2, accent);
        add(x, -1, z, x, -1, z, 'sea_lantern');
        add(x, 0, z, x, 1, z, glass);
    }
    for (const [x, z] of [[46, 34], [56, 60], [56, 89], [46, 115]]) {
        for (const sideX of [x, 149 - x]) {
            add(sideX - 1, 0, z - 1, sideX + 1, 2, z + 1, 'polished_deepslate');
        }
    }
}

export function arenaBoxes(spec) {
    const parts = [];
    const add = (x0, y0, z0, x1, y1, z1, block) => parts.push({
        from: offset(spec, x0, y0, z0), to: offset(spec, x1, y1, z1), type: 'minecraft:' + block,
    });
    if (spec.id === king.id) kingBlocks(add);
    else flagBlocks(add);
    const { min, max } = spec;
    for (const edge of [min, max]) {
        add(min, 0, edge, max, 5, edge, 'polished_blackstone_bricks');
        add(edge, 0, min + 1, edge, 5, max - 1, 'polished_blackstone_bricks');
    }
    return parts;
}
