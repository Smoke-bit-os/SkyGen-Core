export const DISTRICT_ORDERS_READY_KEY = 'sg_phase4_district_orders_ready_v1';
export const DISTRICT_DISPLAY_TAG = 'sg_district_station_display';
export const DISTRICT_STATIONS = [
    { id: 'market', x: 8, y: 1, z: -54, block: 'minecraft:polished_blackstone_bricks' },
    { id: 'saplings', x: -55, y: 1, z: 60, block: 'minecraft:moss_block' },
    { id: 'trims', x: 62, y: 1, z: -48, block: 'minecraft:polished_blackstone_bricks' },
];
export const FOUNDRY_SMITHING_TABLE = [63, 1, -48, 'minecraft:smithing_table'];
export const DISTRICT_ORDER_BUILDS = DISTRICT_STATIONS.map(station => ({
    name: { market: 'Market District Orders', saplings: 'Garden Nursery', trims: 'Foundry Armor Trims' }[station.id],
    blocks: [[station.x, station.y, station.z, station.block],
        ...(station.id === 'trims' ? [FOUNDRY_SMITHING_TABLE] : [])],
}));

export function isNearDistrictStation(player, station) {
    if (player.dimension?.id !== 'minecraft:overworld') return false;
    const { x, y, z } = player.location;
    return Math.abs(y - station.y) <= 2 && Math.hypot(x - station.x - 0.5, z - station.z - 0.5) <= 5;
}
